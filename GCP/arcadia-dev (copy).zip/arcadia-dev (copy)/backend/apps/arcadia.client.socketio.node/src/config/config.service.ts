/* eslint-disable max-lines */
import { SecretManagerServiceClient } from '@google-cloud/secret-manager/build/src/v1';
import { DnsResolver, Environment, JoiExtended } from '@lib/common';
import { redisValidationSchema, rmqValidationSchema } from '@lib/config';
import { NpmLogLevel } from '@lib/logger';
import { config } from 'dotenv';
import { existsSync } from 'fs';
import {
  concatMap, firstValueFrom, from, toArray,
} from 'rxjs';

const populateEnvFromGCPSecretManager = async (envConfig, initialConfigs) => {
  const secretManagerServiceClient = new SecretManagerServiceClient();

  const envVarMapping = {
    SYSTEM_LOG_LEVEL: 'SYSTEM_LOG_LEVEL',
    REDIS_HOST: 'REDIS_HOST',
    REDIS_PORT: 'REDIS_PORT',
    RABBITMQ_HOST: 'RABBITMQ_HOST',
    RABBITMQ_USERNAME: 'RABBITMQ_USERNAME',
    RABBITMQ_PASSWORD: 'RABBITMQ_PASSWORD',
    RABBITMQ_PORT: 'RABBITMQ_PORT',
    LOGIN_WAIT_TIMEOUT: 'CSN_LOGIN_WAIT_TIMEOUT',
    MESSAGES_PER_SECOND_RATE: 'CSN_MESSAGES_PER_SECOND_RATE',
    SOCKET_PORT: 'CSN_SOCKET_PORT',
    GAME_CORE_API_HOST: 'GAME_CORE_API_HOST',
    GAME_CORE_API_PORT: 'GAME_CORE_API_PORT',
    CLIENT_FE_BASE_URL: 'CLIENT_FE_BASE_URL',
  };

  await firstValueFrom(from(Object.entries(envVarMapping))
    .pipe(
      concatMap(async ([key, secretName]) => {
        try {
          const [version] = await secretManagerServiceClient.accessSecretVersion({
            name: `${initialConfigs.GCP_PROJECT}/secrets/${secretName}/versions/latest`,
          });
          if (version?.payload?.data) {
            // eslint-disable-next-line no-param-reassign
            envConfig[key] = version.payload.data.toString();
          }
        } catch (err) {
          // eslint-disable-next-line no-console
          console.log(err.message);
        }
        return key;
      }),
      toArray(),
    ),
  );

  return envConfig;
};

const validateInitial = async envConfig => {
  const initialEnvVarsSchema = JoiExtended.object({
    SYSTEM_LOG_LEVEL: JoiExtended.valid(...Object.values(NpmLogLevel))
      .default(NpmLogLevel.DEBUG),
    NODE_ENV: JoiExtended.string()
      .valid(...Object.values(Environment))
      .required(),
    USE_GCP_SM: JoiExtended.boolean()
      .default(false),
    GCP_PROJECT: JoiExtended.string()
      .when('USE_GCP_SM', {
        is: true,
        then: JoiExtended.required(),
      }),
    GOOGLE_APPLICATION_CREDENTIALS: JoiExtended.string()
      .when('USE_GCP_SM', {
        is: true,
        then: JoiExtended.required(),
      }),
  });

  const {
    error,
    value: validatedEnvConfig,
  } = initialEnvVarsSchema.validate(envConfig, { stripUnknown: true });
  if (error) {
    throw new Error(`Initial validation error: ${error.message}`);
  }

  return validatedEnvConfig;
};

const loadAndValidateMain = async (envConfig, initialConfigs) => {
  const envVarsSchema = JoiExtended.object({
    ...rmqValidationSchema,
    ...redisValidationSchema,
    LOGIN_WAIT_TIMEOUT: JoiExtended.number()
      .default(30000),
    MESSAGES_PER_SECOND_RATE: JoiExtended.number()
      .required(),
    SOCKET_PORT: JoiExtended.number()
      .default(3001),
    GAME_CORE_API_HOST: JoiExtended.string()
      .required(),
    GAME_CORE_API_PORT: JoiExtended.number()
      .default(3000),
    CLIENT_FE_BASE_URL: JoiExtended.string()
      .required(),
  });

  if (initialConfigs.USE_GCP_SM) {
    // eslint-disable-next-line no-param-reassign
    envConfig = await populateEnvFromGCPSecretManager(envConfig, initialConfigs);
  }

  const {
    error,
    value: validatedEnvConfig,
  } = envVarsSchema.validate(envConfig, { stripUnknown: true });

  validatedEnvConfig.GAME_CORE_API_HOST = await new DnsResolver(validatedEnvConfig.GAME_CORE_API_HOST, initialConfigs.NODE_ENV).resolve();

  if (error) {
    throw new Error(`Config validation error: ${error.message}`);
  }

  return validatedEnvConfig;
};

const loadConfigAsync = async (filePath: string) => {
  let parseConf;

  if (existsSync(filePath)) {
    parseConf = config({ path: filePath });
    if (parseConf.error) {
      throw new Error(`Dotenv error: ${parseConf.error}`);
    }

    parseConf = parseConf.parsed;
  } else {
    parseConf = process.env;
  }

  const initialConfigs = await validateInitial(parseConf);
  return { ...initialConfigs, ...(await loadAndValidateMain(parseConf, initialConfigs)) };
};

export async function getConfigs(filePath: string): Promise<Record<string, any>> {
  const configs = await loadConfigAsync(filePath);
  const apiPrefix = '/api/v1';

  return {
    gameCore: {
      apiUrl: (configs.GAME_CORE_API_HOST && configs.GAME_CORE_API_PORT)
        ? `http://${configs.GAME_CORE_API_HOST}:${configs.GAME_CORE_API_PORT}${apiPrefix}`
        : `http://localhost:3000${apiPrefix}`,
    },
    redis: {
      host: configs.REDIS_HOST,
      port: configs.REDIS_PORT,
    },
    rabbitMQ: {
      amqpUrl: [`amqp://${configs.RABBITMQ_USERNAME}:${configs.RABBITMQ_PASSWORD}@${configs.RABBITMQ_HOST}:${configs.RABBITMQ_PORT}`],
    },
    loginWaitTimeout: parseInt(configs.LOGIN_WAIT_TIMEOUT || '30000', 10),
    messagesRate: parseInt(configs.MESSAGES_PER_SECOND_RATE, 10),
    server: {
      port: parseInt(configs.SOCKET_PORT, 10) || 3001,
    },
    corsOrigin: configs.CLIENT_FE_BASE_URL,
    isCloud: configs.USE_GCP_SM,
    env: configs.NODE_ENV,
    logLevel: configs.SYSTEM_LOG_LEVEL,
  };
}
