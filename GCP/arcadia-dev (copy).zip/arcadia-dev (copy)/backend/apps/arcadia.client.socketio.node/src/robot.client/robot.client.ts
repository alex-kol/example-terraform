import { Server } from 'socket.io';

export class RobotClient {
  private directRoomId: string;

  constructor(
    private readonly socketServer: Server,
    private readonly clientId: string,
  ) {
  }

  public sendToRobot({
    action,
    data,
    userId,
    isVolatile = false,
  }: Record<string, any>): void {
    if (!this.directRoomId) {
      return;
    }

    const targetedRoom = this.socketServer.to(this.directRoomId);
    const channel = !isVolatile ? targetedRoom : targetedRoom.volatile;

    channel.emit('player2robot', {
      action,
      ...data,
      user: {
        id: userId,
        socketId: this.clientId,
      },
    });
  }

  public setRoomIds(directRoomId: string): void {
    this.directRoomId = directRoomId;
  }
}
