export class DisconnectTimer {
  private readonly timeoutMs: number;
  private readonly handler: () => any;
  private timer: NodeJS.Timeout;

  constructor(timeoutMs: number, handler: () => any) {
    this.timeoutMs = timeoutMs;
    this.timer = null;
    this.handler = handler;
  }

  public startTimer(): void {
    this.timer = setTimeout(() => {
      this.handler();
      this.timer = null;
    }, this.timeoutMs);
  }

  public restartTimer(): void {
    this.timer && clearTimeout(this.timer);
    this.startTimer();
  }

  public stopTimer(): void {
    this.timer && clearTimeout(this.timer);
    this.timer = null;
  }
}