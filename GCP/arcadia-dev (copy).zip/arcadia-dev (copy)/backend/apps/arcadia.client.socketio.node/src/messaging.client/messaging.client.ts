import { keepAliveAgents, RmqQueueName } from '@lib/common';
import { defaultRmqOptions } from '@lib/rmq.server/config';
import { ServerAsyncRMQ } from '@lib/rmq.server/service.factory';
import axios, { AxiosInstance } from 'axios';
import { Logger } from 'winston';

export class MessagingClient {
  private readonly amqpUrl: string[];
  private readonly coreApiClient: AxiosInstance;
  private rmqClient: ServerAsyncRMQ;

  constructor(
    config: Record<string, any>,
    private logger: Logger,
  ) {
    this.coreApiClient = axios.create({
      baseURL: config.gameCore.apiUrl,
      timeout: 46000, // Video service delay
      httpAgent: keepAliveAgents.httpAgent,
      httpsAgent: keepAliveAgents.httpsAgent,
    });
    this.amqpUrl = config.rabbitMQ.amqpUrl;
  }

  public async startRmq(): Promise<boolean> {
    const rmqServer = new ServerAsyncRMQ(
      defaultRmqOptions,
      [],
      this.amqpUrl,
      this.logger,
    );
    return new Promise(res => {
      rmqServer.listen(() => {
        this.rmqClient = rmqServer;
        res(true);
      });
    });
  }

  public sendCoreMessage(type, gameId, data) {
    try {
      this.rmqClient.sendMessage({
        type,
        gameId,
        ...data,
      }, RmqQueueName.PLAYER_TO_CORE_QUEUE);
    } catch (err) {
      this.logger.error('Send core message', {
        stack: err.stack,
        errorMessage: err.message,
      });
    }
  }

  public sendMonitoringMessage(data) {
    try {
      this.rmqClient.sendMessage({
        type: 'eventlog',
        ...data,
      }, RmqQueueName.CORE_TO_MONITORING_WORKER_QUEUE);
    } catch (err) {
      this.logger.error('Send monitoring message', {
        stack: err.stack,
        errorMessage: err.message,
      });
    }
  }

  public clientLogin(correlationId, token, groupId, footprint, gameId) {
    return this.coreApiClient.post('/auth/verify', {
      token,
      groupId,
      footprint,
      gameId,
    }, { headers: { correlation: correlationId } },
    )
      .then(value => value.data);
  }

  public clientReconnect(correlationId, sessionId, footprint, gameId) {
    return this.coreApiClient.post('/auth/reconnect', {
      sessionId: Number(sessionId),
      footprint,
      gameId,
    }, { headers: { correlation: correlationId } },
    )
      .then(value => value.data);
  }
}
