const amqp = require('amqp-connection-manager');
const axios = require('axios');
const { MessagingClient } = require('./messaging-client');

jest.mock('axios');
jest.mock('amqp-connection-manager');

const amqpWrapperMock = {
  sendToQueue: (queue, options) => Promise.resolve(),
};

const amqpConnectionMock = {
  createChannel: () => amqpWrapperMock,
};

describe('Core Client (Unit)', () => {
  let messagingClient;

  beforeAll(() => {
    jest.spyOn(amqp, 'connect').mockReturnValue(amqpConnectionMock);
    messagingClient = new MessagingClient({
      gameCore: {
        apiUrl: '<url>',
      },
      rabbitMQ: {
        coreQueue: '<queue>',
      },
    }, {});
  });

  describe('sendMessage', () => {
    it('should send message using rabbitMQ', async () => {
      const sendToQueueSpy = jest.spyOn(amqpWrapperMock, 'sendToQueue');
      await messagingClient.sendMessage('<type>', '<data>');
      expect(sendToQueueSpy).toBeCalledWith('<queue>', { type: '<type>', data: '<data>' });
    });
  });

  describe('verifyToken', () => {
    it('should send verify token request to api', async () => {
      const dataMock = { test: 'test' };
      const postSpy = jest.spyOn(axios, 'post').mockResolvedValueOnce({ data: dataMock });
      const result = await messagingClient.verifyToken('<corr>', '<token>', '<foot>');
      expect(result).toMatchObject(dataMock);
      expect(postSpy).toBeCalledWith('<url>/auth/verify', { token: '<token>', footprint: '<foot>' }, { headers: { correlation: '<corr>' } });
    });
  });

  describe('verifyReconnect', () => {
    it('should send verify reconnect request to api', async () => {
      const dataMock = { test: 'test' };
      const postSpy = jest.spyOn(axios, 'post').mockResolvedValueOnce({ data: dataMock });
      const result = await messagingClient.verifyReconnect('<corr>', 5, '<foot>');
      expect(result).toMatchObject(dataMock);
      expect(postSpy).toBeCalledWith('<url>/auth/reconnect', { sessionId: 5, footprint: '<foot>' }, { headers: { correlation: '<corr>' } });
    });
  });
});
