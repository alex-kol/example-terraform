/* eslint-disable max-lines */
import { LoggingWinston } from '@google-cloud/logging-winston';
import { EventSource, PlayerMessageType } from '@lib/common';
import { NewrelicGroupName } from '@lib/common/newrelic/enum/group.name';
import { newrelicFunctionWrapper } from '@lib/common/newrelic/newrelic.function.wrapper';
import { newrelicStart } from '@lib/common/newrelic/newrelic.instance';
import { EventType, GameId } from '@lib/dal';
import { defaultMetaFactory, GLOBAL_LOGGER_CONTEXT } from '@lib/logger';
import { DEFAULT_OPTIONS } from '@lib/logger/default.options';
import { createAdapter } from '@socket.io/redis-adapter';
import express from 'express';
import helmet from 'helmet';
import http from 'http';
import Redis from 'ioredis';
import { Server, Socket } from 'socket.io';
import { v4 as uuidv4 } from 'uuid';
import { createLogger, transports } from 'winston';
import { getConfigs } from './config/config.service';
import { CONNECTION, DISCONNECT } from './constants/connection.constants';
import { SERVICE_NAME } from './constants/service';
import { MessagingClient } from './messaging.client/messaging.client';
import { RobotClient } from './robot.client/robot.client';
import { DisconnectTimer } from './utils/disconnect.timer';

const clientDataExtractor = data => {
  // eslint-disable-next-line no-param-reassign
  delete data.playerDirectRoomId;
  // eslint-disable-next-line no-param-reassign
  delete data.robotDirectRoomId;
  // eslint-disable-next-line no-param-reassign
  delete data.robotQueueRoomId;
  // eslint-disable-next-line no-param-reassign
  delete data.joinRobotDirectRoom;
  return data;
};

const sessionToSocketMap = {};
const forcedResolveMap = {};

const killStaleSocket = async (socket: Socket) => {
  const promise = new Promise<void>(resolve => {
    forcedResolveMap[socket.id] = resolve;
    setTimeout(() => {
      resolve();
      delete forcedResolveMap[socket.id];
    }, 2000);
  });
  socket.disconnect(true);
  await promise;
};

async function bootstrap() {
  await newrelicStart();
  const config = await getConfigs('./.env');

  const logger = createLogger({
    ...DEFAULT_OPTIONS,
    level: config.logLevel,
    transports: config.isCloud ? new LoggingWinston({ logName: SERVICE_NAME }) : new transports.Console(),
    defaultMeta: defaultMetaFactory({
      label: SERVICE_NAME,
      context: GLOBAL_LOGGER_CONTEXT,
    }),
  });

  const app = express();
  app.use(helmet({
    crossOriginEmbedderPolicy: true,
    crossOriginOpenerPolicy: true,
    crossOriginResourcePolicy: true,
  }));
  const server = http.createServer(app);
  const socketIo = new Server(server, {
    pingInterval: 5000,
    cors: {
      origin: config.corsOrigin,
      methods: ['GET', 'POST'],
      credentials: true,
    },
  });

  const pubClient = new Redis(config.redis);
  const subClient = pubClient.duplicate();
  const proxyHandler = {
    get(target, propKey) {
      if (!~['on'].indexOf(propKey)) {
        return Reflect.get(target, propKey);
      }
      const origMethod = target[propKey];
      return function catchUnhandledError(eventName: string | symbol, listener: (...args: any[]) => void) {
        if (eventName !== 'pmessageBuffer') {
          return origMethod.call(target, eventName, listener);
        }

        const tryCatchListener = (...args: any[]) => {
          try {
            listener(...args);
          } catch (error) {
            logger.error(error.message, error.stack);
          }
        };

        return origMethod.call(target, eventName, tryCatchListener);
      };
    },
  };

  const subClientProxy: Redis.Redis = new Proxy<Redis.Redis>(subClient, proxyHandler);

  socketIo.adapter(createAdapter(pubClient, subClientProxy));
  socketIo.of('/')
    .adapter
    .on('error', error => {
      logger.error(error.message, error.stack);
    });

  const messagingClient = new MessagingClient(config, logger);
  await messagingClient.startRmq();

  // Health check
  app.get('/health', (req, res) => {
    res.sendStatus(200);
  });

  socketIo.on(CONNECTION, client => {
    const onEvent = (
      event: PlayerMessageType | 'disconnect',
      cb: (data?: any) => any,
    ) => {
      const newCb = newrelicFunctionWrapper(event, cb, NewrelicGroupName.WEBSOCKET);
      client.on(event, newCb);
    };

    let sessionFootprint: string = null;
    let userId: string = null;
    let sessionId: number = null;
    let playerDirectRoomId: string = null;
    let robotQueueRoomId: string = null;
    let robotDirectRoomId: string = null;
    let machineId: number = null;
    let machineSerial: string = null;
    let operatorId: number = null;
    let groupId: number = null;
    let gameId: GameId = null;

    logger.info('Socket connect', {
      event: CONNECTION,
      socketId: client.id,
    });

    const robotClient = new RobotClient(socketIo, client.id);
    const disconnectTimer = new DisconnectTimer(config.loginWaitTimeout, () => client.disconnect(true));

    onEvent(DISCONNECT, () => {
      const correlationId = uuidv4();
      logger.info('Socket disconnect', {
        event: DISCONNECT,
        sessionId: sessionId || 'none',
        socketId: client.id,
        correlationId,
      });

      if (robotDirectRoomId) {
        client.leave(robotDirectRoomId);
      }
      if (robotQueueRoomId) {
        client.leave(robotQueueRoomId);
      }
      if (playerDirectRoomId) {
        client.leave(playerDirectRoomId);
      }

      robotClient.sendToRobot({
        action: PlayerMessageType.PLAYER_LEFT,
        data: { correlationId },
        isVolatile: true,
        userId,
      });

      if (sessionId) {
        messagingClient.sendCoreMessage(PlayerMessageType.PLAYER_LEFT, gameId, {
          sessionId,
          correlationId,
        });
      }

      sessionFootprint && delete sessionToSocketMap[sessionFootprint];

      const pendingResolve = forcedResolveMap[client.id];
      if (pendingResolve) {
        pendingResolve();
        delete forcedResolveMap[client.id];
      }
    });

    onEvent(PlayerMessageType.LOGIN, async data => {
      if (!data) {
        logger.error('login: incoming data are undefined');
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.LOGIN, { correlationId, ...data });
      const {
        token,
        groupId: groupIdParam,
        footprint,
        gameId: gameIdParam,
      } = data;

      sessionFootprint = footprint;
      const existingSocket = sessionToSocketMap[sessionFootprint];
      if (existingSocket) {
        await killStaleSocket(existingSocket);
      }
      sessionToSocketMap[sessionFootprint] = client;

      disconnectTimer.restartTimer();

      try {
        const coreResp = await messagingClient.clientLogin(
          correlationId, token, groupIdParam, footprint, gameIdParam,
        );
        userId = coreResp.playerId;
        sessionId = Number(coreResp.sessionId);
        machineId = coreResp.machineId;
        machineSerial = coreResp.machineSerial;
        operatorId = coreResp.operatorId;
        groupId = coreResp.groupId;
        playerDirectRoomId = coreResp.playerDirectRoomId;
        robotDirectRoomId = coreResp.robotDirectRoomId;
        robotQueueRoomId = coreResp.robotQueueRoomId;
        gameId = coreResp.gameId;
        robotClient.setRoomIds(robotDirectRoomId);

        client.join(robotQueueRoomId);
        client.join(playerDirectRoomId);

        messagingClient.sendCoreMessage(PlayerMessageType.PLAYER_JOINED, gameId, {
          sessionId,
          correlationId,
        });

        disconnectTimer.stopTimer();

        logger.info('User connected', {
          event: PlayerMessageType.LOGIN,
          userId,
          sessionId,
          correlationId,
        });

        socketIo.to(client.id)
          .emit('login', clientDataExtractor(coreResp));
      } catch (error) {
        logger.info('Failed to login', {
          event: PlayerMessageType.LOGIN,
          data: error.response?.data || {},
          message: error.message,
        });
        const notification = error.response?.data?.data?.notificationId
          ? error.response.data.data
          : {
            notificationId: 'loginFailed',
            title: 'Error',
            message: error.response?.data?.data?.message || error.message,
            command: 'goToLobby',
          };
        socketIo.to(client.id)
          .emit(PlayerMessageType.NOTIFICATION, notification);
        client.disconnect(true);
      }
    });

    onEvent(PlayerMessageType.RESTORE_CONNECTION, async params => {
      if (!params) {
        logger.error('restoreConnection: incoming data are undefined');
        return;
      }
      const {
        sessionId: sid,
        footprint,
        gameId: gameIdParam,
      } = params;

      sessionFootprint = footprint;
      const existingSocket = sessionToSocketMap[sessionFootprint];
      if (existingSocket) {
        await killStaleSocket(existingSocket);
      }
      sessionToSocketMap[sessionFootprint] = client;

      const correlationId = uuidv4();
      logger.info(PlayerMessageType.RESTORE_CONNECTION, {
        sessionId: sid,
        footprint,
        correlationId,
      });
      disconnectTimer.restartTimer();

      const coreResp = await messagingClient.clientReconnect(correlationId, sid, footprint, gameIdParam)
        .catch(error => {
          logger.info('Failed to verify reconnect', {
            event: PlayerMessageType.RESTORE_CONNECTION,
            data: error.response?.data || {},
            message: error.message,
          });
          const notification = error.response?.data?.data?.notificationId
            ? error.response.data.data
            : {
              notificationId: 'restoreConnectionFailed',
              title: 'Error',
              message: error.response?.data?.data?.message || error.message,
              command: 'goToLobby',
            };
          socketIo.to(client.id)
            .emit(PlayerMessageType.NOTIFICATION, notification);
        });
      if (!coreResp) {
        return;
      }

      userId = coreResp.playerId;
      sessionId = Number(coreResp.sessionId);
      gameId = coreResp.gameId;
      machineId = coreResp.machineId;
      playerDirectRoomId = coreResp.playerDirectRoomId;
      robotDirectRoomId = coreResp.robotDirectRoomId;
      robotQueueRoomId = coreResp.robotQueueRoomId;
      robotClient.setRoomIds(robotDirectRoomId);
      machineSerial = coreResp.machineSerial;
      operatorId = coreResp.operatorId;
      groupId = coreResp.groupId;

      client.join(robotQueueRoomId);
      client.join(playerDirectRoomId);
      const { joinRobotDirectRoom } = coreResp;
      if (joinRobotDirectRoom) {
        client.join(robotDirectRoomId);
      }

      disconnectTimer.stopTimer();
      logger.info('User reconnected', {
        event: PlayerMessageType.RESTORE_CONNECTION,
        userId,
        sessionId,
        footprint,
        correlationId,
      });
      socketIo.to(client.id)
        .emit('restoreConnection', clientDataExtractor(coreResp));

      messagingClient.sendCoreMessage(PlayerMessageType.PLAYER_JOINED, gameId, {
        sessionId,
        reconnect: true,
        correlationId,
      });
    });

    onEvent(PlayerMessageType.BUY_STACKS, params => {
      if (!params) {
        logger.error(`${PlayerMessageType.BUY_STACKS}: incoming data are undefined`);
        return;
      }

      const {
        stacks,
        voucherId,
      } = params;

      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.BUY_STACKS, {
        event: PlayerMessageType.BUY_STACKS,
        sessionId,
        stacks,
        correlationId,
      });

      client.join(robotDirectRoomId);

      messagingClient.sendCoreMessage(PlayerMessageType.BUY_STACKS, gameId, {
        sessionId,
        stacks,
        voucherId,
        correlationId,
      });
    });

    onEvent(PlayerMessageType.PLACE_BET, data => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.PLACE_BET, {
        ...data,
        sessionId,
        correlationId,
      });

      messagingClient.sendCoreMessage(PlayerMessageType.PLACE_BET, gameId, {
        ...data,
        sessionId,
        correlationId,
      });
    });

    onEvent(PlayerMessageType.REMOVE_BET, () => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.REMOVE_BET, {
        sessionId,
        correlationId,
      });

      messagingClient.sendCoreMessage(PlayerMessageType.REMOVE_BET, gameId, {
        sessionId,
        correlationId,
      });
    });

    onEvent(PlayerMessageType.CANCEL_BET, () => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.CANCEL_BET, {
        sessionId,
        correlationId,
      });

      messagingClient.sendCoreMessage(PlayerMessageType.CANCEL_BET, gameId, {
        sessionId,
        correlationId,
      });
    });

    onEvent(PlayerMessageType.DOUBLE_BET, () => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.DOUBLE_BET, {
        sessionId,
        correlationId,
      });

      messagingClient.sendCoreMessage(PlayerMessageType.DOUBLE_BET, gameId, {
        sessionId,
        correlationId,
      });
    });

    onEvent(PlayerMessageType.ENABLE_AUTOPLAY, data => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.ENABLE_AUTOPLAY, {
        event: PlayerMessageType.ENABLE_AUTOPLAY,
        sessionId,
        config: data,
        correlationId,
      });

      messagingClient.sendCoreMessage(PlayerMessageType.ENABLE_AUTOPLAY, gameId, {
        sessionId,
        autoplay: data,
        correlationId,
      });
    });

    onEvent(PlayerMessageType.DISABLE_AUTOPLAY, () => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.DISABLE_AUTOPLAY, {
        event: PlayerMessageType.DISABLE_AUTOPLAY,
        sessionId,
        correlationId,
      });

      messagingClient.sendCoreMessage(PlayerMessageType.DISABLE_AUTOPLAY, gameId, {
        sessionId,
        correlationId,
      });
    });

    onEvent(PlayerMessageType.BALANCE, () => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.BALANCE, {
        event: PlayerMessageType.BALANCE,
        sessionId,
        correlationId,
      });
      messagingClient.sendCoreMessage(PlayerMessageType.BALANCE, gameId, {
        sessionId,
        correlationId,
      });
    });

    onEvent(PlayerMessageType.ENABLE_BET_BEHIND, data => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.ENABLE_BET_BEHIND, {
        event: PlayerMessageType.ENABLE_BET_BEHIND,
        sessionId,
        config: data,
        correlationId,
      });
      messagingClient.sendCoreMessage(PlayerMessageType.ENABLE_BET_BEHIND, gameId, {
        sessionId,
        betBehind: data,
        correlationId,
      });
    });

    onEvent(PlayerMessageType.DISABLE_BET_BEHIND, () => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.DISABLE_BET_BEHIND, {
        event: PlayerMessageType.DISABLE_BET_BEHIND,
        sessionId,
        correlationId,
      });
      messagingClient.sendCoreMessage(PlayerMessageType.DISABLE_BET_BEHIND, gameId, {
        sessionId,
        correlationId,
      });
    });

    onEvent(PlayerMessageType.SET_SWING_MODE, params => { // mode: 'auto' | 'manual'
      if (!params) {
        logger.error(`${PlayerMessageType.SET_SWING_MODE}: incoming data are undefined`);
        return;
      }

      const { mode } = params;

      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.SET_SWING_MODE, {
        event: PlayerMessageType.SET_SWING_MODE,
        sessionId,
        mode,
        correlationId,
      });
      robotClient.sendToRobot({
        action: PlayerMessageType.SET_SWING_MODE,
        data: {
          mode,
          correlationId,
        },
        isVolatile: true,
        userId,
      });
      messagingClient.sendMonitoringMessage({
        source: EventSource.PLAYER,
        eventType: EventType.SET_SWING_MODE,
        params: {
          sessionId,
          playerCid: userId,
          machineId,
          mode,
        },
      });
    });

    onEvent(PlayerMessageType.READY_FOR_NEXT_ROUND, () => {
      if (!sessionId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.READY_FOR_NEXT_ROUND, {
        event: PlayerMessageType.READY_FOR_NEXT_ROUND,
        sessionId,
        correlationId,
      });
      messagingClient.sendCoreMessage(PlayerMessageType.READY_FOR_NEXT_ROUND, gameId, {
        sessionId,
        correlationId,
      });
    });

    onEvent(PlayerMessageType.MOVE_RAIL, params => {
      if (!params) {
        logger.error(`${PlayerMessageType.MOVE_RAIL}: incoming data are undefined`);
        return;
      }

      const { direction } = params;

      if (!userId) {
        return;
      }
      const correlationId = uuidv4();

      logger.info(PlayerMessageType.MOVE_RAIL, {
        event: PlayerMessageType.MOVE_RAIL,
        sessionId,
        direction,
        correlationId,
      });
      robotClient.sendToRobot({
        action: PlayerMessageType.MOVE_RAIL,
        data: {
          direction,
          correlationId,
        },
        isVolatile: true,
        userId,
      });
      messagingClient.sendCoreMessage(PlayerMessageType.MOVE_RAIL, gameId, {
        sessionId,
        direction,
        correlationId,
      });
    });

    onEvent(PlayerMessageType.SET_ANGLE, params => {
      if (!params) {
        logger.error(`${PlayerMessageType.SET_ANGLE}: incoming data are undefined`);
        return;
      }

      const { angle } = params;

      if (!userId) {
        return;
      }
      const correlationId = uuidv4();

      logger.info(PlayerMessageType.SET_ANGLE, {
        event: PlayerMessageType.SET_ANGLE,
        sessionId,
        angle,
        correlationId,
      });
      robotClient.sendToRobot({
        action: PlayerMessageType.SET_ANGLE,
        data: {
          angle,
          correlationId,
        },
        isVolatile: true,
        userId,
      });
      messagingClient.sendMonitoringMessage({
        source: EventSource.PLAYER,
        eventType: EventType.SET_ANGLE,
        params: {
          gameId,
          sessionId,
          playerCid: userId,
          machineId,
          angle,
          machineSerial,
          groupId,
          operatorId,
        },
      });
    });

    onEvent(PlayerMessageType.FIRE_COIN, () => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();

      logger.info(PlayerMessageType.FIRE_COIN, {
        event: PlayerMessageType.FIRE_COIN,
        sessionId,
        correlationId,
      });
      robotClient.sendToRobot({
        action: PlayerMessageType.FIRE_COIN,
        data: { correlationId },
        isVolatile: true,
        userId,
      });
    });

    onEvent(PlayerMessageType.INIT, () => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();

      logger.info(PlayerMessageType.INIT, {
        event: PlayerMessageType.INIT,
        sessionId,
        correlationId,
      });
      robotClient.sendToRobot({
        action: PlayerMessageType.INIT,
        data: { correlationId },
        isVolatile: true,
        userId,
      });
      messagingClient.sendMonitoringMessage({
        source: EventSource.PLAYER,
        eventType: EventType.ENGAGED,
        params: {
          sessionId,
          playerCid: userId,
          machineId,
        },
      });
    });

    onEvent(PlayerMessageType.VOUCHER, () => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.VOUCHER, {
        event: PlayerMessageType.VOUCHER,
        sessionId,
        correlationId,
      });
      messagingClient.sendCoreMessage(PlayerMessageType.VOUCHER, gameId, {
        sessionId,
        correlationId,
      });
    });

    onEvent(PlayerMessageType.LIST_BETS, () => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.LIST_BETS, {
        event: PlayerMessageType.LIST_BETS,
        sessionId,
        correlationId,
      });
      messagingClient.sendCoreMessage(PlayerMessageType.LIST_BETS, gameId, {
        sessionId,
        correlationId,
      });
    });

    onEvent(PlayerMessageType.LEAVE_QUEUE, () => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.LEAVE_QUEUE, {
        event: PlayerMessageType.LEAVE_QUEUE,
        sessionId,
        correlationId,
      });
      messagingClient.sendCoreMessage(PlayerMessageType.LEAVE_QUEUE, gameId, {
        sessionId,
        correlationId,
      });
    });

    onEvent(PlayerMessageType.QUEUE_BALANCE, data => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      const decision = data?.decision || 'reject';
      logger.info(PlayerMessageType.QUEUE_BALANCE, {
        event: PlayerMessageType.QUEUE_BALANCE,
        sessionId,
        decision,
        correlationId,
      });
      messagingClient.sendCoreMessage(PlayerMessageType.QUEUE_BALANCE, gameId, {
        sessionId,
        decision,
        correlationId,
      });
    });

    onEvent(PlayerMessageType.CANCEL_STACKS, () => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.CANCEL_STACKS, {
        event: PlayerMessageType.CANCEL_STACKS,
        sessionId,
        correlationId,
      });
      messagingClient.sendCoreMessage(PlayerMessageType.CANCEL_STACKS, gameId, {
        sessionId,
        correlationId,
      });
    });

    onEvent(PlayerMessageType.ARM_SWING, () => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.ARM_SWING, {
        event: PlayerMessageType.ARM_SWING,
        sessionId,
        correlationId,
      });
      messagingClient.sendMonitoringMessage({
        source: EventSource.PLAYER,
        eventType: EventType.ARM_SWING,
        params: {
          sessionId,
          playerCid: userId,
          machineId,
        },
      });
    });

    onEvent(PlayerMessageType.ORIENTATION_CHANGED, params => {
      if (!params) {
        logger.error(`${PlayerMessageType.ORIENTATION_CHANGED}: incoming data are undefined`);
        return;
      }

      const { orientation } = params;

      if (!userId) {
        return;
      }
      const correlationId = uuidv4();

      logger.info(PlayerMessageType.ORIENTATION_CHANGED, {
        event: PlayerMessageType.ORIENTATION_CHANGED,
        sessionId,
        orientation,
        correlationId,
      });
      messagingClient.sendMonitoringMessage({
        source: EventSource.PLAYER,
        eventType: EventType.ORIENTATION_CHANGED,
        params: {
          sessionId,
          playerCid: userId,
          machineId,
          orientation,
        },
      });
    });

    onEvent(PlayerMessageType.VIDEO, params => {
      if (!params) {
        logger.error(`${PlayerMessageType.VIDEO}: incoming data are undefined, gameId: ${gameId}`);
        return;
      }

      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.VIDEO,
        {
          event: PlayerMessageType.VIDEO,
          sessionId,
          correlationId,
          gameId,
          ...params,
        });
      messagingClient.sendMonitoringMessage({
        source: EventSource.PLAYER,
        eventType: EventType.VIDEO,
        params: {
          sessionId,
          playerCid: userId,
          machineId,
          gameId,
          ...params,
        },
      });
    });

    onEvent(PlayerMessageType.VIDEO_FAILED, data => {
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.VIDEO_FAILED, {
        event: PlayerMessageType.VIDEO_FAILED,
        sessionId,
        correlationId,
        ...data,
      });
      messagingClient.sendCoreMessage(PlayerMessageType.VIDEO_FAILED, gameId, {
        sessionId,
        machineId,
        ...data,
      });
    });

    onEvent(PlayerMessageType.SETTINGS_UPDATE, settings => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.SETTINGS_UPDATE, {
        event: PlayerMessageType.SETTINGS_UPDATE,
        sessionId,
        correlationId,
        settings,
      });
      messagingClient.sendCoreMessage(PlayerMessageType.SETTINGS_UPDATE, gameId, {
        sessionId,
        settings,
      });
      messagingClient.sendMonitoringMessage({
        source: EventSource.PLAYER,
        eventType: EventType.SETTINGS_UPDATE,
        params: {
          sessionId,
          playerCid: userId,
          machineId,
          settings,
        },
      });
    });

    onEvent(PlayerMessageType.MENU_CLICKED, () => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.MENU_CLICKED, {
        event: PlayerMessageType.MENU_CLICKED,
        sessionId,
        correlationId,
      });
      messagingClient.sendMonitoringMessage({
        source: EventSource.PLAYER,
        eventType: EventType.MENU_CLICKED,
        params: {
          sessionId,
          playerCid: userId,
          machineId,
        },
      });
    });

    onEvent(PlayerMessageType.MENU_CLOSED, () => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.MENU_CLOSED, {
        event: PlayerMessageType.MENU_CLOSED,
        sessionId,
        correlationId,
      });
      messagingClient.sendMonitoringMessage({
        source: EventSource.PLAYER,
        eventType: EventType.MENU_CLOSED,
        params: {
          sessionId,
          playerCid: userId,
          machineId,
        },
      });
    });

    onEvent(PlayerMessageType.LOST_FOCUS, () => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.LOST_FOCUS, {
        event: PlayerMessageType.LOST_FOCUS,
        sessionId,
        correlationId,
      });
      messagingClient.sendMonitoringMessage({
        source: EventSource.PLAYER,
        eventType: EventType.LOST_FOCUS,
        params: {
          sessionId,
          playerCid: userId,
          machineId,
        },
      });
    });

    onEvent(PlayerMessageType.REGAINED_FOCUS, () => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.REGAINED_FOCUS, {
        event: PlayerMessageType.REGAINED_FOCUS,
        sessionId,
        correlationId,
      });
      messagingClient.sendMonitoringMessage({
        source: EventSource.PLAYER,
        eventType: EventType.REGAINED_FOCUS,
        params: {
          sessionId,
          playerCid: userId,
          machineId,
        },
      });
    });

    onEvent(PlayerMessageType.QUIT, data => {
      if (!userId) {
        return;
      }
      const reason = data?.reason || 'manual';
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.QUIT, {
        event: PlayerMessageType.QUIT,
        sessionId,
        correlationId,
        reason,
      });
      messagingClient.sendCoreMessage(PlayerMessageType.QUIT, gameId, {
        sessionId,
        reason,
        correlationId,
      });
    });

    onEvent(PlayerMessageType.RETURN_TO_LOBBY, () => {
      if (!userId) {
        return;
      }

      const correlationId = uuidv4();
      logger.info(PlayerMessageType.RETURN_TO_LOBBY, {
        event: PlayerMessageType.RETURN_TO_LOBBY,
        sessionId,
        correlationId,
      });
      messagingClient.sendCoreMessage(PlayerMessageType.RETURN_TO_LOBBY, gameId, {
        sessionId,
        correlationId,
      });
    });

    onEvent(PlayerMessageType.READY_BET_BEHIND, () => {
      if (!userId) {
        return;
      }
      const correlationId = uuidv4();
      logger.info(PlayerMessageType.READY_BET_BEHIND, {
        event: PlayerMessageType.READY_BET_BEHIND,
        sessionId,
        correlationId,
      });
      messagingClient.sendCoreMessage(PlayerMessageType.READY_BET_BEHIND, gameId, {
        sessionId,
        correlationId,
      });
    });

    onEvent(PlayerMessageType.VIDEO_TUTORIAL_EVENT, data => {
      const validTypes = [EventType.VIDEO_TUTORIAL_CLOSE, EventType.VIDEO_TUTORIAL_OPEN, EventType.VIDEO_TUTORIAL_PLAY];

      if (!userId || !data.videoTutorialAction || !validTypes.some(v => data.videoTutorialAction === v)) {
        return;
      }

      logger.info(PlayerMessageType.VIDEO_TUTORIAL_EVENT, {
        event: PlayerMessageType.VIDEO_TUTORIAL_EVENT,
        ...data,
        sessionId,
      });

      messagingClient.sendMonitoringMessage({
        source: EventSource.PLAYER,
        eventType: data.videoTutorialAction,
        params: {
          sessionId,
          playerCid: userId,
          machineId,
          machineSerial,
          operatorId,
          groupId,
        },
      });
    });

    onEvent(PlayerMessageType.MOVE, data => {
      logger.info(PlayerMessageType.MOVE, {
        event: PlayerMessageType.MOVE,
        ...data,
        sessionId,
      });
      const correlationId = uuidv4();
      messagingClient.sendCoreMessage(PlayerMessageType.MOVE, gameId, {
        sessionId,
        correlationId,
        ...data,
      });
      robotClient.sendToRobot({
        action: PlayerMessageType.MOVE,
        data,
        isVolatile: true,
        userId,
      });
    });

    onEvent(PlayerMessageType.STOP, () => {
      logger.info(PlayerMessageType.STOP, {
        event: PlayerMessageType.STOP,
        sessionId,
      });
      const correlationId = uuidv4();
      messagingClient.sendCoreMessage(PlayerMessageType.STOP, gameId, {
        sessionId,
        correlationId,
      });
      robotClient.sendToRobot({
        action: PlayerMessageType.STOP,
        data: {},
        isVolatile: true,
        userId,
      });
    });

    disconnectTimer.startTimer();
  });

  server.listen(config.server.port, () => {
    logger.info(`Server is listening on port ${config.server.port}`);
  });
  logger.info('Bootstrap complete');
}

bootstrap();
