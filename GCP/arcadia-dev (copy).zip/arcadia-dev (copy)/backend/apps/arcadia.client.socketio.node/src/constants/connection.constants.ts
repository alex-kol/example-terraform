export const CONNECTION = 'connection';
export const DISCONNECT = 'disconnect';
