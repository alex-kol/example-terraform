import { newrelicConfig } from '@lib/common/newrelic/newrelic.config';
import { merge } from 'lodash';

const serviceConfig = {
  app_name: 'game_core',
  agent_enabled: true,
};

export const config = merge(newrelicConfig, serviceConfig);
