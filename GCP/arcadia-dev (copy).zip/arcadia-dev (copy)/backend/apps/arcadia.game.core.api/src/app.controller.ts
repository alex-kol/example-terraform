import {
  Controller, Get, HttpCode, HttpStatus, UseInterceptors,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { LoggerInterceptor } from '@lib/common';
import { HealthCheckInterface, HealthCheckService } from '@lib/health.check';

@ApiTags('system')
@Controller('')
@UseInterceptors(LoggerInterceptor)
export class AppController {
  constructor(
    private readonly healthCheckService: HealthCheckService,
  ) {
  }

  @Get('/health')
  @HttpCode(HttpStatus.OK)
  public getHealth(): Promise<HealthCheckInterface> {
    return this.healthCheckService.getHealth();
  }
}
