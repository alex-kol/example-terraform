export const CORRELATION_ID_HEADER = 'correlation';
