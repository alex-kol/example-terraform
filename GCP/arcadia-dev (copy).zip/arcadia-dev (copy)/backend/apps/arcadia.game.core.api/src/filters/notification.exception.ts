import { HttpException } from '@nestjs/common';
import { PlayerNotification } from '../modules/player.client/player.notification';

export class NotificationException extends HttpException {
  constructor(notification: PlayerNotification, statusCode: number) {
    super(notification, statusCode);
  }
}