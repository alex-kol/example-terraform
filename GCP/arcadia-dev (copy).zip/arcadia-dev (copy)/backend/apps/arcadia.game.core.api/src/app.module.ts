import { ConfigModule, ConfigService } from '@lib/config';
import {
  ConnectionType, getConfig, MysqlDriver, SQL_DB_CONNECTION_LOST_MESSAGE, TypeOrmModule,
} from '@lib/dal';
import { LoggerModule, MAIN_LOGGER } from '@lib/logger';
import { RedisCacheModule } from '@lib/redis.cache';
import { RmqServerModule } from '@lib/rmq.server';
import { Inject, MiddlewareConsumer, Module } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { Logger } from 'winston';
import { HealthCheckModule } from '@lib/health.check';
import { AppController } from './app.controller';
import { AuthModule } from './modules/auth/auth.module';
import { BetBehindModule } from './modules/bet.behind/bet.behind.module';
import { BoHandlerModule } from './modules/bo.handler/bo.handler.module';
import { CommandModule } from './modules/command/command.module';
import { configProviderFactory } from './modules/config/config.provider.factory';
import { loggerConfig } from './modules/config/logger.config';
import { rmqProviderFactory } from './modules/config/rmq.provider.factory';
import { MessagingModule } from './modules/messaging/messaging.module';
import { PlayerClientModule } from './modules/player.client/player.client.module';
import { QueueManagerModule } from './modules/queue.manager/queue.manager.module';
import { RobotErrorHandlingModule } from './modules/robot.error/robot.error.handling.module';
import { StatusHandlingModule } from './modules/robot.status.handling/status.handling.module';
import { RouletteEngineModule } from './modules/roulette.engine/roulette.engine.module';
import { WorkerHandlerModule } from './modules/worker.handler/worker.handler.module';
import { SERVICE_NAME } from './constants/service';
import { ChipWatcherModule } from './modules/chip.watcher/chip.watcher.module';
import { ClawEngineModule } from './modules/claw.engine/claw.engine.module';

@Module({
  imports: [
    ConfigModule.register(configProviderFactory()),
    LoggerModule.register(loggerConfig),
    TypeOrmModule.forRootAsync({
      useFactory: (configService: ConfigService, logger: Logger) => getConfig(
        ConnectionType.MAIN,
        configService.get(['core']),
        // new MysqlWinstonLoggerAdapter(cloneLogger(logger, { context: 'MySQL' })),
      ),
      inject: [ConfigService, MAIN_LOGGER],
    }),
    RmqServerModule.register(rmqProviderFactory()),
    RedisCacheModule.register({
      useFactory: async (config: ConfigService) => config.getRedisConfig(),
      inject: [ConfigService],
    }),
    MessagingModule,
    WorkerHandlerModule,
    QueueManagerModule,
    AuthModule,
    BoHandlerModule,
    PlayerClientModule,
    StatusHandlingModule,
    RobotErrorHandlingModule,
    CommandModule,
    HealthCheckModule.register(
      {
        checkMongo: false, checkRmq: true, checkMySqlDb: true, checkRedis: true,
      },
      SERVICE_NAME),
    BetBehindModule,
    RouletteEngineModule,
    ChipWatcherModule,
    ClawEngineModule,
  ],
  controllers: [AppController],
})
export class AppModule {
  constructor(
    dataSource: DataSource,
    @Inject(MAIN_LOGGER) logger: Logger,
  ) {
    if (dataSource.driver.isReplicated) {
      const mysqlDriver = dataSource.driver as MysqlDriver;
      mysqlDriver.poolCluster.on('offline', nodeId => logger.error(SQL_DB_CONNECTION_LOST_MESSAGE, { nodeId }));
    }
  }

  public configure(consumer: MiddlewareConsumer): void {
    consumer
      .apply((req: any, res: any, next: any) => {
        req.executionTime = Date.now();
        next();
      })
      .forRoutes('*');
  }
}
