import { APIExceptionFilter } from '@lib/common';
import { newrelicStart } from '@lib/common/newrelic/newrelic.instance';
import { MAIN_LOGGER } from '@lib/logger';
import { ServerRMQ } from '@lib/rmq.server';
import { ShutdownSignal, ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { NestExpressApplication } from '@nestjs/platform-express';
import { SecuritySchemeObject } from '@nestjs/swagger/dist/interfaces/open-api-spec.interface';
import 'reflect-metadata';
import { Logger } from 'winston';
import { AppModule } from './app.module';
import { initDocumentation } from './documentation';

async function bootstrap() {
  await newrelicStart();
  const app = await NestFactory.create<NestExpressApplication>(AppModule);
  app.enableShutdownHooks([ShutdownSignal.SIGTERM]);
  app.connectMicroservice({
    strategy: app.get(ServerRMQ),
  });
  const logger: Logger = app.get(MAIN_LOGGER);
  app.useLogger(logger);
  app.useGlobalFilters(new APIExceptionFilter(logger));
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
    }),
  );
  app.enableCors();
  app.setGlobalPrefix('api');

  initDocumentation(app, {
    description: 'Arcadia game core API',
    title: 'Arcadia game core API',
    schemes: ['http'],
    basePath: 'api',
    bearerAuth: <SecuritySchemeObject>{ type: 'oauth2' },
    endpoint: '/docs',
  });

  await app.listen(Number(process.env.PORT || 3000));
  await app.startAllMicroservices();
}

bootstrap();
