export enum RobotError {
  DISPENSING_FAILED = 'Dispensing failed',
  MOTOR_FAILURE = 'Motor failure',
  NO_ENGAGEMENT = 'NoEngagement',
  DOOR_OPENED = 'Door opened',
  ACTION_TIMEOUT = 'Action timeout',
  MOTOR_OVERLOAD = 'Motor overload',
  CPU_OVERHEAT = 'CPU overheat',
  CHIP_DROPPED_AGAIN = 'ChipDroppedAgain',
  NETWORKING = 'networking',
}