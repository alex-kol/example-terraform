export const seededChipListKeyFactory = (machineId: number) => `${machineId}_CHIP_SEEDED_LIST`;
