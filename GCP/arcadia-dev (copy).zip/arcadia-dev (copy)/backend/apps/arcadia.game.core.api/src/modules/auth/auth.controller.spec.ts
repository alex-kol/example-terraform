import { CacheModule, INestApplication, ValidationPipe, } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { SpinomenalLaunchUrlCreator } from './launch.url/spinomenal.launch.url.creator';

jest.mock('./auth.service');
jest.mock('../logger/logger.service');

describe('Auth Controller (unit)', () => {
  let app: INestApplication;
  let authService: AuthService;

  beforeAll(
    async (): Promise<void> => {
      const moduleFixture = await Test.createTestingModule({
        imports: [CacheModule.register()],
        controllers: [AuthController],
        providers: [
          AuthService,
          {
            provide: SpinomenalLaunchUrlCreator,
            useValue: {},
          }
        ],
      })
        .compile();
      app = moduleFixture.createNestApplication();
      app.useGlobalPipes(
        new ValidationPipe({
          whitelist: true,
        }),
      );
      await app.init();
      authService = moduleFixture.get<AuthService>(AuthService);
    });

  beforeEach(
    () => {
      jest.restoreAllMocks();
    },
  );

  describe(
    'createValidationToken',
    () => {
      it('should return error', (): void => request(app.getHttpServer())
        .post('/v1/auth/')
        .send({})
        .expect(400)
        .then(response => {
          expect(authService.authPlayer)
            .toBeCalledTimes(0);
        }));

      it('should return 201', (): void => request(app.getHttpServer())
        .post('/v1/auth/')
        .send({
          operatorId: 1,
          accessToken: '<token>',
          gameCode: '<code>',
          language: 'en',
          isReal: true,
          partnerId: '<id>',
          playerIP: '1.1.1.1',
          os: '<os>',
          deviceType: '<device>',
          browser: '<browser>',
          footprint: '<footprint>',
        })
        .expect(201)
        .then(response => {
          expect(authService.authPlayer)
            .toBeCalledTimes(1);
        }));
    },
  );

  describe('exchangeValidationToken', () => {
    it('should return error', (): void => request(app.getHttpServer())
      .post('/v1/auth/verify/')
      .send({})
      .expect(400)
      .then(response => {
        expect(authService.loginPlayer)
          .toBeCalledTimes(0);
      }));

    it('should return 201', (): void => request(app.getHttpServer())
      .post('/v1/auth/verify/')
      .send({
        groupId: 1,
        token: '<token>',
        footprint: '<footprint>',
      })
      .expect(201)
      .then(response => {
        expect(authService.loginPlayer)
          .toBeCalledTimes(1);
      }));
  });

  describe('verifyReconnect', () => {
    it('should return error', (): void => request(app.getHttpServer())
      .post('/v1/auth/reconnect/')
      .send({})
      .expect(400)
      .then(response => {
        expect(authService.verifyReconnect)
          .toBeCalledTimes(0);
      }));

    it('should return 201', (): void => request(app.getHttpServer())
      .post('/v1/auth/reconnect/')
      .send({
        sessionId: 1,
        footprint: '<footprint>',
      })
      .expect(201)
      .then(response => {
        expect(authService.verifyReconnect)
          .toBeCalledTimes(1);
      }));
  });

  describe('videoStreamAuth', () => {
    it('should return error', () => request(app.getHttpServer())
      .post('/v1/auth/videoStreamAuth/')
      .send({})
      .expect(400)
      .then(response => {
        expect(authService.videoStreamAuth)
          .toBeCalledTimes(0);
      }));

    it('should return 201', () => request(app.getHttpServer())
      .post('/v1/auth/videoStreamAuth/')
      .send({
        token: '<token>',
      })
      .expect(201)
      .then(response => {
        expect(authService.videoStreamAuth)
          .toBeCalledTimes(1);
      }));
  });
});
