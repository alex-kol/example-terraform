import { OperatorException } from '@lib/common';
import { HttpStatus } from '@nestjs/common';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

export function operatorErrorMapper(source: Observable<any>): Observable<any> {
  return source.pipe(
    catchError(error => {
      if (error.response?.status === HttpStatus.PAYMENT_REQUIRED) {
        return throwError(() => new OperatorException(error.response.data.data));
      }
      return throwError(() => error);
    }),
  );
}