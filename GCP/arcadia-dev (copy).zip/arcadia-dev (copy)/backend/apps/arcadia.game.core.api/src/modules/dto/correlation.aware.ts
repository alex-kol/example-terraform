import { IsOptional, Length } from 'class-validator';

export class CorrelationAware {
  @IsOptional()
  @Length(10, 50)
  public correlationId?: string;
}
