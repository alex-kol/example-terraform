import { ApiProperty } from '@nestjs/swagger';
import { LobbyDataRes } from './lobby.data.res';

export class ClawRouletteLobbyRes {
  @ApiProperty({ type: [LobbyDataRes] })
  public groups: LobbyDataRes[];
}
