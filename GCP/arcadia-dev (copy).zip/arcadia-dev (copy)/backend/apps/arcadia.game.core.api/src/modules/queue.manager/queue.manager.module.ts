import { MachineRepository, QueueRepository, SessionRepository } from '@lib/dal';
import { MonitoringWorkerClientModule } from '@lib/monitoring.worker.client';
import { Module } from '@nestjs/common';
import { SessionDataManagerModule } from '../session.data.manager/session.data.manager.module';
import { SessionModule } from '../session/session.module';
import { QueueChangeHandler } from './queue.change.handler';
import { QueueController } from './queue.controller';
import { QueueManagerService } from './queue.manager.service';
import { QueueTransactionController } from './queue.transaction.controller';

@Module({
  imports: [
    SessionModule,
    MonitoringWorkerClientModule,
    SessionDataManagerModule,
  ],
  providers: [
    QueueManagerService,
    QueueChangeHandler,
    QueueRepository,
    SessionRepository,
    MachineRepository,
  ],
  controllers: [QueueController, QueueTransactionController],
  exports: [QueueManagerService],
})
export class QueueManagerModule {

}
