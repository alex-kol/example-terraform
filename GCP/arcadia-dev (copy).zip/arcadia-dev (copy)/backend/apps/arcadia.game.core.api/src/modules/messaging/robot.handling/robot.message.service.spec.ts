import { EventSource, EventType } from '@lib/common';
import { ConfigService } from '@lib/config';
import {
  ChipRepository,
  connectionNames,
  getRepositoryToken,
  MachineDispenserRepository,
  MachineRepository,
  MachineStatus,
  QueueRepository,
  RngChipPrizeRepository,
  SessionEndReason,
  SessionRepository,
  SessionStatus,
  TiltMode,
} from '@lib/dal';
import { NotFoundException } from '@nestjs/common';
import { CommandPublisher } from '../../command/command.publisher';
import { ConfigValidator } from '../../config.validator/config.validator';
import { NotificationLevel } from '../../player.client/notification.level';
import { NotificationType } from '../../player.client/notification.type';
import { PlayerClientService } from '../../player.client/player.client.service';
import { QueueManagerService } from '../../queue.manager/queue.manager.service';
import { ServerRMQ } from '../../rmq.server/rmq.server';
import { RngClientService } from '../../rng.service.client/rng.client.service';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { RoundServiceFactory } from '../../round/round.service.factory';
import { SessionDataManager } from '../../session.data.manager/session.data.manager';
import { SessionService } from '../../session/session.service';
import { WorkerClientService } from '../../worker.client/worker.client.service';
import { RobotLoginDto } from './dto/robot.login.dto';
import { makeTestModule } from './mocks/beforeAll.mock';
import { prepareMocks, } from './mocks/engageNextSession.mocks';
import {
  handleChipPushedChipMock,
  handleChipPushedMachineMock,
  handleChipPushedPhantomSeedMock,
  shouldHandlePhantomChip,
  shouldSetChipMachine,
} from './mocks/handleChipPushed.mocks';
import { handleChipValidationChipMock, handleChipValidationMachineMock, } from './mocks/handleChipValidation.mocks';
import { handleDisengagedSessionMock, shouldDisengagePlayer } from './mocks/handleDisengaged.mocks';
import { handleEngagedSessionMock, shouldSendAutoplaySessionDisconnected, shouldStartIdleNotifyQueue, } from './mocks/handleEngaged.mocks';
import { loginRobotMachineMock, shouldReturnLoginData } from './mocks/loginRobot.mocks';
import { shouldPushChips, startSeedingMachineMock } from './mocks/startSeeding.mocks';
import { RobotMessageService } from './robot.message.service';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';

jest.mock('../../logger/logger.service');

describe('Robot Message Service (Unit)', () => {
  let robotMessageService: RobotMessageService;
  let machineRepository: MachineRepository;
  let configService: ConfigService;
  let queueRepository: QueueRepository;
  let sessionRepository: SessionRepository;
  let monitoringsService: MonitoringWorkerClientService;
  let workerPublisher: WorkerClientService;
  let robotClientService: RobotClientService;
  let chipRepository: ChipRepository;
  let rngService: RngClientService;
  let dispenserRepository: MachineDispenserRepository;
  let queueManager: QueueManagerService;
  let sessionService: SessionService;
  let rngChipPrizeRepository: RngChipPrizeRepository;
  let configValidator: ConfigValidator;
  let roundServiceFactory: RoundServiceFactory;
  let commandPublisher: CommandPublisher;
  let sessionDataManager: SessionDataManager;
  let playerClientService: PlayerClientService;

  beforeAll(
    async () => {
      const moduleFixture = await makeTestModule();
      robotMessageService = moduleFixture.get<RobotMessageService>(RobotMessageService);
      machineRepository = moduleFixture.get<MachineRepository>(getRepositoryToken(MachineRepository, connectionNames.DATA));
      configService = moduleFixture.get<ConfigService>(ConfigService);
      queueRepository = moduleFixture.get<QueueRepository>(getRepositoryToken(QueueRepository, connectionNames.DATA));
      sessionRepository = moduleFixture.get<SessionRepository>(getRepositoryToken(SessionRepository, connectionNames.DATA));
      monitoringsService = moduleFixture.get<MonitoringWorkerClientService>(MonitoringWorkerClientService);
      workerPublisher = moduleFixture.get<WorkerClientService>(WorkerClientService);
      robotClientService = moduleFixture.get<RobotClientService>(RobotClientService);
      chipRepository = moduleFixture.get<ChipRepository>(getRepositoryToken(ChipRepository, connectionNames.DATA));
      rngService = moduleFixture.get<RngClientService>(RngClientService);
      dispenserRepository = moduleFixture
        .get<MachineDispenserRepository>(getRepositoryToken(MachineDispenserRepository, connectionNames.DATA));
      queueManager = moduleFixture.get<QueueManagerService>(QueueManagerService);
      sessionService = moduleFixture.get<SessionService>(SessionService);
      configValidator = moduleFixture.get<ConfigValidator>(ConfigValidator);
      roundServiceFactory = moduleFixture.get<RoundServiceFactory>(RoundServiceFactory);
      rngChipPrizeRepository = moduleFixture.get<RngChipPrizeRepository>(getRepositoryToken(RngChipPrizeRepository, connectionNames.DATA));
      commandPublisher = moduleFixture.get(CommandPublisher);
      sessionDataManager = moduleFixture.get<SessionDataManager>(SessionDataManager);
      playerClientService = moduleFixture.get<PlayerClientService>(PlayerClientService);
    });

  describe('loginRobot', () => {
    it('should throw exception if machine is not found', async () => {
      try {
        jest.spyOn(machineRepository, 'findOneOrFail')
          .mockRejectedValue(null);
        await robotMessageService.loginRobot({
          serial: '<serial>',
          secret: '<secret>',
          env: '<emu>',
          version: '<emu>',
        } as RobotLoginDto);
        expect(true)
          .toBe(false);
      } catch (e) {
        expect(e)
          .toBeInstanceOf(NotFoundException);
      }
    });
    it('should return login data', async () => {
      shouldReturnLoginData({
        machineRepository,
        configService,
        queueRepository
      });
      const result = await robotMessageService.loginRobot({
        serial: '<serial>',
        secret: '<secret>',
        env: '<emu>',
        version: '<emu>',
      } as RobotLoginDto);
      expect(result)
        .toMatchObject({
          robotKey: loginRobotMachineMock.id,
          mgrMessageServer: '<user>:<password>@<host>:<port>',
          queues: ServerRMQ.getConnectors(loginRobotMachineMock.serial),
          playerMessageServer: {
            redis: {},
            key: 'socket.io',
          },
        });
    });
  });

  describe('handleDisengaged', () => {
    it('should disengage player', async () => {
      shouldDisengagePlayer({
        sessionRepository,
        machineRepository,
        robotMessageService,
        workerPublisher,
      });
      const sendEventLogSpy = jest.spyOn(monitoringsService, 'sendEventLogMessage');
      await robotMessageService.handleDisengaged({
        // @ts-ignore
        session: handleDisengagedSessionMock,
        sessionId: handleDisengagedSessionMock.id,
        serial: '<serial>',
        type: '',
      });
      expect(sendEventLogSpy)
        .toBeCalledWith({
          eventType: EventType.BREAKUP,
          source: EventSource.ROBOT,
          params: {
            sessionId: handleDisengagedSessionMock.id,
            playerCid: '<cid>',
            machineSerial: handleDisengagedSessionMock.machine.serial,
          },
        });
    });
  });

  describe('handleChipValidation', () => {
    it('should validate chip', async () => {
      jest.spyOn(configValidator, 'getValidatedConfig')
        .mockResolvedValue({ rtpSegment: '<rtp>' });
      const sendChipValidationSpy = jest.spyOn(robotClientService, 'sendChipValidationMessage');
      // @ts-ignore
      jest.spyOn(rngChipPrizeRepository, 'getChipPrize')
        .mockResolvedValue({ chipValue: 5 });
      // @ts-ignore
      jest.spyOn(machineRepository, 'findOneOrFail')
        .mockResolvedValue(handleChipValidationMachineMock);
      // @ts-ignore
      jest.spyOn(chipRepository, 'findOne')
        .mockResolvedValue(handleChipValidationChipMock);
      await robotMessageService.chipPushValidation({
        serial: handleChipValidationMachineMock.serial,
        rfid: '<rfid>',
        dispenser: '<dispenser>',
        type: '<type>',
      });
      expect(sendChipValidationSpy)
        .toBeCalledWith('<rfid>', true, handleChipValidationMachineMock.serial);
    });
  });

  describe('handleChipPushed', () => {
    it('should set chip\'s machine', async () => {
      shouldSetChipMachine({
        machineRepository,
        chipRepository,
        rngChipPrizeRepository,
        configValidator
      });
      // @ts-ignore
      jest.spyOn(rngChipPrizeRepository, 'getChipPrize')
        .mockResolvedValue({ chipValue: 5 });
      const chipUpdateSpy = jest.spyOn(chipRepository, 'update');
      await robotMessageService.chipPushed({
        rfid: handleChipPushedChipMock.rfid,
        dispenser: 'D1',
        serial: 'asdf'
      } as any);
      expect(chipUpdateSpy)
        .toBeCalledWith(handleChipPushedChipMock.rfid, {
          isScatter: false,
          machine: handleChipPushedMachineMock,
          value: 5,
        });
    });
    it('should handle phantom chip push', async () => {
      shouldHandlePhantomChip({
        machineRepository,
        chipRepository,
        rngService
      });
      const chipUpdateSpy = jest.spyOn(chipRepository, 'update');
      jest.spyOn(configValidator, 'getValidatedConfig')
        .mockResolvedValue({ rtpSegment: '<rtp>' });
      await robotMessageService.chipPushed({
        serial: handleChipPushedMachineMock.serial,
        rfid: handleChipPushedChipMock.rfid,
        dispenser: 'D1',
        type: '<type>',
      });
      expect(chipUpdateSpy)
        .toBeCalledWith(handleChipPushedChipMock.rfid, {
          machine: handleChipPushedMachineMock,
          value: handleChipPushedPhantomSeedMock.value,
          isScatter: true,
        });
    });
    it('should decrement dispenser level', async () => {
      shouldSetChipMachine({
        machineRepository,
        configValidator,
        chipRepository,
        rngChipPrizeRepository
      });
      const levelDecrementSpy = jest.spyOn(dispenserRepository, 'decrement');
      await robotMessageService.chipPushed({
        serial: handleChipPushedMachineMock.serial,
        rfid: handleChipPushedChipMock.rfid,
        dispenser: 'D1',
        type: '<type>',
      });
      expect(levelDecrementSpy)
        .toBeCalledWith({ id: 'x' }, 'level', 1);
    });
  });

  describe('engageNextSession', () => {
    const nextSessionId = 1;
    const getNextSessionForQueue = {
      id: nextSessionId,
      isDisconnected: false,
      status: '<status>',
      player: {},
      operator: {},
      vouchers: [],
    };
    it('is expected to start new round', async () => {
      const getMachineToEngage = jest.fn()
        .mockResolvedValue({
          queue: { id: 1 },
          group: {},
          status: MachineStatus.READY,
        });
      const startRound = jest.fn()
        .mockResolvedValue({ id: 1 });
      const createRoundServiceFactory = jest.fn()
        .mockReturnValue({ startRound });
      jest.spyOn(machineRepository, 'getMachineToEngage')
        .mockImplementation(getMachineToEngage);
      jest.spyOn(sessionRepository, 'getNextSessionForQueue')
        .mockImplementation(jest.fn()
          .mockResolvedValue(getNextSessionForQueue));
      jest.spyOn(roundServiceFactory, 'create')
        .mockImplementation(createRoundServiceFactory);
      jest.spyOn(monitoringsService, 'sendAlertMessage')
        .mockImplementation(jest.fn());
      jest.spyOn(sessionDataManager, 'isAutoplay')
        .mockImplementation(jest.fn());
      jest.spyOn(workerPublisher, 'timeoutStart')
        .mockImplementation(jest.fn());

      await robotMessageService.engageNextSession(1);

      expect(getMachineToEngage)
        .toBeCalled();
      expect(startRound)
        .toBeCalled();
      expect(createRoundServiceFactory)
        .toBeCalled();
    });
    it('should notify and return if machine is not ready', async () => {
      const queueId = 1;
      const getMachineToEngage = jest.spyOn(machineRepository, 'getMachineToEngage')
        .mockImplementation(jest.fn()
          .mockResolvedValue({
            queue: { id: queueId },
            group: {},
            status: MachineStatus.OFFLINE,
            id: 1,
          }));
      jest.spyOn(sessionRepository, 'getNextSessionForQueue')
        .mockResolvedValue(null);
      const machineUpdateSpy = jest.spyOn(machineRepository, 'update');
      const notifyQueueUpdateSpy = jest.spyOn(queueManager, 'notifyQueueUpdate');

      await robotMessageService.engageNextSession(1);

      expect(machineUpdateSpy)
        .toBeCalledWith(1, { status: MachineStatus.READY });
      expect(notifyQueueUpdateSpy)
        .toBeCalledWith(queueId, null);
      expect(getMachineToEngage)
        .toBeCalled();
    });
    it('should exit if can\'t engage new session', async () => {
      jest.resetAllMocks();
      prepareMocks({
        machineRepository,
        sessionRepository,
        monitoringsService
      });
      jest.spyOn(sessionRepository, 'getNextSessionForQueue')
        .mockImplementation(jest.fn()
          .mockResolvedValue(getNextSessionForQueue));
      const sessionRepositoryUpdate = jest.spyOn(sessionRepository, 'update');
      const roundServiceFactoryCreate = jest.spyOn(roundServiceFactory, 'create')
        .mockImplementation(jest.fn());

      await robotMessageService.engageNextSession(1, 1);

      expect(sessionRepositoryUpdate)
        .not
        .toBeCalled();
      expect(roundServiceFactoryCreate)
        .not
        .toBeCalled();
    });
    it('should return if session is disconnected and it\'s not a re-buy', async () => {
      const getMachineToEngage = jest.fn()
        .mockResolvedValue({
          queue: { id: 1 },
          group: {},
          status: MachineStatus.READY,
        });
      const getNextSessionForQueue = jest.fn()
        .mockResolvedValue({
          id: 1,
          isDisconnected: true,
          status: '<status>',
          player: {},
          operator: {},
          vouchers: [],
        });
      jest.spyOn(machineRepository, 'getMachineToEngage')
        .mockImplementation(getMachineToEngage);
      jest.spyOn(sessionRepository, 'getNextSessionForQueue')
        .mockImplementation(getNextSessionForQueue);
      const commandPublisherEngageNextSession = jest.spyOn(commandPublisher, 'engageNextSession');
      const sessionRepositoryUpdate = jest.spyOn(sessionRepository, 'update');
      const roundServiceFactoryCreate = jest.spyOn(roundServiceFactory, 'create');

      await robotMessageService.engageNextSession(1);

      expect(sessionRepositoryUpdate)
        .toBeCalled();
      expect(commandPublisherEngageNextSession)
        .toBeCalled();
      expect(roundServiceFactoryCreate)
        .not
        .toBeCalled();
    });
    it('should send monitoring event and remove session data if session is queueBetBehind', async () => {
      const getNextSessionForQueue = jest.fn()
        .mockResolvedValue({
          id: nextSessionId,
          isDisconnected: false,
          status: SessionStatus.QUEUE_BET_BEHIND,
          player: {},
          operator: {},
          vouchers: [],
        });

      prepareMocks({
        machineRepository,
        sessionRepository,
        monitoringsService,
        machineStatus: MachineStatus.READY,
      });
      const startRound = jest.fn()
        .mockResolvedValue({ id: 1 });
      const createRoundServiceFactory = jest.fn()
        .mockReturnValue({ startRound });
      const sessionRepositoryUpdate = jest.spyOn(sessionRepository, 'update')
        .mockImplementation();
      const sendEventLogMessage = jest.spyOn(monitoringsService, 'sendEventLogMessage');
      const removeSessionData = jest.spyOn(sessionDataManager, 'removeSessionData');

      jest.spyOn(sessionRepository, 'getNextSessionForQueue')
        .mockImplementation(getNextSessionForQueue);
      jest.spyOn(roundServiceFactory, 'create')
        .mockImplementation(createRoundServiceFactory);

      await robotMessageService.engageNextSession(1);

      expect(sessionRepositoryUpdate)
        .toBeCalled();
      expect(removeSessionData)
        .toBeCalledWith({ betBehind: {} }, nextSessionId);
      expect(sendEventLogMessage)
        .toBeCalledWith({
          eventType: EventType.BET_BEHIND_STOPPED,
          source: EventSource.GAME,
          params: {
            sessionId: nextSessionId,
            machineSerial: '<machineSerial>',
            reason: 'User turn to play',
          }
        });
    });
    it('should finalize session if round start failed', async () => {
      jest.resetAllMocks();
      const getMachineToEngage = jest.fn()
        .mockResolvedValue({
          queue: { id: 1 },
          group: {},
          status: MachineStatus.READY,
          serial: '<machineSerial>'
        });
      const sendAlertMessage = jest.spyOn(monitoringsService, 'sendAlertMessage')
        .mockImplementation(jest.fn());
      const finalizeSession = jest.spyOn(sessionService, 'finalizeSession')
        .mockImplementation(jest.fn());
      const engageNextSession = jest.spyOn(commandPublisher, 'engageNextSession')
        .mockImplementation(jest.fn());
      const playerNotification = jest.spyOn(playerClientService, 'notification')
        .mockImplementation(jest.fn());
      const sessionUpdate = jest.spyOn(sessionRepository, 'update');
      jest.spyOn(machineRepository, 'getMachineToEngage')
        .mockImplementation(getMachineToEngage);
      jest.spyOn(sessionRepository, 'getNextSessionForQueue')
        .mockImplementation(jest.fn()
          .mockResolvedValue(getNextSessionForQueue));
      jest.spyOn(roundServiceFactory, 'create')
        .mockReturnValue(null);

      await robotMessageService.engageNextSession(1);

      expect(sendAlertMessage)
        .toBeCalled();
      expect(engageNextSession)
        .toBeCalled();
      expect(playerNotification)
        .toBeCalledWith(nextSessionId, {
          level: NotificationLevel.ERROR,
          notificationId: NotificationType.BET_FAILED,
          title: 'Wallet error',
          message: 'Bet failed',
        });
      expect(finalizeSession)
        .toBeCalledWith(nextSessionId, SessionEndReason.WALLET_TRANSACTION_ERROR, true);
      expect(sessionUpdate)
        .not
        .toBeCalled();

    });
  });

  describe('handleEngaged', () => {
    it('should send autoplay message if session is disconnected', async () => {
      shouldSendAutoplaySessionDisconnected({ sessionRepository });
      const sessionUpdateSpy = jest.spyOn(sessionRepository, 'update');
      const sendAutoplaySpy = jest.spyOn(robotClientService, 'sendAutoplayMessage');
      await robotMessageService.handleEngaged({
        // @ts-ignore
        session: handleEngagedSessionMock,
        sessionId: 51,
      });
      expect(sessionUpdateSpy)
        .toBeCalledWith(handleEngagedSessionMock.id, { queueDuration: expect.any(Number) });
      expect(sessionUpdateSpy)
        .toBeCalledWith(handleEngagedSessionMock.id, { status: SessionStatus.FORCED_AUTOPLAY }, expect.anything());
      expect(sendAutoplaySpy)
        .toBeCalledWith(handleEngagedSessionMock.machine.serial, handleEngagedSessionMock.id, TiltMode.AUTO);
    });
    it('should start idle timeout and notify about queue status', async () => {
      shouldStartIdleNotifyQueue({ sessionRepository });
      const sendAllowCoinsSpy = jest.spyOn(robotClientService, 'sendAllowCoinsMessage');
      const sessionUpdateSpy = jest.spyOn(sessionRepository, 'update')
        .mockReset();
      const sendEventLogSpy = jest.spyOn(monitoringsService, 'sendEventLogMessage');
      const notifyQueueSpy = jest.spyOn(queueManager, 'notifyQueueUpdate');

      await robotMessageService.handleEngaged({
        // @ts-ignore
        session: handleEngagedSessionMock,
        serial: handleEngagedSessionMock.machine.serial,
        sessionId: 51,
      });

      expect(sendAllowCoinsSpy)
        .toBeCalledWith(1, handleEngagedSessionMock.machine.serial, handleEngagedSessionMock.id);
      expect(sessionUpdateSpy)
        .toBeCalledTimes(1);
      expect(sendEventLogSpy)
        .toBeCalledWith({
          eventType: EventType.ENGAGED,
          source: EventSource.ROBOT,
          params: {
            sessionId: handleEngagedSessionMock.id,
            machineSerial: handleEngagedSessionMock.machine.serial,
          },
        });
      expect(notifyQueueSpy)
        .toBeCalledWith(handleEngagedSessionMock.queue.id, handleEngagedSessionMock);
    });
  });

  xdescribe('startSeeding', () => {
    it('should push chips', async done => {
      shouldPushChips({
        machineRepository,
        rngService,
        configValidator
      });
      const machineUpdateSpy = jest.spyOn(machineRepository, 'update');
      const sendSeedSpy = jest.spyOn(robotClientService, 'sendSeedMessage');
      const gameEventLogSpy = jest.spyOn(monitoringsService, 'sendOutOfSessionEventLogMessage');

      // @ts-ignore
      await robotMessageService.seeding(startSeedingMachineMock.serial);
      expect(machineUpdateSpy)
        .toBeCalledWith(1, { status: MachineStatus.IN_PLAY });
      expect(gameEventLogSpy)
        .toBeCalledWith(startSeedingMachineMock.serial, expect.objectContaining({
          source: EventSource.GAME,
          eventType: EventType.SEED,
          params: expect.objectContaining({
            serial: startSeedingMachineMock.serial,
            toPush: expect.any(Array),
            reshuffleCoins: 4,
          }),
        }));
      expect(sendSeedSpy)
        .toBeCalledWith(startSeedingMachineMock.serial, expect.any(Array), 4);
    });
  });
});
