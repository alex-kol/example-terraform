import { IsNotEmpty, IsOptional, IsString } from 'class-validator';
import { RobotMessage } from './robot.message';

export class RobotChipDropDto extends RobotMessage {
  @IsString()
  @IsNotEmpty()
  public rfid: string;

  @IsOptional()
  public duration?: number;
}
