import { RpcException } from '@nestjs/microservices';
import { v4 as uuidv4 } from 'uuid';
import { Logger } from 'winston';
import { CorrelationAware } from '../dto/correlation.aware';

export abstract class CommandHandler<T extends CorrelationAware = CorrelationAware> {
  protected correlationId: string;

  protected constructor(protected readonly logger: Logger) {
  }

  public async handle(data: T): Promise<void> {
    try {
      await this.init(data);
      await this.handleEvent();
    } catch (err) {
      await this.onError(err);
    }
  }

  protected async init(data: T): Promise<void> {
    this.correlationId = data.correlationId || uuidv4();
  }

  protected abstract handleEvent(): Promise<void>;

  protected async onError(err: string | Record<string, any>): Promise<never> {
    throw new RpcException(err);
  }
}
