import { OperatorRequestParams } from './operator.request.params';

export class CidOperatorParams extends OperatorRequestParams {
  cid: string;
}