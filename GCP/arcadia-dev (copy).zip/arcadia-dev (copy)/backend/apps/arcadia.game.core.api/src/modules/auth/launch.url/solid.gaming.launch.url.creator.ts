import { deleteUndefinedValue, OperatorTag, UserLoginDto } from '@lib/common';
import { ConfigService } from '@lib/config';
import { OperatorEntity, OperatorRepository, OperatorStatus } from '@lib/dal';
import { Injectable, NotAcceptableException } from '@nestjs/common';
import { StandardLanguageMapper } from './languages';
import { LaunchUrlCreator } from './launch.url.creator';
import { solidGamingLaunchParamsValidationSchema } from './params.validation.schemas';
import { SolidGamingLaunchUrlParams } from './types';

@Injectable()
export class SolidGamingLaunchUrlCreator extends LaunchUrlCreator<SolidGamingLaunchUrlParams> {
  protected readonly paramsValidationSchema = solidGamingLaunchParamsValidationSchema;

  constructor(
    config: ConfigService,
    private readonly operatorRepo: OperatorRepository,
    private readonly solidGamingLanguage: StandardLanguageMapper,
  ) {
    super(config);
  }

  protected getId(): OperatorTag {
    return OperatorTag.SOLID_GAMING;
  }

  protected getOperator(): Promise<OperatorEntity> {
    return this.operatorRepo.findOneByOrFail({
      apiConnectorId: this.params.operator,
      externalId: this.params.brandId,
      isDeleted: false,
      status: OperatorStatus.ENABLED,
    })
      .catch(() => {
        throw new NotAcceptableException('Operator not found or disabled');
      });
  }

  protected mapParams(): UserLoginDto {
    const result: UserLoginDto = {
      operatorId: this.operator.id,
      gameId: this.params.gameId,
      accessToken: this.params.authToken,
      language: this.solidGamingLanguage.getLanguageCode(this.params.language),
      externalId: this.params.brandId,
      homeUrl: this.params.homeUrl,
      events: this.getId(),
    };
    deleteUndefinedValue(result);
    return result;
  }
}
