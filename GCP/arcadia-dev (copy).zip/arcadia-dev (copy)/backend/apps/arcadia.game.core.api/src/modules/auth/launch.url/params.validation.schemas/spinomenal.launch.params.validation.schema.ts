import { GameId } from '@lib/dal';
import Joi from 'joi';
import { urlPattern } from '../../../../util';
import { SpinomenalLaunchUrlParams } from '../types';

export const spinomenalLaunchParamsValidationSchema = Joi.object<SpinomenalLaunchUrlParams>({
  operator: Joi.string()
    .required(),
  gameToken: Joi.string()
    .required(),
  callerIp: Joi.string()
    .ip()
    .required(),
  partnerId: Joi.string()
    .required(),
  authToken: Joi.string()
    .allow(null)
    .empty(null),
  gameId: Joi
    .valid(...Object.values(GameId))
    .required(),
  isReal: Joi.boolean()
    .allow(null)
    .empty(null),
  languageCode: Joi.string()
    .allow(null)
    .empty(null),
  homeUrl: Joi.string()
    .pattern(urlPattern)
    .allow(null)
    .empty(null),
  cashierUrl: Joi.string()
    .pattern(urlPattern)
    .allow(null)
    .empty(null),
  jurisdiction: Joi.string()
    .allow(null)
    .empty(null),
});
