import { GameId } from '@lib/dal';

export interface AuthTokenPayload {
  operatorId: number;
  cid: string;
  gameId: GameId;
}
