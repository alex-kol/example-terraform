import { GroupEntity, OperatorEntity, SessionEntity } from '@lib/dal';

export const shouldSendBetsSessionMock = new SessionEntity();
shouldSendBetsSessionMock.id = 5;
shouldSendBetsSessionMock.currency = 'USD';
shouldSendBetsSessionMock.currencyConversionRate = 1;
shouldSendBetsSessionMock.group = new GroupEntity();
shouldSendBetsSessionMock.operator = new OperatorEntity();

export const shouldSendBetsLobbyBetDataMock = [{
  groupId: 1,
  groupName: '<groupName>',
  denominator: 15,
  queueLength: 4,
  config: {},
  color: 'red',
  prizeGroup: '<prizeGroup>',
}];

export const shouldSendBetsPayTableMock = {
  type: '<type>',
  currencyValue: 25,
};

export const shouldSendBetsBetListMock = {
  groups: [
    {
      groupId: shouldSendBetsLobbyBetDataMock[0].groupId,
      groupName: shouldSendBetsLobbyBetDataMock[0].groupName,
      queueLength: shouldSendBetsLobbyBetDataMock[0].queueLength,
      currency: shouldSendBetsSessionMock.currency,
      betInCash: 15,
      color: shouldSendBetsLobbyBetDataMock[0].color,
      payTable: {
        type: shouldSendBetsPayTableMock.type,
        currencyValue: shouldSendBetsPayTableMock.currencyValue,
      },
    },
  ],
}

export function shouldSendBets(spyTargets: any): void {
  jest.spyOn(spyTargets.machineRepository, 'getLobbyAndChangeBetGroupData').mockResolvedValue(shouldSendBetsLobbyBetDataMock);
  jest.spyOn(spyTargets.rngChipPrizeRepository, 'getPayTable').mockResolvedValue(shouldSendBetsPayTableMock);
}