import { Length } from 'class-validator';
import { BaseCommand } from '../../command/dto/base.command';

export class ForcedGrabDto extends BaseCommand {
  @Length(1, 128)
  public reason: string;
}
