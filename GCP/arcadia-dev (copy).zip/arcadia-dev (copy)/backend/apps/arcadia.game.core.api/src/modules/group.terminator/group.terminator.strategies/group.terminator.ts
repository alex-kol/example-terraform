import { GroupStopDto } from '../../bo.handler/dto';

export abstract class GroupTerminator {
  abstract groupSoftStop(groupId: number, machineIds?: number[], correlationId?: string): Promise<void>;
  abstract groupHardStop(groupId: number, data: GroupStopDto, correlationId?: string): Promise<void>;
}