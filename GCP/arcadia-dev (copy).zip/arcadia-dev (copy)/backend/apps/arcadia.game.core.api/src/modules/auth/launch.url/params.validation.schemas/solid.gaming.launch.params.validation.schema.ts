import { GameId } from '@lib/dal';
import Joi from 'joi';
import { urlPattern } from '../../../../util';
import { SolidGamingLaunchUrlParams } from '../types';

export const solidGamingLaunchParamsValidationSchema = Joi.object<SolidGamingLaunchUrlParams>({
  operator: Joi.string()
    .required(),
  callerIp: Joi.string()
    .ip()
    .required(),
  authToken: Joi.string()
    .required(),
  gameId: Joi.valid(...Object.values(GameId))
    .required(),
  language: Joi.string()
    .default('en'),
  brandId: Joi.string()
    .required(),
  homeUrl: Joi.string()
    .pattern(urlPattern)
    .allow(null)
    .empty(null),
});
