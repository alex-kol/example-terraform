import {
  Configuration, GroupEntity, MachineEntity, RtpData, SeedHistoryRepository,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { Inject, Injectable } from '@nestjs/common';
import { from, of } from 'rxjs';
import {
  groupBy, map, mergeMap, repeat, toArray,
} from 'rxjs/operators';
import { Logger } from 'winston';
import { RngClientService } from './rng.client.service';

@Injectable()
export class RngHelper {
  constructor(
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly seedHistoryRepo: SeedHistoryRepository,
    private readonly rngClient: RngClientService,
  ) {

  }

  public async calcRtp(
    group: GroupEntity, machine: MachineEntity, config: Configuration, roundsRange = 100,
  ): Promise<RtpData[]> {
    const history = await this.seedHistoryRepo.getSeedHistory(machine.id, roundsRange);
    const rtpSeedResp = await this.rngClient.rtp(group.prizeGroup, config.rtpSegment, history);
    this.logger.debug('RNG "rtp"', { result: rtpSeedResp, machineSerial: machine.serial });
    return from(Object.entries(rtpSeedResp))
      .pipe(
        mergeMap(([type, count]) => of(type)
          .pipe(repeat(count))),
        map(type => ({
          afterCoin: this.getAfterCoin(group.stackSize),
          type,
        })),
        groupBy(value => value.afterCoin, value => value.type),
        mergeMap(g => g.pipe(
          toArray(),
          map(value => ({
            afterCoin: g.key,
            types: value,
          })),
        )),
        toArray())
      .toPromise();
  }

  private getAfterCoin(stackSize: number, limitMultiplier = 0.9): number {
    return Math.floor(Math.random() * (stackSize * limitMultiplier)) || 1;
  }
}
