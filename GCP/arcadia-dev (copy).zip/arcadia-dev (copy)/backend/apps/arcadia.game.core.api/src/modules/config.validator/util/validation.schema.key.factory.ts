import { GameId } from '@lib/dal';

export const validationSchemaKeyFactory = (gameId: GameId) => `${gameId}_VALIDATION_SCHEMA_KEY`;
