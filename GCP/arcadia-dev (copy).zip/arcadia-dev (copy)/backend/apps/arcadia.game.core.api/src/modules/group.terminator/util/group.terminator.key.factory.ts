import { GameId } from '@lib/dal';

export const groupTerminatorKeyFactory = (gameId: GameId) => `${gameId}_GROUP_TERMINATOR_STRATEGY`;
