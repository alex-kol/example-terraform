import { ConfigService } from '@lib/config';
import {
  MachineEntity, MachineRepository, MachineStatus, QueueRepository, QueueStatus,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Inject, Injectable } from '@nestjs/common';
import { Logger } from 'winston';
import { ConfigValidator } from '../../config.validator/config.validator';
import { RobotMessageService } from '../../messaging/robot.handling/robot.message.service';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { StartupStatusStrategy } from './startup.status.strategy';

@Injectable()
export class ClawStartupStatusStrategy extends StartupStatusStrategy {
  constructor(
      @Inject(MAIN_LOGGER) logger: Logger,
        queueRepo: QueueRepository,
        machineRepo: MachineRepository,
        robotClientService: RobotClientService,
        robotMessageService: RobotMessageService,
        monitoringWorkerClient: MonitoringWorkerClientService,
        configValidator: ConfigValidator,
        configService: ConfigService,
  ) {
    super(
      logger,
      queueRepo,
      machineRepo,
      robotClientService,
      robotMessageService,
      monitoringWorkerClient,
      configValidator,
      configService,
    );
  }

  public async onIdle(machine: MachineEntity): Promise<void> {
    await this.queueRepo.update({ machine: { id: machine.id } }, { status: QueueStatus.READY });
    await this.machineRepo.update(machine.id, { status: MachineStatus.READY });
  }

  public toString(): string {
    return ClawStartupStatusStrategy.name;
  }
}