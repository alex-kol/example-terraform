/* eslint-disable max-lines */
import { EventSource, OperatorErrorType, OperatorException } from '@lib/common';
import {
  AlertSeverity,
  AlertSource,
  AlertType,
  EntityManager,
  EventType,
  MachineEntity,
  OperatorEntity,
  PlayerEntity,
  PlayerRepository,
  RoundEntity,
  RoundRepository,
  RoundStatus,
  RoundType,
  SessionEntity,
  SessionRepository,
} from '@lib/dal';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import BigNumber from 'bignumber.js';
import { Logger } from 'winston';
import { toCash } from '../../util';
import { RoundStartedDto } from '../messaging/player.handling/dto/round.started.dto';
import { OperatorApiClientService } from '../operator.api.client/operator.api.client.service';
import { NotificationLevel } from '../player.client/notification.level';
import { NotificationType } from '../player.client/notification.type';
import { PlayerClientService } from '../player.client/player.client.service';
import { RouletteBet } from '../roulette.engine/types';
import { SessionDataManager } from '../session.data.manager/session.data.manager';
import { RoundContext } from './round.context';

export class RouletteRoundStarter {
  private readonly roundRepo: RoundRepository;
  private readonly sessionRepo: SessionRepository;
  private readonly playerRepo: PlayerRepository;

  private readonly session: SessionEntity;
  private readonly machine: MachineEntity;
  private readonly player: PlayerEntity;
  private readonly operator: OperatorEntity;
  private readonly correlationId: string;

  constructor(
    private readonly logger: Logger,
    private readonly operatorClient: OperatorApiClientService,
    private readonly playerPublisher: PlayerClientService,
    private readonly monitoringService: MonitoringWorkerClientService,
    private readonly sessionDataManager: SessionDataManager,
    context: RoundContext,
    manager: EntityManager,
  ) {
    this.sessionRepo = new SessionRepository(manager);
    this.roundRepo = new RoundRepository(manager);
    this.playerRepo = new PlayerRepository(manager);

    this.session = context.session;
    this.operator = context.operator;
    this.player = context.player;
    this.machine = context.machine;
    this.correlationId = context.correlationId;
  }

  public async startRound(betData: RouletteBet): Promise<RoundEntity> {
    const { totalBet } = Object.values(betData)
      .flat()
      .reduce((acc, bet) => {
        acc.totalBet = acc.totalBet.plus(bet);
        return acc;
      }, { totalBet: new BigNumber(0) });

    const betInValue = totalBet.dp(2)
      .toNumber();
    const betInCash = toCash(betInValue, this.session.currencyConversionRate);

    const round = await this.createRound(RoundType.REGULAR, betInValue, betInCash);
    await this.placeBet(betInCash, `${round.id}`, betData);

    await this.sessionRepo.countNewRound(this.session.id, betInValue, betInCash, 0, 1);
    await this.playerRepo.countBet(this.player.cid, this.operator.id, betInValue);

    const roundStartMessage = await this.getRoundStartedMessage(round);
    this.playerPublisher.sessionState(this.session.id, { status: this.session.status });
    this.playerPublisher.notifyRoundStart(this.session.id, roundStartMessage);
    this.monitoringService.sendEventLogMessage({
      eventType: EventType.START_ROUND,
      source: EventSource.GAME,
      params: {
        type: round.type,
        sessionId: this.session.id,
        machineSerial: this.machine.serial,
        round: round.id,
      },
    });
    return round;
  }

  public async getRoundStartedMessage(
    round: RoundEntity,
  ): Promise<RoundStartedDto> {
    const stackBuyLimit = new BigNumber(this.session.configuration.stackBuyLimit)
      .minus(this.session.totalStacksUsed)
      .minus(1)
      .toNumber();
    let rounds = Number(this.session.roundsLeft);
    let betBehindRounds = 0;
    if (round.type === RoundType.BET_BEHIND) {
      rounds = this.session.roundsLeft;
      const { betBehind } = await this.sessionDataManager.getSessionData(this.session.id);
      betBehindRounds = betBehind?.stopAfterRounds ? new BigNumber(betBehind.stopAfterRounds)
        .minus(1)
        .toNumber() : 0;
    }
    return {
      type: round.type,
      stackBuyLimit,
      rounds,
      betBehindRounds,
      totalBet: round.betInCash,
    };
  }

  private createRound(
    type: RoundType, bet: number, betInCash: number, status = RoundStatus.ACTIVE,
  ): Promise<RoundEntity> {
    const round = this.roundRepo.create({
      type,
      status,
      bet,
      betInCash,
      session: this.session,
      machineId: this.machine.id,
    });
    return this.roundRepo.save(round, { transaction: false });
  }

  private async placeBet(betInCash: number, roundId: string, betDetails: RouletteBet): Promise<void> {
    const {
      loginOptions: {
        sessionToken,
        extGameId,
      },
    } = await this.sessionDataManager.getSessionData(this.session.id);

    try {
      const {
        transactionId,
        balance,
      } = await this.operatorClient.bet({
        accessToken: sessionToken,
        operator: this.operator,
        cid: this.player.cid,
        amount: betInCash,
        roundId,
        correlationId: this.correlationId,
        gameId: this.session.gameId,
        extGameId,
      });
      await this.sessionDataManager.updateSessionData({
        transaction: {
          roundId,
          transactionId,
        },
      }, this.session.id);
      this.playerPublisher.notifyBalance(this.session.id, { valueInCash: balance });
      this.monitoringService.sendEventLogMessage({
        eventType: EventType.BET,
        source: EventSource.GAME,
        params: {
          betDetails,
          sum: betInCash,
          sessionId: Number(this.session.id),
          round: Number(roundId),
          machineSerial: this.machine.serial,
          currency: this.session.currency,
          transactionId,
        },
      });
    } catch (err) {
      await this.roundRepo.delete(roundId);
      this.logger.error('Bet error', {
        sessionId: Number(this.session.id),
        operator: this.operator.apiConnectorId,
        errorMessage: err instanceof OperatorException ? err.getResponse() : err.message,
        correlationId: this.correlationId,
        stack: err.stack,
      });
      if (err instanceof OperatorException
        && err.getResponse().type === OperatorErrorType.INSUFFICIENT_FUNDS) {
        this.playerPublisher.notification(this.session.id,
          {
            notificationId: NotificationType.INSUFFICIENT_FUNDS,
            level: NotificationLevel.WARNING,
            title: 'Insufficient funds',
            message: 'Insufficient funds',
            data: { canBuy: 0 },
          });
      } else {
        this.playerPublisher.notification(this.session.id,
          {
            notificationId: NotificationType.BET_FAILED,
            level: NotificationLevel.ERROR,
            title: 'Bet failed',
            message: 'Oops, something went wrong with your wallet!',
          });
      }
      this.monitoringService.sendAlertMessage({
        alertType: AlertType.ERROR,
        severity: AlertSeverity.HIGH,
        source: AlertSource.GAME_CORE,
        description: 'Bet failed on round start',
        gameId: this.machine.gameId,
        details: {
          sessionId: this.session.id,
          machineId: this.machine.id,
          machineName: this.machine.name,
          machineSerial: this.machine.serial,
          error: err.message,
        },
      });
      throw err;
    }
  }
}
