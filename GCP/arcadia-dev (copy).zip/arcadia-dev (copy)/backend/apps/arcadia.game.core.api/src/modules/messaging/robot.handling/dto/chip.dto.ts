import { Length } from 'class-validator';
import { RobotMessage } from './robot.message';

export class ChipDto extends RobotMessage {
  @Length(1)
  public rfid: string;

  @Length(1)
  public dispenser: string;
}
