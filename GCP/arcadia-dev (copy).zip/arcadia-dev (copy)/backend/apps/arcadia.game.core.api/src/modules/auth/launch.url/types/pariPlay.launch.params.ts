import { GameId } from '@lib/dal';
import { LaunchParams } from './launch.params';

export class PariPlayLaunchParams extends LaunchParams {
  token: string;
  gameCode: GameId;
  currencyCode: string;
  isReal: string;
  languageCode: string;
  homeUrl: string;
  cashierUrl: string;
  historyUrl: string;
}
