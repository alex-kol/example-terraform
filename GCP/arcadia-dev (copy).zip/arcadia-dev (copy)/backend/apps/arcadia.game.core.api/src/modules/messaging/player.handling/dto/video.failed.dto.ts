import { ArrayMaxSize, IsNumber } from 'class-validator';
import { Transform } from 'class-transformer';
import { arrayTransformer } from '@lib/dal';
import { SessionAwareDto } from '../../../dto/session.aware.dto';

export class VideoFailedDto extends SessionAwareDto {
  @Transform(arrayTransformer)
  @ArrayMaxSize(10)
  @IsNumber({ maxDecimalPlaces: 2 }, { each: true })
  public connectionSpeedKbps: number[];
}
