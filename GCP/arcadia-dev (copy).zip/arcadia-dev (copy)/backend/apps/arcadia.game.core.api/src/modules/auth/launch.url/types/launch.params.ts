import { OperatorTag } from '@lib/common';

export class LaunchParams {
  operator: OperatorTag;
  callerIp: string;
  groupId?: number;
}
