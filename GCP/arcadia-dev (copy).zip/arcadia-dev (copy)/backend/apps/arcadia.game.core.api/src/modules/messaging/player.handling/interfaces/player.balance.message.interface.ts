export interface PlayerBalanceMessageInterface {
  valueInCash: number;
}
