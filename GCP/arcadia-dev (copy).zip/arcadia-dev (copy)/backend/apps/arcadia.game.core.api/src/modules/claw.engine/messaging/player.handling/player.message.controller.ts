/* eslint-disable max-lines */
import {
  LoggerInterceptor,
  NewrelicAndMessagePattern,
  PlayerMessageType,
  RmqQueueName,
  rmqRoutingGenerate,
  RpcMainExceptionFilter,
  rpcValidationExceptionFactory,
} from '@lib/common';
import { GameId } from '@lib/dal';
import {
  Controller, UseFilters, UseInterceptors, UsePipes, ValidationPipe,
} from '@nestjs/common';
import { Payload } from '@nestjs/microservices';
import { PlayerMessageService } from './player.message.service';
import { SessionAwareDto } from '../../../dto/session.aware.dto';
import { PlayerMoveMessageDto } from '../../types/player.move.message.dto';

@Controller('v1/player')
@UseInterceptors(LoggerInterceptor)
@UseFilters(RpcMainExceptionFilter)
@UsePipes(new ValidationPipe({
  transform: true,
  whitelist: true,
  exceptionFactory: rpcValidationExceptionFactory,
}))
export class PlayerMessageController {
  constructor(
    private readonly messageHandler: PlayerMessageService,
  ) {
  }
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.READY_FOR_NEXT_ROUND, GameId.CLAW))
  public async readyForRound(@Payload() data: SessionAwareDto): Promise<void> {
    await this.messageHandler.readyForRound(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.MOVE, GameId.CLAW))
  public async move(@Payload() data: PlayerMoveMessageDto): Promise<void> {
    await this.messageHandler.move(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.STOP, GameId.CLAW))
  public async stop(@Payload() data: SessionAwareDto): Promise<void> {
    await this.messageHandler.stop(data);
  }
}
