import { CommandType } from '@lib/common';
import {
  GroupRepository, GroupStatus, MachineEntity, MachineRepository, MachineStatus, QueueRepository, QueueStatus,
} from '@lib/dal';
import { Injectable } from '@nestjs/common';
import { FindOptionsWhere, In, Not } from 'typeorm';
import { CommandPublisher } from '../../command/command.publisher';
import { RouletteEventCommand } from '../../command/dto/roulette.event.command';
import { RouletteEventType } from '../../roulette.engine/enums';
import { RouletteHardStopData } from '../../roulette.engine/types';
import { GroupTerminator } from './group.terminator';

@Injectable()
export class ClawRouletteGroupTerminator extends GroupTerminator {
  constructor(
    private readonly commandPublisher: CommandPublisher,
    private readonly machineRepo: MachineRepository,
    private readonly groupRepo: GroupRepository,
    private readonly queueRepository: QueueRepository,
  ) {
    super();
  }

  async groupSoftStop(groupId: number, machineIds?: number[], correlationId?: string): Promise<void> {
    const machines = await this.getActiveMachineByGroupId(groupId, machineIds);

    if (!machineIds?.length) {
      await this.groupRepo.update(groupId, { status: machines.length ? GroupStatus.DRYING : GroupStatus.OFFLINE });
    }

    if (machines.length) {
      const ids: number[] = [];
      machines.forEach(({
        serial,
        id,
      }) => {
        this.commandPublisher.sendRouletteCommand<RouletteEventCommand>(
          {
            type: CommandType.ROULETTE_EVENT,
            serial,
            eventType: RouletteEventType.SOFT_STOP,
          },
          correlationId);
        ids.push(id);
      });
      await this.queueRepository.update({ machine: { id: In(ids) } }, { status: QueueStatus.DRYING });
    }
  }

  async groupHardStop(groupId: number, data, correlationId?: string): Promise<void> {
    const {
      machineIds,
      reason,
    } = data;

    const machines = await this.getActiveMachineByGroupId(groupId, machineIds);

    if (!machineIds?.length) {
      await this.groupRepo.update(groupId, { status: GroupStatus.OFFLINE });
    }

    machines.length && machines.forEach(({ serial }) => this.commandPublisher.sendRouletteCommand<RouletteEventCommand<RouletteHardStopData>>(
      {
        type: CommandType.ROULETTE_EVENT,
        serial,
        eventType: RouletteEventType.HARD_STOP,
        data: { reason },
      },
      correlationId));
  }

  private async getActiveMachineByGroupId(groupId: number, machineIds?: number[]): Promise<Pick<MachineEntity, 'serial' | 'id'>[]> {
    const where: FindOptionsWhere<MachineEntity> = {
      group: { id: groupId },
      status: Not(In([MachineStatus.SHUTTING_DOWN, MachineStatus.STOPPED, MachineStatus.OFFLINE, MachineStatus.ERROR])),
    };

    if (machineIds?.length) {
      where.id = In(machineIds);
    }

    return this.machineRepo.find({
      where,
      select: ['serial', 'id'],
    });
  }
}
