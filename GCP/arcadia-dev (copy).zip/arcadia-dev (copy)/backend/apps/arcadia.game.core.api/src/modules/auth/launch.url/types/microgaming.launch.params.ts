import { MicrogamingClients, MicrogamingEnv } from '@lib/common';
import { GameId } from '@lib/dal';
import { LaunchParams } from './launch.params';

export class MicrogamingLaunchParams extends LaunchParams {
  siteid: MicrogamingEnv;
  sessiontoken: string;
  playmode: 'real' | 'demo';
  gameid: GameId;
  clientid: MicrogamingClients;
  lang?: string;
  lobbyurl?: string;
  serverid?: string;
  casinoid?: string;
  bingoroom?: string;
  chatroom?: string;
  skin?: string;
}
