import { IsInt } from 'class-validator';
import { RobotMessage } from './robot.message';

export class RobotCoinDto extends RobotMessage {
  @IsInt()
  public remaining: number;
}
