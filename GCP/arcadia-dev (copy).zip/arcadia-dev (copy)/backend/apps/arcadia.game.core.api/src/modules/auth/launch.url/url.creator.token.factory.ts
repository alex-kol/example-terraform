import { OperatorTag } from '@lib/common';

export const urlCreatorTokenFactory = (apiConnectorId: OperatorTag): string => `${apiConnectorId.toUpperCase()}_URL_CREATOR_INJECT_TOKEN`;
