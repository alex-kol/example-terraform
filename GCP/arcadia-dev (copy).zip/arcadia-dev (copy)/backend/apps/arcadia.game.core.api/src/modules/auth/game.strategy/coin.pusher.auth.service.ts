/* eslint-disable max-lines */
import {
  Cache, CacheClear, ConversionDto, EventSource, PlayerQueueStrategy, QueueStrategyInfoProvider, TimeoutType,
} from '@lib/common';
import { ConfigService } from '@lib/config';
import {
  ChipRepository,
  CurrencyConversionRepository,
  EventType,
  GameId,
  GroupEntity,
  GroupRepository,
  MachineEntity,
  MachineRepository,
  OperatorRepository,
  PlayerEntity,
  PlayerId,
  PlayerRepository,
  RngChipPrizeRepository,
  RngPhantomPrizeRepository,
  RoundRepository,
  RoundType,
  SessionEndReason,
  SessionEntity,
  SessionRepository,
  SessionStatus,
  SortOrder,
  VoucherRepository,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { EventLogData, MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import {
  HttpStatus, Inject, Injectable, NotAcceptableException, NotFoundException, UnauthorizedException,
} from '@nestjs/common';
import BigNumber from 'bignumber.js';
import * as _ from 'lodash';
import moment from 'moment';
import { from, lastValueFrom, of } from 'rxjs';
import {
  concatMap, repeat, take, toArray,
} from 'rxjs/operators';
import { Logger } from 'winston';
import { LOBBY_LONG_POLLING_INTERVAL_SEC } from '../../../constants/game.client';
import { NotificationException } from '../../../filters/notification.exception';
import { toCash } from '../../../util';
import { ConfigValidator } from '../../config.validator/config.validator';
import { ConversionTracker } from '../../conversion.tracker/conversion.tracker';
import { EntrySource } from '../../conversion.tracker/entry.source';
import { IpChecker } from '../../ip.checker/ip.checker';
import { getRobotDirectRoom, getRobotQueueRoom, sessionRoomNameFactory } from '../../messaging/room.name.template';
import { NotificationLevel } from '../../player.client/notification.level';
import { NotificationType } from '../../player.client/notification.type';
import { PlayerClientService } from '../../player.client/player.client.service';
import { SessionDataManager } from '../../session.data.manager/session.data.manager';
import { sessionCacheKeyFactory } from '../../session/session.cache.key.factory';
import { getSessionHash } from '../../session/session.hash';
import { SessionService } from '../../session/session.service';
import { WorkerClientService } from '../../worker.client/worker.client.service';
import { AuthService } from '../auth.service';
import { GROUP_NOT_ASSIGNED, GROUP_WITHOUT_MACHINE } from '../constants';
import { LoginReconnectDto } from '../dtos';
import { GameAuthHandler, LoginOptions } from '../interfaces';
import { CoinPusherLobbyRes, CoinPusherReconnectVerifyRes, CoinPusherVerifyResp } from '../responses';

@Injectable()
export class CoinPusherAuthService extends GameAuthHandler {
  constructor(
    private readonly machineRepository: MachineRepository,
    private readonly groupRepository: GroupRepository,
    private readonly playerRepository: PlayerRepository,
    private readonly operatorRepository: OperatorRepository,
    private readonly sessionRepository: SessionRepository,
    private readonly currencyConversionRepo: CurrencyConversionRepository,
    private readonly rngChipPrizeRepository: RngChipPrizeRepository,
    private readonly rngPhantomPrizeRepository: RngPhantomPrizeRepository,
    private readonly roundRepository: RoundRepository,
    private readonly voucherRepository: VoucherRepository,
    private readonly chipRepository: ChipRepository,
    private readonly sessionService: SessionService,
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly configService: ConfigService,
    private readonly monitoringClient: MonitoringWorkerClientService,
    private readonly sessionDataManager: SessionDataManager,
    private readonly ipChecker: IpChecker,
    private readonly configValidator: ConfigValidator,
    private readonly conversionTracker: ConversionTracker,
    private readonly queueStrategyInfoProvider: QueueStrategyInfoProvider,
    private readonly authService: AuthService,
    private readonly workerClient: WorkerClientService,
    private readonly playerClientService: PlayerClientService,
  ) {
    super();
  }

  public async loginPlayer(token: string, lobbyGroupId: number, footprint: string): Promise<CoinPusherVerifyResp> {
    const existingSession = await this.sessionRepository.findOne({
      where: { footprint },
      order: { createDate: SortOrder.DESC },
      relations: ['player', 'operator'],
    });
    const player = await this.authService.getPlayerForSession(token, existingSession);

    const { operator } = player;

    const [{ spilloverGroupId: groupId }] = await this.groupRepository.getLobbyAndChangeBetGroupData(operator.id, player.cid, lobbyGroupId);

    const gto = operator.groupToOperator?.find(gto => gto.group?.id === groupId);

    if (!gto) {
      throw new NotAcceptableException(GROUP_NOT_ASSIGNED);
    }

    const {
      group,
      machine,
      spilloverEventLogMessage,
    } = await this.getTargetForSession(Number(operator.id), groupId, player.cid, !!existingSession);
    if (!machine) {
      throw new NotAcceptableException(GROUP_WITHOUT_MACHINE);
    }
    const sessionConfig = await this.configValidator.getValidatedConfig(machine.serial, operator.id);

    if (token !== 'token') { // login case (non change bet case)
      await this.authService.parallelSessionCheck(player, sessionConfig.maxConcurrentSessions, GameId.COIN_PUSHER_V1);
    }

    const {
      sessionOptions,
      loginOptions,
    } = await this.authService.getSessionOptions(token, existingSession);

    if (existingSession && token === 'token') {
      await this.conversionTracker.createTracker(player, EntrySource.CHANGE_BET, {
        ...loginOptions,
        sessionToken: null,
      } as LoginOptions);
      await this.conversionTracker.closeTracker(player, {
        sessionId: existingSession.id,
        groupId,
      });
    }

    sessionOptions.configuration = sessionConfig;
    sessionOptions.footprint = footprint;
    const { currencies } = sessionConfig;
    if (!currencies.includes(sessionOptions.currency.toUpperCase())) {
      throw new NotificationException({
        notificationId: NotificationType.CURRENCY_NOT_SUPPORTED,
        level: NotificationLevel.ERROR,
        title: 'Error',
        message: `Currency "${sessionOptions.currency}" is not supported!`,
        command: 'goToLobby',
      }, HttpStatus.NOT_ACCEPTABLE);
    }
    if (!(await this.ipChecker.verifyIp(sessionOptions.playerIP as string,
      sessionOptions.configuration.countryWhitelist))) {
      throw new NotificationException({
        notificationId: NotificationType.IP_ADDRESS_FORBIDDEN,
        level: NotificationLevel.ERROR,
        title: 'Error',
        message: 'IP-address is forbidden!',
        command: 'goToLobby',
      }, HttpStatus.NOT_ACCEPTABLE);
    }
    const convRate = await this.currencyConversionRepo.getCurrencyConversion(sessionOptions.currency);

    if (existingSession) {
      await this.terminateParentOnChangeBet(existingSession);
    }

    sessionOptions.currencyConversionRate = Number(convRate.rate);

    const streams = await this.authService.getCamerasStreams(machine);

    const session = await this.sessionService.createSession({
      ...sessionOptions,
      operator,
      player,
      group,
      machine,
      queue: machine.queue,
      denominator: group.denominator,
      cameraIds: machine.cameras.map(({ cameraId }) => cameraId).join(','),
    });
    await this.conversionTracker.closeTracker(player, {
      sessionId: session.id,
      groupId: group.id,
    });
    const updateUserData: Partial<PlayerEntity> = { lastSessionDate: new Date() };
    if (player.firstSessionDate === null) {
      updateUserData.firstSessionDate = new Date();
    }

    if (gto.isNewPlayerVoucher && !player.isVoucherAwarded) {
      const checkExistVoucher = await this.voucherRepository.findOneBy({
        group: { id: group.id },
        operator: { id: operator.id },
        player: {
          cid: player.cid,
          operatorId: player.operatorId,
        },
      });
      if (!checkExistVoucher) {
        const voucher = this.voucherRepository.create({
          expirationDate: moment()
            .add(1, 'week')
            .toDate(),
          operator,
          player,
          group,
          session,
        });
        await this.voucherRepository.insert(voucher);
      }
      updateUserData.isVoucherAwarded = true;
    }

    await this.playerRepository.update({
      cid: player.cid,
      operatorId: operator.id,
    }, updateUserData);
    await this.sessionDataManager.updateSessionData({ loginOptions }, session.id);

    const tableState = await this.chipRepository.getTableState(machine.id);
    this.monitoringClient.sendEventLogMessage({
      eventType: EventType.SESSION_CREATED,
      source: EventSource.GAME,
      params: {
        sessionId: session.id,
        machineSerial: machine.serial,
        groupId: group.id,
        videoUrl: JSON.stringify(streams),
        tableState,
        tableChipCount: tableState.length,
      },
    });
    if (spilloverEventLogMessage) {
      spilloverEventLogMessage.params.sessionId = session.id;
      this.monitoringClient.sendEventLogMessage(spilloverEventLogMessage);
    }
    return this.loginReconnectDataMapper({
      session,
      player,
      machine,
      group,
      operator,
      streams,
    });
  }

  @Cache({ ttl: LOBBY_LONG_POLLING_INTERVAL_SEC - 1 }, args => (`lobby-request-${args[0].token}`))
  public async handleLobby({
    token,
    clicks,
    swipes,
  }: ConversionDto): Promise<CoinPusherLobbyRes> {
    const {
      operatorId,
      cid,
    } = await this.authService.verifyAuthToken(token);
    const operator = await this.operatorRepository.findOneByOrFail({ id: operatorId })
      .catch(() => {
        throw new NotFoundException(`Operator id=${operatorId} not found!`);
      });
    const { sessionOptions } = await this.authService.getSessionOptions(token)
      .catch(() => {
        throw new UnauthorizedException('Token is stale or not valid!');
      });

    await this.conversionTracker.track({
      cid,
      operatorId,
    }, {
      clicks,
      swipes,
    });

    const convRate = await this.currencyConversionRepo.getCurrencyConversion(sessionOptions.currency);
    const { isVoucherAwarded } = await this.playerRepository.findOne({
      select: ['isVoucherAwarded'],
      where: {
        cid,
        operatorId,
      },
    });

    const groups = await this.groupRepository.getLobbyAndChangeBetGroupData(operator.id, cid);

    const groupsMapped = await lastValueFrom(from(groups)
      .pipe(
        concatMap(async group => {
          const config = { ...group.machineConfig, ...group.groupConfig };
          const highestPhantomValue = await this.rngPhantomPrizeRepository.getHighestPhantomValue(group.prizeGroup, config.rtpSegment);
          const highestChipValue = await this.rngChipPrizeRepository.getHighestChipValue(group.prizeGroup, config.rtpSegment);

          const payTable = [];
          highestPhantomValue && payTable.push(highestPhantomValue);
          highestChipValue && payTable.push(highestChipValue);

          return {
            groupId: group.groupId,
            groupName: group.groupName,
            groupDisplayName: group.groupDisplayName,
            queueLength: group.queueLength,
            betInCash: toCash(group.denominator, convRate.rate),
            currency: convRate.currency,
            color: group.color,
            hasVoucher: Boolean(group.hasVoucher || (!isVoucherAwarded && group.isNewPlayerVoucher)),
            payTable,
          };
        }),
        toArray(),
      ));
    return {
      groups: groupsMapped,
    };
  }

  @CacheClear(args => sessionCacheKeyFactory(args[0]))
  public async verifyReconnect(sessionId: number, footprint: string): Promise<CoinPusherReconnectVerifyRes> {
    const session = await this.sessionRepository.findOne({
      where: {
        id: sessionId,
        footprint,
      },
      relations: ['machine', 'machine.dispensers', 'machine.dispensers.chipType',
        'group', 'operator', 'player', 'rounds', 'machine.site', 'machine.cameras'],
    });
    if (!session
      || session.status === SessionStatus.TERMINATED
      || session.status === SessionStatus.TERMINATING
      || session.status === SessionStatus.COMPLETED) {
      const activeOrArchived = session || await this.authService.getArchiveSession(sessionId);
      if (activeOrArchived) {
        throw new NotificationException({
          notificationId: NotificationType.SESSION_COMPLETED,
          level: NotificationLevel.INFO,
          title: 'Session completed',
          message: 'Your session has been completed in autoplay mode',
          command: 'goToLobby',
          data: {
            totalWinInCash: activeOrArchived.totalWinInCash,
            currency: activeOrArchived.currency,
          },
        }, HttpStatus.GONE);
      }
      throw new NotFoundException('Session not found');
    }

    const {
      group,
      machine,
      player,
      operator,
    } = session;
    const activeRound = session.getActiveRound();
    if (activeRound?.type === RoundType.BET_BEHIND) {
      const activeRoundFromMachine = await this.roundRepository.getActiveRoundForMachine(machine.id);
      if (activeRoundFromMachine) {
        activeRound.coins = activeRoundFromMachine.coins;
      }
    }

    const streams = await this.authService.getCamerasStreams(machine);

    return this.loginReconnectDataMapper<CoinPusherReconnectVerifyRes>({
      session,
      player,
      machine,
      group,
      operator,
      streams,
      activeRound,
      isReconnect: true,
    });
  }

  private async loginReconnectDataMapper<T extends CoinPusherVerifyResp | CoinPusherReconnectVerifyRes>(
    params: LoginReconnectDto,
  ): Promise<T> {
    const {
      session,
      player,
      machine,
      group,
      operator,
      streams,
      activeRound,
      isReconnect,
    } = params;
    const { configuration: config } = session;
    const phantomWinValues = await this.getWheelData(group.denominator, group.prizeGroup, session.currencyConversionRate, config.rtpSegment);

    const bigWinThresholdInCash = config.bigWinThreshold && toCash(
      new BigNumber(config.bigWinThreshold).multipliedBy(group.denominator),
      session.currencyConversionRate);

    let result: CoinPusherVerifyResp | CoinPusherReconnectVerifyRes = {
      playerId: player.cid,
      sessionId: session.id,
      gameId: session.gameId,
      settings: player.settings[session.gameId],
      sessionStatus: session.status,
      balance: await this.authService.getBalance(session, operator, player),
      currency: session.currency,
      locale: session.locale,
      stackSize: group.stackSize,
      stackBuyLimit: new BigNumber(config.stackBuyLimit).minus(session.totalStacksUsed)
        .toNumber(),
      playerDirectRoomId: sessionRoomNameFactory(session.id),
      robotDirectRoomId: getRobotDirectRoom(machine.serial, `${session.id}`),
      robotQueueRoomId: getRobotQueueRoom(machine.serial),
      video: {
        streams,
        streamAuthToken: await this.authService.getStreamAuthToken(session),
        cropConfig: config.videoCrop,
      },
      machineId: machine.id,
      graceTimeoutSec: group.graceTimeout,
      autoplayConfig: config.autoplay,
      betBehindConfig: config.betBehind,
      phantomWidgetType: config.phantomWidgetType,
      slotConfig: config.slot,
      payTable: (await this.rngChipPrizeRepository
        .getPayTable(session.currencyConversionRate, group.prizeGroup, config.rtpSegment, group.denominator)),
      machineName: machine.name,
      groupName: group.name,
      groupDisplayName: group.groupDisplayName,
      betInCash: toCash(group.denominator, session.currencyConversionRate),
      phantomWinValues,
      activeRound: activeRound && _.pick(activeRound, 'type', 'coins', 'voucherId', 'wins'),
      groupColor: group.color,
      phantomWidgetAnimationDurationMS: Number(this.configService
        .get(['core', 'PHANTOM_WIDGET_ANIMATION_DURATION_MS'])),
      machineSerial: machine.serial,
      operatorId: operator.id,
      groupId: group.id,
      bigWinThresholdInCash: bigWinThresholdInCash || null,
      toastChipAdded: config.toastChipAdded,
      gameMode: config.gameMode,
    };

    if (!isReconnect) {
      const vouchers = await this.voucherRepository.getVouchersForSession(operator.id, group.id, player.cid);
      result.freeTokens = vouchers.length
        ? new BigNumber(vouchers.length)
          .multipliedBy(group.stackSize)
          .integerValue()
          .toNumber()
        : undefined;
    }

    if (isReconnect) {
      await this.playerClientService.forceClientClose(session.id);
      const {
        betBehind,
        autoplay,
      } = await this.sessionDataManager.getSessionData(session.id);

      result = {
        ...result,
        sessionStatus: autoplay?.forced ? SessionStatus.FORCED_AUTOPLAY : session.status,
        rounds: session.roundsLeft,
        betBehindRounds: (typeof betBehind?.stopAfterRounds === 'number') ? betBehind.stopAfterRounds : 0,
        coins: activeRound?.coins || 0,
        queueToken: getSessionHash(session),
        joinRobotDirectRoom: (session.status !== SessionStatus.VIEWER_BET_BEHIND),
        totalWin: session.totalWinInCash,
      };
    }
    return result as T;
  }

  private async getMachineData(
    group: GroupEntity,
    playerId: PlayerId,
  ): Promise<{ machine: MachineEntity; queueLength: number; skipSpillover: boolean }> {
    const {
      queueStrategy,
      machineSerials,
    } = await this.queueStrategyInfoProvider.getQueueStrategyInfo(playerId);
    let machineData: { machine: MachineEntity; queueLength: number; } = null;
    const maxSessionsThreshold = this.authService.getMaxSessionsThreshold(group.configuration.maxSessionsThreshold);

    if (queueStrategy === PlayerQueueStrategy.SPAMMING) {
      machineData = await this.machineRepository.getMachineForNewSessionWherePlayerSpammer(group.id, maxSessionsThreshold, playerId);
    }

    if (queueStrategy === PlayerQueueStrategy.AMBUSHING) {
      if (machineSerials.length) {
        machineData = await this.machineRepository.getMachineForNewSessionWherePlayerAmbusher(group.id, maxSessionsThreshold, machineSerials);
      }
    }

    const skipSpillover = !!machineData;

    if (!machineData) {
      machineData = await this.machineRepository.getMachineForNewSession(group.id, maxSessionsThreshold, playerId);
    }

    return machineData ? {
      ...machineData,
      skipSpillover,
    } : null;
  }

  private async getTargetForSession(
    operatorId: number, groupId: number, playerCid: string, isReconnect: boolean,
  ): Promise<{ group: GroupEntity, machine: MachineEntity, spilloverEventLogMessage?: EventLogData }> {
    const group = await this.groupRepository.findOneOrFail({
      where: { id: groupId },
      relations: ['groupToOperator', 'groupToOperator.operator', 'machines'],
    });

    const machineData = await this.getMachineData(group, {
      operatorId,
      cid: playerCid,
    });

    if (!machineData) {
      throw new NotAcceptableException('No machine for session');
    }
    if (!isReconnect && !machineData.skipSpillover) {
      try {
        const gto = group.groupToOperator?.find(value => Number(value.operator?.id) === operatorId);
        if (machineData.queueLength >= gto?.spilloverThreshold) {
          const machineId = await this.groupRepository
            .getSpilloverMachine(operatorId, group.denominator, [group.id]);
          if (machineId) {
            const spillover = await this.machineRepository.findOneOrFail({
              where: { id: Number(machineId) },
              relations: ['group', 'queue', 'site'],
            });
            this.logger.debug(`spilling over from group ${group.id} to group ${spillover.group.id}`);
            const spilloverEventLogMessage: EventLogData = {
              eventType: EventType.GROUP_SPILLOVER,
              source: EventSource.GAME,
              params: {
                operatorId,
                playerCid,
                machineSerial: null,
                settings: {
                  fromGroup: group.id,
                  toGroup: spillover.group.id,
                },
              },
            };
            return {
              machine: spillover,
              group: spillover.group,
              spilloverEventLogMessage,
            };
          }
        }
        this.logger.debug('Spillover skipped');
      } catch (e) {
        this.logger.error('spillover failed, falling back to original group', e);
      }
    }
    return {
      group,
      machine: machineData.machine,
    };
  }

  private async terminateParentOnChangeBet(session: SessionEntity): Promise<void> {
    const [{ transaction }] = await Promise.all([
      this.sessionDataManager.getSessionData(session.id),
      this.sessionRepository.update(session.id, { isDenominationChanged: true }),
    ]);
    if (!transaction) {
      if (session.status === SessionStatus.VIEWER || session.status === SessionStatus.VIEWER_BET_BEHIND) {
        await this.sessionService.finalizeSession(session.id, SessionEndReason.CHANGE_BET);
      } else if (session.status === SessionStatus.RE_BUY) {
        await this.workerClient.timeoutStart({
          timeoutType: TimeoutType.REBUY,
          sessionId: Number(session.id),
          timeoutSec: 1,
          payload: { gameId: session.gameId },
        });
      }
    }
  }

  private async getWheelData(
    denominator: number, prizeGroup: string, currencyConvRate: number, rtpSegment: string, wheelSize = 30,
  ): Promise<number[]> {
    const phantomPrizes = await this.rngPhantomPrizeRepository.getPhantomPrizes(prizeGroup, rtpSegment);
    if (!phantomPrizes?.length) {
      return [];
    }
    const prizes: { prizeValue: number; probability: number; }[] = phantomPrizes
      .map(value => ({
        prizeValue: value.prize_value
          ? toCash(new BigNumber(value.prize_value).multipliedBy(denominator)
            .dp(2), currencyConvRate)
          : -1,
        probability: Number(value.probability),
      }))
      .sort((a, b) => a.probability - b.probability);
    const result = await lastValueFrom(from(prizes)
      .pipe(
        concatMap(prize => {
          const quantity = Math.round(prize.probability * wheelSize) || 1;
          return of(prize.prizeValue)
            .pipe(repeat(quantity));
        }),
        take(wheelSize),
        toArray(),
      ));
    while (result.length < wheelSize) {
      result.push(result[result.length - 1]);
    }
    return result;
  }
}
