export function rebuyExpSkipKeyFactory(sessionId: number): string {
  return `rebuy-exp-skip-key-${sessionId}`;
}