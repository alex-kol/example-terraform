import { GameId, TransactionStatus, TransactionType } from '@lib/dal';
import {
  IsEnum, IsInt, IsNumber, IsOptional, IsString,
} from 'class-validator';

export class RetryTransactionCommand {
  @IsInt()
  public operatorId: number;

  @IsString()
  public playerCid: string;

  @IsNumber()
  public amountInCash: number;

  @IsString()
  public roundId: string;

  @IsString()
  public sessionToken: string;

  @IsEnum(TransactionType)
  public transactionType: TransactionType;

  @IsOptional()
  @IsString()
  public originalTransactionId?: string;

  @IsOptional()
  @IsEnum(TransactionStatus)
  public status?: TransactionStatus;

  @IsOptional()
  @IsInt()
  public retries?: number;

  @IsOptional()
  @IsInt()
  public sessionId?: number;

  @IsEnum(GameId)
  public gameId: GameId;

  @IsOptional()
  @IsString()
  public extGameId?: string;
}
