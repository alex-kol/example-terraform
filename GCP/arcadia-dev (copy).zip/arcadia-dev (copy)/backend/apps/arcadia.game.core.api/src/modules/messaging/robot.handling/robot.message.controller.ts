/* eslint-disable max-lines */
import {
  CommandType,
  LoggerInterceptor,
  NewrelicAndMessagePattern,
  RmqQueueName,
  rmqRoutingGenerate,
  RobotMessageType,
  RpcMainExceptionFilter,
  rpcValidationExceptionFactory,
} from '@lib/common';
import { GameId } from '@lib/dal';
import {
  Controller, Get, Query, UseFilters, UseGuards, UseInterceptors, UsePipes, ValidationPipe,
} from '@nestjs/common';
import { Payload } from '@nestjs/microservices';
import { ThrottlerGuard } from '@nestjs/throttler';
import { EngageSessionCommand } from '../../command/dto/engage.session.command';
import { SessionInjectorPipe } from '../session.injector.pipe';
import {
  AddBallDto, ChipDto, RobotMessage, RobotPositionDto, RobotWorkingHoursDto,
} from './dto';
import { PlayerAbuseDto } from './dto/player.abuse.dto';
import { RobotLoginDto } from './dto/robot.login.dto';
import { RobotMessageService } from './robot.message.service';
import { RobotLoginRes } from './responses/robot.login.res';
import { SessionAwareDto } from '../../dto/session.aware.dto';

@Controller('v1/robots')
@UseInterceptors(LoggerInterceptor)
@UseFilters(RpcMainExceptionFilter)
@UsePipes(new ValidationPipe({
  transform: true,
  whitelist: true,
  exceptionFactory: rpcValidationExceptionFactory,
}))
export class RobotMessageController {
  constructor(private readonly messageHandler: RobotMessageService) {
  }

  @Get('/login')
  @UseGuards(ThrottlerGuard)
  public async loginRobot(@Query() query: RobotLoginDto): Promise<RobotLoginRes> {
    return this.messageHandler.loginRobot(query);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.ENGAGED, GameId.COIN_PUSHER_V1))
  async clientEngagedHandler(@Payload() data: RobotMessage): Promise<void> {
    await this.messageHandler.handleEngaged(data);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.DISENGAGED, GameId.COIN_PUSHER_V1))
  async clientDisengagedHandler(@Payload() data: RobotMessage): Promise<void> {
    await this.messageHandler.handleDisengaged(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.SEEDING_COMPLETE, GameId.COIN_PUSHER_V1))
  async seedCompleteHandler(@Payload() data: RobotMessage): Promise<void> {
    await this.messageHandler.seedCompleteHandler(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.POSITION, GameId.COIN_PUSHER_V1))
  async positionHandler(@Payload() data: RobotPositionDto): Promise<void> {
    await this.messageHandler.handlePosition(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.CHIP_VALIDATION, GameId.COIN_PUSHER_V1))
  async chipValidationHandler(@Payload() data: ChipDto): Promise<void> {
    await this.messageHandler.chipPushValidation(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.CHIP_PUSHED, GameId.COIN_PUSHER_V1))
  async chipPushedHandler(@Payload() data: ChipDto): Promise<void> {
    await this.messageHandler.chipPushed(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.CHIP_REMOVED, GameId.COIN_PUSHER_V1))
  async chipRemovedHandler(@Payload() data: ChipDto): Promise<void> {
    await this.messageHandler.chipRemoved(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.PONG, GameId.COMMON))
  public pongHandler(@Payload() data: RobotMessage): Promise<void> {
    return this.messageHandler.handlePong(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.CORE_COMMAND_QUEUE, CommandType.ENGAGE_SESSION, GameId.COIN_PUSHER_V1))
  async engageSession(@Payload() data: EngageSessionCommand): Promise<void> {
    await this.messageHandler.engageNextSession(data.machineId, data.reBuySessionId, data.correlationId);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.CORE_COMMAND_QUEUE, CommandType.IDL_TIMEOUT_EXPIRED, GameId.COIN_PUSHER_V1))
  async idleTimeoutExpired(@Payload() data: SessionAwareDto): Promise<void> {
    await this.messageHandler.idleTimeoutExpired(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.WORKING_HOURS, GameId.COMMON))
  async workingHoursHandler(@Payload() data: RobotWorkingHoursDto): Promise<void> {
    await this.messageHandler.updateWorkingHours(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.PLAYER_ABUSE, GameId.COIN_PUSHER_V1))
  async playerAbuse(@Payload() data: PlayerAbuseDto): Promise<void> {
    await this.messageHandler.playerAbuse(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.ADD_BALL, GameId.CLAW_ROULETTE))
  public async addBallClawRoulette(@Payload() data: AddBallDto): Promise<void> {
    await this.messageHandler.addBallClawRoulette(data);
  }
}
