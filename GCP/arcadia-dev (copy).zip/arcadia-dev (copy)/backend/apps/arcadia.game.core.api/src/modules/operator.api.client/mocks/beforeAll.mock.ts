import { Test } from '@nestjs/testing';
import { HttpModule } from '@nestjs/axios';
import { OperatorApiClientService } from '../operator.api.client.service';
import { CommandPublisher } from '../../command/command.publisher';

export async function makeTestModule() {
  const moduleFixture = await Test.createTestingModule({
    imports: [HttpModule],
    providers: [
      OperatorApiClientService,
      {
        provide: CommandPublisher,
        useValue: {},
      }
    ],
  }).compile();
  return moduleFixture;
}
