/* eslint-disable max-lines */
import {
  LoggerInterceptor,
  NewrelicAndMessagePattern,
  PlayerMessageType,
  RmqQueueName,
  rmqRoutingGenerate,
  RpcMainExceptionFilter,
  rpcValidationExceptionFactory,
} from '@lib/common';
import { GameId } from '@lib/dal';
import {
  Controller, UseFilters, UseInterceptors, UsePipes, ValidationPipe,
} from '@nestjs/common';
import { Payload } from '@nestjs/microservices';
import { SessionAwareDto } from '../../dto/session.aware.dto';
import { SessionInjectorPipe } from '../session.injector.pipe';
import { BbEnableMessageDto } from './dto/bb.enable.message.dto';
import { EnableAutoplayMessageDto } from './dto/enable.autoplay.message.dto';
import { PlayerJoinedMessageDto } from './dto/player.joined.message.dto';
import { QueueBalanceDto } from './dto/queueBalanceDto';
import { SettingsUpdateMessageDto } from './dto/settings.update.message.dto';
import { VideoFailedDto } from './dto/video.failed.dto';
import { PlayerMessageService } from './player.message.service';

@Controller('v1/player')
@UseInterceptors(LoggerInterceptor)
@UseFilters(RpcMainExceptionFilter)
@UsePipes(new ValidationPipe({
  transform: true,
  whitelist: true,
  exceptionFactory: rpcValidationExceptionFactory,
}))
export class PlayerMessageController {
  constructor(
    private readonly messageHandler: PlayerMessageService,
  ) {
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.PLAYER_JOINED, GameId.COMMON))
  public userJoinedHandlerCoinPusher(@Payload() data: PlayerJoinedMessageDto): Promise<void> {
    return this.messageHandler.userJoinedHandlerCommon(data);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.PLAYER_LEFT, GameId.COMMON))
  public async userDisconnectHandler(@Payload() data: SessionAwareDto): Promise<void> {
    await this.messageHandler.userDisconnectHandler(data);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.QUIT, GameId.COIN_PUSHER_V1))
  public playerQuit(@Payload() data: SessionAwareDto): Promise<void> {
    return this.messageHandler.pusherPlayerQuit(data);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.LEAVE_QUEUE, GameId.COMMON))
  public async playerLeaveQueue(@Payload() data: SessionAwareDto): Promise<void> {
    await this.messageHandler.leaveQueue(data);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.CANCEL_STACKS, GameId.COIN_PUSHER_V1))
  public async playerCancelStacks(@Payload() data: SessionAwareDto): Promise<void> {
    await this.messageHandler.cancelStacks(data.session);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.ENABLE_AUTOPLAY, GameId.COIN_PUSHER_V1))
  public async enableAutoplayHandler(@Payload() data: EnableAutoplayMessageDto): Promise<void> {
    await this.messageHandler.enableAutoplayHandler(data);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.DISABLE_AUTOPLAY, GameId.COIN_PUSHER_V1))
  public async disableAutoplayHandler(@Payload() data: SessionAwareDto): Promise<void> {
    await this.messageHandler.disableAutoplayHandler(data);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.ENABLE_BET_BEHIND, GameId.COIN_PUSHER_V1))
  public async enableBBHandler(@Payload() data: BbEnableMessageDto): Promise<void> {
    await this.messageHandler.enableBetBehindHandler(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.DISABLE_BET_BEHIND, GameId.COIN_PUSHER_V1))
  public async disableBBHandler(@Payload() data: SessionAwareDto): Promise<void> {
    await this.messageHandler.disableBetBehindHandler(data.sessionId);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.QUEUE_BALANCE, GameId.COIN_PUSHER_V1))
  public async queueChangeDecision(@Payload() data: QueueBalanceDto): Promise<void> {
    await this.messageHandler.handleQueueBalanceDecision(data);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.LIST_BETS, GameId.COIN_PUSHER_V1))
  public async listBets(@Payload() data: SessionAwareDto): Promise<void> {
    await this.messageHandler.handleListBets(data.session);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.VOUCHER, GameId.COIN_PUSHER_V1))
  public async getVoucher(@Payload() data: SessionAwareDto): Promise<void> {
    await this.messageHandler.sendVoucher(data.session);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.READY_FOR_NEXT_ROUND, GameId.COIN_PUSHER_V1))
  public async readyForRound(@Payload() data: SessionAwareDto): Promise<void> {
    await this.messageHandler.readyForRound(data);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.VIDEO_FAILED, GameId.COMMON))
  public async videoFailed(@Payload() data: VideoFailedDto): Promise<void> {
    await this.messageHandler.videoFailed(data);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.SETTINGS_UPDATE, GameId.COMMON))
  public async updatePlayerSettings(@Payload() data: SettingsUpdateMessageDto): Promise<void> {
    await this.messageHandler.updatePlayerSettingHandler(data);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.RETURN_TO_LOBBY, GameId.COMMON))
  public async returnToLobby(@Payload() data: Pick<SessionAwareDto, 'session'>): Promise<void> {
    await this.messageHandler.returnToLobby(data);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.PLAYER_JOINED, GameId.CLAW_ROULETTE))
  public async userJoinedHandlerRoulette(@Payload() data: PlayerJoinedMessageDto): Promise<void> {
    await this.messageHandler.userJoinedHandlerRoulette(data);
  }
}
