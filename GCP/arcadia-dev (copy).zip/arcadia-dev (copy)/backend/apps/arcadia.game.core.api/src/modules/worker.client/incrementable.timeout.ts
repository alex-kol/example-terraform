import { TimeoutType } from '@lib/common';

export type IncrementableTimeout = TimeoutType.ROUND_END_DELAY | TimeoutType.IDLE;