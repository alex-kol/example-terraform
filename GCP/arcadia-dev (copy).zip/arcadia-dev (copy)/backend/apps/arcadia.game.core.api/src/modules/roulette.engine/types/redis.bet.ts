import { RouletteBet } from './roulette.bet';

export interface RedisBet {
  sessionId: number;
  bet: RouletteBet;
}
