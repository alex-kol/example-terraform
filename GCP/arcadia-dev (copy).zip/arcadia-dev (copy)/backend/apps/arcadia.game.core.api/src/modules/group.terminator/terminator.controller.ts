import {
  CommandType,
  LoggerInterceptor,
  NewrelicAndMessagePattern,
  RmqQueueName,
  rmqRoutingGenerate,
  RpcMainExceptionFilter,
  rpcValidationExceptionFactory,
} from '@lib/common';
import { GameId } from '@lib/dal';
import {
  Controller, Scope, UseFilters, UseInterceptors, UsePipes, ValidationPipe,
} from '@nestjs/common';
import { Payload } from '@nestjs/microservices';
import { FinalizeSessionCommand } from '../command/dto/finalize.session.command';
import { SessionInjectorPipe } from '../messaging/session.injector.pipe';
import { CoinPusherV1SessionTerminator } from './coin.pusher.v1.session.terminator';
import { ClawRouletteSessionTerminator } from './claw.roulette.session.terminator';
import { ClawSessionTerminator } from './claw.session.terminator';

@Controller({ path: 'v1/terminator', scope: Scope.REQUEST })
@UseInterceptors(LoggerInterceptor)
@UseFilters(RpcMainExceptionFilter)
@UsePipes(new ValidationPipe({
  transform: true,
  whitelist: true,
  exceptionFactory: rpcValidationExceptionFactory,
}), SessionInjectorPipe)
export class TerminatorController {
  constructor(
    private readonly coinPusherV1SessionTerminator: CoinPusherV1SessionTerminator,
    private readonly clawRouletteSessionTerminator: ClawRouletteSessionTerminator,
    private readonly clawSessionTerminator: ClawSessionTerminator,
  ) {}

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.CORE_COMMAND_QUEUE, CommandType.TERMINATE_SESSION, GameId.COIN_PUSHER_V1))
  public async coinPusherV1TerminateSession(@Payload() data: FinalizeSessionCommand): Promise<void> {
    await this.coinPusherV1SessionTerminator.handle(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.CORE_COMMAND_QUEUE, CommandType.TERMINATE_SESSION, GameId.CLAW_ROULETTE))
  public async clawRouletteTerminateSession(@Payload() data: FinalizeSessionCommand): Promise<void> {
    await this.clawRouletteSessionTerminator.handle(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.CORE_COMMAND_QUEUE, CommandType.TERMINATE_SESSION, GameId.CLAW))
  public async clawTerminateSession(@Payload() data: FinalizeSessionCommand): Promise<void> {
    await this.clawSessionTerminator.handle(data);
  }
}
