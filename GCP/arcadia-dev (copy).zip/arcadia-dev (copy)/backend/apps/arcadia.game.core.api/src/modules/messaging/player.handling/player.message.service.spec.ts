import { EventSource } from '@lib/common';
import {
  connectionNames,
  getRepositoryToken,
  MachineRepository,
  QueueRepository,
  RngChipPrizeRepository,
  SessionEntity,
  SessionRepository,
  SessionStatus,
  TiltMode,
} from '@lib/dal';
import { RpcException } from '@nestjs/microservices';
import { PlayerClientService } from '../../player.client/player.client.service';
import { QueueManagerService } from '../../queue.manager/queue.manager.service';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { WorkerClientService } from '../../worker.client/worker.client.service';
import { AutoplayStatus } from './enum/autoplay.status';
import { makeTestModule } from './mocks/beforeAll.mock';
import { handleIdleTimeoutSessionMock, shouldStartAutoplay } from './mocks/handleIdleTimeout.mocks';
import { shouldSendBets, shouldSendBetsBetListMock, shouldSendBetsSessionMock } from './mocks/handleListBets.mocks';
import {
  handleQueueChangedQueueMock,
  handleQueueChangedSessionMock,
  shouldAssignNewQueue,
  shouldThrowExceptionNotQueueStatus
} from './mocks/handleQueueChangeOfferAccepted.mocks';
import { shouldHandleReconnect, shouldNotifyQueueUpdate } from './mocks/userJoinedHandler.mocks';
import { shouldMarkDisconnected, } from './mocks/userLeftHandler.mocks';
import { PlayerMessageService } from './player.message.service';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';

jest.mock('../../logger/logger.service');
jest.mock('@lib/config');

describe('Player Message Service (Unit)', () => {
  let playerMessageService: PlayerMessageService;
  let monitoringsService: MonitoringWorkerClientService;
  let queueManager: QueueManagerService;
  let sessionRepository: SessionRepository;
  let machineRepository: MachineRepository;
  let rngChipPrizeRepository: RngChipPrizeRepository;
  let robotPublisher: RobotClientService;
  let workerPublisher: WorkerClientService;
  let playerPublisher: PlayerClientService;
  let queueRepository: QueueRepository;

  beforeAll(
    async () => {
      const moduleFixture = await makeTestModule();
      playerMessageService = moduleFixture.get<PlayerMessageService>(PlayerMessageService);
      monitoringsService = moduleFixture.get<MonitoringWorkerClientService>(MonitoringWorkerClientService);
      queueManager = moduleFixture.get<QueueManagerService>(QueueManagerService);
      sessionRepository = moduleFixture.get<SessionRepository>(getRepositoryToken(SessionRepository, connectionNames.DATA));
      machineRepository = moduleFixture.get<MachineRepository>(getRepositoryToken(MachineRepository, connectionNames.DATA));
      robotPublisher = moduleFixture.get<RobotClientService>(RobotClientService);
      workerPublisher = moduleFixture.get<WorkerClientService>(WorkerClientService);
      playerPublisher = moduleFixture.get<PlayerClientService>(PlayerClientService);
      rngChipPrizeRepository = moduleFixture.get<RngChipPrizeRepository>(getRepositoryToken(RngChipPrizeRepository, connectionNames.DATA));
      queueRepository = moduleFixture.get<QueueRepository>(getRepositoryToken(QueueRepository, connectionNames.DATA));
    },
  );

  beforeEach(() => {
    jest.resetAllMocks();
  });

  describe('userJoinedHandler', () => {
    it('should notify queue update', async () => {
      shouldNotifyQueueUpdate({ sessionRepository });
      const sendEventLogSpy = jest.spyOn(monitoringsService, 'sendEventLogMessage');
      const queueNotifySpy = jest.spyOn(queueManager, 'notifyQueueUpdate');
      // @ts-ignore
      await playerMessageService.userJoinedHandler({
        sessionId: 4,
        session: {
          id: 4,
          machine: { serial: '<serial>' },
          queue: { id: 9000 },
          status: SessionStatus.PLAYING
        }
      });
      expect(sendEventLogSpy)
        .toBeCalledWith({
          eventType: EventType.CONNECTED,
          source: EventSource.PLAYER,
          params: {
            sessionId: 4,
            machineSerial: '<serial>',
          },
        });
      expect(queueNotifySpy)
        .toBeCalledWith(9000, {
          id: 4,
          machine: { serial: '<serial>' },
          queue: { id: 9000 },
          status: 'playing'
        });
    });
    it('should handle reconnection', async () => {
      shouldHandleReconnect({ sessionRepository });
      const sendStopAutoplaySpy = jest.spyOn(robotPublisher, 'sendStopAutoplayMessage');
      const sessionUpdateSpy = jest.spyOn(sessionRepository, 'update');
      const startIdleSpy = jest.spyOn(workerPublisher, 'timeoutStart');
      // @ts-ignore
      await playerMessageService.userJoinedHandler({
        sessionId: 4,
        reconnect: true,
        session: {
          id: 4,
          // @ts-ignore
          machine: { serial: '<serial>' },
          // @ts-ignore
          group: {
            timePerShotMs: 100,
            graceTimeout: 100
          },
          // @ts-ignore
          queue: { id: 9000 },
          status: SessionStatus.PLAYING
        }
      });
      expect(sendStopAutoplaySpy)
        .toBeCalledWith('<serial>', 4);
      expect(sessionUpdateSpy)
        .toBeCalledWith(4, { status: SessionStatus.PLAYING }, expect.anything());
      expect(startIdleSpy)
        .toBeCalledWith(
          {
            sessionId: 4,
            timeoutSec: 200,
            timeoutType: 'idleTimeout'
          },
          '<corrId>',
          startIdleSpy.mock.calls[0][2],
        );
    });
  });

  describe('userDisconnectHandler', () => {
    it('should mark session as disconnected', async () => {
      shouldMarkDisconnected({ sessionRepository });
      const sessionUpdateSpy = jest.spyOn(sessionRepository, 'update');
      // @ts-ignore
      await playerMessageService.userDisconnectHandler({
        session: {
          id: 1,
          status: SessionStatus.PLAYING
        },
        sessionId: 1
      });
      expect(sessionUpdateSpy)
        .toBeCalledWith(1, expect.objectContaining({ isDisconnected: true }));
    });
  });

  describe('enableAutoplayHandler', () => {
    it('should enable autoplay if session is in playing status', async () => {
      // @ts-ignore
      jest.spyOn(sessionRepository, 'findOne')
        .mockResolvedValue({
          status: SessionStatus.PLAYING,
          configuration: {},
        });
      const sendAutoplaySpy = jest.spyOn(robotPublisher, 'sendAutoplayMessage');
      const sessionUpdateSpy = jest.spyOn(sessionRepository, 'update');
      // @ts-ignore
      await playerMessageService.enableAutoplayHandler({
          id: 1,
          machine: { serial: '<serial>' }
        },
        { tiltMode: 'auto' });
      expect(sendAutoplaySpy)
        .toBeCalledWith('<serial>', 1, 'auto');
      expect(sessionUpdateSpy)
        .toBeCalledWith(1,
          {
            status: SessionStatus.AUTOPLAY,
          }, expect.anything());
    });
  });

  describe('disableAutoplayHandler', () => {
    it('should stop autoplay', async () => {
      // @ts-ignore
      jest.spyOn(sessionRepository, 'findOneOrFail')
        .mockResolvedValue({
          status: SessionStatus.AUTOPLAY,
          configuration: {
            // @ts-ignore
            autoplay: {},
          },
        });
      const sessionUpdateSpy = jest.spyOn(sessionRepository, 'update');
      const sendStopAutoplaySpy = jest.spyOn(robotPublisher, 'sendStopAutoplayMessage');
      const startIdleSpy = jest.spyOn(workerPublisher, 'timeoutStart');
      await playerMessageService.disableAutoplayHandler({
        session: {
          id: 1,
          // @ts-ignore
          group: {
            timePerShotMs: 100,
            graceTimeout: 100
          },
          // @ts-ignore
          machine: { serial: '<serial>' },
          // @ts-ignore
          player: { cid: '<cid>' }
        },
        sessionId: 1,
        correlationId: '<corr>',
      });
      expect(sendStopAutoplaySpy)
        .toBeCalledWith('<serial>', 1);
      expect(sessionUpdateSpy)
        .toBeCalledWith(1, { status: SessionStatus.PLAYING }, expect.anything());
      expect(startIdleSpy)
        .toBeCalledWith(
          {
            sessionId: 1,
            timeoutSec: 200,
            timeoutType: 'idleTimeout'
          },
          '<corr>',
          startIdleSpy.mock.calls[0][2],);
    });
  });

  xdescribe('handleIdleTimeout', () => {
    it('should start autoplay', async () => {
      const sessionMock = handleIdleTimeoutSessionMock;
      shouldStartAutoplay({ sessionRepository });
      const sessionUpdateSpy = jest.spyOn(sessionRepository, 'update');
      const sendAutoplaySpy = jest.spyOn(robotPublisher, 'sendAutoplayMessage');
      const notifyForceAutoplaySpy = jest.spyOn(playerPublisher, 'notifyAutoplay');
      // @ts-ignore
      await playerMessageService.handleIdleTimeout({
        sessionId: sessionMock.id,
        session: sessionMock
      });
      expect(sessionUpdateSpy)
        .toBeCalledWith(sessionMock.id, { status: SessionStatus.FORCED_AUTOPLAY }, expect.anything());
      expect(sendAutoplaySpy)
        .toBeCalledWith(sessionMock.machine.serial, sessionMock.id, TiltMode.AUTO);
      expect(notifyForceAutoplaySpy)
        .toBeCalledWith(sessionMock.id, {
          status: AutoplayStatus.FORCED_ENABLE,
          config: {},
        });
    });
  });

  describe('handleQueueChangeOfferAccepted', () => {
    it('should throw exception if no queue offered', async () => {
      jest.spyOn(sessionRepository, 'findOneOrFail')
        .mockResolvedValue(new SessionEntity());
      try {
        // @ts-ignore
        await playerMessageService.handleQueueBalanceDecision({
          session: handleQueueChangedSessionMock,
          decision: 'accept'
        });
        expect(true)
          .toBe(false);
      } catch (e) {
        expect(e)
          .toBeInstanceOf(RpcException);
      }
    });
    it('should throw exception if session is not in queue status', async () => {
      shouldThrowExceptionNotQueueStatus({ sessionRepository });
      try {
        // @ts-ignore
        await playerMessageService.handleQueueBalanceDecision({
          session: handleQueueChangedSessionMock,
          decision: 'accept'
        });
        expect(true)
          .toBe(false);
      } catch (e) {
        expect(e)
          .toBeInstanceOf(RpcException);
      }
    });
    it('should assign session to new queue', async () => {
      shouldAssignNewQueue({
        sessionRepository,
        queueRepository
      });
      const sessionUpdateSpy = jest.spyOn(sessionRepository, 'update');
      const forceReconnectSpy = jest.spyOn(playerPublisher, 'forceReconnect');
      const notifyQueueUpdateSpy = jest.spyOn(queueManager, 'notifyQueueUpdate');
      // @ts-ignore
      jest.spyOn(queueManager, 'assignSessionToQueue')
        .mockResolvedValue(handleQueueChangedSessionMock);
      // @ts-ignore
      await playerMessageService.handleQueueBalanceDecision({
        sessionId: 1,
        session: handleQueueChangedSessionMock,
        decision: 'accept'
      });
      expect(sessionUpdateSpy)
        .toBeCalledWith(handleQueueChangedSessionMock.id,
          {
            queue: handleQueueChangedQueueMock,
            machine: handleQueueChangedQueueMock.machine,
            group: handleQueueChangedQueueMock.machine.group,
            offeredQueueId: null,
          });
      expect(notifyQueueUpdateSpy)
        .toBeCalledWith(handleQueueChangedSessionMock.queue.id, handleQueueChangedSessionMock);
      expect(forceReconnectSpy)
        .toBeCalledWith(handleQueueChangedSessionMock.id);
    });
  });

  describe('handleListBets', () => {
    it('should send bets to players', async () => {
      shouldSendBets({
        machineRepository,
        rngChipPrizeRepository
      });
      const sendBetsSpy = jest.spyOn(playerPublisher, 'sendBets');
      await playerMessageService.handleListBets(shouldSendBetsSessionMock);
      expect(sendBetsSpy)
        .toBeCalledWith(shouldSendBetsSessionMock.id, shouldSendBetsBetListMock);
    });
  });
});
