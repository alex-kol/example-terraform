import {
  GameId,
  GroupRepository,
  MachineRepository,
  QueueRepository,
  SeedHistoryRepository,
  SessionRepository,
} from '@lib/dal';
import { MonitoringWorkerClientModule } from '@lib/monitoring.worker.client';
import { Module } from '@nestjs/common';
import { OperatorApiClientModule } from '../operator.api.client/operator.api.client.module';
import { PlayerClientModule } from '../player.client/player.client.module';
import { RobotClientModule } from '../robot.client/robot.client.module';
import { SessionDataManagerModule } from '../session.data.manager/session.data.manager.module';
import { SessionModule } from '../session/session.module';
import { WorkerClientModule } from '../worker.client/worker.client.module';
import { ClawRouletteSessionTerminator } from './claw.roulette.session.terminator';
import { CoinPusherV1SessionTerminator } from './coin.pusher.v1.session.terminator';
import { GroupTerminatorService } from './group.terminator.service';
import {
  ClawGroupTerminator,
  ClawRouletteGroupTerminator,
  CoinPusherV1GroupTerminator,
} from './group.terminator.strategies';
import { TerminatorController } from './terminator.controller';
import { groupTerminatorKeyFactory } from './util/group.terminator.key.factory';
import { ChipWatcherModule } from '../chip.watcher/chip.watcher.module';
import { ClawSessionTerminator } from './claw.session.terminator';

@Module({
  imports: [
    OperatorApiClientModule,
    SessionModule,
    WorkerClientModule,
    MonitoringWorkerClientModule,
    RobotClientModule,
    SessionDataManagerModule,
    PlayerClientModule,
    ChipWatcherModule,
  ],
  controllers: [TerminatorController],
  providers: [
    GroupTerminatorService,
    CoinPusherV1SessionTerminator,
    ClawRouletteSessionTerminator,
    ClawSessionTerminator,
    MachineRepository,
    QueueRepository,
    GroupRepository,
    SessionRepository,
    SeedHistoryRepository,
    {
      provide: groupTerminatorKeyFactory(GameId.CLAW_ROULETTE),
      useClass: ClawRouletteGroupTerminator,
    },
    {
      provide: groupTerminatorKeyFactory(GameId.COIN_PUSHER_V1),
      useClass: CoinPusherV1GroupTerminator,
    },
    {
      provide: groupTerminatorKeyFactory(GameId.CLAW),
      useClass: ClawGroupTerminator,
    },
  ],
  exports: [GroupTerminatorService],
})
export class GroupTerminatorModule {

}
