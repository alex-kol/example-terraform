import {
  AutoplayConfiguration, BetBehindConfiguration, CoinPusherGameMode, PhantomWidgetType,
} from '@lib/dal';
import { ApiPropertyOptional, ApiResponseProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { PayTableDto } from '../dtos';
import { ReconnectVerifyRes } from './reconnect.verify.res';

export class CoinPusherReconnectVerifyRes extends ReconnectVerifyRes {
  @ApiResponseProperty()
  public stackSize: number;

  @ApiResponseProperty()
  public stackBuyLimit: number;

  @ApiResponseProperty()
  public graceTimeoutSec: number;

  @ApiResponseProperty()
  public autoplayConfig?: AutoplayConfiguration;

  @ApiResponseProperty()
  public betBehindConfig?: BetBehindConfiguration;

  @ApiResponseProperty()
  public slotConfig?: string[];

  @ApiResponseProperty({ enum: PhantomWidgetType })
  public phantomWidgetType?: PhantomWidgetType;

  @ApiResponseProperty()
  @Type(() => PayTableDto)
  public payTable?: PayTableDto[];

  @ApiResponseProperty()
  public betInCash: number;

  @ApiResponseProperty()
  public phantomWinValues: number[];

  @ApiResponseProperty()
  public phantomWidgetAnimationDurationMS: number;

  @ApiPropertyOptional()
  public freeTokens?: number;

  @ApiResponseProperty()
  public betBehindRounds: number;

  @ApiResponseProperty()
  public coins: number;

  @ApiResponseProperty()
  public bigWinThresholdInCash: number;

  @ApiResponseProperty()
  public toastChipAdded: boolean;

  @ApiResponseProperty()
  public gameMode: CoinPusherGameMode;
}
