import {
  EventType,
  GameId,
  GroupEntity,
  MachineEntity,
  MachineRepository,
  MachineStatus,
  QueueRepository,
  QueueStatus,
  SessionEntity,
} from '@lib/dal';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Injectable, NotAcceptableException } from '@nestjs/common';
import { CommandType, EventSource } from '@lib/common';
import { CommandPublisher } from '../../command/command.publisher';
import { GroupTerminatorService } from '../../group.terminator/group.terminator.service';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { GroupStopDto, MachineStartDto } from '../dto';
import { BoHandlerStrategy } from './bo.handler.strategy';
import { CoreToRobotMessage } from '../../robot.client/robot.interface';
import { CoreMessage } from '../../messaging/robot.handling/enum/core.message';

@Injectable()
export class ClawBoHandlerStrategy extends BoHandlerStrategy {
  constructor(
      private readonly machineRepo: MachineRepository,
      private readonly monitoringWorkerClient: MonitoringWorkerClientService,
      private readonly robotClient: RobotClientService,
      private readonly groupTerminator: GroupTerminatorService,
      private readonly commandPublisher: CommandPublisher,
      private readonly queueRepo: QueueRepository,
  ) {
    super();
  }

  public async groupHardStopHandler(groupId: number, data: GroupStopDto, correlationId?: string): Promise<void> {
    await this.groupTerminator.groupHardStop(GameId.CLAW, groupId, data, correlationId);
  }

  public async groupSoftStopHandler(groupId: number, machineIds?: number[], correlationId?: string): Promise<void> {
    await this.groupTerminator.groupSoftStop(GameId.CLAW, groupId, machineIds, correlationId);
  }

  public async machineReassign(machine: MachineEntity, toGroup: GroupEntity): Promise<void> {
    const { queue } = machine;
    if (queue.status === QueueStatus.DRYING || machine.status === MachineStatus.OFFLINE) {
      throw new NotAcceptableException('Unexpected machine state');
    }

    const active = (queue.sessions || [] as SessionEntity[]).reduce((acc: SessionEntity[], session) => {
      if (session.getActiveRound()) {
        acc.push(session);
      } else {
        this.commandPublisher.queueChange({
          type: CommandType.CHANGE_QUEUE,
          gameId: GameId.CLAW,
          sessionId: Number(session.id),
          ignoreMachines: [machine.id],
        });
      }
      return acc;
    }, []);

    await this.machineRepo.update(machine.id, { reassignTo: toGroup.id });

    await this.queueRepo.update(queue.id, { status: QueueStatus.DRYING });

    if (!active.length) {
      this.commandPublisher.sendCommand({
        type: CommandType.MACHINE_REASSIGN,
        gameId: GameId.CLAW,
        machineId: machine.id,
      });
    }
  }

  public async machineStartHandler(machine: MachineEntity, group: GroupEntity, params: MachineStartDto): Promise<void> {
    if (machine.cameras.length !== 2) {
      throw new NotAcceptableException('Cameras are not assigned');
    }

    const runMessage: CoreToRobotMessage = {
      action: CoreMessage.RUN,
      clearTable: params.resetTableState,
      resetDispensers: params.resetDispensers,
    };

    await this.machineRepo.update(machine.id,
      {
        status: MachineStatus.STOPPED,
        shutdownReason: null,
        startedDate: new Date(),
      });
    const { action, ...paramsForEvent } = runMessage;
    this.monitoringWorkerClient.sendEventLogMessage({
      eventType: EventType.RUN,
      source: EventSource.GAME,
      params: {
        machineId: machine.id,
        machineSerial: machine.serial,
        groupId: group.id,
        ...paramsForEvent,
      },
    });
    this.robotClient.sendRobotMessage(runMessage, machine.serial);
  }
}
