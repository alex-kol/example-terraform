import { RoundRepository } from '@lib/dal';
import { Module } from '@nestjs/common';
import { RobotClientService } from './robot.client.service';

@Module({
  providers: [
    RobotClientService,
    RoundRepository,
  ],
  exports: [RobotClientService],
})
export class RobotClientModule {

}
