import { ConfigService } from '@lib/config';
import {
  Configuration, GameId, MachineRepository, OperatorRepository,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { Inject, Injectable, NotAcceptableException } from '@nestjs/common';
import { ModuleRef } from '@nestjs/core';
import * as Joi from 'joi';
import { Logger } from 'winston';
import { ValidationContext } from './config.validator.module';
import { validationSchemaKeyFactory } from './util/validation.schema.key.factory';

@Injectable()
export class ConfigValidator {
  private readonly configTtl: number;

  constructor(
    config: ConfigService,
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly machineRepo: MachineRepository,
    private readonly operatorRepo: OperatorRepository,
    private readonly cacheManager: RedisCacheService,
    private readonly moduleRef: ModuleRef,
  ) {
    this.configTtl = Number(config.get(['core', 'VALIDATED_CONFIG_TTL_SEC']));
  }

  public async getValidatedConfig(machineSerial: string, operatorId?: number): Promise<Configuration> {
    const key = ConfigValidator.getCacheKey(machineSerial, operatorId);
    const cachedConfig: Configuration = await this.cacheManager.get(key);
    if (cachedConfig) {
      return cachedConfig;
    }

    const machine = await this.machineRepo.findOneOrFail({
      where: { serial: machineSerial },
      relations: ['group'],
    });
    if (!machine.group) {
      throw new NotAcceptableException('Configuration validation failed: no group');
    }
    let config: Configuration = { ...machine.configuration, ...machine.group.configuration };

    const context: ValidationContext = { level: 'group' };
    if (operatorId) {
      const operator = await this.operatorRepo.findOneByOrFail({ id: operatorId });
      config = { ...config, ...operator.configuration };
      context.level = 'operator';
    }
    config = this.validateConfig(config, context, machine.gameId);
    await this.cacheManager.set(key, config, { ttl: this.configTtl });
    return config;
  }

  public validateConfig(config: Configuration, context: ValidationContext, gameId: GameId): Configuration {
    const schema: Joi.ObjectSchema = this.moduleRef.get(validationSchemaKeyFactory(gameId));
    const {
      error,
      value,
    } = schema
      .validate(config, {
        stripUnknown: false,
        allowUnknown: true,
        context,
      });
    if (error) {
      this.logger.error('Config validation', { error });
      throw new NotAcceptableException(`Configuration validation failed: ${error
        .details?.map(error => error.message)
        ?.join(', ') || 'unknown error'}`);
    }

    return value;
  }

  public async dropCache(machineSerial: string, operatorId?: number): Promise<void> {
    await this.cacheManager.del(ConfigValidator.getCacheKey(machineSerial, operatorId));
  }

  private static getCacheKey(machineSerial: string, operatorId?: number): string {
    return `configuration-${machineSerial}-${operatorId || 'noOperator'}`;
  }
}
