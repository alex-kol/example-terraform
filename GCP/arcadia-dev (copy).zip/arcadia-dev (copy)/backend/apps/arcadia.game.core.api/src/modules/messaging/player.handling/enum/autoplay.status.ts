export enum AutoplayStatus {
  FORCED_ENABLE = 'forcedEnable',
  FORCED_DISABLE = 'forcedDisable',
}
