export const refurbishChipListKeyFactory = (machineId: number, chipTypeId: number) => `${machineId}_${chipTypeId}_CHIP_REFURBISH_LIST`;
