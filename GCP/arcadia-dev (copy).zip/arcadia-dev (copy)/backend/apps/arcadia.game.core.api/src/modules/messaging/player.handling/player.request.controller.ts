import {
  LoggerInterceptor,
  NewrelicAndMessagePattern,
  PlayerMessageType,
  RmqQueueName,
  rmqRoutingGenerate,
  RpcMainExceptionFilter,
  rpcValidationExceptionFactory,
} from '@lib/common';
import { GameId } from '@lib/dal';
import {
  Controller, Scope, UseFilters, UseInterceptors, UsePipes, ValidationPipe,
} from '@nestjs/common';
import { Payload } from '@nestjs/microservices';
import { BetBehindReadyHandler } from '../../bet.behind/bet.behind.ready.handler';
import { SessionAwareDto } from '../../dto/session.aware.dto';
import { SessionInjectorPipe } from '../session.injector.pipe';
import { BuyMessageDto } from './dto/buy.message.dto';
import { BuyStacksCoinPusherHandler } from './game.strategy/buy.stacks.coin.pusher.handler';

@Controller({
  path: 'v1/player-rs',
  scope: Scope.REQUEST,
})
@UseInterceptors(LoggerInterceptor)
@UseFilters(RpcMainExceptionFilter)
@UsePipes(new ValidationPipe({
  transform: true,
  whitelist: true,
  exceptionFactory: rpcValidationExceptionFactory,
}))
export class PlayerRequestController {
  constructor(
    private readonly betBehindReadyHandler: BetBehindReadyHandler,
    private readonly buyStacksCoinPusherHandler: BuyStacksCoinPusherHandler,
  ) {
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.BUY_STACKS, GameId.COIN_PUSHER_V1))
  public buyStacksCPV1(@Payload() data: BuyMessageDto): Promise<void> {
    return this.buyStacksCoinPusherHandler.handle(data);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.READY_BET_BEHIND, GameId.COIN_PUSHER_V2))
  public async confirmedInvitation(@Payload() data: SessionAwareDto): Promise<void> {
    await this.betBehindReadyHandler.handle(data);
  }
}
