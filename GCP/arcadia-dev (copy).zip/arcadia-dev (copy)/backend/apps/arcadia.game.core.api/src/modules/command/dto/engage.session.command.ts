import { Transform } from 'class-transformer';
import { IsInt, IsOptional } from 'class-validator';
import { BaseCommand } from './base.command';

export class EngageSessionCommand extends BaseCommand {
  @Transform(({ value }) => parseInt(value, 10))
  @IsInt()
  public machineId: number;

  @Transform(({ value }) => {
    if (typeof value === 'undefined') {
      return undefined;
    }
    return parseInt(value, 10);
  })
  @IsOptional()
  @IsInt()
  public reBuySessionId?: number;
}
