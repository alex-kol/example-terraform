/* eslint-disable max-lines */
import {
  CommandType, EventSource, OperatorErrorType, OperatorException,
} from '@lib/common';
import {
  AlertSeverity,
  AlertSource,
  AlertType,
  EntityManager,
  EventType,
  GameId,
  GroupEntity,
  MachineEntity,
  MachineRepository,
  OperatorEntity,
  PlayerEntity,
  PlayerRepository,
  QueueEntity,
  RoundEntity,
  RoundRepository,
  RoundStatus,
  RoundType,
  SessionEntity,
  SessionRepository,
  VoucherEntity,
} from '@lib/dal';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { RpcException } from '@nestjs/microservices';
import BigNumber from 'bignumber.js';
import { Logger } from 'winston';
import { toCash } from '../../util/toCash';
import { CommandPublisher } from '../command/command.publisher';
import { RoundStartedDto } from '../messaging/player.handling/dto/round.started.dto';
import { OperatorApiClientService } from '../operator.api.client/operator.api.client.service';
import { NotificationLevel } from '../player.client/notification.level';
import { NotificationType } from '../player.client/notification.type';
import { PlayerClientService } from '../player.client/player.client.service';
import { RngHelper } from '../rng.service.client/rng.helper';
import { SessionDataManager } from '../session.data.manager/session.data.manager';
import { RoundContext } from './round.context';
import { RoundOptions } from './round.options';

export class CoinPusherRoundStarter {
  private readonly roundRepo: RoundRepository;
  private readonly sessionRepo: SessionRepository;
  private readonly playerRepo: PlayerRepository;
  private readonly machineRepo: MachineRepository;

  private readonly session: SessionEntity;
  private readonly queue: QueueEntity;
  private readonly machine: MachineEntity;
  private readonly player: PlayerEntity;
  private readonly group: GroupEntity;
  private readonly operator: OperatorEntity;
  private readonly vouchers: VoucherEntity[];
  private readonly correlationId: string;
  private readonly isAutoplayRound;

  constructor(
    private readonly logger: Logger,
    private readonly commandPublisher: CommandPublisher,
    private readonly rngHelper: RngHelper,
    private readonly operatorClient: OperatorApiClientService,
    private readonly playerPublisher: PlayerClientService,
    private readonly monitoringService: MonitoringWorkerClientService,
    private readonly sessionDataManager: SessionDataManager,
    context: RoundContext,
    manager: EntityManager,
  ) {
    this.sessionRepo = new SessionRepository(manager);
    this.roundRepo = new RoundRepository(manager);
    this.playerRepo = new PlayerRepository(manager);
    this.machineRepo = new MachineRepository(manager);

    this.session = context.session;
    this.queue = context.queue;
    this.operator = context.operator;
    this.player = context.player;
    this.group = context.group;
    this.machine = context.machine;
    this.isAutoplayRound = context.isAutoplayRound;
    this.vouchers = context.vouchers;
    this.correlationId = context.correlationId;
  }

  public async startRound(type: RoundType, isBbScatter = false): Promise<RoundEntity> {
    const {
      bet,
      rtp,
      deductRound,
      countToLimit,
    } = this.getRoundOptions(type, isBbScatter);
    const betInCash = toCash(bet, this.session.currencyConversionRate);
    const round = await this.createRound(type, bet, betInCash, rtp);

    if (type === RoundType.SCATTER || isBbScatter) {
      await this.trackScatterRound(`${round.id}`);
    } else {
      await this.placeBet(betInCash, `${round.id}`);
    }

    await this.sessionRepo.countNewRound(this.session.id, bet, betInCash, deductRound, countToLimit);
    await this.playerRepo.countBet(this.player.cid, this.operator.id, bet);
    if (rtp) {
      await this.machineRepo.increment({ id: this.machine.id }, 'roundsCount', 1);
    }

    if (round.type !== RoundType.BET_BEHIND) {
      await this.notifyBetBehindRoundStart();
      this.playerPublisher.broadcastRemainingCoins(this.machine.serial, round.coins);
    }
    const roundStartMessage = await this.getRoundStartedMessage(round, isBbScatter);
    this.playerPublisher.sessionState(this.session.id, { status: this.session.status });
    this.playerPublisher.notifyRoundStart(this.session.id, roundStartMessage);
    this.monitoringService.sendEventLogMessage({
      eventType: EventType.START_ROUND,
      source: EventSource.GAME,
      params: {
        type: round.type,
        sessionId: this.session.id,
        machineSerial: this.machine.serial,
        round: round.id,
      },
    });
    return round;
  }

  private async trackScatterRound(roundId: string): Promise<void> {
    const { transaction } = await this.sessionDataManager.getSessionData(this.session.id);
    if (!transaction) {
      throw new RpcException('No parent transaction for scatter');
    }
    if (Array.isArray(transaction.scatterRounds)) {
      transaction.scatterRounds.push(roundId);
    } else {
      transaction.scatterRounds = [roundId];
    }
    await this.sessionDataManager.updateSessionData({ transaction }, this.session.id);
    await this.roundRepo.update({ id: Number(roundId) }, { transactionId: transaction.transactionId });
  }

  public async getRoundStartedMessage(
    round: RoundEntity, isBbScatter = false,
  ): Promise<RoundStartedDto> {
    const {
      deductRound,
      countToLimit,
    } = this.getRoundOptions(round.type, isBbScatter);
    const stackBuyLimit = new BigNumber(this.session.configuration.stackBuyLimit)
      .minus(this.session.totalStacksUsed)
      .minus(countToLimit)
      .toNumber();
    let rounds = new BigNumber(this.session.roundsLeft).minus(deductRound)
      .toNumber();
    let betBehindRounds = 0;
    if (round.type === RoundType.BET_BEHIND) {
      rounds = this.session.roundsLeft;
      const { betBehind } = await this.sessionDataManager.getSessionData(this.session.id);
      betBehindRounds = betBehind?.stopAfterRounds ? new BigNumber(betBehind.stopAfterRounds)
        .minus(1)
        .toNumber() : 0;
    }
    return {
      type: round.type,
      stackBuyLimit,
      rounds,
      betBehindRounds,
      totalBet: round.betInCash,
    };
  }

  private async notifyBetBehindRoundStart() {
    const sessions = await this.sessionRepo.getBetBehindersFromQueue(this.queue.id);
    sessions.forEach(sessionId => this.commandPublisher.sendCommand({
      type: CommandType.BET_BEHIND_ROUND_START,
      gameId: GameId.COIN_PUSHER_V1,
      sessionId,
    }, this.correlationId));
  }

  private async createRound(
    type: RoundType, bet: number, betInCash: number, rtp = true,
    status = RoundStatus.ACTIVE,
  ): Promise<RoundEntity> {
    const rtpSeed = rtp ? await this.rngHelper.calcRtp(this.group, this.machine, this.session.configuration) : null;
    const round = this.roundRepo.create({
      type,
      status,
      coins: this.group.stackSize,
      bet,
      betInCash,
      session: this.session,
      rtp: rtpSeed,
      machineId: this.machine.id,
      isAutoplay: this.isAutoplayRound,
      voucherId: (type === RoundType.VOUCHER && this.vouchers.length) ? this.vouchers[0].id : null,
    });
    return this.roundRepo.save(round, { transaction: false });
  }

  private async placeBet(betInCash: number, roundId: string): Promise<void> {
    const {
      loginOptions: {
        sessionToken,
        extGameId,
      },
    } = await this.sessionDataManager.getSessionData(this.session.id);

    try {
      const {
        transactionId,
        balance,
      } = await this.operatorClient.bet({
        accessToken: sessionToken,
        operator: this.operator,
        cid: this.player.cid,
        amount: betInCash,
        roundId,
        correlationId: this.correlationId,
        gameId: this.session.gameId,
        extGameId,
      });
      await this.sessionDataManager.updateSessionData({
        transaction: {
          roundId,
          transactionId,
        },
      }, this.session.id);
      this.playerPublisher.notifyBalance(this.session.id, { valueInCash: balance });
      this.monitoringService.sendEventLogMessage({
        eventType: EventType.BET,
        source: EventSource.GAME,
        params: {
          sum: betInCash,
          sessionId: Number(this.session.id),
          round: Number(roundId),
          machineSerial: this.machine.serial,
          currency: this.session.currency,
          transactionId,
        },
      });
      await this.roundRepo.update({ id: Number(roundId) }, { transactionId });
    } catch (err) {
      await this.roundRepo.delete(roundId);
      this.logger.error('Bet error', {
        sessionId: Number(this.session.id),
        operator: this.operator.apiConnectorId,
        errorMessage: err instanceof OperatorException ? err.getResponse() : err.message,
        correlationId: this.correlationId,
        stack: err.stack,
        roundId,
      });
      if (err instanceof OperatorException
        && err.getResponse().type === OperatorErrorType.INSUFFICIENT_FUNDS) {
        this.playerPublisher.notification(this.session.id,
          {
            notificationId: NotificationType.INSUFFICIENT_FUNDS,
            level: NotificationLevel.WARNING,
            title: 'Insufficient funds',
            message: 'Insufficient funds',
            data: { canBuy: 0 },
          });
      } else {
        this.playerPublisher.notification(this.session.id,
          {
            notificationId: NotificationType.BET_FAILED,
            level: NotificationLevel.ERROR,
            title: 'Bet failed',
            message: 'Oops, something went wrong with your wallet!',
          });
      }
      this.monitoringService.sendAlertMessage({
        alertType: AlertType.ERROR,
        severity: AlertSeverity.HIGH,
        source: AlertSource.GAME_CORE,
        description: 'Bet failed on round start',
        gameId: this.machine.gameId,
        details: {
          sessionId: this.session.id,
          machineId: this.machine.id,
          machineName: this.machine.name,
          machineSerial: this.machine.serial,
          error: err.message,
          roundId,
        },
      });
      throw err;
    }
  }

  private getRoundOptions(type: RoundType, isBbScatter: boolean): RoundOptions {
    const roundType = (type === RoundType.BET_BEHIND && isBbScatter) ? 'bbScatter' : type;
    const result: RoundOptions = {
      bet: Number(this.group.denominator),
      rtp: true,
      deductRound: 1,
      countToLimit: 1,
    };
    switch (roundType) {
      case RoundType.BET_BEHIND:
        result.rtp = false;
        result.deductRound = 0;
        break;
      case 'bbScatter':
        result.bet = 0;
        result.rtp = false;
        result.deductRound = 0;
        result.countToLimit = 0;
        break;
      case RoundType.SCATTER:
      case RoundType.VOUCHER:
        result.bet = 0;
        result.countToLimit = 0;
        break;
      case RoundType.REGULAR:
      default:
    }
    return result;
  }
}
