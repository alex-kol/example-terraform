import { EntityManager } from '@lib/dal';
import { DataSource } from 'typeorm';
import { Logger } from 'winston';
import { CommandHandler } from './command.handler';

export abstract class TransactionalHandler<T> extends CommandHandler<T> {
  protected entityManager: EntityManager;

  protected constructor(
    protected readonly logger: Logger,
    private readonly dataSource: DataSource,
  ) {
    super(logger);
  }

  protected async onCommit(): Promise<void> {
    // stub
  }

  public async handle(data: T): Promise<void> {
    await this.dataSource.transaction(async entityManager => {
      this.entityManager = entityManager;
      await super.handle(data);
    })
      .then(() => this.onCommit());
  }
}
