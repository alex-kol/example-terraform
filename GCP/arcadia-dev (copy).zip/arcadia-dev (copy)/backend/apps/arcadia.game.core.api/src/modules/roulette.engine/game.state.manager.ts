import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { Injectable } from '@nestjs/common';
import { gameStateKeyFactory } from './game.state.key.factory';
import { RouletteGameState } from './types';

@Injectable()
export class GameStateManager {
  constructor(private readonly cacheManager: RedisCacheService) {

  }

  public getGameState(serial: string): Promise<RouletteGameState | undefined> {
    return this.cacheManager.get(gameStateKeyFactory(serial));
  }

  public async setGameState(serial: string, state: RouletteGameState): Promise<void> {
    await this.cacheManager.set(gameStateKeyFactory(serial), state);
  }

  public async dropGameState(serial: string): Promise<void> {
    await this.cacheManager.del(gameStateKeyFactory(serial));
  }
}
