export enum GamePhase {
  GAME_INIT = 'gameInit',
  BETS_OPEN = 'betsOpen',
  BETS_CLOSED = 'betsClosed',
  PROCESS_BETS = 'processBets',
  PICK_NUMBER = 'pickNumber',
  PROCESS_WINS = 'processWins',
  SHOW_RESULTS = 'showResults',
}
