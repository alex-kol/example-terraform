import {
  CommandType,
  LoggerInterceptor,
  NewrelicAndMessagePattern,
  RmqQueueName,
  rmqRoutingGenerate,
  RpcMainExceptionFilter,
  rpcValidationExceptionFactory,
} from '@lib/common';
import { GameId } from '@lib/dal';
import {
  Controller, Scope, UseFilters, UseInterceptors, UsePipes, ValidationPipe,
} from '@nestjs/common';
import { Payload } from '@nestjs/microservices';
import { ChangeQueueCommand } from '../command/dto/change.queue.command';
import { SessionInjectorPipe } from '../messaging/session.injector.pipe';
import { QueueChangeHandler } from './queue.change.handler';

@Controller({ path: 'v1/queuesTrans', scope: Scope.REQUEST })
@UseInterceptors(LoggerInterceptor)
@UseFilters(RpcMainExceptionFilter)
@UsePipes(new ValidationPipe({
  transform: true,
  whitelist: true,
  exceptionFactory: rpcValidationExceptionFactory,
}))
export class QueueTransactionController {
  constructor(
    private readonly coinPusherQueueChangeHandler: QueueChangeHandler,
  ) {}

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.CORE_COMMAND_QUEUE, CommandType.CHANGE_QUEUE, GameId.COMMON))
  public async coinPusherQueueChange(@Payload() data: ChangeQueueCommand): Promise<void> {
    await this.coinPusherQueueChangeHandler.handle(data);
  }
}