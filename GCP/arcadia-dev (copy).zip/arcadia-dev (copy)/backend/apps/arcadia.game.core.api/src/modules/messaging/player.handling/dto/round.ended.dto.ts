import { RoundType } from '@lib/dal';

export class RoundEndedDto {
  type: RoundType;
  winAmount: number;
}
