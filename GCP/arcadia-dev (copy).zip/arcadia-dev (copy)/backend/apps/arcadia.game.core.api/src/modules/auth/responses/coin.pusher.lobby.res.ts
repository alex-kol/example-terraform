import { ApiProperty } from '@nestjs/swagger';
import { LobbyDataRes } from './lobby.data.res';

class CoinPusherLobbyData extends LobbyDataRes {
  @ApiProperty()
  public betInCash: number;
}

export class CoinPusherLobbyRes {
  @ApiProperty({ type: [CoinPusherLobbyData] })
  public groups: CoinPusherLobbyData[];
}
