import {
  CommandType,
  LoggerInterceptor,
  NewrelicAndMessagePattern,
  RmqQueueName,
  rmqRoutingGenerate,
  RobotMessageType,
  RpcMainExceptionFilter,
  rpcValidationExceptionFactory,
} from '@lib/common';
import { GameId } from '@lib/dal';
import {
  Controller, Scope, UseFilters, UseInterceptors, UsePipes, ValidationPipe,
} from '@nestjs/common';
import { Payload } from '@nestjs/microservices';
import { ResultHandler } from './result.handler';
import { ClawResultDto } from '../../types/claw.result.dto';
import { SessionInjectorPipe } from '../../../messaging/session.injector.pipe';
import { BaseCommand } from '../../../command/dto/base.command';
import { RoundEndHandler } from './round.end.handler';

@Controller({
  path: 'v1/transactional',
  scope: Scope.REQUEST,
})
@UseInterceptors(LoggerInterceptor)
@UseFilters(RpcMainExceptionFilter)
@UsePipes(new ValidationPipe({
  transform: true,
  whitelist: true,
  exceptionFactory: rpcValidationExceptionFactory,
}), SessionInjectorPipe)
export class RobotRequestController {
  constructor(
    private readonly resultHandler: ResultHandler,
    private readonly roundEndHandler: RoundEndHandler,
  ) {
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.RESULT, GameId.CLAW))
  public async result(@Payload() data: ClawResultDto): Promise<void> {
    return this.resultHandler.handle(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.CORE_COMMAND_QUEUE, CommandType.ROUND_END, GameId.CLAW))
  public async roundEnd(@Payload() data: BaseCommand): Promise<void> {
    await this.roundEndHandler.handle(data);
  }
}
