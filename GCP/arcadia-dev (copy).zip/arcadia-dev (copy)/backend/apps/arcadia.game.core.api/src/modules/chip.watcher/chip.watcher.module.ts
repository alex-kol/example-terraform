import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import {
  ChangeRepository,
  ChipRepository,
  ChipTypeRepository,
  configOptionWithAudit,
  connectionNames,
  ConnectionType,
  getConfig,
  GroupRepository,
  provideCustomRepository,
} from '@lib/dal';
import { ConfigService } from '@lib/config';
import { ChipWatcherService } from './chip.watcher.service';

@Module({
  imports: [
    TypeOrmModule.forRootAsync({
      name: connectionNames.AUDIT,
      useFactory: (configService: ConfigService) => getConfig(ConnectionType.AUDIT, <configOptionWithAudit>configService.get(['core'])),
      inject: [ConfigService],
    }),
  ],
  controllers: [],
  providers: [
    ChipWatcherService,
    GroupRepository,
    ChipRepository,
    ChipTypeRepository,
    ...provideCustomRepository([ChangeRepository], connectionNames.AUDIT),
  ],
  exports: [ChipWatcherService],
})
export class ChipWatcherModule {
}
