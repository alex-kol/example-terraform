export class AuthData {
  cid: string;
  name?: string;
  playerToken?: string;
  currencyCode: string;
  balance?: number;
}
