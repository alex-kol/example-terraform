import {
  connectionNames,
  getRepositoryToken,
  QueueRepository,
  SessionEntity,
  SessionStatus,
} from '@lib/dal';
import { makeTestModule } from './mocks/beforeAll.mock';
import { QueueManagerService } from './queue.manager.service';
import { PlayerClientService } from '../player.client/player.client.service';
import { getSessionHash } from '../session/session.hash';

describe('Queue Manager Service (Unit)', () => {
  let queueManagerService: QueueManagerService;
  let playerClientService: PlayerClientService;
  let queueRepository: QueueRepository;

  beforeAll(async () => {
    const moduleFixture = await makeTestModule();
    queueManagerService = moduleFixture.get<QueueManagerService>(QueueManagerService);
    playerClientService = moduleFixture.get<PlayerClientService>(PlayerClientService);
    queueRepository = moduleFixture.get<QueueRepository>(getRepositoryToken(QueueRepository, connectionNames.DATA));
  });

  describe('notifyQueueUpdate', () => {
    it('should send notify queue message', async () => {
      const notifyQueueUpdateSpy = jest.spyOn(playerClientService, 'notifyQueueUpdate');
      jest.spyOn(queueManagerService, 'notifyQueueUpdate').mockClear();
      const viewerSesssion = new SessionEntity();
      viewerSesssion.status = SessionStatus.VIEWER;
      const playingSession = new SessionEntity();
      playingSession.status = SessionStatus.PLAYING;
      // @ts-ignore
      jest.spyOn(queueRepository, 'findOne').mockResolvedValue({ machine: { serial: '<serial>' }, sessions: [viewerSesssion, playingSession] });
      await queueManagerService.notifyQueueUpdate(5);
      expect(notifyQueueUpdateSpy).toBeCalledWith('<serial>', {
        queue: [{
          queueToken: getSessionHash(playingSession),
          stacks: playingSession.roundsLeft,
          status: playingSession.status,
        }],
        viewers: 1,
      });
    });
  });
});
