import { EventSource, TimeoutType } from '@lib/common';
import { EventType, PlayerId } from '@lib/dal';
import { Injectable } from '@nestjs/common';
import moment from 'moment';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { LOBBY_LONG_POLLING_INTERVAL_SEC } from '../../constants/game.client';
import { WorkerClientService } from '../worker.client/worker.client.service';
import { ConversionData } from './conversion.data';
import { conversionTrackingKeyFactory } from './conversion.tracking.key.factory';
import { EntrySource } from './entry.source';

@Injectable()
export class ConversionTracker {
  constructor(
    private readonly cacheManager: RedisCacheService,
    private readonly workerClient: WorkerClientService,
    private readonly monitoringClient: MonitoringWorkerClientService,
  ) {
  }

  public async createTracker(playerId: PlayerId, source: EntrySource, launchParams: Record<string, any>): Promise<void> {
    const existing = await this.cacheManager.get<ConversionData>(conversionTrackingKeyFactory(playerId));
    if (existing) {
      await this.closeTracker(playerId);
    }
    const conversionData: ConversionData = {
      playerCid: playerId.cid,
      operatorId: playerId.operatorId,
      source,
      launchParams,
      entryTimestamp: new Date(),
      clicks: 0,
      swipes: 0,
    };
    await this.cacheManager.set(conversionTrackingKeyFactory(playerId), conversionData, { ttl: 15 });
    await this.workerClient.timeoutStart({
      timeoutType: TimeoutType.CONVERSION_TRACKING,
      playerCid: playerId.cid,
      operatorId: playerId.operatorId,
      timeoutSec: LOBBY_LONG_POLLING_INTERVAL_SEC * 2,
      payload: { gameId: launchParams?.gameId },
    });
  }

  public async track(playerId: PlayerId, data: Partial<ConversionData>): Promise<void> {
    let conversionData = await this.cacheManager.get<ConversionData>(conversionTrackingKeyFactory(playerId));
    if (!conversionData) {
      return;
    }
    conversionData = {
      ...conversionData,
      ...data,
      clicks: conversionData.clicks + (data.clicks || 0),
      swipes: conversionData.swipes + (data.swipes || 0),
    };
    await this.cacheManager.set(conversionTrackingKeyFactory(playerId), conversionData, { ttl: 15 });
    await this.workerClient.timeoutStart({
      timeoutType: TimeoutType.CONVERSION_TRACKING,
      playerCid: playerId.cid,
      operatorId: playerId.operatorId,
      timeoutSec: LOBBY_LONG_POLLING_INTERVAL_SEC * 2,
      payload: { gameId: conversionData?.launchParams?.gameId },
    });
  }

  public async closeTracker(playerId: PlayerId, data?: Partial<ConversionData>): Promise<void> {
    let conversionData = await this.cacheManager.get<ConversionData>(conversionTrackingKeyFactory(playerId));
    await this.workerClient.timeoutStop({
      timeoutType: TimeoutType.CONVERSION_TRACKING,
      playerCid: playerId.cid,
      operatorId: playerId.operatorId,
      payload: { gameId: conversionData?.launchParams?.gameId },
    });
    if (!conversionData) {
      return;
    }
    await this.cacheManager.del(conversionTrackingKeyFactory(playerId));
    if (data) {
      conversionData = {
        ...conversionData,
        ...data,
        clicks: conversionData.clicks + (data.clicks || 0),
        swipes: conversionData.swipes + (data.swipes || 0),
      };
    }
    this.monitoringClient.sendEventLogMessage({
      eventType: EventType.PLAYER_CONVERSION,
      source: EventSource.GAME,
      params: {
        ...conversionData,
        duration: moment()
          .diff(conversionData.entryTimestamp, 'second'),
      },
    });
  }
}