export class IpGeoResp {
  ip: string;
  countryCode: string; // ISO 3166 Country Codes
  countryCode3: string;
  continentCode?: string;
  country?: string;
  region?: string;
  city?: string;
}
