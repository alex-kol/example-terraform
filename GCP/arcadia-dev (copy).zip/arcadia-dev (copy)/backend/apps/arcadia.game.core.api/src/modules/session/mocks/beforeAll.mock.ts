import { connectionNames, getRepositoryToken, RoundArchiveRepository, RoundRepository, SessionArchiveRepository, SessionRepository, } from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { Test } from '@nestjs/testing';
import { repoMockFactory } from '../../../util/repoMockFactory';
import { PlayerClientService } from '../../player.client/player.client.service';
import { SessionDataManager } from '../../session.data.manager/session.data.manager';
import { SessionService } from '../session.service';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';

export async function makeTestModule() {
  const moduleFixture = await Test.createTestingModule({
    imports: [],
    providers: [
      SessionService,
      {
        useValue: {
          ...repoMockFactory(),
          findByIds: () => null,
          manager: { transaction: () => null }
        },
        provide: getRepositoryToken(SessionRepository, connectionNames.DATA),
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(SessionArchiveRepository, connectionNames.DATA),
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(RoundArchiveRepository, connectionNames.DATA),
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(RoundRepository, connectionNames.DATA),
      },
      {
        useValue: {
          notifyReturnToLobby: () => null,
          notification: () => null
        },
        provide: PlayerClientService,
      },
      {
        useValue: {
          get: () => null,
          set: () => null,
          del: () => null
        },
        provide: RedisCacheService,
      },
      {
        provide: MAIN_LOGGER,
        useValue: {},
      },
      {
        provide: RedisCacheService,
        useValue: {
          get: () => null,
          set: () => null,
          del: () => null
        },
      },
      {
        provide: SessionDataManager,
        useValue: {
          deleteSessionToken: () => null,
          dropSessionData: () => null
        },
      },
      {
        provide: MonitoringWorkerClientService,
        useValue: { sendEventLogMessage: () => null },
      },
    ],
  })
    .compile();
  return moduleFixture;
}
