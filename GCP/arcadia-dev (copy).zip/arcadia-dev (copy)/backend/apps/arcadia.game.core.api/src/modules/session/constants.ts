export const FINALIZE_SESSION_LOCK_INJECT_TOKEN = 'finalizeSessionLockInjectToken';
export const FINALIZE_SESSION_LOCK_PREFIX = 'finalize-session-lock';
export const FINALIZE_SESSION_LOCK_TTL = 3;
