import { deleteUndefinedValue, OperatorTag, UserLoginDto } from '@lib/common';
import { jwtVerifier } from '@lib/common/utils/jwt.promisified';
import { ConfigService } from '@lib/config';
import { OperatorEntity, OperatorRepository, OperatorStatus } from '@lib/dal';
import { Injectable, NotAcceptableException, UnauthorizedException } from '@nestjs/common';
import { StandardLanguageMapper } from './languages';
import { LaunchUrlCreator } from './launch.url.creator';
import { spinomenalLaunchParamsValidationSchema } from './params.validation.schemas';
import { SpinomenalLaunchUrlParams } from './types';

@Injectable()
export class SpinomenalLaunchUrlCreator extends LaunchUrlCreator<SpinomenalLaunchUrlParams> {
  protected readonly paramsValidationSchema = spinomenalLaunchParamsValidationSchema;

  constructor(
    config: ConfigService,
    private readonly operatorRepo: OperatorRepository,
    private readonly spinomenalLanguage: StandardLanguageMapper,
  ) {
    super(config);
  }

  protected getId(): string {
    return OperatorTag.SPINOMENAL;
  }

  private getOperatorSecretKey(apiConnectorId: string): string | undefined {
    const pattern = `${apiConnectorId.toUpperCase()}_SECRET_KEY`;
    const config = this.config.get(['core']);
    return config[Object.keys(config)
      .find(value => value.includes(pattern))] as string;
  }

  protected getOperator(): Promise<OperatorEntity> {
    return this.operatorRepo.findOneByOrFail({
      apiConnectorId: this.params.operator,
      externalId: this.params.partnerId,
      isDeleted: false,
      status: OperatorStatus.ENABLED,
    })
      .catch(() => {
        throw new NotAcceptableException('Operator not found or disabled');
      });
  }

  protected async validateCaller(): Promise<void> {
    const {
      authToken,
      callerIp,
    } = this.params;
    if (authToken) {
      const secret = this.getOperatorSecretKey(this.operator.apiConnectorId);
      if (!secret) {
        throw new NotAcceptableException('Operator key not found');
      }
      await jwtVerifier(authToken, secret, {
        clockTolerance: 2,
        maxAge: '1h',
      })
        .catch(reason => {
          throw new UnauthorizedException('Token verification failed!', reason.message);
        });
    } else if (!callerIp || !this.ipWhitelist.has(callerIp)) {
      throw new UnauthorizedException('IP address is unknown');
    }
  }

  protected mapParams(): UserLoginDto {
    const {
      gameToken,
      partnerId,
      gameId,
      isReal: isRealParam,
      languageCode,
      homeUrl,
      cashierUrl,
      jurisdiction,
    } = this.params;
    const isReal = isRealParam !== undefined && isRealParam;
    const result: UserLoginDto = {
      operatorId: this.operator.id,
      accessToken: gameToken,
      gameId,
      language: this.spinomenalLanguage.getLanguageCode(languageCode),
      isReal,
      externalId: partnerId,
      homeUrl,
      cashierUrl,
      jurisdiction,
    };
    deleteUndefinedValue(result);
    return result;
  }
}
