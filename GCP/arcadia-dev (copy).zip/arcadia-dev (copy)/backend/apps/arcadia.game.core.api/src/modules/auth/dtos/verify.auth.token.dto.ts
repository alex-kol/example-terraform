import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import {
  IsEnum,
  IsInt,
  IsNotEmpty,
  Length,
  Min,
} from 'class-validator';
import { GameId, intTransformer } from '@lib/dal';

export class VerifyAuthTokenDto {
  @ApiProperty()
  @IsNotEmpty()
  public token: string;

  @ApiProperty()
  @Transform(intTransformer)
  @IsInt()
  @Min(1)
  public groupId: number;

  @ApiProperty()
  @Length(10, 50)
  public footprint: string;

  @ApiProperty()
  @IsEnum(GameId)
  public gameId: GameId;
}
