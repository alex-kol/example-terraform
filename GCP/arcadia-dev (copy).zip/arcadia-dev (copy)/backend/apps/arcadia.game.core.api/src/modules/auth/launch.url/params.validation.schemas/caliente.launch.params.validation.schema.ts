import { GameId } from '@lib/dal';
import Joi from 'joi';
import { urlPattern } from '../../../../util';
import { CalienteLaunchParams } from '../types';

export const calienteLaunchParamsValidationSchema = Joi.object<CalienteLaunchParams>({
  operator: Joi.string()
    .required(),
  callerIp: Joi.string()
    .ip()
    .required(),
  authToken: Joi.string()
    .required(),
  gameId: Joi.valid(...Object.values(GameId))
    .required(),
  language: Joi.string()
    .default('en'),
  externalId: Joi.string()
    .allow(null)
    .empty(null),
  homeUrl: Joi.string()
    .pattern(urlPattern)
    .allow(null)
    .empty(null),
  cashierUrl: Joi.string()
    // .pattern(urlPattern) TODO: Return this after fixing on caliente side
    .allow(null)
    .empty(null),
  clientType: Joi.string()
    .allow(null)
    .empty(null),
});
