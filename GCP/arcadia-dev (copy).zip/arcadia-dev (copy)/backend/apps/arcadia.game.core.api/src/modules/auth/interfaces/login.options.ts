export class LoginOptions {
  sessionToken: string;
  extGameId?: string;
  homeUrl?: string;
  cashierUrl?: string;
}