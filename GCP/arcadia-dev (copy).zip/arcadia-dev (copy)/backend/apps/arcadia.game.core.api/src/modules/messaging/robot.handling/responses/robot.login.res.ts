import IORedis from 'ioredis';
import { GameId } from '@lib/dal';
import { RmqQueueName } from '@lib/common';

export class RobotLoginRes {
  queues: {
    publisher: RmqQueueName;
    subscriber: string;
  };
  robotKey: number;
  mgrMessageServer: string[];
  playerMessageServer: {
    redis: IORedis.RedisOptions;
    key: string;
  };
  gameId: GameId;
  fileApiUrl: string;
}