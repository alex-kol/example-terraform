import { Type } from 'class-transformer';
import { IsEnum, ValidateNested } from 'class-validator';
import { GameId } from '@lib/dal';
import { SessionAwareDto } from '../../../dto/session.aware.dto';
import { PlayerSettingsDto } from './player.settings.dto';

export class SettingsUpdateMessageDto extends SessionAwareDto {
  @Type(() => PlayerSettingsDto)
  @ValidateNested()
  public settings: PlayerSettingsDto;

  @IsEnum(GameId)
  public gameId: GameId;
}
