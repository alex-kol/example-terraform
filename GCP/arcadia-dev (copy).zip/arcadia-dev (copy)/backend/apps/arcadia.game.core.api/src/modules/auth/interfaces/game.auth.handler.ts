import { ConversionDto } from '@lib/common';
import { LobbyDataRes, ReconnectVerifyRes, VerifyRes } from '../responses';

export abstract class GameAuthHandler {
  abstract loginPlayer(token: string, groupId: number, footprint: string): Promise<VerifyRes>;
  abstract handleLobby(data: ConversionDto): Promise<{ groups: LobbyDataRes[] }>;
  abstract verifyReconnect(sessionId: number, footprint: string): Promise<ReconnectVerifyRes>
}