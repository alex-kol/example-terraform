/* eslint-disable max-lines */
import { CommandType, EventSource, TimeoutType } from '@lib/common';
import { ConfigService } from '@lib/config';
import {
  EventType, GameId, RoundType, SessionEndReason, SessionStatus,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Inject, Injectable, Scope } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { DataSource } from 'typeorm';
import { Logger } from 'winston';
import { CommandPublisher } from '../../command/command.publisher';
import { BaseCommand } from '../../command/dto/base.command';
import { SessionContextHandler } from '../../command/session.context.handler';
import { NotificationLevel } from '../../player.client/notification.level';
import { NotificationType } from '../../player.client/notification.type';
import { PlayerClientService } from '../../player.client/player.client.service';
import { RoundContext } from '../../round/round.context';
import { RoundServiceFactory } from '../../round/round.service.factory';
import { SessionDataManager } from '../../session.data.manager/session.data.manager';
import { WorkerClientService } from '../../worker.client/worker.client.service';

@Injectable({ scope: Scope.REQUEST })
export class BbRoundStartHandler extends SessionContextHandler<BaseCommand> {
  private isScatter: boolean;
  private readonly terminateSessionTimeoutSec: number;

  constructor(
    config: ConfigService,
    @Inject(MAIN_LOGGER) logger: Logger,
    private readonly roundServiceFactory: RoundServiceFactory,
    private readonly commandPublisher: CommandPublisher,
    private readonly playerPublisher: PlayerClientService,
    private readonly monitoringWorkerClient: MonitoringWorkerClientService,
    private readonly sessionDataManager: SessionDataManager,
    private readonly workerClient: WorkerClientService,
    dataSource: DataSource,
  ) {
    super(logger, dataSource);
    this.terminateSessionTimeoutSec = config
      .get(['core', 'TERMINATE_SESSION_TIMEOUT_SEC']) as unknown as number;
  }

  protected async init(data: BaseCommand): Promise<void> {
    await super.init(data);

    this.session = await this.sessionRepository.findOneByOrFail({ id: this.cachedSession.id });

    this.isScatter = this.session.pendingScatter > 0;
  }

  protected async handleEvent(): Promise<void> {
    if (this.session.isDisconnected && !this.isScatter) {
      await this.disableBetBehind('player disconnected');
      return;
    }

    const { betBehind } = await this.sessionDataManager.getSessionData(this.session.id);
    if (!betBehind) {
      throw new RpcException('No bet behind configs');
    }

    if (this.session.totalStacksUsed >= this.sessionConfig.stackBuyLimit && !this.isScatter) {
      this.onRoundLimitReached();
      return;
    }

    const ctx: RoundContext = new RoundContext(
      this.session,
      this.cachedSession.queue,
      this.cachedMachine,
      this.cachedPlayer,
      this.cachedGroup,
      this.cachedOperator,
      false,
      [],
      this.correlationId,
    );
    await this.roundServiceFactory
      .getStarter(GameId.COIN_PUSHER_V1, ctx, this.entityManager)
      .startRound(RoundType.BET_BEHIND, this.isScatter)
      .catch(err => {
        this.logger.error('Round start error', {
          sessionId: this.session.id,
          errorMessage: err.message,
          correlationId: this.correlationId,
          stack: err.stack,
        });
        this.commandPublisher.finalizeSession({
          type: CommandType.FINALIZE_SESSION,
          gameId: GameId.COIN_PUSHER_V1,
          sessionId: this.session.id,
          terminate: true,
          reason: SessionEndReason.WALLET_TRANSACTION_ERROR,
        }, this.correlationId);
        throw err;
      });
  }

  private onRoundLimitReached() {
    this.logger.warn('Round limit reached', { sessionId: this.session.id });
    this.playerPublisher.notification(this.session.id,
      {
        notificationId: NotificationType.ROUND_LIMIT_REACHED,
        level: NotificationLevel.WARNING,
        title: 'Round limit reached!',
        message: 'You have reached the regulatory round limit, see you next time.',
      });
    this.monitoringWorkerClient.sendEventLogMessage({
      eventType: EventType.BET_BEHIND_STOPPED,
      source: EventSource.GAME,
      params: {
        sessionId: this.session.id,
        machineSerial: this.session.machine?.serial,
        reason: 'Round limit reached!',
      },
    });
    this.commandPublisher.finalizeSession({
      type: CommandType.FINALIZE_SESSION,
      gameId: GameId.COIN_PUSHER_V1,
      sessionId: this.session.id,
      terminate: false,
      showSessionResult: true,
      reason: SessionEndReason.ROUND_LIMIT_REACHED,
    }, this.correlationId);
  }

  private async disableBetBehind(reason: string): Promise<void> {
    const status = this.session.status === SessionStatus.QUEUE_BET_BEHIND
      ? SessionStatus.QUEUE
      : SessionStatus.VIEWER;
    this.monitoringWorkerClient.sendEventLogMessage({
      eventType: EventType.BET_BEHIND_STOPPED,
      source: EventSource.GAME,
      params: {
        sessionId: this.session.id,
        machineSerial: this.cachedMachine.serial,
        playerCid: this.cachedPlayer.cid,
        reason,
      },
    });
    await this.sessionRepository.update(
      this.session.id,
      { status },
      () => this.playerPublisher.sessionState(this.session.id, { status }),
    );
    await this.sessionDataManager.removeSessionData(['betBehind'], this.session.id);
    if (status === SessionStatus.VIEWER && this.session.isDisconnected) {
      await this.workerClient.timeoutStart({
        timeoutType: TimeoutType.TERMINATE_SESSION,
        sessionId: this.sessionId,
        timeoutSec: this.terminateSessionTimeoutSec,
        payload: { reason: SessionEndReason.VIEWER_DISCONNECTED, gameId: this.session.gameId },
      });
    }
  }
}
