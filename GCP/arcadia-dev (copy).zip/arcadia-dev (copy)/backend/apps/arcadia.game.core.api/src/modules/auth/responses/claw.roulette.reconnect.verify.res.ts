import { ApiResponseProperty } from '@nestjs/swagger';
import { RouletteField } from '@lib/dal';
import { ReconnectVerifyRes } from './reconnect.verify.res';
import { RoundBet } from '../../roulette.engine/types';

export class ClawRouletteReconnectVerifyRes extends ReconnectVerifyRes {
  @ApiResponseProperty()
  public betList: number[];

  @ApiResponseProperty()
  public currentBets: RoundBet;

  @ApiResponseProperty()
  public ballHistory: RouletteField[];

  @ApiResponseProperty()
  public lastWinInCash: number;
}
