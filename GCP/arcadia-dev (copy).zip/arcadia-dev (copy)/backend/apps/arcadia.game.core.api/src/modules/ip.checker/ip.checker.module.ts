import { keepAliveAgents } from '@lib/common';
import { HttpModule } from '@nestjs/axios';
import { Module } from '@nestjs/common';
import { GeoIpClient } from './geo.ip.client';
import { IpChecker } from './ip.checker';

@Module({
  imports: [
    HttpModule.register({
      baseURL: 'https://get.geojs.io/v1/ip',
      timeout: 3000,
      httpAgent: keepAliveAgents.httpAgent,
      httpsAgent: keepAliveAgents.httpsAgent,
    }),
  ],
  providers: [IpChecker, GeoIpClient],
  exports: [IpChecker],
})
export class IpCheckerModule {

}