/* eslint-disable max-lines */
import {
  AlertDescription, CommandType, EventSource, TimeoutOptions, TimeoutType,
} from '@lib/common';
import {
  AlertSeverity,
  AlertSource,
  AlertType,
  EventType,
  MachineRepository,
  MachineStatus,
  SessionEndReason,
  SessionRepository,
  SessionStatus,
  ShutdownReason,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { ServerRMQ } from '@lib/rmq.server';
import { Inject, Injectable } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import moment from 'moment';
import { v4 as uuidV4 } from 'uuid';
import { Logger } from 'winston';
import { getRobotQueueName } from '../../util';
import { CommandPublisher } from '../command/command.publisher';
import { PhaseEndCommand } from '../command/dto/phase.end.command';
import { ConversionTracker } from '../conversion.tracker/conversion.tracker';
import { GroupTerminatorService } from '../group.terminator/group.terminator.service';
import { PlayerClientService } from '../player.client/player.client.service';
import { QueueManagerService } from '../queue.manager/queue.manager.service';
import { RobotClientService } from '../robot.client/robot.client.service';
import { SessionDataManager } from '../session.data.manager/session.data.manager';
import { SessionService } from '../session/session.service';
import { QueueChangeOfferDto } from '../worker.client/dto';
import { WorkerClientService } from '../worker.client/worker.client.service';

@Injectable()
export class WorkerMessageService {
  constructor(
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly sessionRepo: SessionRepository,
    private readonly machineRepo: MachineRepository,
    private readonly monitoringClient: MonitoringWorkerClientService,
    private readonly playerClient: PlayerClientService,
    private readonly robotClient: RobotClientService,
    private readonly workerClient: WorkerClientService,
    private readonly groupTerminator: GroupTerminatorService,
    private readonly sessionService: SessionService,
    private readonly commandPublisher: CommandPublisher,
    private readonly queueManager: QueueManagerService,
    private readonly serverRMQ: ServerRMQ,
    private readonly sessionDataManager: SessionDataManager,
    private readonly conversionTracker: ConversionTracker,
  ) {
  }

  public async timeoutExpired(options: TimeoutOptions): Promise<void> {
    const handler: (opts: TimeoutOptions) => void | Promise<void> = Reflect
      .get(this, `${options.timeoutType}Handler`);
    if (typeof handler !== 'function') {
      throw new RpcException('Timeout handler not found');
    }
    await handler.call(this, options);
  }

  public async handlePingOutdated(serial: string, correlationId: string = uuidV4()): Promise<void> {
    try {
      const machine = await this.machineRepo.findOneOrFail({
        where: { serial },
        relations: ['group'],
      });
      await this.monitoringClient.sendAlertMessage({
        alertType: AlertType.MAINTENANCE,
        severity: AlertSeverity.CRITICAL,
        source: AlertSource.GAME_CORE,
        description: AlertDescription.MACHINE_IS_NOT_RESPONDING,
        gameId: machine.gameId,
        details: {
          machineId: machine.id,
          machineName: machine.name,
          machineSerial: machine.serial,
        },
      });
      await this.groupTerminator.groupHardStop(machine.gameId, machine.group.id, {
        reason: ShutdownReason.MACHINE_IS_NOT_RESPONDING,
        machineIds: [machine.id],
      }, correlationId);
      await this.machineRepo.update(
        machine.id,
        { status: MachineStatus.OFFLINE, stoppedDate: new Date(), groupIdForRefurbish: machine.group.id },
      );
      await this.serverRMQ.purgeQueue(getRobotQueueName(machine.serial));
    } catch (err) {
      throw new RpcException(err);
    }
  }

  public async handleQueueChangeOffer(data: QueueChangeOfferDto): Promise<void> {
    if (!data.session) {
      throw new RpcException('No session to offer new queue');
    }
    const {
      sessionId,
      toQueueId,
      position,
    } = data;
    const toMachine = await this.machineRepo.getMachineByQueueId(toQueueId);
    if (!toMachine) {
      throw new RpcException('No machine to send offer to');
    }
    this.playerClient.queueBalance(sessionId, {
      machineId: toMachine.id,
      machineName: toMachine.name,
      queuePosition: position,
    });
  }

  protected async idleTimeoutHandler(options: TimeoutOptions): Promise<void> {
    this.commandPublisher.sendCommand({
      type: CommandType.IDL_TIMEOUT_EXPIRED,
      gameId: options.payload.gameId,
      sessionId: options.sessionId,
    }, uuidV4());
  }

  protected async rebuyTimeoutHandler({
    sessionId,
    session,
  }: TimeoutOptions): Promise<void> {
    const skipRequested = await this.sessionDataManager.getRebuyExpirationSkip(sessionId)
      || (await this.sessionRepo.getRoundsLeftFromMaster(sessionId)) > 0;
    if (skipRequested) {
      this.logger.info('rebuyTimeoutHandler skipped', { sessionId });
      return;
    }
    this.robotClient.sendDisengageMessage(sessionId, session.machine.serial);
  }

  protected async engageTimeoutHandler(options: TimeoutOptions): Promise<void> {
    const {
      session,
    } = options;
    if (!session) {
      throw new RpcException('No session on engage timeout');
    }
    const { machine } = session;
    await this.monitoringClient.sendEventLogMessage({
      eventType: EventType.ENGAGE_TIMEOUT,
      source: EventSource.GAME,
      params: {
        sessionId: session.id,
        machineSerial: machine.serial,
      },
    });
    await this.handlePingOutdated(machine.serial);
  }

  protected async disengageTimeoutHandler(options: TimeoutOptions): Promise<void> {
    const {
      sessionId,
      session,
      payload: { groupId, machineId, gameId },
    } = options;
    await this.workerClient.timeoutStop({
      timeoutType: TimeoutType.IDLE,
      sessionId,
      payload: { gameId: session.gameId },
    }, uuidV4());
    await this.workerClient.timeoutStop({
      timeoutType: TimeoutType.REBUY,
      sessionId,
      payload: { gameId: session.gameId },
    }, uuidV4());
    await this.sessionService.finalizeSession(sessionId, SessionEndReason.NO_DISENGAGE, true);
    await this.groupTerminator.groupHardStop(
      session?.machine?.gameId ?? gameId,
      session?.group?.id ?? groupId,
      {
        reason: ShutdownReason.DISENGAGE_TIMEOUT,
        machineIds: [session?.machine?.id ?? machineId],
      },
      uuidV4());
  }

  protected roundEndDelayHandler(options: TimeoutOptions): void {
    const {
      sessionId,
      payload: { gameId },
    } = options;
    this.commandPublisher.sendCommand({
      type: CommandType.ROUND_END,
      gameId,
      sessionId,
    }, uuidV4());
  }

  protected async terminateSessionTimeoutHandler({
    sessionId,
    session: cachedSession,
  }: TimeoutOptions): Promise<void> {
    const session = await this.sessionRepo.findOneOrFail({
      where: { id: sessionId },
      relations: ['rounds'],
    });
    const activeRound = session.getActiveRound();
    const stateCheck = (session.status === SessionStatus.VIEWER
      || session.status === SessionStatus.VIEWER_BET_BEHIND) && session.isDisconnected;
    if (stateCheck && !activeRound) {
      await this.sessionRepo.update(sessionId, {
        viewerDuration: moment()
          .diff(session.createDate, 'second'),
      });
      await this.sessionService.finalizeSession(sessionId, SessionEndReason.VIEWER_DISCONNECTED, true);
      await this.queueManager.notifyQueueUpdate(cachedSession.queue.id);
    }
  }

  protected async engageNextSessionDelayHandler(options: TimeoutOptions): Promise<void> {
    const machine = await this.machineRepo.findOneByOrFail({ serial: options.machineSerial });
    this.commandPublisher.engageNextSession({
      type: CommandType.ENGAGE_SESSION,
      gameId: machine.gameId,
      machineId: machine.id,
      sessionId: options.sessionId, // used for session locks
    });
  }

  protected async conversionTrackingHandler({
    playerCid,
    operatorId,
  }: TimeoutOptions): Promise<void> {
    await this.conversionTracker.closeTracker({
      cid: playerCid,
      operatorId,
    });
  }

  protected async phaseEndHandler({
    machineSerial,
    payload: { phase },
  }: TimeoutOptions): Promise<void> {
    this.commandPublisher.sendRouletteCommand<PhaseEndCommand>({
      type: CommandType.PHASE_END,
      serial: machineSerial,
      phase,
    });
  }

  protected animationInQueueDelayHandler(): Promise<void> {
    return Promise.resolve();
  }

  protected async waitingResultHandler(options: TimeoutOptions) {
    const {
      session,
      payload: { gameId },
    } = options;
    if (!session) {
      throw new RpcException('No session on waiting result timeout');
    }
    await this.groupTerminator.groupHardStop(
      gameId,
      session.group.id,
      {
        reason: ShutdownReason.WAITING_RESULT,
        machineIds: [session.machine.id],
      },
      uuidV4());
  }
}
