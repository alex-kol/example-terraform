import Joi from 'joi';
import { Configuration } from '@lib/dal';

export const commonSchema: Joi.SchemaMap<Configuration> = {
  videoCrop: Joi.object({
    portrait: Joi.object({
      top: Joi.number()
        .default(0),
      bottom: Joi.number()
        .default(0),
      left: Joi.number()
        .default(0),
      right: Joi.number()
        .default(0),
    }),
    landscape: Joi.object({
      top: Joi.number()
        .default(0),
      bottom: Joi.number()
        .default(0),
      left: Joi.number()
        .default(0),
      right: Joi.number()
        .default(0),
    }),
  })
    .default({
      portrait: {
        top: 0,
        bottom: 0,
        left: 0,
        right: 0,
      },
      landscape: {
        top: 0,
        bottom: 0,
        left: 0,
        right: 0,
      },
    }),
  countryWhitelist: Joi
    .array()
    .items(Joi.string().regex(/[A-Z]{2}/)),
  maxSessionsThreshold: Joi
    .number()
    .integer()
    .positive(),
  maxConcurrentSessions: Joi
    .number()
    .integer()
    .default(0),
};