export const WAITING_RESULT_TTL_SEC = 20;
export const ROUND_END_TTL_SEC = 10;
