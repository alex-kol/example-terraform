import { MachineStatus, GroupStatus } from '@lib/dal';

export function shouldThrowExceptionMachineCannotStart(spyTargets: any): void {
    jest.spyOn(spyTargets.machineRepository, 'findOneOrFail').mockResolvedValue({ status: MachineStatus.READY });
}

export function shouldUpdateMachineSendRun(spyTargets: any): void {
    jest.spyOn(spyTargets.machineRepository, 'findOneOrFail').mockResolvedValue({
        status: MachineStatus.ON_HOLD,
        id: 1,
        serial: '<serial>',
        group: { status: GroupStatus.IDLE }
    });
}
