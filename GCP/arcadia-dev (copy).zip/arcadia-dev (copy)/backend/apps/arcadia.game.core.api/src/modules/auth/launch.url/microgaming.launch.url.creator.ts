import {
  deleteUndefinedValue, microgamingConnectorFactory, OperatorTag, UserLoginDto,
} from '@lib/common';
import { ConfigService } from '@lib/config';
import { OperatorEntity, OperatorRepository, OperatorStatus } from '@lib/dal';
import { Injectable, NotFoundException } from '@nestjs/common';
import { IsNull } from 'typeorm';
import { StandardLanguageMapper } from './languages';
import { LaunchUrlCreator } from './launch.url.creator';
import { microgamingLaunchParamsValidationSchema } from './params.validation.schemas';
import { MicrogamingLaunchParams } from './types';

@Injectable()
export class MicrogamingLaunchUrlCreator extends LaunchUrlCreator<MicrogamingLaunchParams> {
  protected readonly paramsValidationSchema = microgamingLaunchParamsValidationSchema;

  constructor(
    config: ConfigService,
    private readonly operatorRepo: OperatorRepository,
    private readonly microgamingLanguage: StandardLanguageMapper,
  ) {
    super(config);
  }

  protected getId(): string {
    return OperatorTag.MICROGAMING;
  }

  protected async getOperator(): Promise<OperatorEntity> {
    const [operator = null] = await this.operatorRepo.find({
      where: [{
        apiConnectorId: microgamingConnectorFactory(this.params.siteid),
        externalId: IsNull(),
        isDeleted: false,
        status: OperatorStatus.ENABLED,
      },
      {
        apiConnectorId: microgamingConnectorFactory(this.params.siteid),
        externalId: this.params.casinoid || this.params.serverid,
        isDeleted: false,
        status: OperatorStatus.ENABLED,
      }],
      order: { externalId: 'DESC' },
    });
    if (!operator) {
      throw new NotFoundException('Operator not found');
    }
    return operator;
  }

  protected mapParams(): UserLoginDto {
    const {
      sessiontoken,
      playmode,
      casinoid,
      lang,
      lobbyurl,
      serverid,
      siteid,
      clientid,
      gameid,
    } = this.params;
    const isReal = playmode === 'real';
    const externalId = casinoid || serverid;

    const result: UserLoginDto = {
      operatorId: this.operator.id,
      accessToken: sessiontoken,
      gameId: gameid,
      extGameId: clientid,
      language: this.microgamingLanguage.getLanguageCode(lang),
      isReal,
      externalId,
      homeUrl: lobbyurl,
      siteId: siteid,
      events: OperatorTag.MICROGAMING,
    };
    deleteUndefinedValue(result);
    return result;
  }

  protected async validateCaller(): Promise<void> {
    return Promise.resolve();
  }
}
