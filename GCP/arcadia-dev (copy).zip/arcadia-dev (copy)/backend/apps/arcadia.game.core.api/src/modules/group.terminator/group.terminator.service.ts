/* eslint-disable max-lines */
import { GameId } from '@lib/dal';
import { Injectable } from '@nestjs/common';
import { ModuleRef } from '@nestjs/core';
import { GroupStopDto } from '../bo.handler/dto';
import { groupTerminatorKeyFactory } from './util/group.terminator.key.factory';
import { GroupTerminator } from './group.terminator.strategies';

@Injectable()
export class GroupTerminatorService {
  constructor(
    private readonly moduleRef: ModuleRef,
  ) {
  }

  public async groupSoftStop(
    gameId: GameId, groupId: number, machineIds?: number[], correlationId?: string,
  ): Promise<void> {
    await this.getTerminatorStrategy(gameId).groupSoftStop(groupId, machineIds, correlationId);
  }

  public async groupHardStop(
    gameId: GameId,
    groupId: number,
    data: GroupStopDto,
    correlationId?: string,
  ): Promise<void> {
    await this.getTerminatorStrategy(gameId).groupHardStop(groupId, data, correlationId);
  }

  private getTerminatorStrategy(gameId: GameId): GroupTerminator {
    return this.moduleRef.get(groupTerminatorKeyFactory(gameId));
  }
}
