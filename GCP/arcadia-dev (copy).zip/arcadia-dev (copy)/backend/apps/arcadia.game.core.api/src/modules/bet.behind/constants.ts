export const bbSendInvitationThresholdCoins = 25;
export const betBehindInvitationTtlSec = 6;
export const cacheInvitationKey = 'bb-invitation-';
