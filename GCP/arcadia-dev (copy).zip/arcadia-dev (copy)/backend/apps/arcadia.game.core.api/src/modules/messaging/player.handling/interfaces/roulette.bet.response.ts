export class RouletteBetResponse {
  bet: Record<string, number>;
  totalInCash: number;
}
