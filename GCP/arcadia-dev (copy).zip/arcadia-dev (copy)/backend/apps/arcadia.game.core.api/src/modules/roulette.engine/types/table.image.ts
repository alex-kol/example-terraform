import { IsBase64, Length } from 'class-validator';
import { RobotMessage } from '../../messaging/robot.handling/dto';

export class TableImageDto extends RobotMessage {
  @IsBase64()
  public image: string;

  @Length(1)
  public tag: string;
}