import { Type } from 'class-transformer';
import { IsNotEmpty, ValidateNested } from 'class-validator';
import { RobotMessage } from '../../messaging/robot.handling/dto';
import { Status } from './status';

export class RobotStatusDto extends RobotMessage {
  @Type(() => Status)
  @ValidateNested()
  @IsNotEmpty()
  public status: Status;
}
