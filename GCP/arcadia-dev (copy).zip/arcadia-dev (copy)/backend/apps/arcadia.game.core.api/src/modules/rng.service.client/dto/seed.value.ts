export class SeedValue {
  name: string;
  value?: number;
}