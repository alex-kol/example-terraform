import { Transform } from 'class-transformer';
import { IsInt } from 'class-validator';
import { CorrelationAware } from '../../../dto/correlation.aware';

export class PlayerAbuseDto extends CorrelationAware {
  @Transform(({ value }) => {
    const result = parseInt(value, 10);
    if (Number.isNaN(result)) {
      return undefined;
    }
    return result;
  })
  @IsInt()
  public sessionId: number;
}
