import { HttpService } from '@nestjs/axios';
import { of } from 'rxjs';
import { makeTestModule } from './mocks/beforeAll.mock';
import { RngClientService } from './rng.client.service';
import { dataToAxiosResponse } from '../../util';

jest.mock('../logger/logger.service');

describe('RNG Client Service (Unit)', () => {
  let rngClientService: RngClientService;
  let httpClient: HttpService;
  const seedA = { name: 'a' };
  const seedB = { name: 'b' };
  const rtpSegment = '<rtp>';
  const group = 'group';

  beforeAll(async () => {
    jest.setTimeout(30000)
    const moduleFixture = await makeTestModule();
    rngClientService = moduleFixture.get<RngClientService>(RngClientService);
    httpClient = moduleFixture.get<HttpService>(HttpService);
  });

  describe('seed', () => {
    it('should call rng service to get seed data', async () => {
      const minimalCount = 5;
      const minimalValue = 1;
      const getSpy = jest.spyOn(httpClient, 'get')
        .mockReturnValue(
          of(
            dataToAxiosResponse({ status: 'ok', seed: [seedA, seedA, seedB] })
          )
        );
      const result = await rngClientService.seed(group, minimalValue, minimalCount, rtpSegment, []);
      expect(result).toMatchObject({ a: 2, b: 1 });
      expect(getSpy).toBeCalledWith('/seed',
        {
          params: {
            group,
            minimal_count: minimalCount,
            minimal_value: minimalValue,
            rtpSegment,
            chips_on_table: '[]',
          },
        });
    });
    it('should empty array on no need to seed', async () => {
      const noNeedToSeed = 'No need to seed'
      jest.spyOn(httpClient, 'get').mockReturnValue(of(dataToAxiosResponse({ status: 'err', msg: noNeedToSeed })));
      const result = await rngClientService.seed('group',1, 5, '<rtp>', []).catch(err => err.message);
      expect(result).toBe(noNeedToSeed);
    });
  });

  describe('rtp', () => {
    it('should return rtp data', async () => {
      const resultData = { a: 1, b: 2 };
      const getSpy = jest.spyOn(httpClient, 'get')
        .mockReturnValue(of(dataToAxiosResponse({ status: 'ok', rtp: [seedA, seedB, seedB] })));
      const result = await rngClientService.rtp('group','<rtp>', {});
      expect(result).toMatchObject(resultData);
      expect(getSpy).toBeCalledWith('/rtp',
        {
          params: {
            group,
            rtpSegment,
            seed: '[{}]',
          },
        });
    });
  });

  describe('phantom', () => {
    it('should return phantom chip data', async () => {
      const getSpy = jest.spyOn(httpClient, 'get').mockReturnValue(of(dataToAxiosResponse({ status: 'ok', prize: '<prize>' })));
      const result = await rngClientService.phantom('group', '<rtp>');
      expect(result).toBe('<prize>');
      expect(getSpy).toBeCalledWith('/phantom', {
        params: {
          group,
          rtpSegment,
        },
      },
      );
    });
  });
});
