import { intTransformer, SessionEntity } from '@lib/dal';
import { Transform } from 'class-transformer';
import { Allow, IsInt, IsOptional } from 'class-validator';
import { CorrelationAware } from './correlation.aware';

export class SessionAwareDto extends CorrelationAware {
  @Transform(intTransformer)
  @IsOptional()
  @IsInt()
  public sessionId?: number;

  @Allow()
  public session?: SessionEntity;
}
