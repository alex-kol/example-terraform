import { CommandType } from '@lib/common';
import {
  AlertSeverity,
  AlertSource,
  AlertType,
  Configuration,
  GroupRepository,
  GroupStatus,
  MachineEntity,
  MachineRepository,
  MachineStatus,
  QueueRepository,
  QueueStatus,
  SessionEndReason,
  SessionRepository,
  ShutdownReason,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Inject, Injectable } from '@nestjs/common';
import {
  count, firstValueFrom, from, mergeMap,
} from 'rxjs';
import { Logger } from 'winston';
import { CommandPublisher } from '../../command/command.publisher';
import { PhaseEndCommand } from '../../command/dto/phase.end.command';
import { ConfigValidator } from '../../config.validator/config.validator';
import { PlayerClientService } from '../../player.client/player.client.service';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { SessionService } from '../../session/session.service';
import { BetManager } from '../bet.manager';
import { GamePhase, PhaseStatus, StateMachineStatus } from '../enums';
import { CommonContext, PhaseResult } from '../types';
import { PhaseHandler } from './phase.handler';

@Injectable()
export class InitPhaseHandler extends PhaseHandler {
  constructor(
    commandPublisher: CommandPublisher,
    betManager: BetManager,
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly playerClient: PlayerClientService,
    sessionRepo: SessionRepository,
    robotPublisher: RobotClientService,
    private readonly sessionService: SessionService,
    machineRepo: MachineRepository,
    private readonly groupRepository: GroupRepository,
    queueRepo: QueueRepository,
    private readonly configValidator: ConfigValidator,
    private readonly monitoringWorkerClientService: MonitoringWorkerClientService,
  ) {
    super(
      commandPublisher,
      betManager,
      sessionRepo,
      machineRepo,
      robotPublisher,
      queueRepo,
    );
  }

  public async onStart(context: CommonContext): Promise<PhaseResult> {
    const { serial } = context;
    const machine = await this.machineRepo.findOne({
      where: { serial },
      relations: ['group'],
    });

    const stale = await this.finalyzeStaleSession(serial);

    const ids = await this.sessionRepo.getSessionIdsForMachine(serial, false, stale);
    ids.forEach(id => this.playerClient.gamePhase(id, { phase: GamePhase.GAME_INIT }));

    await this.robotPublisher.sendRouletteDisplayMessage(serial, { phase: GamePhase.GAME_INIT });

    if (machine.reassignTo) {
      await this.machineReassign(context, machine, ids);
    }

    if (context.softStop) {
      await this.softStopHandler(context, machine, ids);
    }

    if (ids?.length && context.status !== StateMachineStatus.STOPPED) {
      if (context.status !== StateMachineStatus.RUNNING) {
        await this.machineRepo.update(machine.id, { status: MachineStatus.IN_PLAY });
      }
      context.status = StateMachineStatus.RUNNING;

      return { status: PhaseStatus.COMPLETE };
    }

    if (context.status !== StateMachineStatus.STOPPED) {
      await this.machineRepo.update(machine.id, { status: MachineStatus.READY });

      context.status = StateMachineStatus.PAUSED;
    }

    return { status: PhaseStatus.IN_PROGRESS };
  }

  public onComplete({ serial }: CommonContext): Promise<void> {
    return Promise.resolve();
  }

  public onError(context: CommonContext): Promise<void> {
    return Promise.resolve();
  }

  public async softStop(context: CommonContext): Promise<void> {
    const {
      serial,
      machineId,
    } = context;
    const machine = await this.machineRepo.findOne({
      where: { id: machineId },
      relations: ['group'],
    });
    const ids = await this.sessionRepo.getSessionIdsForMachine(serial, false);
    await this.softStopHandler(context, machine, ids);
  }

  public async userJoin({
    status,
    serial,
  }: CommonContext): Promise<void> {
    if (status === StateMachineStatus.PAUSED) {
      this.commandPublisher.sendRouletteCommand<PhaseEndCommand>({
        type: CommandType.PHASE_END,
        serial,
        phase: GamePhase.GAME_INIT,
      });
    }
  }

  public async reassign(context: CommonContext): Promise<void> {
    const machine = await this.machineRepo.findOne({
      where: { id: context.machineId },
      relations: ['group'],
    });
    const ids = await this.sessionRepo.getSessionIdsForMachine(context.serial, false);
    await this.machineReassign(context, machine, ids);
  }

  private async machineReassign(context: CommonContext, machine: MachineEntity, sessionIds: number[]): Promise<CommonContext> {
    try {
      const group = await this.groupRepository.findOneByOrFail({
        id: machine.reassignTo,
        isDeleted: false,
      });

      if ((machine.status === MachineStatus.READY || machine.status === MachineStatus.IN_PLAY)
        && (group.status === GroupStatus.IDLE || group.status === GroupStatus.IN_PLAY)) {
        const config: Configuration = { ...machine.configuration, ...group.configuration };

        await this.configValidator.dropCache(machine.serial);
        await this.configValidator.validateConfig(config, { level: 'group' }, machine.gameId);
      }

      machine.group = group;

      await this.finalizeSession(machine.serial, sessionIds, SessionEndReason.MACHINE_REASSIGNED);

      await this.monitoringWorkerClientService.sendAlertMessage({
        alertType: AlertType.INFORMATION,
        severity: AlertSeverity.LOW,
        source: AlertSource.GAME_CORE,
        description: 'Machine reassign complete',
        gameId: machine.gameId,
        details: {
          machineId: machine.id,
          machineName: machine.name,
          machineSerial: machine.serial,
          groupId: group.id,
        },
      });
    } catch (e) {
      await this.monitoringWorkerClientService.sendAlertMessage({
        alertType: AlertType.ERROR,
        severity: AlertSeverity.HIGH,
        source: AlertSource.GAME_CORE,
        description: 'Machine reassign failed',
        gameId: machine.gameId,
        details: {
          error: e.message,
          groupId: machine.reassignTo,
          machineId: machine.id,
          machineName: machine.name,
          machineSerial: machine.serial,
        },
      });
    }
    machine.reassignTo = null;
    await this.machineRepo.save(machine, {
      reload: false,
      transaction: false,
    });

    return context;
  }

  private async softStopHandler(context: CommonContext, machine: MachineEntity, sessionIds: number[]): Promise<CommonContext> {
    context.status = StateMachineStatus.STOPPED;
    context.softStop = false;
    machine.status = MachineStatus.STOPPED;

    let isStopGroup = false;
    await this.machineRepo.manager.transaction('READ UNCOMMITTED', async manager => {
      const machineRepo = new MachineRepository(manager);
      const queueRepo = new QueueRepository(manager);
      await machineRepo.update(context.machineId, { status: machine.status });
      await queueRepo.update({ machine: { id: context.machineId } }, { status: QueueStatus.STOPPED });
      if (machine.group.status === GroupStatus.DRYING) {
        const {
          countInPlay,
          countReady,
        } = await machineRepo.getMachinesAvailabilityData([String(machine.group.id)]);
        isStopGroup = !countReady && !countInPlay;
      }
    });

    await this.finalizeSession(machine.serial, sessionIds, SessionEndReason.MACHINE_STOP);

    if (isStopGroup) {
      await this.groupRepository.update(machine.group.id, { status: GroupStatus.OFFLINE });
    }
    await this.robotPublisher.sendStopMessage(machine.serial, ShutdownReason.USER_REQUEST);
    return context;
  }

  protected onHardStop(context: CommonContext, ids: number[]): void {
    this.finalizeSession(context.serial, ids, SessionEndReason.MACHINE_STOP);
  }

  private async finalyzeStaleSession(serial: string): Promise<number[]> {
    const stale = await this.sessionRepo.getRouletteStaleSessions(serial);
    await firstValueFrom(from(stale)
      .pipe(
        mergeMap(async sessionId => {
          try {
            await this.sessionService.finalizeSession(sessionId, SessionEndReason.NORMAL);
          } catch (e) {
            this.logger.error('Finalize session error', {
              sessionId,
              serial,
              errorMessage: e.message,
            });
          }
          return sessionId;
        }, 2),
        count(),
      ));
    return stale;
  }
}
