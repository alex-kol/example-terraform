import { GameId } from '@lib/dal';
import { StatusStrategyType } from './status.strategy.type';

export function statusStrategyIdFactory(gameId: GameId, type: StatusStrategyType): string {
  return `status-handling-strategy[${gameId}|${type}]`;
}