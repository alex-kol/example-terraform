export class RefurbishChip {
  value: number;
  isScatter: boolean;
}
