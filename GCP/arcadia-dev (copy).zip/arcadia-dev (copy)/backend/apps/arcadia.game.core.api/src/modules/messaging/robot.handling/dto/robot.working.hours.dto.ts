import { intTransformer } from '@lib/dal';
import { Transform } from 'class-transformer';
import { IsInt } from 'class-validator';
import { RobotMessage } from './robot.message';

export class RobotWorkingHoursDto extends RobotMessage {
  @Transform(intTransformer)
  @IsInt()
  public workingHours: number;
}
