export class GetChipsToPush {
  chipsToPush: Record<string, number>;
  hasChips: boolean;
  seedChipsToPush: Record<string, number>;
}