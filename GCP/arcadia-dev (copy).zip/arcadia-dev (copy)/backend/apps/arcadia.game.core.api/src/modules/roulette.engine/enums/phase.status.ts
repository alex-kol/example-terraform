export enum PhaseStatus {
  IN_PROGRESS = 'inProgress',
  COMPLETE = 'complete',
}
