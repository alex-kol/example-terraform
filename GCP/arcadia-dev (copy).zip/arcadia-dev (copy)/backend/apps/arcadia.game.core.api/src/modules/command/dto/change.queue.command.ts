import { IsArray, IsInt, IsOptional } from 'class-validator';
import { BaseCommand } from './base.command';

export class ChangeQueueCommand extends BaseCommand {
  @IsOptional()
  @IsArray()
  @IsInt({ each: true })
  public ignoreMachines?: number[];

  @IsOptional()
  @IsArray()
  @IsInt({ each: true })
  public ignoreGroups?: number[];
}
