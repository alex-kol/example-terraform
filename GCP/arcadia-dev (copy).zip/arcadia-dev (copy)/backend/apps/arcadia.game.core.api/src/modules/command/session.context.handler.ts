import {
  Configuration,
  GroupEntity,
  MachineEntity,
  OperatorEntity,
  PlayerEntity,
  SessionEntity,
  SessionRepository,
} from '@lib/dal';
import { RpcException } from '@nestjs/microservices';
import { DataSource } from 'typeorm';
import { Logger } from 'winston';
import { SessionAwareDto } from '../dto/session.aware.dto';
import { TransactionalHandler } from './transactional.handler';

export abstract class SessionContextHandler<T extends SessionAwareDto = SessionAwareDto>
  extends TransactionalHandler<T> {
  protected sessionId: number;
  protected session: SessionEntity;
  protected cachedSession: SessionEntity;
  protected cachedMachine: MachineEntity;
  protected cachedGroup: GroupEntity;
  protected cachedPlayer: PlayerEntity;
  protected cachedOperator: OperatorEntity;
  protected sessionRepository: SessionRepository;
  protected sessionConfig: Configuration;

  protected constructor(
    protected readonly logger: Logger,
    dataSource: DataSource,
  ) {
    super(logger, dataSource);
  }

  protected async init(data: T): Promise<void> {
    await super.init(data);
    const {
      sessionId,
      session,
    } = data;
    if (!sessionId || !session) {
      throw new RpcException('Session has not been injected!');
    }

    this.sessionId = Number(sessionId);
    this.cachedSession = session;
    this.cachedMachine = session.machine;
    this.cachedGroup = session.group;
    this.cachedOperator = session.operator;
    this.cachedPlayer = session.player;
    this.sessionConfig = session.configuration;

    this.sessionRepository = new SessionRepository(this.entityManager);
  }
}
