import { PhaseStatus } from '../enums';

export class PhaseResult {
  status: PhaseStatus;
  endTimestamp?: string;
}
