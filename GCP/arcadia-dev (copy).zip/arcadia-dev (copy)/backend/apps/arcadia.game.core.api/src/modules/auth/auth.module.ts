import { OperatorTag, QueueStrategyInfoProvider } from '@lib/common';
import { ConfigService } from '@lib/config';
import {
  ChipRepository,
  CMSRepository,
  CurrencyConversionRepository,
  GameId,
  GroupRepository,
  MachineRepository,
  OperatorRepository,
  PlayerRepository,
  RngChipPrizeRepository,
  RngPhantomPrizeRepository,
  RoundRepository,
  SessionArchiveRepository,
  SessionRepository,
  VoucherRepository,
} from '@lib/dal';
import { FileUrl } from '@lib/file.manager';
import { MonitoringWorkerClientModule } from '@lib/monitoring.worker.client';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { VideoApiClientModule } from '@lib/video.api';
import { Module } from '@nestjs/common';
import { ConfigValidatorModule } from '../config.validator/config.validator.module';
import { ConversionTrackerModule } from '../conversion.tracker/conversion.tracker.module';
import { IpCheckerModule } from '../ip.checker/ip.checker.module';
import { OperatorApiClientModule } from '../operator.api.client/operator.api.client.module';
import { PlayerClientModule } from '../player.client/player.client.module';
import { RobotClientModule } from '../robot.client/robot.client.module';
import { RouletteEngineModule } from '../roulette.engine/roulette.engine.module';
import { SessionDataManagerModule } from '../session.data.manager/session.data.manager.module';
import { SessionModule } from '../session/session.module';
import { WorkerClientModule } from '../worker.client/worker.client.module';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { ClawAuthService, ClawRouletteAuthService, CoinPusherAuthService } from './game.strategy';
import { ArcadiaLaunchUrlCreator } from './launch.url/arcadia.launch.url.creator';
import { CalienteLaunchUrlCreator } from './launch.url/caliente.launch.url.creator';
import { StandardLanguageMapper } from './launch.url/languages';
import { MicrogamingLaunchUrlCreator } from './launch.url/microgaming.launch.url.creator';
import { PariPlayLaunchUrlCreator } from './launch.url/pariPlay.launch.url.creator';
import { SolidGamingLaunchUrlCreator } from './launch.url/solid.gaming.launch.url.creator';
import { SpinomenalLaunchUrlCreator } from './launch.url/spinomenal.launch.url.creator';
import { urlCreatorTokenFactory } from './launch.url/url.creator.token.factory';
import { gameProviderKeyFactory } from './util/game.provider.key.factory';
import { PlainGamingLaunchUrlCreator } from './launch.url/plain.gaming.launch.url.creator';

@Module({
  imports: [
    SessionModule,
    OperatorApiClientModule,
    VideoApiClientModule,
    RobotClientModule,
    MonitoringWorkerClientModule,
    SessionDataManagerModule,
    IpCheckerModule,
    ConfigValidatorModule,
    PlayerClientModule,
    ConversionTrackerModule,
    VideoApiClientModule.register(
      {
        provide: 'VIDEO_CONFIG',
        useFactory: (config: ConfigService) => new Map(Object.entries(config.get(['core'])) as any),
        inject: [ConfigService],
      },
    ),
    RouletteEngineModule,
    WorkerClientModule,
    PlayerClientModule,
  ],
  controllers: [AuthController],
  providers: [
    AuthService,
    StandardLanguageMapper,
    FileUrl,
    {
      provide: urlCreatorTokenFactory(OperatorTag.SPINOMENAL),
      useClass: SpinomenalLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.MICROGAMING),
      useClass: MicrogamingLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.CALIENTE),
      useClass: CalienteLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.ARCADIA),
      useClass: ArcadiaLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.SOLID_GAMING),
      useClass: SolidGamingLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_ENG),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_EWN),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_LVT),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_LVLV),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_8X1),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_BPL),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_BVR),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_VSL),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_VW),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_VMO),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_VSP),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_VLJ),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_VGC),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_VG),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_VUC),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_MGR),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_VRC),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_VMG),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_VAC),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PLAIN_GAMING),
      useClass: PlainGamingLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_IBE),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_IBE1),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_S2B),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_CYS),
      useClass: PariPlayLaunchUrlCreator,
    },
    {
      provide: urlCreatorTokenFactory(OperatorTag.PARIPLAY_CYB),
      useClass: PariPlayLaunchUrlCreator,
    },
    MachineRepository,
    GroupRepository,
    PlayerRepository,
    OperatorRepository,
    SessionArchiveRepository,
    SessionRepository,
    CurrencyConversionRepository,
    RngChipPrizeRepository,
    ChipRepository,
    RoundRepository,
    VoucherRepository,
    CMSRepository,
    RngPhantomPrizeRepository,
    {
      provide: QueueStrategyInfoProvider,
      useFactory: redis => new QueueStrategyInfoProvider(redis),
      inject: [RedisCacheService],
    },
    {
      provide: gameProviderKeyFactory(GameId.COIN_PUSHER_V1),
      useClass: CoinPusherAuthService,
    },
    {
      provide: gameProviderKeyFactory(GameId.CLAW_ROULETTE),
      useClass: ClawRouletteAuthService,
    },
    {
      provide: gameProviderKeyFactory(GameId.CLAW),
      useClass: ClawAuthService,
    },
  ],
})
export class AuthModule {
}
