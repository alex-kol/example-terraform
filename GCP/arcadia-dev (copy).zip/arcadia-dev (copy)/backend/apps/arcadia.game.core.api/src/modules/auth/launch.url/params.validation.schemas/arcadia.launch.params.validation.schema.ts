import * as Joi from 'joi';
import { GameId } from '@lib/dal';
import { urlPattern } from '../../../../util';

export const arcadiaLaunchParamsValidationSchema = Joi.object({
  operator: Joi.string()
    .required(),
  accessToken: Joi.string()
    .required(),
  gameId: Joi
    .string()
    .valid(...Object.values(GameId))
    .required(),
  externalId: Joi.string(),
  groupId: Joi.string(),
  homeUrl: Joi.string()
    .pattern(urlPattern)
    .allow(null)
    .empty(null),
  languageCode: Joi.string(),
  cashierUrl: Joi.string()
    .pattern(urlPattern)
    .allow(null)
    .empty(null),
  jurisdiction: Joi.string()
    .allow(null)
    .empty(null),
});
