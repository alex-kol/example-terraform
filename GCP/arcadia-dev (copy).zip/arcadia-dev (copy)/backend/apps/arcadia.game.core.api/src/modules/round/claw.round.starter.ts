/* eslint-disable max-lines */
import { EventSource, TimeoutType } from '@lib/common';
import {
  ClawPhase,
  EntityManager,
  EventType,
  GroupEntity,
  MachineEntity,
  MachineRepository,
  OperatorEntity,
  PlayerEntity,
  PlayerRepository,
  RoundEntity,
  RoundRepository,
  RoundStatus,
  RoundType,
  SessionEntity,
  SessionRepository,
  SessionStatus,
  VoucherEntity,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Inject } from '@nestjs/common';
import BigNumber from 'bignumber.js';
import { Logger } from 'winston';
import { v4 as uuid } from 'uuid';
import { toCash } from '../../util';
import { RoundStartedDto } from '../messaging/player.handling/dto/round.started.dto';
import { BetData } from '../operator.api.client/dtos';
import { OperatorApiClientService } from '../operator.api.client/operator.api.client.service';
import { NotificationLevel } from '../player.client/notification.level';
import { NotificationType } from '../player.client/notification.type';
import { PlayerClientService } from '../player.client/player.client.service';
import { SessionDataManager } from '../session.data.manager/session.data.manager';
import { RoundContext } from './round.context';
import { RoundOptions } from './round.options';
import { RobotClientService } from '../robot.client/robot.client.service';
import { CoreMessage } from '../messaging/robot.handling/enum/core.message';
import { RngClientService } from '../rng.service.client/rng.client.service';
import { WorkerClientService } from '../worker.client/worker.client.service';

export class ClawRoundStarter {
  private readonly roundRepo: RoundRepository;
  private readonly sessionRepo: SessionRepository;
  private readonly playerRepo: PlayerRepository;
  private readonly machineRepo: MachineRepository;

  private readonly session: SessionEntity;
  private readonly machine: MachineEntity;
  private readonly player: PlayerEntity;
  private readonly group: GroupEntity;
  private readonly operator: OperatorEntity;
  private readonly vouchers: VoucherEntity[];
  private readonly correlationId: string;
  private readonly isAutoplayRound;

  constructor(
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly operatorClient: OperatorApiClientService,
    private readonly playerPublisher: PlayerClientService,
    private readonly monitoringService: MonitoringWorkerClientService,
    private readonly sessionDataManager: SessionDataManager,
    private readonly robotClientService: RobotClientService,
    private readonly rngClientService : RngClientService,
    private readonly workerClientService: WorkerClientService,
    context: RoundContext,
    manager: EntityManager,
  ) {
    this.sessionRepo = new SessionRepository(manager);
    this.roundRepo = new RoundRepository(manager);
    this.playerRepo = new PlayerRepository(manager);
    this.machineRepo = new MachineRepository(manager);

    this.session = context.session;
    this.operator = context.operator;
    this.player = context.player;
    this.group = context.group;
    this.machine = context.machine;
    this.isAutoplayRound = context.isAutoplayRound;
    this.vouchers = context.vouchers;
    this.correlationId = context.correlationId;
  }

  public async startRound(type: RoundType): Promise<RoundEntity> {
    const {
      bet,
      rtp,
      deductRound,
      countToLimit,
    } = await this.getRoundOptions(type);
    const betInCash = toCash(bet, this.session.currencyConversionRate);
    const round = await this.createRound(type, bet, betInCash);
    let betResult: BetData;
    try {
      betResult = await this.placeBet(betInCash, round.id);
    } catch (err) {
      await this.roundRepo.delete(round.id);
      this.logger.error('Bet transaction error');
      this.logger.error(err.message, err.stack);
      this.playerPublisher.notification(this.session.id,
        {
          notificationId: NotificationType.BET_FAILED,
          level: NotificationLevel.ERROR,
          title: 'Bet failed',
          message: 'Oops, something went wrong with your wallet!',
        });
      throw err;
    }
    const {
      transactionId,
      balance,
    } = betResult;
    await this.sessionDataManager.updateSessionData({
      transaction: {
        roundId: `${round.id}`,
        transactionId,
      },
    }, this.session.id);
    this.playerPublisher.notifyBalance(this.session.id, { valueInCash: balance });
    this.monitoringService.sendEventLogMessage({
      eventType: EventType.BET,
      source: EventSource.GAME,
      params: {
        sum: betInCash,
        sessionId: Number(this.session.id),
        round: Number(round.id),
        machineSerial: this.machine.serial,
        currency: this.session.currency,
        transactionId,
        type,
      },
    });
    await this.sessionRepo.countNewRound(this.session.id, bet, betInCash, deductRound, countToLimit);
    await this.playerRepo.countBet(this.player.cid, this.operator.id, bet);
    if (rtp) {
      await this.machineRepo.increment({ id: this.machine.id }, 'roundsCount', 1);
    }

    if (this.session.status === SessionStatus.RE_BUY) {
      const pickup = await this.rngClientService.clawRound(this.group.prizeGroup, this.session.configuration.rtpSegment);
      const roundStartMessage = await this.getRoundStartedMessage(round);
      this.robotClientService.sendRobotMessage(
        {
          action: CoreMessage.START_ROUND,
          pickup,
        },
        this.machine.serial,
      );
      this.playerPublisher.notifyRoundStart(this.session.id, roundStartMessage);
      this.monitoringService.sendEventLogMessage({
        eventType: EventType.START_ROUND,
        source: EventSource.GAME,
        params: {
          type: round.type,
          sessionId: this.session.id,
          machineSerial: this.machine.serial,
          round: round.id,
          pickup,
        },
      });
    }
    return round;
  }

  public async getRoundStartedMessage(
    round: RoundEntity,
  ): Promise<RoundStartedDto> {
    const {
      deductRound,
      countToLimit,
    } = await this.getRoundOptions(round.type);
    const stackBuyLimit = new BigNumber(this.session.configuration.stackBuyLimit)
      .minus(this.session.totalStacksUsed)
      .minus(countToLimit)
      .toNumber();
    const rounds = new BigNumber(this.session.roundsLeft).minus(deductRound)
      .toNumber();
    const betBehindRounds = 0;

    await this.workerClientService.timeoutStart({
      timeoutType: TimeoutType.IDLE,
      sessionId: this.session.id,
      timeoutSec: this.group.configuration.idleTimeout,
      payload: { gameId: this.machine.gameId },
    },
    uuid(),
    options => this.playerPublisher.setCountdown(this.session.id, options.timeoutSec),
    );

    await this.sessionDataManager.updateSessionData({ clawPhase: ClawPhase.WAITING_MOVING_RIGHT }, this.session.id);

    return {
      type: round.type,
      stackBuyLimit,
      rounds,
      betBehindRounds,
      totalBet: round.betInCash,
    };
  }

  private async createRound(
    type: RoundType, bet: number, betInCash: number,
    status = RoundStatus.ACTIVE,
  ): Promise<RoundEntity> {
    const round = this.roundRepo.create({
      type,
      status,
      coins: 0,
      bet,
      betInCash,
      session: this.session,
      rtp: [],
      machineId: this.machine.id,
      isAutoplay: this.isAutoplayRound,
      voucherId: (type === RoundType.VOUCHER && this.vouchers.length) ? this.vouchers[0].id : null,
    });
    return this.roundRepo.save(round, { transaction: false });
  }

  private async placeBet(betInCash: number, roundId: number): Promise<BetData> {
    const { loginOptions } = await this.sessionDataManager.getSessionData(this.session.id);
    const {
      sessionToken,
      extGameId,
    } = loginOptions;
    return this.operatorClient.bet(
      {
        accessToken: sessionToken,
        operator: this.operator,
        cid: this.player.cid,
        amount: betInCash,
        roundId,
        correlationId: this.correlationId,
        gameId: this.session.gameId,
        extGameId,
      },
    );
  }

  private async getRoundOptions(roundType: RoundType): Promise<RoundOptions> {
    const result: RoundOptions = {
      bet: Number(this.group.denominator),
      rtp: true,
      deductRound: 1,
      countToLimit: 1,
    };
    switch (roundType) {
      case RoundType.VOUCHER:
        result.bet = 0;
        result.countToLimit = 0;
        result.deductRound = this.vouchers.length;
        break;
      case RoundType.REGULAR:
      default:
    }
    return result;
  }
}
