import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class VideoStreamAuthDto {
  @ApiProperty()
  @IsNotEmpty()
  public token: string;
}
