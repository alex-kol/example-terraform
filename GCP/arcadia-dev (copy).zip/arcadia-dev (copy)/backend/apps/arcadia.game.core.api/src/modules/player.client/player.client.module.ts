import { ConfigService } from '@lib/config';
import { MAIN_LOGGER } from '@lib/logger';
import { Global, Module } from '@nestjs/common';
import { Emitter } from '@socket.io/redis-emitter';
import Redis from 'ioredis';
import { Logger } from 'winston';
import { PlayerClientService } from './player.client.service';

const playerClientPublisher = {
  provide: Emitter,
  useFactory: (configService: ConfigService, logger: Logger): Emitter => {
    const redisClient = new Redis(configService.getRedisConfig());
    const emitter = new Emitter(redisClient);
    redisClient.on('error', error => {
      logger.error(error.message, { stack: error.stack });
    });
    return emitter;
  },
  inject: [ConfigService, MAIN_LOGGER],
};

@Global()
@Module({
  providers: [PlayerClientService, playerClientPublisher],
  exports: [PlayerClientService],
})
export class PlayerClientModule {
}
