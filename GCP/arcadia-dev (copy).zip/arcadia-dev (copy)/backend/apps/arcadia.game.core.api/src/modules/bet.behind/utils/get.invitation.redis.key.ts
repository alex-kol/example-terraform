import { cacheInvitationKey } from '../constants';

export const getInvitationRedisKey = (sessionId: number | string): string => `${cacheInvitationKey}${sessionId}`;
