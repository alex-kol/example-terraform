import { RouletteField } from '@lib/dal';
import { BetPosition } from '../enums';
import { RouletteBet } from '../types';
import { rouletteWinCalculator } from './roulette.win.calculator';

const allPositionsBetMock: RouletteBet = Object.values(BetPosition)
  .reduce((acc, pos) => {
    acc[pos] = [1];
    return acc;
  }, {});

const inputData = [
  {
    winField: RouletteField.FIELD_00,
    expectedWin: 121
  },
  {
    winField: RouletteField.FIELD_0,
    expectedWin: 160
  },
  {
    winField: RouletteField.FIELD_1,
    expectedWin: 157
  },
  {
    winField: RouletteField.FIELD_2,
    expectedWin: 238
  },
  {
    winField: RouletteField.FIELD_3,
    expectedWin: 187
  },
  {
    winField: RouletteField.FIELD_4,
    expectedWin: 144
  },
  {
    winField: RouletteField.FIELD_5,
    expectedWin: 180
  },
  {
    winField: RouletteField.FIELD_6,
    expectedWin: 144
  },
  {
    winField: RouletteField.FIELD_7,
    expectedWin: 144
  },
  {
    winField: RouletteField.FIELD_8,
    expectedWin: 180
  },
  {
    winField: RouletteField.FIELD_9,
    expectedWin: 144
  },
  {
    winField: RouletteField.FIELD_10,
    expectedWin: 144
  },
  {
    winField: RouletteField.FIELD_11,
    expectedWin: 180
  },
  {
    winField: RouletteField.FIELD_12,
    expectedWin: 144
  },
  {
    winField: RouletteField.FIELD_13,
    expectedWin: 144
  },
  {
    winField: RouletteField.FIELD_14,
    expectedWin: 180
  },
  {
    winField: RouletteField.FIELD_15,
    expectedWin: 144
  },
  {
    winField: RouletteField.FIELD_16,
    expectedWin: 144
  },
  {
    winField: RouletteField.FIELD_17,
    expectedWin: 180
  },
  {
    winField: RouletteField.FIELD_18,
    expectedWin: 144
  },
  {
    winField: RouletteField.FIELD_19,
    expectedWin: 144
  },
  {
    winField: RouletteField.FIELD_20,
    expectedWin: 180
  },
  {
    winField: RouletteField.FIELD_21,
    expectedWin: 144
  },
  {
    winField: RouletteField.FIELD_22,
    expectedWin: 144
  },
  {
    winField: RouletteField.FIELD_23,
    expectedWin: 180
  },
  {
    winField: RouletteField.FIELD_24,
    expectedWin: 144
  },
  {
    winField: RouletteField.FIELD_25,
    expectedWin: 144
  },
  {
    winField: RouletteField.FIELD_26,
    expectedWin: 180
  },
  {
    winField: RouletteField.FIELD_27,
    expectedWin: 144
  },
  {
    winField: RouletteField.FIELD_28,
    expectedWin: 144
  },
  {
    winField: RouletteField.FIELD_29,
    expectedWin: 180
  },
  {
    winField: RouletteField.FIELD_30,
    expectedWin: 144
  },
  {
    winField: RouletteField.FIELD_31,
    expectedWin: 144
  },
  {
    winField: RouletteField.FIELD_32,
    expectedWin: 180
  },
  {
    winField: RouletteField.FIELD_33,
    expectedWin: 144
  },
  {
    winField: RouletteField.FIELD_34,
    expectedWin: 111
  },
  {
    winField: RouletteField.FIELD_35,
    expectedWin: 138
  },
  {
    winField: RouletteField.FIELD_36,
    expectedWin: 111
  },
];

describe('Roulette win matrix', () => {
  test.each(inputData)('Win field: "$winField"', ({
    winField,
    expectedWin
  }) => {
    const {
      totalWinInValue,
      totalWinInCash
    } = rouletteWinCalculator(allPositionsBetMock, winField, 1);
    expect(totalWinInValue)
      .toStrictEqual(expectedWin);
    expect(totalWinInCash)
      .toStrictEqual(expectedWin);
  });
});
