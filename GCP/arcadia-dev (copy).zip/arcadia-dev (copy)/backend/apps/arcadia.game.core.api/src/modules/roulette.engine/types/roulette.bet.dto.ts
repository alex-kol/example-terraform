import { IsEnum, IsNumber, IsPositive } from 'class-validator';
import { SessionAwareDto } from '../../dto/session.aware.dto';
import { BetPosition } from '../enums';

export class RouletteBetDto extends SessionAwareDto {
  @IsEnum(BetPosition)
  public position: BetPosition;

  @IsNumber()
  @IsPositive()
  public bet: number;
}
