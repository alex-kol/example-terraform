import { NotificationLevel } from './notification.level';
import { NotificationType } from './notification.type';

export class PlayerNotification {
  notificationId: NotificationType;
  title: string;
  message: string;
  level: NotificationLevel;
  command?: string;
  data?: Record<string, any>;
}