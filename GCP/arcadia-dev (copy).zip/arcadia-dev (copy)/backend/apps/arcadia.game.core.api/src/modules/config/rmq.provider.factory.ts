import { RmqQueueName } from '@lib/common';
import { ConfigService } from '@lib/config';
import { MAIN_LOGGER } from '@lib/logger';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { RmqModuleRegisterData } from '@lib/rmq.server';
import { SESSION_LOCK_TTL_SEC } from '../../constants/redis.constants';

export const rmqProviderFactory = () => new RmqModuleRegisterData(
  {
    provide: 'RMQ_LOGGER',
    useFactory: logger => logger,
    inject: [MAIN_LOGGER],
  },
  {
    provide: 'RMQ_URLS',
    useFactory: (config: ConfigService) => config.getRabbitMQConfig(),
    inject: [ConfigService],
  },
  [
    RmqQueueName.WORKER_TO_CORE_QUEUE,
    RmqQueueName.CORE_COMMAND_QUEUE,
    RmqQueueName.PLAYER_TO_CORE_QUEUE,
    RmqQueueName.ROBOT_TO_CORE_QUEUE,
  ],
  {
    prefetchCount: 10,
  },
  {
    ttlSec: SESSION_LOCK_TTL_SEC,
    lockKeyPrefix: 'core-message-sync-key',
    lockStrategy: packet => packet?.data?.sessionId || packet?.data?.serial,
    redisCacheProvider: {
      provide: 'RMQ_CACHE',
      useFactory: cache => cache,
      inject: [RedisCacheService],
    },
  },
);
