import {
  GameId, MachineRepository, QueueRepository, SessionEndReason, SessionRepository,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { Inject, Injectable } from '@nestjs/common';
import { count, firstValueFrom, mergeMap } from 'rxjs';
import { Logger } from 'winston';
import { CommandPublisher } from '../../command/command.publisher';
import { RouletteEventCommand } from '../../command/dto/roulette.event.command';
import { PlayerClientService } from '../../player.client/player.client.service';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { RoundContext } from '../../round/round.context';
import { RoundServiceFactory } from '../../round/round.service.factory';
import { SessionDataManager } from '../../session.data.manager/session.data.manager';
import { SessionService } from '../../session/session.service';
import { BetManager } from '../bet.manager';
import { GamePhase, PhaseStatus } from '../enums';
import { CommonContext, PhaseResult } from '../types';
import { PhaseHandler } from './phase.handler';

@Injectable()
export class ProcessBetsPhaseHandler extends PhaseHandler {
  constructor(
    commandPublisher: CommandPublisher,
    betManager: BetManager,
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly sessionService: SessionService,
    private readonly roundCreatorFactory: RoundServiceFactory,
    private readonly playerPublisher: PlayerClientService,
    private readonly sessionDataManager: SessionDataManager,
    robotPublisher: RobotClientService,
    sessionRepo: SessionRepository,
    machineRepo: MachineRepository,
    queueRepo: QueueRepository,
  ) {
    super(
      commandPublisher,
      betManager,
      sessionRepo,
      machineRepo,
      robotPublisher,
      queueRepo,
    );
  }

  public async onStart({ serial }: CommonContext): Promise<PhaseResult> {
    await this.robotPublisher.sendRouletteDisplayMessage(serial, { phase: GamePhase.PROCESS_BETS });
    await firstValueFrom(this.betManager.getMachineBets(serial)
      .pipe(
        mergeMap(async ({
          sessionId,
          bet,
        }) => {
          const session = await this.sessionService.findByIdCached(sessionId);
          if (!session) {
            return 1;
          }
          const {
            machine,
            queue,
            player,
            group,
            operator,
          } = session;
          this.playerPublisher.gamePhase(sessionId, { phase: GamePhase.PROCESS_BETS });
          const ctx: RoundContext = new RoundContext(session, queue, machine, player, group, operator, false);
          try {
            await this.roundCreatorFactory.getStarter(GameId.CLAW_ROULETTE, ctx).startRound(bet as any);
            await this.sessionDataManager.updateSessionData({ lastBet: bet }, sessionId);
          } catch (err) {
            await this.betManager.removeBet(serial, sessionId);
            this.finalizeSession(serial, sessionId, SessionEndReason.WALLET_TRANSACTION_ERROR, true);
          }
          return 1;
        }),
        count(),
      ));
    return { status: PhaseStatus.COMPLETE };
  }

  public onComplete(context: CommonContext): Promise<void> {
    return Promise.resolve();
  }

  public onError(context: CommonContext): Promise<void> {
    return Promise.resolve();
  }

  public async playerQuit(
    context: CommonContext,
    event: RouletteEventCommand<{ sessionId: number }>,
  ): Promise<void> {
    this.logger.warn('Roulette event ignored', {
      serial: context.serial,
      sessionId: event.data.sessionId,
      event: event.eventType,
      handler: ProcessBetsPhaseHandler.name,
    });
  }
}
