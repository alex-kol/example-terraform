import { GameId, MachineRepository, OperatorRepository } from '@lib/dal';
import { Module } from '@nestjs/common';
import { ConfigValidator } from './config.validator';
import { clawRouletteSchema, clawSchema, coinPusherSchema } from './shemas';
import { validationSchemaKeyFactory } from './util/validation.schema.key.factory';

export type ValidationContext = { level: 'machine' | 'group' | 'operator' };

@Module({
  providers: [ConfigValidator,
    {
      provide: validationSchemaKeyFactory(GameId.COIN_PUSHER_V1),
      useValue: coinPusherSchema,
    },
    {
      provide: validationSchemaKeyFactory(GameId.CLAW_ROULETTE),
      useValue: clawRouletteSchema,
    },
    {
      provide: validationSchemaKeyFactory(GameId.CLAW),
      useValue: clawSchema,
    },
    MachineRepository,
    OperatorRepository,
  ],
  exports: [ConfigValidator],
})
export class ConfigValidatorModule {

}
