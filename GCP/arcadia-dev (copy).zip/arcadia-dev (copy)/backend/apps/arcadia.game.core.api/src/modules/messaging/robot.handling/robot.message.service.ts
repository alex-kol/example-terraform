/* eslint-disable max-lines */
import {
  AlertDescription, Cache, CommandType, EventSource, TimeoutType,
} from '@lib/common';
import { ConfigService } from '@lib/config';
import {
  AlertAction,
  AlertSeverity,
  AlertSource,
  AlertType,
  AutoSwingMode,
  BallEntity,
  BallRepository,
  ChipEntity,
  ChipRepository,
  Configuration,
  EventType,
  GameId,
  GroupEntity,
  GroupRepository,
  GroupStatus,
  MachineDispenserEntity,
  MachineDispenserRepository,
  MachineEntity,
  MachineRepository,
  MachineStatus,
  QueueRepository,
  QueueStatus,
  RngChipPrizeRepository,
  RouletteField,
  RouletteType,
  RoundEntity,
  RoundType,
  SeedHistoryRepository,
  SessionEndReason,
  SessionRepository,
  SessionStatus,
  ShutdownReason,
  VoucherStatus,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { Alert, MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import {
  Inject, Injectable, NotAcceptableException, UnauthorizedException,
} from '@nestjs/common';
import { ModuleRef } from '@nestjs/core';
import { RpcException } from '@nestjs/microservices';
import BigNumber from 'bignumber.js';
import moment from 'moment';
import {
  from, interval, lastValueFrom, of, zip,
} from 'rxjs';
import {
  concatMap, mergeMap, repeat, toArray,
} from 'rxjs/operators';
import { v4 as uuidv4 } from 'uuid';
import { Logger } from 'winston';
import { RedisList } from '@lib/redis.cache/redis.list';
import { PHANTOM_CHIP_TYPE_NAME } from '../../../constants/phantom.type';
import { engageLockKeyFactory, reassignRtpKeyFactory } from '../../../util';
import { CommandPublisher } from '../../command/command.publisher';
import { ConfigValidator } from '../../config.validator/config.validator';
import { ConversionTracker } from '../../conversion.tracker/conversion.tracker';
import { EntrySource } from '../../conversion.tracker/entry.source';
import { GroupTerminatorService } from '../../group.terminator/group.terminator.service';
import { PlayerClientService } from '../../player.client/player.client.service';
import { QueueManagerService } from '../../queue.manager/queue.manager.service';
import { RngClientService } from '../../rng.service.client/rng.client.service';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { RoundContext } from '../../round/round.context';
import { RoundServiceFactory } from '../../round/round.service.factory';
import { SessionDataManager } from '../../session.data.manager/session.data.manager';
import { SessionService } from '../../session/session.service';
import { WorkerClientService } from '../../worker.client/worker.client.service';
import {
  AddBallDto, ChipDto, GetChipsToPush, RobotMessage, RobotPositionDto, RobotWorkingHoursDto,
} from './dto';
import { PlayerAbuseDto } from './dto/player.abuse.dto';
import { RobotLoginDto } from './dto/robot.login.dto';
import { CoreMessage } from './enum/core.message';
import { RobotLoginInterface } from './login.strategies/robot.login.interface';
import { RobotLoginRes } from './responses/robot.login.res';
import { robotLoginKeyFactory } from './util/robot.login.key.factory';
import { SeedValue } from '../../rng.service.client/dto/seed.value';
import { ChipWatcherService } from '../../chip.watcher/chip.watcher.service';
import { AutoplayStatus } from '../player.handling/enum/autoplay.status';
import { SessionAwareDto } from '../../dto/session.aware.dto';

@Injectable()
export class RobotMessageService {
  private readonly secret: string;
  private readonly robotEngageTimeoutSec: number;
  private readonly terminateSessionTimeoutSec: number;

  constructor(
    private readonly machineRepo: MachineRepository,
    private readonly chipRepo: ChipRepository,
    private readonly chipWatcherService: ChipWatcherService,
    private readonly queueRepo: QueueRepository,
    private readonly sessionRepo: SessionRepository,
    private readonly dispenserRepo: MachineDispenserRepository,
    private readonly seedHistoryRepo: SeedHistoryRepository,
    private readonly rngChipPrizeRepo: RngChipPrizeRepository,
    private readonly groupRepo: GroupRepository,
    private readonly ballRepository: BallRepository,
    private readonly sessionService: SessionService,
    private readonly robotClient: RobotClientService,
    private readonly playerClient: PlayerClientService,
    private readonly workerClient: WorkerClientService,
    private readonly monitoringClient: MonitoringWorkerClientService,
    private readonly configService: ConfigService,
    private readonly queueManager: QueueManagerService,
    public readonly cacheManager: RedisCacheService,
    public readonly redisList: RedisList,
    private readonly rngClient: RngClientService,
    private readonly roundServiceFactory: RoundServiceFactory,
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly groupTerminator: GroupTerminatorService,
    private readonly sessionDataManager: SessionDataManager,
    private readonly configValidator: ConfigValidator,
    private readonly commandPublisher: CommandPublisher,
    private readonly conversionTracker: ConversionTracker,
    private readonly moduleRef: ModuleRef,
  ) {
    this.secret = this.configService.get(['core', 'ROBOTS_AUTH_SECRET']);
    this.robotEngageTimeoutSec = this.configService.get(['core', 'ROBOT_ENGAGE_TIMEOUT_SEC']);
    this.terminateSessionTimeoutSec = this.configService.get(['core', 'TERMINATE_SESSION_TIMEOUT_SEC']);
  }

  public async loginRobot(loginData: RobotLoginDto): Promise<RobotLoginRes> {
    const {
      serial,
      secret,
    } = loginData;
    if (this.secret !== secret) {
      throw new UnauthorizedException('Incorrect secret');
    }
    const machine = await this.machineRepo.findOneOrFail({
      where: { serial },
      relations: ['queue', 'group', 'site', 'cameras'],
    });

    return this.moduleRef.get<RobotLoginInterface>(robotLoginKeyFactory(machine.gameId))
      .loginRobot(machine, loginData);
  }

  public async handleEngaged(data: RobotMessage): Promise<void> {
    const {
      sessionId,
      session: cachedSession,
      correlationId,
    } = data;
    const session = await this.sessionRepo.findOneOrFail({
      where: { id: sessionId },
      relations: ['rounds'],
    });
    const { coins } = session.getActiveRound();
    const { machine } = data.session;
    await this.robotClient.sendAllowCoinsMessage(coins, machine.serial, sessionId);
    await this.sessionRepo.update(sessionId, {
      queueDuration: moment()
        .diff(session.createDate, 'seconds') - session.viewerDuration,
    });

    await this.workerClient.timeoutStart({
      timeoutType: TimeoutType.IDLE,
      sessionId,
      timeoutSec: GroupEntity.getIdleTimeoutSec(cachedSession.group) + cachedSession.group.graceTimeout,
      payload: { gameId: machine.gameId },
    },
    correlationId,
    options => this.playerClient.setCountdown(sessionId, options.timeoutSec),
    );
    await this.monitoringClient.sendEventLogMessage({
      eventType: EventType.ENGAGED,
      source: EventSource.ROBOT,
      params: {
        sessionId,
        machineSerial: data.serial,
      },
    });

    await this.queueManager.notifyQueueUpdate(data.session.queue.id, session);
    await this.releaseEngageLock(machine.id);
    // delay for better start/stop correlation under load
    await new Promise<void>(resolve => {
      setTimeout(async () => {
        await this.workerClient.timeoutStop({
          timeoutType: TimeoutType.ENGAGE,
          sessionId,
          payload: { gameId: machine.gameId },
        }, correlationId);
        resolve();
      }, 200);
    });
    this.logger.info('Machine engaged game session', {
      sessionId,
      serial: machine.serial,
    });
  }

  public async handleDisengaged({
    sessionId,
    serial,
    correlationId,
    session: injectedSession,
  }: RobotMessage): Promise<void> {
    if (!sessionId || !injectedSession?.queue) {
      throw new RpcException('No-session disengage');
    }

    const session = await this.sessionRepo.findOne({
      where: { id: sessionId },
      relations: ['machine'],
    });
    if (!session) {
      this.logger.error('No session found on disengage', { sessionId });
      await this.seeding(serial);
      return;
    }

    const {
      queue,
      player,
    } = injectedSession;

    const { machine } = session;
    this.monitoringClient.sendEventLogMessage({
      eventType: EventType.BREAKUP,
      source: EventSource.ROBOT,
      params: {
        sessionId,
        machineSerial: serial,
        playerCid: player?.cid,
      },
    });
    const terminate = session.status === SessionStatus.TERMINATING;
    if (terminate) {
      await this.workerClient.timeoutStop({
        timeoutType: TimeoutType.DISENGAGE,
        sessionId,
        payload: { gameId: machine.gameId },
      }, correlationId);
    }
    await this.workerClient.timeoutStop({
      timeoutType: TimeoutType.IDLE,
      sessionId,
      payload: { gameId: machine.gameId },
    }, correlationId);
    await this.workerClient.timeoutStop({
      timeoutType: TimeoutType.REBUY,
      sessionId,
      payload: { gameId: machine.gameId },
    }, correlationId);

    const {
      endReason,
      loginOptions,
    } = await this.sessionDataManager.getSessionData(sessionId);
    delete loginOptions.sessionToken;
    await this.conversionTracker.createTracker(player, EntrySource.RETENTION, loginOptions);
    await this.sessionService
      .finalizeSession(session.id, endReason || SessionEndReason.NORMAL, terminate);

    if (machine.status === MachineStatus.READY || machine.status === MachineStatus.IN_PLAY) {
      await this.queueManager.notifyQueueUpdate(queue.id);
      await this.seeding(serial);
    }
  }

  private async validateChipPush(
    dispenser: MachineDispenserEntity, chip: ChipEntity, machine: MachineEntity, group: GroupEntity,
  ): Promise<void | never> {
    if (!chip) {
      throw new Error('Chip not found');
    }
    if (!dispenser) {
      throw new Error('Dispenser not found');
    }
    if (dispenser.chipType.name !== chip.type.name) {
      throw new Error('Dispenser and chip types do not match');
    }
    const config = await this.configValidator.getValidatedConfig(machine.serial);
    const chipPrize = await this.rngChipPrizeRepo
      .getChipPrize(group.prizeGroup, chip.type.id, config.rtpSegment);
    if (!chipPrize) {
      throw new Error('Chip prize not found');
    }
    if (chip.machine) {
      throw new Error(`Chip is already registered to another machine: ${chip.machine.name}`);
    }
    if (chip.site.id !== machine.site.id) {
      throw new Error(`Chip is registered to another site: ${chip.site.name}`);
    }
  }

  public async chipPushValidation(data: ChipDto): Promise<void> {
    const {
      rfid,
      serial,
      dispenser: dispenserName,
    } = data;
    const [machine, chip] = await Promise.all([
      this.machineRepo.findOneOrFail({
        where: { serial },
        relations: ['group', 'site', 'dispensers', 'dispensers.chipType'],
      }),
      this.chipRepo.findOne({
        where: { rfid },
        relations: ['type', 'machine', 'site'],
      }),
    ]);
    const dispenser = machine.dispensers?.find(value => value.name === dispenserName);
    try {
      await this.validateChipPush(dispenser, chip, machine, machine.group);
      await this.robotClient.sendChipValidationMessage(rfid, true, machine.serial, chip.type.name);
    } catch (err) {
      this.monitoringClient.sendAlertMessage({
        alertType: AlertType.ALERT,
        severity: AlertSeverity.MEDIUM,
        source: AlertSource.GAME_CORE,
        description: AlertDescription.INVALID_CHIP_DETECTED,
        gameId: machine.gameId,
        details: {
          rfid,
          chipType: chip?.type?.name,
          machineId: machine.id,
          machineName: machine.name,
          machineSerial: machine.serial,
          error: err.message,
        },
      });
      await this.robotClient.sendChipValidationMessage(rfid, false, machine.serial, chip?.type?.name);
    }
  }

  public async chipPushed(data: ChipDto): Promise<void> {
    const {
      rfid,
      dispenser: dispenserName,
      serial,
      correlationId,
    } = data;
    const [machine, chip] = await Promise.all([
      this.machineRepo.findOneOrFail({
        where: { serial },
        relations: ['dispensers', 'dispensers.chipType', 'group'],
      }),
      this.chipRepo.findOneOrFail({
        where: { rfid },
        relations: ['type'],
      }),
    ]);
    const { group } = machine;

    const refurbishChip = await this.chipWatcherService.getChipFromRefurbishList(machine.id, chip.type.id);

    const dispenser = machine.dispensers?.find(dispenser => dispenser.name === dispenserName);
    if (!dispenser) {
      await this.groupTerminator.groupHardStop(machine.gameId, group.id, {
        reason: ShutdownReason.DISPENSER_NOT_FOUND,
        machineIds: [machine.id],
      }, correlationId);
      throw new RpcException('Dispenser not found');
    }
    await this.dispenserLevelCheck(dispenser, machine, correlationId);

    const config = await this.configValidator.getValidatedConfig(machine.serial);
    await this.monitoringClient.sendEventLogMessage({
      eventType: EventType.CHIP_ADDED,
      source: EventSource.ROBOT,
      params: {
        rfid,
        type: chip.type.name,
        machineId: machine.id,
        machineSerial: machine.serial,
        groupId: group.id,
      },
    });
    try {
      if (refurbishChip) {
        const { value, isScatter } = refurbishChip;
        await this.chipRepo.update(chip.rfid, {
          machine,
          value,
          isScatter,
        });
        return;
      }
      if (chip.type.name === PHANTOM_CHIP_TYPE_NAME) {
        const phantomSeed = await this.rngClient.phantom(group.prizeGroup, config.rtpSegment);
        await this.chipRepo.update(chip.rfid, {
          machine,
          value: new BigNumber(phantomSeed.value).multipliedBy(group.denominator)
            .dp(2)
            .toNumber(),
          isScatter: phantomSeed.type === 'scatter',
        });
      } else {
        const chipPrize = await this.rngChipPrizeRepo
          .getChipPrize(group.prizeGroup, chip.type.id, config.rtpSegment);
        await this.chipRepo.update(chip.rfid,
          {
            machine,
            value: new BigNumber(chipPrize.chipValue).multipliedBy(group.denominator)
              .dp(2)
              .toNumber(),
            isScatter: false,
          });
      }
      if (machine.status === MachineStatus.SEEDING || machine.status === MachineStatus.SHUTTING_DOWN) {
        await this.chipWatcherService.pushToSeededChipList(machine.id, chip.type.name);
      }
    } catch (err) {
      this.logger.error('Chip value calc failed', { errorMessage: err.message });
      this.monitoringClient.sendAlertMessage({
        alertType: AlertType.ERROR,
        severity: AlertSeverity.HIGH,
        source: AlertSource.GAME_CORE,
        description: AlertDescription.CHIP_VALUE_CALC_FAILED,
        gameId: machine.gameId,
        details: {
          rfid: chip.rfid,
          chipType: chip.type.name,
          machineId: machine.id,
          machineName: machine.name,
          machineSerial: machine.serial,
          error: err.message,
        },
      });
      await this.groupTerminator.groupHardStop(machine.gameId, group.id, {
        reason: ShutdownReason.CHIP_VALUE_CALC_FAILED,
        machineIds: [machine.id],
      }, correlationId);
      throw err;
    }
  }

  private async dispenserLevelCheck(
    dispenser: MachineDispenserEntity, machine: MachineEntity, correlationId: string,
  ): Promise<void> {
    const dispenserLevelDecremented = dispenser.level - 1;
    if (dispenserLevelDecremented === dispenser.alertThreshold) {
      this.monitoringClient.sendAlertMessage({
        alertType: AlertType.MAINTENANCE,
        severity: AlertSeverity.CRITICAL,
        source: AlertSource.GAME_CORE,
        description: AlertDescription.DISPENSER_IS_RUNNING_LOW,
        action: AlertAction.FILL_DISPENSER,
        gameId: machine.gameId,
        details: {
          dispenserName: dispenser.name,
          dispenserLevel: dispenserLevelDecremented,
          chipType: dispenser.chipType.name,
          machineId: machine.id,
          machineSerial: machine.serial,
          machineName: machine.name,
        },
      });
    }
    if (dispenser.level <= 0) {
      this.monitoringClient.sendAlertMessage({
        alertType: AlertType.MAINTENANCE,
        severity: AlertSeverity.CRITICAL,
        source: AlertSource.GAME_CORE,
        description: AlertDescription.DISPENSER_IS_RUNNING_LOW,
        action: AlertAction.FILL_DISPENSER,
        gameId: machine.gameId,
        details: {
          dispenserName: dispenser.name,
          dispenserLevel: 0,
          chipType: dispenser.chipType.name,
          machineId: machine.id,
          machineSerial: machine.serial,
          machineName: machine.name,
        },
      });
      await this.groupTerminator.groupHardStop(machine.gameId, machine.group.id, {
        reason: ShutdownReason.EMPTY_DISPENSER,
        machineIds: [machine.id],
      }, correlationId);
      throw new RpcException('Dispenser is empty');
    }
    await this.dispenserRepo.decrementDispenserLevel(dispenser.id);
  }

  public async chipRemoved(data: ChipDto): Promise<void> {
    const {
      rfid,
      serial,
      dispenser: dispenserName,
      correlationId,
    } = data;
    this.logger.info('Chip removed', {
      rfid,
      serial,
    });
    const machine = await this.machineRepo.findOneOrFail({
      where: { serial },
      relations: ['dispensers', 'dispensers.chipType', 'group'],
    });
    if (rfid !== 'calibration') {
      this.monitoringClient.sendAlertMessage({
        alertType: AlertType.MAINTENANCE,
        severity: AlertSeverity.LOW,
        source: AlertSource.GAME_CORE,
        description: 'Chip removed',
        gameId: machine.gameId,
        details: {
          rfid,
          machineId: machine.id,
          machineName: machine.name,
          machineSerial: machine.serial,
        },
      });
    }
    const dispenser = machine.dispensers?.find(dispenser => dispenser.name === dispenserName);
    if (!dispenser) {
      await this.groupTerminator.groupHardStop(
        machine.gameId,
        machine.group.id,
        {
          reason: ShutdownReason.DISPENSER_NOT_FOUND,
          machineIds: [machine.id],
        },
        correlationId,
      );
      throw new RpcException('Dispenser not found');
    }
    await this.dispenserLevelCheck(dispenser, machine, correlationId);
  }

  public async engageNextSession(
    machineId: number,
    reBuySessionId?: number,
    correlationId: string = uuidv4(),
  ): Promise<void> {
    const lock = await this.acquireEngageLock(machineId);
    if (!lock) {
      this.logger.debug('Engage skipped due to lock', { machineId });
      return;
    }

    let releaseLock = true;
    try {
      const machine = await this.machineRepo.getMachineToEngage(machineId);
      if (!machine) {
        throw new RpcException(`Machine not found, cant engage: machineId=${machineId}`);
      }
      const {
        queue,
        group,
      } = machine;
      const nextSession = await this.sessionRepo.getNextSessionForQueue(queue.id);
      if (!nextSession) {
        if (machine.status !== MachineStatus.READY) {
          await this.machineRepo.update(machine.id, { status: MachineStatus.READY });
        }

        const viewers = await this.sessionRepo.getViewersByMachineId(machineId);
        if (viewers.length) {
          this.monitoringClient.sendEventLogMessage({
            eventType: EventType.MACHINE_VIEWERS,
            source: EventSource.GAME,
            params: {
              machineSerial: machine.serial,
              groupId: group.id,
              viewers,
            },
          });
        }

        return;
      }

      const isRebuy = Number(nextSession.id) === reBuySessionId;
      if (!this.canEngageNewSession(machine, isRebuy)) {
        this.logger.warn('Skip engage new session', {
          machineSerial: machine.serial,
          machineStatus: machine.status,
          queueStatus: queue.status,
          nextSessionId: nextSession.id,
          reBuySessionId: reBuySessionId || null,
        });
        return;
      }

      if (nextSession.isDisconnected && !isRebuy) {
        await this.sessionRepo.update(nextSession.id, {
          status: SessionStatus.VIEWER,
          roundsLeft: 0,
          buyDate: null,
        }, data => this.playerClient.sessionState(nextSession.id, { status: data.status }));
        await this.sessionDataManager.removeSessionData(['autoplay', 'betBehind'],
          nextSession.id,
        );
        await this.workerClient.timeoutStart({
          timeoutType: TimeoutType.TERMINATE_SESSION,
          sessionId: Number(nextSession.id),
          timeoutSec: this.terminateSessionTimeoutSec,
          payload: { reason: SessionEndReason.VIEWER_DISCONNECTED, gameId: machine.gameId },
        });
        this.commandPublisher.engageNextSession({
          type: CommandType.ENGAGE_SESSION,
          gameId: machine.gameId,
          machineId,
        }, correlationId);
        return;
      }

      nextSession.machine = machine;

      // disable bb if was enabled
      if (nextSession.status === SessionStatus.QUEUE_BET_BEHIND) {
        nextSession.status = SessionStatus.QUEUE;
        await this.sessionRepo.update(
          nextSession.id,
          { status: SessionStatus.QUEUE },
          data => this.playerClient.sessionState(nextSession.id, { status: data.status }),
        );
        this.monitoringClient.sendEventLogMessage({
          eventType: EventType.BET_BEHIND_STOPPED,
          source: EventSource.GAME,
          params: {
            sessionId: nextSession.id,
            machineSerial: nextSession.machine?.serial,
            reason: 'User turn to play',
          },
        });
        await this.sessionDataManager.removeSessionData(['betBehind'], nextSession.id);
      }
      const {
        player,
        operator,
        vouchers = [],
      } = nextSession;
      const pendingVouchers = vouchers.filter(({ status }) => status === VoucherStatus.PENDING)
        .sort((a, b) => (a.expirationDate || new Date()).valueOf() - (b.expirationDate || new Date()).valueOf());
      const isAutoplayRoundStart = await this.sessionDataManager.isAutoplay(nextSession.id);
      const ctx: RoundContext = new RoundContext(
        nextSession,
        queue,
        machine,
        player,
        group,
        operator,
        isAutoplayRoundStart,
        pendingVouchers,
        correlationId,
      );
      let round: RoundEntity;
      try {
        round = await this.roundServiceFactory.getStarter(machine.gameId, ctx)
          .startRound(pendingVouchers.length ? RoundType.VOUCHER : RoundType.REGULAR);
      } catch (err) {
        if (nextSession.status === SessionStatus.RE_BUY) {
          this.commandPublisher.terminateSession({
            type: CommandType.TERMINATE_SESSION,
            gameId: machine.gameId,
            sessionId: Number(nextSession.id),
            terminate: true,
            reason: SessionEndReason.WALLET_TRANSACTION_ERROR,
          }, correlationId);
        } else {
          await this.sessionService
            .finalizeSession(nextSession.id, SessionEndReason.WALLET_TRANSACTION_ERROR, true);
          this.commandPublisher.engageNextSession({
            type: CommandType.ENGAGE_SESSION,
            gameId: machine.gameId,
            machineId,
          }, correlationId);
        }
        return;
      }
      await this.sessionRepo.update(
        nextSession.id,
        { status: SessionStatus.PLAYING },
        data => this.playerClient.sessionState(nextSession.id, { status: data.status }),
      );
      if (nextSession.status === SessionStatus.RE_BUY) {
        await this.robotClient.sendAllowCoinsMessage(round.coins, machine.serial, nextSession.id);
        await this.workerClient.timeoutStart({
          timeoutType: TimeoutType.IDLE,
          sessionId: Number(nextSession.id),
          timeoutSec: GroupEntity.getIdleTimeoutSec(group) + group.graceTimeout,
          payload: { gameId: machine.gameId },
        },
        correlationId,
        options => this.playerClient.setCountdown(nextSession.id, options.timeoutSec),
        );
      } else {
        await this.workerClient.timeoutStart({
          timeoutType: TimeoutType.ENGAGE,
          sessionId: Number(nextSession.id),
          timeoutSec: this.robotEngageTimeoutSec,
          payload: { gameId: machine.gameId },
        }, correlationId);
        await this.machineRepo.update(machine.id, { status: MachineStatus.IN_PLAY });
        releaseLock = false;
        await this.monitoringClient.sendEventLogMessage({
          eventType: EventType.ENGAGE_ROBOT,
          source: EventSource.GAME,
          params: {
            sessionId: nextSession.id,
            machineSerial: machine.serial,
          },
        });
        await this.robotClient
          .sendEngageMessage(nextSession.id, machine.serial, group.configuration.burstShoot);
      }
    } finally {
      if (releaseLock) {
        await this.releaseEngageLock(machineId);
      }
    }
  }

  private async acquireEngageLock(machineId: number): Promise<boolean> {
    const key = engageLockKeyFactory(machineId);
    const lock = await this.cacheManager.store.getClient()
      .set(key, `${machineId}`, 'EX', 10, 'NX');
    return !!lock;
  }

  private async releaseEngageLock(machineId: number): Promise<void> {
    await this.cacheManager.del(engageLockKeyFactory(machineId));
  }

  private canEngageNewSession(machine: MachineEntity, isRebuy: boolean): boolean {
    return machine.status === MachineStatus.READY || (machine.status === MachineStatus.IN_PLAY && isRebuy);
  }

  public async reassignMachine(machineId: number): Promise<void> {
    const machine = await this.machineRepo.findOneOrFail({
      where: { id: machineId },
      relations: ['chips', 'chips.type', 'queue'],
    });
    if (!machine.reassignTo) {
      throw new NotAcceptableException('No reassign target');
    }
    const toGroup = await this.groupRepo.findOneByOrFail({ id: machine.reassignTo });
    const requestedRtpSegment = await this.cacheManager
      .get<string>(reassignRtpKeyFactory(machine.id, toGroup.id));
    const rtpSegmentMerged = toGroup.configuration?.rtpSegment || requestedRtpSegment;
    const rngChipPrizes = await this.rngChipPrizeRepo.getAllPrizes(toGroup.prizeGroup, rtpSegmentMerged);
    const targetTypeMap = new Map<number, number>(rngChipPrizes
      .map(prize => [prize.chipType.id, prize.chipValue]));
    if (!machine.chips.every(chip => targetTypeMap.has(chip.type.id))) {
      await this.monitoringClient.sendAlertMessage({
        alertType: AlertType.ERROR,
        severity: AlertSeverity.HIGH,
        source: AlertSource.GAME_CORE,
        description: 'Machine reassign failed. Incompatible target group',
        gameId: machine.gameId,
        details: {
          groupId: toGroup.id,
          machineId: machine.id,
          machineName: machine.name,
          machineSerial: machine.serial,
        },
      });
      this.logger.error('Machine reassign failed: incompatible target group');
      throw new NotAcceptableException('Machine reassign failed: incompatible target group');
    }

    const goToGame = machine.status !== MachineStatus.SHUTTING_DOWN
      && machine.status !== MachineStatus.STOPPED
      && machine.status !== MachineStatus.OFFLINE;

    await this.machineRepo.manager.transaction(async entityManager => {
      const chipRepo = new ChipRepository(entityManager);
      try {
        await lastValueFrom(zip(from(machine.chips), interval(100))
          .pipe(
            mergeMap(async ([chip]) => {
              if (chip.type.name !== PHANTOM_CHIP_TYPE_NAME) {
                const value = new BigNumber(targetTypeMap.get(chip.type.id))
                  .multipliedBy(toGroup.denominator)
                  .dp(2)
                  .toNumber();
                await chipRepo.update(chip.rfid, { value });
              } else {
                const phantomSeed = await this.rngClient
                  .phantom(toGroup.prizeGroup, rtpSegmentMerged);
                const value = new BigNumber(phantomSeed.value)
                  .multipliedBy(toGroup.denominator)
                  .dp(2)
                  .toNumber();
                await chipRepo.update(chip.rfid,
                  {
                    value,
                    isScatter: phantomSeed.type === 'scatter',
                  });
              }
              return chip.rfid;
            }), toArray()));
      } catch (err) {
        await this.monitoringClient.sendAlertMessage({
          alertType: AlertType.ERROR,
          severity: AlertSeverity.HIGH,
          source: AlertSource.GAME_CORE,
          description: 'Chips update during reassign failed',
          gameId: machine.gameId,
          details: {
            groupId: toGroup.id,
            machineId: machine.id,
            machineName: machine.name,
            machineSerial: machine.serial,
          },
        });
        this.logger.error(`Chips update during reassign failed, machineSerial: ${machine.serial}`);
        if (machine.status !== MachineStatus.SHUTTING_DOWN
          && machine.status !== MachineStatus.STOPPED
          && machine.status !== MachineStatus.OFFLINE) {
          await this.robotClient.sendStopMessage(machine.serial, ShutdownReason.REASSIGN_FAILED);
        }
        throw err;
      }
      const machineRepo = new MachineRepository(entityManager);
      machine.configuration.rtpSegment = requestedRtpSegment;
      await machineRepo.update(machine.id,
        {
          group: toGroup,
          configuration: machine.configuration,
          status: goToGame ? MachineStatus.SEEDING : machine.status,
          reassignTo: null,
        });
      if (goToGame) {
        await new QueueRepository(entityManager)
          .update(machine.queue.id, { status: QueueStatus.READY });
      }
    });
    await this.cacheManager.del(reassignRtpKeyFactory(machine.id, toGroup.id));
    await this.configValidator.dropCache(machine.serial);

    if (goToGame) {
      await this.seeding(machine.serial); // seed machine using new group settings
    }

    await this.robotClient.sendRobotMessage({
      action: CoreMessage.SET_GAME,
      gameId: machine.gameId,
    }, machine.serial);

    await this.monitoringClient.sendAlertMessage({
      alertType: AlertType.INFORMATION,
      severity: AlertSeverity.LOW,
      source: AlertSource.GAME_CORE,
      description: 'Machine reassign complete',
      gameId: machine.gameId,
      details: {
        machineId: machine.id,
        machineName: machine.name,
        machineSerial: machine.serial,
        groupId: toGroup.id,
      },
    });
  }

  public async seeding(machineSerial: string, skipRefurbishing = false): Promise<void> {
    const machine = await this.machineRepo.findOneOrFail({
      where: { serial: machineSerial },
      relations: ['group', 'queue', 'chips', 'chips.type', 'site', 'dispensers', 'dispensers.chipType'],
    });
    if (machine.queue.status === QueueStatus.DRYING) {
      const { queue } = machine;
      const toKick = await this.sessionRepo.findBy({ queue: { id: queue.id } });
      if (toKick?.length) {
        toKick.forEach(session => this.commandPublisher.queueChange({
          type: CommandType.CHANGE_QUEUE,
          gameId: GameId.COIN_PUSHER_V1,
          sessionId: session.id,
          ignoreMachines: [machine.id],
        }));
      }
      if (machine.reassignTo) {
        await this.reassignMachine(machine.id);
      } else {
        const {
          drying,
          other,
        } = await this.machineRepo.getQueueStatusesForGroup(machine.group.id);
        if (machine.group.status === GroupStatus.DRYING
          && drying === 1
          && other === 0) {
          await this.groupRepo.update(machine.group.id, { status: GroupStatus.OFFLINE });
        }
        await this.queueRepo.update(queue.id, { status: QueueStatus.STOPPED });
        await this.machineRepo.update(machine.id, {
          status: MachineStatus.SHUTTING_DOWN,
          shutdownReason: ShutdownReason.USER_REQUEST,
        });
        await this.robotClient.sendStopMessage(machine.serial, ShutdownReason.NOC_MACHINE_SHUTDOWN);
      }
      return;
    }

    await this.machineRepo.update(machine.id, { status: MachineStatus.SEEDING });
    const {
      group,
      chips,
    } = machine;
    const config = await this.configValidator.getValidatedConfig(machineSerial);

    let chipsInfo: GetChipsToPush = await this.getChipsToPush(machine, group, config, skipRefurbishing);

    if (!chipsInfo.hasChips && (!machine.isRefurbish || skipRefurbishing)) {
      await this.machineRepo.update(machine.id, { status: MachineStatus.READY, isRefurbish: false });
      this.commandPublisher.engageNextSession({
        type: CommandType.ENGAGE_SESSION,
        gameId: GameId.COIN_PUSHER_V1,
        machineId: machine.id,
      });
      return;
    }

    if (!chipsInfo.hasChips) {
      skipRefurbishing = true;
      machine.isRefurbish = false;
      await this.machineRepo.update(machine.id, { isRefurbish: false });
      chipsInfo = await this.getChipsToPush(machine, group, config, skipRefurbishing);
    }

    const { chipsToPush, seedChipsToPush } = chipsInfo;

    if (Object.keys(seedChipsToPush).length) {
      const history = this.seedHistoryRepo.create({
        machineId: machine.id,
        seed: seedChipsToPush,
        roundsCount: machine.roundsCount,
        isCompleted: false,
      });
      await this.seedHistoryRepo.save(history, {
        reload: false,
        transaction: false,
      });
    }

    const dispenserTypeToNameMap = machine.dispensers.reduce((acc, dispenser) => {
      const dispensers = acc.get(dispenser.chipType.name);
      if (dispensers) {
        dispensers.push(dispenser);
      } else {
        acc.set(dispenser.chipType.name, [dispenser]);
      }
      return acc;
    }, new Map<string, MachineDispenserEntity[]>());
    const corr = uuidv4();
    if (!Object.keys(chipsToPush)
      .every(type => dispenserTypeToNameMap.has(type))) {
      this.logger.error('RNG seed types to dispenser types mismatch', {
        machineSerial,
        correlationId: corr,
        isRefurbish: machine.isRefurbish,
        skipRefurbishing,
      });
      this.monitoringClient.sendAlertMessage({
        alertType: AlertType.ERROR,
        severity: AlertSeverity.HIGH,
        source: AlertSource.GAME_CORE,
        description: 'RNG seed types to dispenser types mismatch',
        gameId: machine.gameId,
        details: {
          groupId: group.id,
          machineId: machine.id,
          machineName: machine.name,
          machineSerial: machine.serial,
          seed: chipsToPush,
          isRefurbish: machine.isRefurbish,
        },
      });
      await this.groupTerminator.groupHardStop(machine.gameId, group.id, {
        reason: ShutdownReason.RNG_SEED_TYPES_TO_DISPENSER_TYPES_MISMATCH,
        machineIds: [machine.id],
      }, corr);
      throw new RpcException('RNG seed types to dispenser types mismatch');
    }
    const chipTypesToPush: string[] = [];
    const dispensersToPush = await lastValueFrom(from(Object.entries(chipsToPush))
      .pipe(
        concatMap(([type, count]) => of(type)
          .pipe(repeat(count))),
        concatMap(async type => {
          const dispenser = dispenserTypeToNameMap.get(type)
            .sort((a, b) => b.level - a.level)[0];
          if (dispenser.level) {
            dispenser.level -= 1;
            chipTypesToPush.push(dispenser.chipType.name);
            return dispenser.name;
          }
          this.monitoringClient.sendAlertMessage({
            alertType: AlertType.MAINTENANCE,
            severity: AlertSeverity.CRITICAL,
            source: AlertSource.GAME_CORE,
            description: 'Not enough chips to complete seed',
            action: AlertAction.FILL_DISPENSER,
            gameId: machine.gameId,
            details: {
              groupId: group.id,
              machineId: machine.id,
              machineName: machine.name,
              machineSerial: machine.serial,
              dispenserName: dispenser.name,
              isRefurbish: machine.isRefurbish,
            },
          });
          await this.groupTerminator.groupHardStop(machine.gameId, group.id, {
            reason: ShutdownReason.NOT_ENOUGH_CHIPS_TO_SEED,
            machineIds: [machine.id],
          }, corr);
          throw new RpcException('Not enough chips to complete seed');
        }),
        toArray(),
      ));

    const reshuffleCoins = chips?.length ? config.reshuffleCoinsNonEmpty : config.reshuffleCoinsEmpty;
    await this.robotClient.sendSeedMessage(machineSerial, dispensersToPush, reshuffleCoins);
    this.monitoringClient.sendEventLogMessage({
      source: EventSource.GAME,
      eventType: EventType.SEED,
      params: {
        machineSerial: machine.serial,
        toPush: chipTypesToPush,
        reshuffleCoins,
        isRefurbish: machine.isRefurbish,
      },
    });
  }

  public async seedCompleteHandler(data: RobotMessage): Promise<void> {
    const machine = await this.machineRepo.findOneOrFail({ where: { serial: data.serial }, relations: { group: true } });
    const correlationId = data.correlationId ?? uuidv4();
    if (machine.status === MachineStatus.SEEDING) {
      if (machine.isRefurbish) {
        const chipDidNotPush = await this.chipWatcherService.getRefurbishChipsToPush(machine.id);
        if (chipDidNotPush.length) {
          await this.chipWatcherService.clearRefurbishData(machine.id);
          const tableState = await this.chipRepo.getTableState(machine.id);
          this.logger.error('Refurbishing seed error', {
            machineId: machine.id, machineSerial: machine.serial, chipDidNotPush, tableState,
          });
          this.monitoringClient.sendAlertMessage({
            alertType: AlertType.MAINTENANCE,
            severity: AlertSeverity.CRITICAL,
            source: AlertSource.GAME_CORE,
            description: AlertDescription.DIFFERENT_TABLE_AFTER_REFURBISHING,
            action: AlertAction.DISMISS,
            gameId: machine.gameId,
            details: {
              groupId: machine.group.id,
              machineId: machine.id,
              machineName: machine.name,
              machineSerial: machine.serial,
              isRefurbish: machine.isRefurbish,
            },
          });
          await this.groupTerminator.groupHardStop(machine.gameId, machine.group.id, {
            reason: ShutdownReason.REFURBISHING_ERROR,
            machineIds: [machine.id],
          }, correlationId);
          return;
        }
        await this.machineRepo.update(machine.id, { isRefurbish: false });
        await this.seeding(machine.serial, true);
        return;
      }
      const seedHistory = await this.seedHistoryRepo.getLastHistoryRecord(machine.id);
      if (!seedHistory) {
        await this.groupTerminator.groupHardStop(machine.gameId, machine.group.id, {
          reason: ShutdownReason.SEED_HISTORY_NOT_FOUND,
          machineIds: [machine.id],
        }, correlationId);
        return;
      }

      await this.seedHistoryRepo.update(seedHistory.id, { isCompleted: true });
      await this.chipWatcherService.clearSeededChipList(machine.id);
      await this.machineRepo.update(machine.id, { status: MachineStatus.READY });
      this.commandPublisher.engageNextSession({
        type: CommandType.ENGAGE_SESSION,
        gameId: GameId.COIN_PUSHER_V1,
        machineId: machine.id,
      });
    }
  }

  public async handlePong({ serial }: RobotMessage): Promise<void> {
    const machine = await this.machineRepo.findOneByOrFail({ serial });
    if (machine.status === MachineStatus.OFFLINE && moment()
      .diff(machine.pingDate, 'second') > 30) {
      this.robotClient.sendRobotMessage({ action: CoreMessage.REBOOT }, machine.serial);
      this.monitoringClient.sendAlertMessage({
        alertType: AlertType.WARNING,
        severity: AlertSeverity.MEDIUM,
        source: AlertSource.GAME_CORE,
        description: 'Ping from offline machine, reboot requested',
        gameId: machine.gameId,
        details: {
          machineId: machine.id,
          machineName: machine.name,
          machineSerial: machine.serial,
        },
      });
    }
    await this.machineRepo.update(machine.id, { pingDate: () => 'NOW()' });
  }

  public async handlePosition(data: RobotPositionDto): Promise<void> {
    await this.monitoringClient.sendEventLogMessage({
      eventType: EventType.MOVE,
      source: EventSource.ROBOT,
      params: {
        angle: data.angle,
        machineSerial: data.serial,
        sessionId: data.sessionId,
      },
    });
  }

  public async updateWorkingHours(data: RobotWorkingHoursDto): Promise<void> {
    const {
      serial,
      workingHours,
    } = data;
    await this.machineRepo.update({ serial }, { workingHours });
  }

  @Cache({ ttl: 1 }, args => `player-abuse-${args[0].sessionId}`)
  public async playerAbuse({
    sessionId,
    correlationId,
  }: PlayerAbuseDto): Promise<boolean> {
    const session = await this.sessionRepo.findOne({ where: { id: sessionId }, select: { status: true } });
    if (!session || session.status === SessionStatus.TERMINATING) {
      this.logger.warn('playerAbuse skipped', { sessionId, correlationId, session });
      return true;
    }

    await this.commandPublisher.terminateSession({
      type: CommandType.TERMINATE_SESSION,
      gameId: GameId.COIN_PUSHER_V1,
      sessionId,
      correlationId,
      terminate: true,
      reason: SessionEndReason.PLAYER_ABUSE,
    });
    return true;
  }

  public async addBallClawRoulette({
    serial,
    rfid,
  }: AddBallDto): Promise<void> {
    const [machine, ball] = await Promise.all([
      this.machineRepo.findOne({
        where: { serial },
        relations: ['group', 'site'],
      }),
      this.ballRepository.findOne({
        where: { rfid },
        relations: ['machine', 'site'],
      }),
    ]);

    const defaultMissing = Object.values<string>(RouletteField);
    const allLabels = new Set<string>(defaultMissing);

    const alert: Alert = {
      alertType: AlertType.ERROR,
      source: AlertSource.GAME_CORE,
      severity: AlertSeverity.MEDIUM,
      description: null,
      gameId: machine.gameId,
      details: {
        machineSerial: serial,
        rfid,
      },
    };

    const response = {
      rejectedReason: null as string,
      label: ball?.label ?? null,
      missing: defaultMissing,
    };

    if (!allLabels.has(ball.label)) {
      alert.description = 'Label must be a valid roulette field';
      response.rejectedReason = alert.description;
      return this.sendAddBallRobotMessage(serial, response, alert);
    }

    if (!machine) {
      alert.description = 'Ball didn\'t assigned. Machine not found';
      response.rejectedReason = alert.description;
      return this.sendAddBallRobotMessage(serial, response, alert);
    }

    const config: Configuration = { ...machine.configuration, ...(machine?.group.configuration ?? {}) };

    const rouletteType = config.rouletteType ?? RouletteType.EUROPEAN;

    if (rouletteType !== RouletteType.AMERICAN) {
      allLabels.delete(RouletteField.FIELD_00);
    }

    const assignedBalls = await this.ballRepository.findBy({
      machine: { id: machine.id },
      site: { id: machine.site.id },
    });
    let assignedSameLabelBall: BallEntity = null;
    assignedBalls.forEach(assignedBall => {
      if (ball && ball.label === assignedBall.label && ball.rfid !== assignedBall.rfid) {
        assignedSameLabelBall = assignedBall;
      }
      allLabels.delete(assignedBall.label);
    });
    response.missing = Array.from(allLabels);

    if (!ball || ball.site.id !== machine.site.id) {
      alert.description = 'Ball didn\'t assigned. Ball not found';
      response.rejectedReason = alert.description;
      return this.sendAddBallRobotMessage(serial, response, alert);
    }

    if (rouletteType !== RouletteType.AMERICAN && ball.label === RouletteField.FIELD_00) {
      alert.description = 'Ball didn\'t assigned. Ball with "00" label use only american roulette';
      response.rejectedReason = alert.description;
      return this.sendAddBallRobotMessage(serial, response, alert);
    }

    if (
      machine.status === MachineStatus.READY
      || machine.status === MachineStatus.PREPARING
      || machine.status === MachineStatus.IN_PLAY
      || machine.status === MachineStatus.SEEDING
    ) {
      alert.description = 'Ball didn\'t assigned. Machine not stopped';
      response.rejectedReason = alert.description;
      return this.sendAddBallRobotMessage(serial, response, alert);
    }

    if (
      ball.machine
      && (ball.machine.status === MachineStatus.READY
        || ball.machine.status === MachineStatus.PREPARING
        || ball.machine.status === MachineStatus.IN_PLAY
        || ball.machine.status === MachineStatus.SEEDING)
    ) {
      alert.description = 'Ball reassigned from ready/playing machine';
      response.rejectedReason = alert.description;
      return this.sendAddBallRobotMessage(serial, response, alert);
    }

    const andWarnAlert = ball.machine && ball.machine.id !== machine.id;

    const ballsUpdate: BallEntity[] = [];
    if (assignedSameLabelBall) {
      assignedSameLabelBall.machine = null;
      ballsUpdate.push(assignedSameLabelBall);
    }

    ball.machine = machine;
    ballsUpdate.push(ball);

    await this.ballRepository.save(ballsUpdate, {
      transaction: true,
      reload: false,
    });
    allLabels.delete(ball.label);
    response.missing = Array.from(allLabels);

    if (andWarnAlert) {
      alert.alertType = AlertType.WARNING;
      alert.description = 'Ball reassigned from stopped/offline machine';
    }

    return this.sendAddBallRobotMessage(serial, response, andWarnAlert && alert);
  }

  private sendAddBallRobotMessage(
    serial: string,
    message: { missing: string[], label: string, rejectedReason: string },
    alert?: Alert,
  ): void {
    this.robotClient.sendBallConfig(serial, message);
    alert && this.monitoringClient.sendAlertMessage(alert);
  }

  private async getChipsToPush(
    machine: MachineEntity, group: GroupEntity, config: Configuration, skipRefurbishing: boolean,
  ): Promise<GetChipsToPush> {
    try {
      const refurbishChipList = await this.chipWatcherService.getRefurbishChipsToPush(machine.id);
      const seedChipList = machine.isRefurbish && !skipRefurbishing
        ? []
        : await this.rngClient.seed(group.prizeGroup, config.minimalHold.value, config.minimalHold.count, config.rtpSegment, machine.chips);

      this.logger.debug('RNG "seed"', {
        seedChipList,
        refurbishChipList,
        machineSerial: machine.serial,
        isRefurbish: machine.isRefurbish,
        skipRefurbishing,
      });

      if (!refurbishChipList.length && !seedChipList.length) {
        return { chipsToPush: {}, hasChips: false, seedChipsToPush: {} };
      }

      const chipsToPushReducer = (acc: Record<string, number>, seed: SeedValue) => {
        if (acc[seed.name]) {
          acc[seed.name] += seed.value;
        } else {
          acc[seed.name] = seed.value;
        }
        return acc;
      };

      const seedChipsToPush = seedChipList.reduce(chipsToPushReducer, {});

      return { seedChipsToPush, chipsToPush: refurbishChipList.reduce(chipsToPushReducer, { ...seedChipsToPush }), hasChips: true };
    } catch (err) {
      const corr = uuidv4();
      this.logger.error('RNG "seed" failed', {
        machineSerial: machine.serial,
        error: err.message,
        correlationId: corr,
        isRefurbish: machine.isRefurbish,
      });
      this.monitoringClient.sendAlertMessage({
        alertType: AlertType.ERROR,
        severity: AlertSeverity.HIGH,
        source: AlertSource.GAME_CORE,
        description: 'RNG seed failed',
        gameId: machine.gameId,
        details: {
          error: err?.message || null,
          groupId: group.id,
          machineId: machine.id,
          machineName: machine.name,
          machineSerial: machine.serial,
          isRefurbish: machine.isRefurbish,
        },
      });
      await this.groupTerminator.groupHardStop(
        machine.gameId,
        group.id,
        {
          reason: ShutdownReason.RNG_SEED_FAILED,
          machineIds: [machine.id],
        },
        corr);
      throw err;
    }
  }

  public async idleTimeoutExpired(options: SessionAwareDto): Promise<void> {
    const {
      sessionId,
      session: cachedSession,
    } = options;
    const session = await this.sessionRepo.findOne({
      where: { id: sessionId },
      relations: ['rounds'],
    });
    if (!session) {
      throw new RpcException('No session on idle timeout');
    }

    if (session.status === SessionStatus.FORCED_AUTOPLAY) {
      this.logger.warn('Idle timeout expiration skipped: already in force auto', { sessionId });
      return;
    }

    const activeRound = session.getActiveRound();
    if (!activeRound || activeRound.coins === 0) {
      this.logger.warn('idle timeout skipped', { sessionId });
      return;
    }

    const {
      machine,
      configuration,
    } = cachedSession;

    await this.monitoringClient.sendEventLogMessage({
      eventType: EventType.IDLE,
      source: EventSource.GAME,
      params: {
        sessionId,
        round: activeRound.id,
        machineSerial: machine?.serial,
      },
    });
    await this.monitoringClient.sendEventLogMessage({
      eventType: EventType.START_AUTO_MODE,
      source: EventSource.GAME,
      params: {
        sessionId,
        machineSerial: machine?.serial,
        reason: 'Player idle',
        stopCriteria: '',
      },
    });

    if (session.status === SessionStatus.AUTOPLAY) {
      const { autoplay } = await this.sessionDataManager.getSessionData(sessionId);
      autoplay.forced = true;
      await this.sessionDataManager.updateSessionData({ autoplay }, sessionId);
    } else {
      await this.sessionRepo.update(sessionId, { status: SessionStatus.FORCED_AUTOPLAY });
      await this.robotClient.sendAutoplayMessage(machine.serial, sessionId, AutoSwingMode.AUTO);
    }
    this.playerClient.sessionState(sessionId, { status: SessionStatus.FORCED_AUTOPLAY });
    this.playerClient.notifyAutoplay(sessionId,
      {
        status: AutoplayStatus.FORCED_ENABLE,
        config: configuration.autoplay,
      });
  }
}
