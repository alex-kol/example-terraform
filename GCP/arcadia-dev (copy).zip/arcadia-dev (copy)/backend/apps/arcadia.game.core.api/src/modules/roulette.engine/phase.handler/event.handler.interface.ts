import { RouletteEventCommand } from '../../command/dto/roulette.event.command';
import { RouletteEventType } from '../enums';
import { CommonContext } from '../types';

export type RouletteEventHandler = Record<RouletteEventType,
  (context: CommonContext, event: RouletteEventCommand) => void | Promise<void>>;
