import { RouletteField } from '@lib/dal';
import { StateMachineStatus } from '../enums';

export class CommonContext {
  machineId: number;
  serial: string;
  status: StateMachineStatus;
  resultHistory: RouletteField[];
  softStop: boolean;
}
