import { PlayerMessageType } from '@lib/common';
import { Emitter } from '@socket.io/redis-emitter';
import { REDIS_PUBLISHER_CLIENT } from '../../constants/redis.constants';
import { AutoplayStatus } from '../messaging/player.handling/enum/autoplay.status';
import { makeTestModule } from './mocks/beforeAll.mock';
import { NotificationLevel } from './notification.level';
import { NotificationType } from './notification.type';
import { PlayerClientService } from './player.client.service';

describe('Player Client Service (Unit)', () => {
  let playerClientService: PlayerClientService;
  let emitter: Emitter;
  let emitSpy: any;

  beforeAll(async () => {
    const moduleFixture = await makeTestModule();
    playerClientService = moduleFixture.get<PlayerClientService>(PlayerClientService);
    emitter = moduleFixture.get<Emitter>(REDIS_PUBLISHER_CLIENT);
    emitSpy = jest.spyOn(emitter, 'emit');
  });

  describe('notifySessionResult', () => {
    it('should send notify session result message', async () => {
      await playerClientService.notifySessionResult('<sessionId>', 0);
      expect(emitSpy)
        .toBeCalledWith(PlayerMessageType.SESSION_RESULT, { totalWin: 0 });
    });
  });

  describe('notifyWin', () => {
    it('should send notify win message', async () => {
      await playerClientService.notifyWin('<cid>', {
        currencyValue: 0,
        type: '',
      });
      expect(emitSpy)
        .toBeCalledWith(PlayerMessageType.WIN, {
          currencyValue: 0,
          type: ''
        });
    });
  });

  describe('notifyTotalWin', () => {
    it('should send notify total win message', async () => {
      await playerClientService.notifyTotalWin('<sessionId>', 0);
      expect(emitSpy)
        .toBeCalledWith(PlayerMessageType.TOTAL_WIN, { totalWin: 0 });
    });
  });

  describe('notifyQueueUpdate', () => {
    it('should send queue update message', async () => {
      await playerClientService.notifyQueueUpdate('<cid>', {
        queue: [],
        viewers: 0,
        betBehindPlayers: 0,
      });
      expect(emitSpy)
        .toBeCalledWith(PlayerMessageType.QUEUE, {
          queue: [],
          viewers: 0
        });
    });
  });

  describe('notifyBuyResult', () => {
    it('should send notify buy result message', async () => {
      await playerClientService.notifyBuyResult('<cid>', '<token>', 5);
      expect(emitSpy)
        .toBeCalledWith(PlayerMessageType.BUY_STACKS, {
          queueToken: '<token>',
          rounds: 5
        });
    });
  });

  describe('notifyRebuy', () => {
    it('should send notify rebuy message', async () => {
      await playerClientService.notifyRebuy(123);
      expect(emitSpy)
        .toBeCalledWith(PlayerMessageType.RE_BUY, {});
    });
  });

  describe('sendNotification', () => {
    it('should send notification message', async () => {
      const message = {
        notificationId: NotificationType.ROUND_LIMIT_REACHED,
        title: '<title>',
        message: '<message>',
        level: NotificationLevel.INFO,
      };
      await playerClientService.notification('<sessionId>', message);
      expect(emitSpy)
        .toBeCalledWith(PlayerMessageType.NOTIFICATION, message);
    });
  });

  describe('notifyAutoplay', () => {
    it('should send notify autoplay message', async () => {
      await playerClientService.notifyAutoplay('<cid>', { status: AutoplayStatus.FORCED_DISABLE });
      expect(emitSpy)
        .toBeCalledWith(PlayerMessageType.AUTOPLAY, { status: AutoplayStatus.FORCED_DISABLE });
    });
  });

  describe('notifyPhantom', () => {
    it('should send notify phantom message', async () => {
      const message = { value: 1 };
      await playerClientService.notifyPhantom('<cid>', message);
      expect(emitSpy)
        .toBeCalledWith(PlayerMessageType.PHANTOM, message);
    });
  });

  describe('sendBets', () => {
    it('should send bets message', async () => {
      const data = {
        groups: [{
          groupId: 1,
          groupName: '<groupName>',
          groupDisplayName: '<groupDisplayName>',
          queueLength: 1,
          betInCash: 10,
          currency: '<currency>',
          payTable: [{
            type: '<type>',
            currencyValue: 1,
          }],
          color: '<white>',
        }],
      };
      await playerClientService.sendBets('<sessionId>', data);
      expect(emitSpy)
        .toBeCalledWith(PlayerMessageType.BETS, data);
    });
  });

  describe('notifyReturnToLobby', () => {
    it('should send notify return to lobby message', async () => {
      await playerClientService.notifyReturnToLobby('<cid>');
      expect(emitSpy)
        .toBeCalledWith(PlayerMessageType.RETURN_TO_LOBBY);
    });
  });

  describe('notifyIdleTimeoutReset', () => {
    it('should send notify idle timeout reset message', async () => {
      await playerClientService.setCountdown('<cid>');
      expect(emitSpy)
        .toBeCalledWith(PlayerMessageType.RESET_IDLE_TIMEOUT);
    });
  });
});
