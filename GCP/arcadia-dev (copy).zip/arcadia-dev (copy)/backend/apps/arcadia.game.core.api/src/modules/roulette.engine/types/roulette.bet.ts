import { BetPosition } from '../enums';

export type RouletteBet = Partial<Record<BetPosition, number[]>>
