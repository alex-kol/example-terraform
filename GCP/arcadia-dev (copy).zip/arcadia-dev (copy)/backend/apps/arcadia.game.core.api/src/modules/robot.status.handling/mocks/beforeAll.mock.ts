import { ConfigService } from '@lib/config';
import {
  ChipRepository,
  ChipTypeRepository,
  connectionNames,
  getRepositoryToken,
  MachineDispenserRepository,
  MachineRepository,
  QueueRepository,
} from '@lib/dal';
import { robotRmqServerMock } from '../../robot.client/mocks/beforeAll.mock';
import { Test } from '@nestjs/testing';
import { repoMockFactory } from '../../../util/repoMockFactory';
import { BoHandlerService } from '../../bo.handler/bo.handler.service';
import { CommandPublisher } from '../../command/command.publisher';
import { ConfigValidator } from '../../config.validator/config.validator';
import { GroupTerminatorService } from '../../group.terminator/group.terminator.service';
import { RobotMessageService } from '../../messaging/robot.handling/robot.message.service';
import { ServerRMQ } from '@lib/rmq.server';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { StatusHandlerService } from '../status.handler.service';
import { ErrorStatusStrategy } from '../strategy/error.status.strategy';
import { GameplayStatusStrategy } from '../strategy/gameplay.status.strategy';
import { ShutdownStatusStrategy } from '../strategy/shutdown.status.strategy';
import { StartupStatusStrategy } from '../strategy/startup.status.strategy';
import { StatusStrategyFactory } from '../strategy/status.strategy.factory';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';

export async function makeTestModule() {
  const moduleFixture = await Test.createTestingModule({
    imports: [],
    providers: [
      StatusHandlerService,
      {
        useValue: robotRmqServerMock,
        provide: ServerRMQ,
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(MachineRepository, connectionNames.DATA),
      },
      {
        useValue: {},
        provide: GroupTerminatorService,
      },
      {
        useValue: {},
        provide: CommandPublisher,
      },
      {
        useValue: { get: () => ('get') },
        provide: ConfigService,
      },
      {
        useValue: {},
        provide: ConfigValidator,
      },
      StatusStrategyFactory,
      ErrorStatusStrategy,
      GameplayStatusStrategy,
      ShutdownStatusStrategy,
      StartupStatusStrategy,
      {
        useValue: {
          groupHardStopHandler: () => null,
        },
        provide: BoHandlerService,
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(QueueRepository, connectionNames.DATA),
      },
      {
        useValue: {
          ...repoMockFactory(),
          findChipsByType: () => null,
          getChipMapForEmul: () => null
        },
        provide: getRepositoryToken(ChipRepository, connectionNames.DATA),
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(MachineDispenserRepository, connectionNames.DATA),
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(ChipTypeRepository, connectionNames.DATA),
      },
      {
        useValue: {
          sendRobotMessage: () => null,
        },
        provide: RobotClientService,
      },
      {
        useValue: {
          startSeeding: () => null,
          seeding: () => null,
        },
        provide: RobotMessageService,
      },
      {
        useValue: {
          sendOutOfSessionEventLogMessage: () => null,
          sendEventLogMessage: () => {
          }
        },
        provide: MonitoringWorkerClientService,
      },
    ],
  })
    .compile();
  return moduleFixture;
}
