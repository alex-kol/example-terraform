import { CidOperatorParams } from './cid.operator.params';

export class OperatorTransactionParams extends CidOperatorParams {
  amount: number;
  roundId: string | number;
  transactionId?: string;
  isRoundFinish?: boolean;
  isRetry?: boolean;
}