import { deleteUndefinedValue, OperatorTag, UserLoginDto } from '@lib/common';
import { ConfigService } from '@lib/config';
import {
  GameId, OperatorEntity, OperatorRepository, OperatorStatus,
} from '@lib/dal';
import { Injectable, NotAcceptableException } from '@nestjs/common';
import { StandardLanguageMapper } from './languages';
import { LaunchUrlCreator } from './launch.url.creator';
import { calienteLaunchParamsValidationSchema } from './params.validation.schemas';
import { CalienteLaunchParams } from './types';

@Injectable()
export class CalienteLaunchUrlCreator extends LaunchUrlCreator<CalienteLaunchParams> {
  protected readonly paramsValidationSchema = calienteLaunchParamsValidationSchema;

  constructor(
    config: ConfigService,
    private readonly operatorRepository: OperatorRepository,
    private readonly calienteLanguage: StandardLanguageMapper,
  ) {
    super(config);
  }

  protected getId(): string {
    return OperatorTag.CALIENTE;
  }

  protected getOperator(): Promise<OperatorEntity> {
    return this.operatorRepository.findOneByOrFail({
      apiConnectorId: this.params.operator,
      externalId: this.params.externalId || null,
      isDeleted: false,
      status: OperatorStatus.ENABLED,
    })
      .catch(() => {
        throw new NotAcceptableException('Operator not found or disabled');
      });
  }

  protected mapParams(): UserLoginDto {
    const result: UserLoginDto = {
      operatorId: this.operator.id,
      gameId: this.params.gameId as GameId,
      accessToken: this.params.authToken,
      language: this.calienteLanguage.getLanguageCode(this.params.language),
      externalId: this.params.externalId,
      homeUrl: this.params.homeUrl,
      cashierUrl: this.params.cashierUrl,
      extGameId: this.params.clientType,
    };
    deleteUndefinedValue(result);
    return result;
  }

  protected async validateCaller(): Promise<void> {
    return Promise.resolve();
  }
}
