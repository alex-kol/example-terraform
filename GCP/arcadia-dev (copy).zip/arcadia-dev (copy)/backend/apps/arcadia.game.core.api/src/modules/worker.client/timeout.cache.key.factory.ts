import { TimeoutId, timeoutJobNameFactory } from '@lib/common';

export function timeoutCacheKeyFactory(options: TimeoutId): string {
  return `core-timeout-cache-${timeoutJobNameFactory(options)}`;
}