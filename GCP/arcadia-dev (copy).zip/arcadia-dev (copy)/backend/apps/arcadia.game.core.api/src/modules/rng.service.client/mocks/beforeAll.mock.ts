import { HttpModule } from '@nestjs/axios';
import { Test } from '@nestjs/testing';
import { RngClientService } from '../rng.client.service';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';

export async function makeTestModule() {
  return await Test.createTestingModule({
    imports: [HttpModule],
    providers: [
      RngClientService,
      {
        provide: MonitoringWorkerClientService,
        useValue: {},
      }
    ],
  })
    .compile();
}
