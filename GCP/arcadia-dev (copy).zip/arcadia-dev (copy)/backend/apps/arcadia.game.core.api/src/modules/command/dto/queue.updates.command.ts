import { Transform } from 'class-transformer';
import { IsInt } from 'class-validator';
import { BaseCommand } from './base.command';

export class QueueUpdatesCommand extends BaseCommand {
  @Transform(({ value }) => parseInt(value, 10))
  @IsInt()
  public queueId: number;
}
