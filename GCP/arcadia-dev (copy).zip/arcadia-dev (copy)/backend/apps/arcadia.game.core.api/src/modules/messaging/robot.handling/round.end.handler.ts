/* eslint-disable max-lines */
import { CommandType, EventSource, TimeoutType } from '@lib/common';
import { ConfigService } from '@lib/config';
import {
  AlertSeverity,
  AlertSource,
  AlertType,
  ChipRepository,
  EventType,
  GameId,
  GroupEntity,
  RoundEntity,
  RoundRepository,
  RoundStatus,
  RoundType,
  SessionEndReason,
  SessionRepository,
  SessionStatus,
  VoucherEntity,
  VoucherRepository,
  VoucherStatus,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Inject, Injectable, Scope } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import BigNumber from 'bignumber.js';
import moment from 'moment';
import { DataSource, In } from 'typeorm';
import { Logger } from 'winston';
import { CommandPublisher } from '../../command/command.publisher';
import { BaseCommand } from '../../command/dto/base.command';
import { SessionContextHandler } from '../../command/session.context.handler';
import { BalanceData } from '../../operator.api.client/dtos';
import { OperatorApiClientService } from '../../operator.api.client/operator.api.client.service';
import { NotificationLevel } from '../../player.client/notification.level';
import { NotificationType } from '../../player.client/notification.type';
import { PlayerClientService } from '../../player.client/player.client.service';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { RoundContext } from '../../round/round.context';
import { RoundServiceFactory } from '../../round/round.service.factory';
import { SessionDataManager } from '../../session.data.manager/session.data.manager';
import { WorkerClientService } from '../../worker.client/worker.client.service';
import { AutoplayStatus } from '../player.handling/enum/autoplay.status';

@Injectable({ scope: Scope.REQUEST })
export class RoundEndHandler extends SessionContextHandler<BaseCommand> {
  protected roundRepo: RoundRepository;
  protected activeRound: RoundEntity;
  protected recalculateEventType: EventType;

  private voucherRepo: VoucherRepository;
  private vouchers: VoucherEntity[];
  private roundLimitReached: boolean = false;
  private transactionFailReason: SessionEndReason = null;
  private isForcedDisengage: boolean = false;
  private bbSessions: number[];
  private nextIsScatter: boolean = false;

  constructor(
    protected readonly config: ConfigService,
    @Inject(MAIN_LOGGER) logger: Logger,
    protected readonly chipRepo: ChipRepository,
    protected readonly sessionRepoInjected: SessionRepository,
    protected readonly playerClient: PlayerClientService,
    protected readonly monitoringClient: MonitoringWorkerClientService,
    protected readonly operatorClient: OperatorApiClientService,
    protected readonly commandPublisher: CommandPublisher,
    protected readonly sessionDataManager: SessionDataManager,
    private readonly robotClient: RobotClientService,
    protected readonly workerClient: WorkerClientService,
    private readonly roundServiceFactory: RoundServiceFactory,
    dataSource: DataSource,
  ) {
    super(logger, dataSource);
    this.recalculateEventType = EventType.ROUND_ENDED;
  }

  protected async init(data: BaseCommand): Promise<void> {
    await super.init(data);

    // transactional repos
    this.roundRepo = new RoundRepository(this.entityManager);
    this.voucherRepo = new VoucherRepository(this.entityManager);

    this.session = await this.sessionRepoInjected.findOneOrFail({
      where: { id: this.cachedSession.id },
      relations: ['rounds', 'vouchers'],
    });

    this.activeRound = this.session.getActiveRound();
    if (!this.activeRound) {
      throw new RpcException('No active round for round end');
    }
    this.vouchers = this.session.vouchers?.length ? this.session.vouchers : [];
  }

  protected async handleEvent(): Promise<void> {
    if (this.activeRound.type === RoundType.VOUCHER && this.activeRound.voucherId) {
      await this.onVoucherRoundEnd();
    }
    if (this.activeRound.type === RoundType.SCATTER) {
      await this.onScatterRoundEnd();
    }
    this.nextIsScatter = this.session.pendingScatter > 0;
    const { videoFailed, isPlayerIdl } = await this.sessionDataManager.getSessionData(this.sessionId);
    await this.sessionDataManager.updateSessionData({ isPlayerIdl: false }, this.sessionId);
    this.isForcedDisengage = (isPlayerIdl || videoFailed || this.session.isDisconnected) && !this.nextIsScatter;
    this.roundLimitReached = this.session.totalStacksUsed >= this.sessionConfig.stackBuyLimit
      && !this.nextIsScatter;

    await this.dropForcedAuto();
    await this.stopAutoplayCheck();

    this.bbSessions = await this.sessionRepoInjected
      .getBetBehindersFromQueue(this.cachedSession.queue.id, true);

    await this.notifyBetBehindRoundEnd();

    if (this.maxPayoutThresholdExceededCheck()) {
      return;
    }

    if (!this.nextIsScatter) {
      try {
        await this.roundPayout();
      } catch (err) {
        await this.onPayoutError(err);
        return;
      }
    }

    await this.roundRepo.update({ id: this.activeRound.id }, {
      status: RoundStatus.COMPLETED,
      endDate: new Date(),
    });

    if (this.roundLimitReached) {
      this.playerClient.notification(this.session.id,
        {
          notificationId: NotificationType.ROUND_LIMIT_REACHED,
          level: NotificationLevel.WARNING,
          title: 'Round limit reached!',
          message: 'You have reached round limit, see you next time',
        });
    }

    await this.sendRoundEndEvent();
    await this.playerClient.notifyRoundEnd(this.session.id, {
      type: this.activeRound.type,
      winAmount: this.activeRound.winInCash,
    });

    if (this.canProceedPlay()) {
      try {
        await this.startNewRound();
      } catch (err) {
        this.onRoundStartError(err);
      }
    } else {
      await this.finalize();
    }
  }

  protected async sendRoundEndEvent(): Promise<void> {
    const {
      bet,
      wins,
    } = this.activeRound;
    const roundDuration = moment()
      .diff(this.activeRound.createDate, 'second');
    const [
      holdAndPopulation,
      queueLength,
    ] = await Promise.all([
      this.chipRepo.countChipsHoldAndPopulation(this.cachedMachine.id),
      this.sessionRepoInjected.getQueueLength(this.cachedMachine.id),
    ]);
    this.monitoringClient.sendEventLogMessage({
      eventType: this.recalculateEventType,
      source: EventSource.GAME,
      params: {
        sessionId: this.session.id,
        operatorId: this.cachedOperator.id,
        groupId: this.cachedGroup.id,
        machineSerial: this.cachedMachine.serial,
        machineId: this.cachedMachine.id,
        playerCid: this.cachedPlayer.cid,
        round: this.activeRound.id,
        additionalInfo: {
          bet,
          wins,
          roundDuration,
          queueLength,
          ...holdAndPopulation,
        },
      },
    });
  }

  protected async onCommit(): Promise<void> {
    if (this.transactionFailReason) {
      this.commandPublisher.terminateSession({
        type: CommandType.TERMINATE_SESSION,
        gameId: GameId.COIN_PUSHER_V1,
        sessionId: this.sessionId,
        terminate: true,
        reason: this.transactionFailReason,
      }, this.correlationId);
    }
  }

  protected maxPayoutThresholdExceededCheck(): boolean {
    const maxPayoutThreshold = new BigNumber(this.cachedGroup.denominator)
      .multipliedBy(this.sessionConfig.maxPayout)
      .decimalPlaces(2);
    if (maxPayoutThreshold.isLessThan(this.activeRound.wins)) {
      this.logger.warn('Illegal payout', {
        win: this.activeRound.wins,
        threshold: maxPayoutThreshold.toFixed(2),
        sessionId: this.session.id,
      });
      this.commandPublisher.terminateSession({
        type: CommandType.TERMINATE_SESSION,
        gameId: GameId.COIN_PUSHER_V1,
        sessionId: this.session.id,
        terminate: true,
        reason: SessionEndReason.ILLEGAL_PAYOUT,
      }, this.correlationId);
      this.monitoringClient.sendEventLogMessage({
        source: EventSource.GAME,
        eventType: EventType.ILLEGAL_PAYOUT,
        params: {
          sessionId: this.session.id,
          machineId: this.cachedMachine.id,
          machineSerial: this.cachedMachine.serial,
          additionalInfo: {
            payout: this.activeRound.wins,
            payoutThreshold: maxPayoutThreshold.toNumber(),
          },
        },
      });
      this.monitoringClient.sendAlertMessage({
        alertType: AlertType.ALERT,
        severity: AlertSeverity.HIGH,
        source: AlertSource.GAME_CORE,
        description: 'Illegal payout',
        gameId: this.cachedMachine.gameId,
        details: {
          sessionId: this.session.id,
          machineId: this.cachedMachine.id,
          payout: this.activeRound.wins,
          payoutThreshold: maxPayoutThreshold.toNumber(),
        },
      });
      return true;
    }
    return false;
  }

  protected async roundPayout(): Promise<BalanceData> {
    const {
      loginOptions: {
        sessionToken,
        extGameId,
      },
      transaction: {
        roundId,
        transactionId,
        scatterRounds = [],
      },
    } = await this.sessionDataManager.getSessionData(this.sessionId);
    const {
      win,
      winInCash,
    } = await this.roundRepo.getTransactionData([roundId, ...scatterRounds]);
    const payout = await this.operatorClient.payout({
      accessToken: sessionToken,
      operator: this.cachedOperator,
      cid: this.cachedPlayer.cid,
      amount: winInCash,
      roundId,
      transactionId,
      correlationId: this.correlationId,
      gameId: this.session.gameId,
      extGameId,
    });
    await this.sessionDataManager.removeSessionData(['transaction'], this.sessionId);
    this.playerClient.notifyBalance(this.session.id, { valueInCash: payout.balance });
    await this.roundRepo.update({ id: Number(roundId) }, { finalBalance: payout.balance });
    await this.monitoringClient.sendEventLogMessage({
      eventType: EventType.PAYOUT,
      source: EventSource.GAME,
      params: {
        sum: win,
        sumInCash: winInCash,
        currency: this.session.currency,
        sessionId: this.session.id,
        machineSerial: this.cachedMachine.serial,
        playerCid: this.cachedPlayer.cid,
        transactionId,
      },
    });
    return payout;
  }

  protected async onPayoutError(err: Error): Promise<void> {
    this.transactionFailReason = SessionEndReason.PAYOUT_FAILED;
    const {
      transaction: {
        roundId,
        scatterRounds = [],
      },
    } = await this.sessionDataManager.getSessionData(this.sessionId);
    await this.sessionDataManager.removeSessionData(['transaction'], this.sessionId);
    const ids = [roundId, ...scatterRounds].map(r => Number(r));
    await this.roundRepo.update({ id: In(ids) },
      {
        status: RoundStatus.TERMINATED,
        endDate: new Date(),
      });
    ids.forEach(roundId => this.monitoringClient.sendEventLogMessage({
      eventType: EventType.ROUND_TERMINATED,
      source: EventSource.GAME,
      params: {
        sessionId: this.session.id,
        operatorId: this.cachedOperator.id,
        groupId: this.cachedGroup.id,
        machineSerial: this.cachedMachine.serial,
        machineId: this.cachedMachine.id,
        playerCid: this.cachedPlayer.cid,
        round: roundId,
      },
    }));
    this.notifyErrors(err, ids[0]);
  }

  protected notifyErrors(err: Error, roundId: number): void {
    this.logger.error('Payout failed', {
      sessionId: this.sessionId,
      errorMessage: err.message,
      roundId,
      stack: err.stack,
    });
    this.monitoringClient.sendAlertMessage({
      alertType: AlertType.ERROR,
      severity: AlertSeverity.HIGH,
      source: AlertSource.GAME_CORE,
      description: 'Payout failed',
      gameId: this.cachedMachine.gameId,
      details: {
        sessionId: this.session.id,
        roundId,
        playerCid: this.cachedPlayer.cid,
        error: err.message,
      },
    });
    this.playerClient.notification(this.session.id,
      {
        notificationId: NotificationType.PAYOUT_FAILED,
        level: NotificationLevel.ERROR,
        title: 'Wallet error',
        message: 'Payout failed',
      });
  }

  protected async onScatterRoundEnd(): Promise<void> {
    if (this.session.pendingScatter > 0) {
      await this.sessionRepository.decrement(
        { id: this.session.id },
        'pendingScatter',
        1,
      );
      this.session.pendingScatter -= 1;
    }
  }

  private onRoundStartError(err: Error): void {
    this.transactionFailReason = SessionEndReason.BET_FAILED;
    this.logger.error('Bet failed', {
      sessionId: this.session.id,
      errorMessage: err.message,
      correlationId: this.correlationId,
      stack: err.stack,
    });
    this.monitoringClient.sendAlertMessage({
      alertType: AlertType.ERROR,
      severity: AlertSeverity.HIGH,
      source: AlertSource.GAME_CORE,
      description: 'Bet failed',
      gameId: this.cachedMachine.gameId,
      details: {
        sessionId: this.sessionId,
        roundId: this.activeRound.id,
        playerCid: this.cachedPlayer.cid,
        error: err.message,
      },
    });
    this.playerClient.notification(this.session.id,
      {
        notificationId: NotificationType.BET_FAILED,
        level: NotificationLevel.ERROR,
        title: 'Wallet error',
        message: 'Bet failed',
      });
  }

  private async finalize() {
    if (this.canReBuy()) {
      await this.initReBuy();
    } else {
      await this.disengage();
    }
  }

  private canReBuy(): boolean {
    return !this.roundLimitReached
      && this.session.roundsLeft === 0
      && !this.isForcedDisengage;
  }

  private canProceedPlay(): boolean {
    return !this.roundLimitReached
      && this.session.roundsLeft > 0
      && !this.isForcedDisengage;
  }

  private async notifyBetBehindRoundEnd() {
    this.bbSessions.forEach(sessionId => this.commandPublisher.sendCommand({
      type: CommandType.BET_BEHIND_ROUND_END,
      gameId: GameId.COIN_PUSHER_V1,
      sessionId,
    }, this.correlationId));
  }

  private async initReBuy(): Promise<void> {
    await this.sessionRepository.update(
      this.session.id,
      { status: SessionStatus.RE_BUY },
      data => this.playerClient.sessionState(this.session.id, { status: data.status }),
    );
    this.playerClient.notifyRebuy(this.session.id, this.session.configuration.rebuyTimeout);
    await this.workerClient.timeoutStart({
      timeoutType: TimeoutType.REBUY,
      sessionId: this.sessionId,
      timeoutSec: this.session.configuration.rebuyTimeout + 1,
      payload: { gameId: this.session.gameId },
    }, this.correlationId);
    const tableState = await this.chipRepo.getTableState(this.cachedMachine.id);
    this.monitoringClient.sendEventLogMessage({
      eventType: EventType.RESERVATION_WAIT,
      source: EventSource.GAME,
      params: {
        sessionId: this.session.id,
        machineSerial: this.cachedMachine.serial,
        tableState,
        tableChipCount: tableState.length,
      },
    });
  }

  private async startNewRound() {
    let roundType = this.nextIsScatter ? RoundType.SCATTER : RoundType.REGULAR;
    const pendingVouchers = this.vouchers
      .filter(({ status }) => status === VoucherStatus.PENDING)
      .sort((a, b) => (a.expirationDate || new Date()).valueOf() - (b.expirationDate || new Date()).valueOf());
    if (pendingVouchers.length) {
      roundType = RoundType.VOUCHER;
    }
    const isAutoplayRoundStart = await this.sessionDataManager.isAutoplay(this.sessionId);
    const context: RoundContext = new RoundContext(
      this.session,
      this.cachedSession.queue,
      this.cachedMachine,
      this.cachedPlayer,
      this.cachedGroup,
      this.cachedOperator,
      isAutoplayRoundStart,
      pendingVouchers,
      this.correlationId,
    );
    const nextRound = await this.roundServiceFactory.getStarter(GameId.COIN_PUSHER_V1, context, this.entityManager)
      .startRound(roundType);
    await this.robotClient
      .sendAllowCoinsMessage(nextRound.coins, this.cachedMachine.serial, this.session.id);
    await this.workerClient.timeoutStart({
      timeoutType: TimeoutType.IDLE,
      sessionId: this.sessionId,
      timeoutSec: GroupEntity.getIdleTimeoutSec(this.cachedGroup) + this.cachedGroup.graceTimeout,
      payload: { gameId: this.session.gameId },
    },
    this.correlationId,
    options => this.playerClient.setCountdown(this.sessionId, options.timeoutSec),
    );
  }

  private async disengage() {
    await this.robotClient.sendDisengageMessage(this.session.id, this.cachedMachine.serial);
    await this.monitoringClient.sendEventLogMessage({
      eventType: EventType.BREAKUP,
      source: EventSource.GAME,
      params: {
        sessionId: this.cachedSession.id,
        machineSerial: this.cachedMachine.serial,
        playerCid: this.cachedPlayer.cid,
      },
    });
    if (this.isForcedDisengage) {
      await this.sessionDataManager
        .updateSessionData({ endReason: SessionEndReason.FORCED_AUTOPLAY }, this.session.id);
      this.monitoringClient.sendEventLogMessage({
        eventType: EventType.IDLE_DISCONNECT,
        source: EventSource.GAME,
        params: {
          sessionId: this.session.id,
          round: this.activeRound.id,
          groupId: this.cachedGroup.id,
          machineId: this.cachedMachine.id,
          machineSerial: this.cachedMachine.serial,
          operatorId: this.cachedOperator.id,
        },
      });
    }
  }

  private async onVoucherRoundEnd() {
    await this.voucherRepo.update(this.activeRound.voucherId,
      {
        status: VoucherStatus.USED,
        usedDate: new Date(),
      });
    const currentVoucher = this.vouchers
      .find(({ id }) => id === this.activeRound.voucherId);
    if (currentVoucher) {
      currentVoucher.status = VoucherStatus.USED;
    }
  }

  private async dropForcedAuto(): Promise<void> {
    if (this.session.status !== SessionStatus.AUTOPLAY) {
      return;
    }
    const { autoplay } = await this.sessionDataManager.getSessionData(this.sessionId);
    if (autoplay?.forced) {
      delete autoplay.forced;
      await this.sessionDataManager.updateSessionData({ autoplay }, this.sessionId);
    }
  }

  private async stopAutoplayCheck() {
    if (this.session.status === SessionStatus.FORCED_AUTOPLAY) {
      await this.disableAutoplay('Forced-auto stopped on round end');
      return;
    }
    if (this.session.status !== SessionStatus.AUTOPLAY
      || (this.activeRound.type === RoundType.SCATTER && this.canProceedPlay())) {
      return;
    }
    const { autoplay } = await this.sessionDataManager.getSessionData(this.session.id);
    if (!this.canProceedPlay() || autoplay.stopAfterRounds === 1) {
      await this.disableAutoplay('Autoplay complete');
    } else if (autoplay.stopAfterRounds > 1) {
      autoplay.stopAfterRounds -= 1;
      await this.sessionDataManager.updateSessionData({ autoplay }, this.session.id);
    }
  }

  private async disableAutoplay(reason: string) {
    await this.robotClient.sendStopAutoplayMessage(this.cachedMachine.serial, this.session.id);
    await this.monitoringClient.sendEventLogMessage({
      eventType: EventType.STOP_AUTO_MODE,
      source: EventSource.GAME,
      params: {
        sessionId: this.session.id,
        machineSerial: this.cachedMachine.serial,
        reason,
      },
    });
    this.playerClient.notifyAutoplay(this.session.id, { status: AutoplayStatus.FORCED_DISABLE });
    await this.sessionRepository.update(
      this.session.id,
      { status: SessionStatus.PLAYING },
      data => this.playerClient.sessionState(this.session.id, { status: data.status }),
    );
    this.session.status = SessionStatus.PLAYING;
    await this.sessionDataManager.removeSessionData(['autoplay'], this.session.id);
  }
}
