import { EventSource } from '@lib/common';
import { ConfigService } from '@lib/config';
import {
  AlertSeverity,
  AlertSource,
  AlertType,
  EventType,
  GameId,
  GroupStatus,
  MachineEntity,
  MachineRepository,
  MachineStatus,
  QueueRepository,
  QueueStatus,
  RouletteType,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Inject, Injectable } from '@nestjs/common';
import moment from 'moment';
import { Logger } from 'winston';
import { ConfigValidator } from '../../config.validator/config.validator';
import { CoreMessage } from '../../messaging/robot.handling/enum/core.message';
import { RobotMessageService } from '../../messaging/robot.handling/robot.message.service';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { CoreToRobotMessage } from '../../robot.client/robot.interface';
import { StatusHandlerStrategy } from './status.handler.strategy';

@Injectable()
export class StartupStatusStrategy extends StatusHandlerStrategy {
  protected readonly offlineThresholdSec: number;

  constructor(
    @Inject(MAIN_LOGGER) logger: Logger,
    protected readonly queueRepo: QueueRepository,
    protected readonly machineRepo: MachineRepository,
    protected readonly robotClientService: RobotClientService,
    protected readonly robotMessageService: RobotMessageService,
    protected readonly monitoringWorkerClient: MonitoringWorkerClientService,
    protected readonly configValidator: ConfigValidator,
    configService: ConfigService,
  ) {
    super(logger);
    this.offlineThresholdSec = configService.get(['core', 'ROBOT_OFFLINE_DURATION_THRESHOLD_SEC']);
  }

  public async onIdle(machine: MachineEntity): Promise<void> {
    await this.queueRepo.update({ machine: { id: machine.id } }, { status: QueueStatus.READY });
    await this.robotMessageService.seeding(machine.serial);
  }

  public async onTesting(machine: MachineEntity): Promise<void> {
    await this.machineRepo.update(machine.id,
      {
        status: MachineStatus.PREPARING,
        shutdownReason: null,
      });
  }

  public async onStopped(machine: MachineEntity): Promise<void> {
    await this.configValidator.dropCache(machine.serial);
    const { group } = machine;
    const groupNotReady = !group
      || (group.status !== GroupStatus.IDLE && group.status !== GroupStatus.IN_PLAY);
    const offlineThresholdElapsed = moment()
      .diff(machine.pingDate || new Date(), 'seconds') > this.offlineThresholdSec;
    if (machine.shutdownReason || offlineThresholdElapsed || groupNotReady) {
      this.logger.debug('Machine on hold', {
        machineSerial: machine.serial,
        reason: machine.shutdownReason || (offlineThresholdElapsed ? 'long offline' : 'unexpected group state'),
      });
      await this.machineRepo.update(machine.id, { status: MachineStatus.ON_HOLD });
      await this.monitoringWorkerClient.sendAlertMessage({
        alertType: AlertType.INFORMATION,
        severity: AlertSeverity.LOW,
        source: AlertSource.GAME_CORE,
        description: 'Machine on hold',
        gameId: machine.gameId,
        details: {
          shutdownReason: machine.shutdownReason || 'unknown',
          machineId: machine.id,
          machineName: machine.name,
          machineSerial: machine.serial,
        },
      });
      return;
    }
    await this.machineRepo.update(machine.id,
      {
        status: MachineStatus.STOPPED,
        startedDate: new Date(),
      });
    const message: CoreToRobotMessage = { action: CoreMessage.RUN };

    if (group.configuration.tableSpeed && machine.gameId === GameId.COIN_PUSHER_V1) {
      message.tableSpeed = group.configuration.tableSpeed;
    }

    if (machine.gameId === GameId.CLAW_ROULETTE) {
      const config = await this.configValidator.getValidatedConfig(machine.serial);
      message.ballCount = config.rouletteType === RouletteType.AMERICAN ? 38 : 37;
    }

    await this.robotClientService.sendRobotMessage(message, machine.serial);
    const { action, ...paramsForEvent } = message;
    this.monitoringWorkerClient.sendEventLogMessage({
      eventType: EventType.RUN,
      source: EventSource.GAME,
      params: {
        machineId: machine.id,
        machineSerial: machine.serial,
        groupId: group.id,
        ...paramsForEvent,
      },
    });
  }

  public toString(): string {
    return StartupStatusStrategy.name;
  }
}
