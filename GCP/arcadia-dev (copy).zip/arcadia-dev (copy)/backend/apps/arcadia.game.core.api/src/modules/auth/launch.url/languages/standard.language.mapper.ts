import { Injectable } from '@nestjs/common';
import { AllowedLanguage } from '@lib/dal';

@Injectable()
export class StandardLanguageMapper {
  private readonly mainDelimiter = '-';
  private readonly languages: Map<string, Set<string>> = new Map();
  private readonly defaultCode = AllowedLanguage.EN_US;

  constructor() {
    Object.values(AllowedLanguage)
      .forEach(value => {
        const [lngCode, cntCode] = value.split(this.mainDelimiter);
        if (this.languages.has(lngCode)) {
          const countries = this.languages.get(lngCode);
          countries.add(cntCode);
        } else {
          this.languages.set(lngCode, new Set([cntCode]));
        }
      });
  }

  public getLanguageCode(code: string): `${string}-${string}` {
    const [langCode, countryCode] = this.parseCode(code);
    if (!this.languages.has(langCode)) {
      return this.defaultCode;
    }

    const cntCodes = this.languages.get(langCode);
    if (cntCodes.has(countryCode)) {
      return `${langCode}${this.mainDelimiter}${countryCode}`;
    }

    return `${langCode}${this.mainDelimiter}${cntCodes.values()
      .next().value}`;
  }

  private parseCode(code: string): string[] {
    let [lang, country] = code.match(/([a-zA-Z]{2})/g);
    lang = lang && lang.toLowerCase();
    country = country && country.toUpperCase();
    return [lang, country];
  }
}
