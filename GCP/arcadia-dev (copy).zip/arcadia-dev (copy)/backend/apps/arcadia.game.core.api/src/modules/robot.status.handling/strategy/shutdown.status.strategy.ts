import {
  MachineEntity, MachineRepository, MachineStatus, SeedHistoryRepository,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { Inject, Injectable } from '@nestjs/common';
import { Logger } from 'winston';
import { ConfigValidator } from '../../config.validator/config.validator';
import { StatusHandlerStrategy } from './status.handler.strategy';
import { ChipWatcherService } from '../../chip.watcher/chip.watcher.service';

@Injectable()
export class ShutdownStatusStrategy extends StatusHandlerStrategy {
  constructor(
    @Inject(MAIN_LOGGER) logger: Logger,
    private readonly machineRepo: MachineRepository,
    private readonly configValidator: ConfigValidator,
    private readonly chipWatcherService : ChipWatcherService,
    private readonly seedHistoryRepository: SeedHistoryRepository,
  ) {
    super(logger);
  }

  public async onStopping(machine: MachineEntity): Promise<void> {
    if (machine.status !== MachineStatus.SHUTTING_DOWN) {
      await this.machineRepo.update(machine.id, { status: MachineStatus.SHUTTING_DOWN });
    }
  }

  public async onStopped(machine: MachineEntity): Promise<void> {
    const seedHistory = await this.seedHistoryRepository.getLastHistoryRecord(machine.id);
    if (seedHistory) {
      const validSeedHistory = await this.chipWatcherService.getAllSeededChips(seedHistory.machineId);
      if (!validSeedHistory) {
        await this.seedHistoryRepository.delete(seedHistory.id);
      } else {
        await this.seedHistoryRepository.update(seedHistory.id, { seed: validSeedHistory, isCompleted: true });
      }
    } else {
      await this.chipWatcherService.clearSeededChipList(machine.id);
    }

    await this.machineRepo.update(
      machine.id,
      { status: MachineStatus.STOPPED, stoppedDate: new Date(), groupIdForRefurbish: machine.group.id });
    await this.configValidator.dropCache(machine.serial);
  }

  public toString(): string {
    return ShutdownStatusStrategy.name;
  }
}
