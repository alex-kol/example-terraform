import { RoundType } from '@lib/dal';

export class RoundStartedDto {
  type: RoundType;
  stackBuyLimit: number;
  rounds: number;
  betBehindRounds: number;
  totalBet: number;
}
