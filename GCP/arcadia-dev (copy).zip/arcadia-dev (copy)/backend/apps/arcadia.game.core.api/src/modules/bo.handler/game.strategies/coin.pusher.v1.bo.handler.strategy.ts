import { CommandType, EventSource } from '@lib/common';
import {
  ChipRepository,
  EventType,
  GameId,
  GroupEntity,
  MachineDispenserRepository,
  MachineEntity,
  MachineRepository,
  MachineStatus,
  QueueRepository,
  QueueStatus,
  RngChipPrizeRepository,
  SeedHistoryRepository,
  SessionEntity,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { Inject, Injectable, NotAcceptableException } from '@nestjs/common';
import { Logger } from 'winston';
import { reassignRtpKeyFactory } from '../../../util';
import { CommandPublisher } from '../../command/command.publisher';
import { ConfigValidator } from '../../config.validator/config.validator';
import { GroupTerminatorService } from '../../group.terminator/group.terminator.service';
import { CoreMessage } from '../../messaging/robot.handling/enum/core.message';
import { RobotMessageService } from '../../messaging/robot.handling/robot.message.service';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { CoreToRobotMessage } from '../../robot.client/robot.interface';
import { GroupStopDto, MachineStartDto } from '../dto';
import { BoHandlerStrategy } from './bo.handler.strategy';
import { ChipWatcherService } from '../../chip.watcher/chip.watcher.service';

@Injectable()
export class CoinPusherV1BoHandlerStrategy extends BoHandlerStrategy {
  constructor(
    private readonly queueRepo: QueueRepository,
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly robotMessageService: RobotMessageService,
    private readonly cacheManager: RedisCacheService,
    private readonly rngChipPrizeRepo: RngChipPrizeRepository,
    private readonly commandPublisher: CommandPublisher,
    private readonly machineRepo: MachineRepository,
    private readonly groupTerminator: GroupTerminatorService,
    private readonly chipRepo: ChipRepository,
    private readonly seedHistoryRepo: SeedHistoryRepository,
    private readonly dispenserRepo: MachineDispenserRepository,
    private readonly monitoringWorkerClient: MonitoringWorkerClientService,
    private readonly robotClient: RobotClientService,
    private readonly configValidator: ConfigValidator,
    private readonly chipWatcherService: ChipWatcherService,
  ) {
    super();
  }
  public async machineReassign(machine: MachineEntity, toGroup: GroupEntity): Promise<void> {
    const { queue } = machine;
    if (queue.status === QueueStatus.DRYING || machine.status === MachineStatus.OFFLINE) {
      throw new NotAcceptableException('Unexpected machine state');
    }

    const { rtpSegment } = toGroup.configuration;
    if (!rtpSegment) {
      throw new NotAcceptableException('Target machine must have rtpSegment configured');
    }

    const rngChipPrizes = await this.rngChipPrizeRepo.getAllPrizes(toGroup.prizeGroup, rtpSegment);
    const prizes = new Set(rngChipPrizes.map(value => value.chipType.id));
    if (!machine.chips.every(chip => prizes.has(chip.type.id))) {
      this.logger.error('Machine reassign failed. Incompatible target group by chip types!', { machineId: machine.id, groupId: toGroup.id });
      throw new NotAcceptableException('Target group is incompatible by chip types');
    }

    await this.cacheManager.set(reassignRtpKeyFactory(machine.id, toGroup.id),
      rtpSegment,
      { ttl: 43200 });

    const active = (queue.sessions || [] as SessionEntity[]).reduce((acc: SessionEntity[], session) => {
      if (session.getActiveRound()) {
        acc.push(session);
      } else {
        this.commandPublisher.queueChange({
          type: CommandType.CHANGE_QUEUE,
          gameId: GameId.COIN_PUSHER_V1,
          sessionId: Number(session.id),
          ignoreMachines: [machine.id],
        });
      }
      return acc;
    }, []);

    await this.machineRepo.update(machine.id, { reassignTo: toGroup.id });

    if (active.length) {
      await this.queueRepo.update(queue.id, { status: QueueStatus.DRYING });
    } else {
      await this.queueRepo.update(queue.id, { status: QueueStatus.STOPPED });
      await this.robotMessageService.reassignMachine(machine.id);
    }
  }

  public async groupSoftStopHandler(groupId: number, machineIds?: number[], correlationId?: string): Promise<void> {
    await this.groupTerminator.groupSoftStop(GameId.COIN_PUSHER_V1, groupId, machineIds, correlationId);
  }

  public async machineStartHandler(machine: MachineEntity, group: GroupEntity, params: MachineStartDto): Promise<void> {
    if (machine.cameras.length !== 1) {
      throw new NotAcceptableException('Camera is not assigned');
    }

    if (params.resetDispensers) {
      await this.dispenserRepo.delete({ machine: { id: machine.id } });
      await this.createDispensers(machine, group);
    }

    const isRefurbish = await this.chipWatcherService.isRefurbish(params.resetTableState, machine);

    if (params.resetTableState && !isRefurbish) {
      await this.resetTableState(machine.id);
    }

    if (isRefurbish) {
      await this.chipWatcherService.prepareForRefurbishing(machine);
    }

    const runMessage: CoreToRobotMessage = {
      action: CoreMessage.RUN,
      clearTable: params.resetTableState,
      resetDispensers: params.resetDispensers,
    };

    if (group.configuration.tableSpeed) {
      runMessage.tableSpeed = group.configuration.tableSpeed;
    }

    await this.machineRepo.update(machine.id,
      {
        status: MachineStatus.STOPPED,
        shutdownReason: null,
        startedDate: new Date(),
        isRefurbish,
      });

    const { action, ...paramsForEvent } = runMessage;
    this.monitoringWorkerClient.sendEventLogMessage({
      eventType: EventType.RUN,
      source: EventSource.GAME,
      params: {
        machineId: machine.id,
        machineSerial: machine.serial,
        groupId: group.id,
        ...paramsForEvent,
      },
    });
    this.robotClient.sendRobotMessage(runMessage, machine.serial);
  }

  public groupHardStopHandler(groupId: number, data: GroupStopDto, correlationId?: string): Promise<void> {
    return this.groupTerminator.groupHardStop(GameId.COIN_PUSHER_V1, groupId, data, correlationId);
  }

  private async resetTableState(machineId: number) {
    await this.chipRepo.update({ machine: { id: machineId } },
      {
        machine: null,
        isScatter: false,
        value: 0,
      });
    await this.seedHistoryRepo.delete({ machineId });
    await this.machineRepo.update(machineId, { roundsCount: 0 });
  }

  private async createDispensers(machine: MachineEntity, group: GroupEntity): Promise<void> {
    const config = await this.configValidator.getValidatedConfig(machine.serial);
    const prizes = await this.rngChipPrizeRepo.getAllPrizes(group.prizeGroup, config.rtpSegment);
    const chipTypes = new Map(prizes.map(value => [value.chipType.name, value.chipType]));
    const dispensers = Object.entries(config.dispensers)
      .map(([name, dispenser]) => this.dispenserRepo
        .create({
          name,
          machine,
          level: dispenser.capacity,
          capacity: dispenser.capacity,
          chipType: chipTypes.get(dispenser.chipType),
          alertThreshold: dispenser.alertThreshold,
        }));
    if (dispensers?.length) {
      await this.dispenserRepo.save(dispensers, {
        reload: false,
        transaction: false,
      });
    }
  }
}
