import { keepAliveAgents } from '@lib/common';
import { ConfigService } from '@lib/config';
import { RoundArchiveRepository, RoundRepository, SeedHistoryRepository } from '@lib/dal';
import { MonitoringWorkerClientModule } from '@lib/monitoring.worker.client';
import { HttpModule } from '@nestjs/axios';
import { Module } from '@nestjs/common';
import { RngClientService } from './rng.client.service';
import { RngHelper } from './rng.helper';

@Module({
  imports: [
    HttpModule.registerAsync({
      useFactory: async (configService: ConfigService) => {
        const host = configService.get(['core', 'RNG_HOST']) as string;
        const port = configService.get(['core', 'RNG_PORT']) as string;
        return {
          baseURL: `http://${host}:${port}`,
          timeout: 3000,
          httpAgent: keepAliveAgents.httpAgent,
          httpsAgent: keepAliveAgents.httpsAgent,
        };
      },
      inject: [ConfigService],
    }),
    MonitoringWorkerClientModule,
  ],
  providers: [
    RngClientService,
    RngHelper,
    SeedHistoryRepository,
    RoundRepository,
    RoundArchiveRepository,
  ],
  exports: [RngClientService, RngHelper],
})
export class RngServiceClientModule {
}
