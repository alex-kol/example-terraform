import { Module } from '@nestjs/common';
import { SessionDataManager } from './session.data.manager';

@Module({
  providers: [SessionDataManager],
  exports: [SessionDataManager],
})
export class SessionDataManagerModule {
}
