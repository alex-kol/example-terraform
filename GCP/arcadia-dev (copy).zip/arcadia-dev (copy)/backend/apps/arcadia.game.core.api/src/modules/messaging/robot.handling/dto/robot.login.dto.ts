import { booleanTransformer } from '@lib/dal';
import { Transform } from 'class-transformer';
import { IsBoolean, IsOptional, Length } from 'class-validator';

export class RobotLoginDto {
  @Length(1)
  private key: string;

  @Length(1)
  // eslint-disable-next-line camelcase
  private sw_version: string;

  @Length(1)
  public serial: string;

  public get secret(): string {
    return this.key;
  }

  public get version(): string {
    return this.sw_version;
  }

  @Transform(booleanTransformer)
  @IsOptional()
  @IsBoolean()
  public demoMode: boolean;
}
