import { GamePhase, PhaseStatus } from '../enums';
import { CommonContext } from './common.context';

export class RouletteGameState {
  currentPhase: {
    phase: GamePhase,
    status: PhaseStatus,
    endTimestamp?: string,
  };
  context: CommonContext;
}
