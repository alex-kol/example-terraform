import { RoundRepository, SessionRepository } from '@lib/dal';
import { MonitoringWorkerClientModule } from '@lib/monitoring.worker.client';
import { Module } from '@nestjs/common';
import { CommandModule } from '../command/command.module';
import { PlayerClientModule } from '../player.client/player.client.module';
import { RoundModule } from '../round/round.module';
import { SessionDataManagerModule } from '../session.data.manager/session.data.manager.module';
import { SessionModule } from '../session/session.module';
import { BetBehindReadyHandler } from './bet.behind.ready.handler';
import { BetBehindService } from './bet.behind.service';

@Module({
  imports: [
    PlayerClientModule,
    SessionDataManagerModule,
    RoundModule,
    CommandModule,
    MonitoringWorkerClientModule,
    SessionModule,
  ],
  providers: [
    BetBehindService,
    BetBehindReadyHandler,
    SessionRepository,
    RoundRepository,
  ],
  exports: [BetBehindService, BetBehindReadyHandler],
})
export class BetBehindModule {
}
