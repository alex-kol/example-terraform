/* eslint-disable max-lines */
import {
  Cache, CacheClear, CommandType, EventSource, TimeoutType,
} from '@lib/common';
import { ConfigService } from '@lib/config';
import {
  AutoSwingMode,
  CoinPusherGameMode,
  EventType,
  GameId,
  GroupRepository,
  MachineStatus,
  PlayerRepository,
  QueueRepository,
  RngChipPrizeRepository,
  RngPhantomPrizeRepository,
  RoundStatus,
  RoundType,
  SessionEndReason,
  SessionEntity,
  SessionRepository,
  SessionStatus,
  VoucherRepository,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Inject, Injectable } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import moment from 'moment';
import {
  EMPTY, firstValueFrom, from, of,
} from 'rxjs';
import { concatMap, mergeMap, toArray } from 'rxjs/operators';
import { Logger } from 'winston';
import { toCash } from '../../../util';
import { PlayerRetentionService } from '../../auth/player.retention.service';
import { CoinPusherLobbyRes } from '../../auth/responses';
import { CommandPublisher } from '../../command/command.publisher';
import { QueueUpdatesCommand } from '../../command/dto/queue.updates.command';
import { RouletteEventCommand } from '../../command/dto/roulette.event.command';
import { SessionAwareDto } from '../../dto/session.aware.dto';
import { NotificationLevel } from '../../player.client/notification.level';
import { NotificationType } from '../../player.client/notification.type';
import { PlayerClientService } from '../../player.client/player.client.service';
import { QueueManagerService } from '../../queue.manager/queue.manager.service';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { BetManager } from '../../roulette.engine/bet.manager';
import { GamePhase, PhaseStatus, RouletteEventType } from '../../roulette.engine/enums';
import { GameStateManager } from '../../roulette.engine/game.state.manager';
import { SessionDataManager } from '../../session.data.manager/session.data.manager';
import { sessionCacheKeyFactory } from '../../session/session.cache.key.factory';
import { SessionService } from '../../session/session.service';
import { WorkerClientService } from '../../worker.client/worker.client.service';
import { VoucherDto } from '../robot.handling/dto/voucher.dto';
import { BbEnableMessageDto } from './dto/bb.enable.message.dto';
import { EnableAutoplayMessageDto } from './dto/enable.autoplay.message.dto';
import { PlayerJoinedMessageDto } from './dto/player.joined.message.dto';
import { QueueBalanceDto } from './dto/queueBalanceDto';
import { SettingsUpdateMessageDto } from './dto/settings.update.message.dto';
import { VideoFailedDto } from './dto/video.failed.dto';

@Injectable()
export class PlayerMessageService {
  private readonly terminateSessionTimeoutSec: number;

  constructor(
    config: ConfigService,
    private readonly playerPublisher: PlayerClientService,
    private readonly robotPublisher: RobotClientService,
    private readonly workerClient: WorkerClientService,
    private readonly monitoringService: MonitoringWorkerClientService,
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly queueManager: QueueManagerService,
    private readonly sessionService: SessionService,
    private readonly sessionRepository: SessionRepository,
    private readonly voucherRepository: VoucherRepository,
    private readonly queueRepository: QueueRepository,
    private readonly rngChipPrizeRepository: RngChipPrizeRepository,
    private readonly rngPhantomPrizeRepository: RngPhantomPrizeRepository,
    private readonly sessionDataManager: SessionDataManager,
    private readonly commandPublisher: CommandPublisher,
    private readonly playerRepository: PlayerRepository,
    private readonly groupRepository: GroupRepository,
    private readonly gameStateManager: GameStateManager,
    private readonly betManager: BetManager,
    private readonly playerRetentionService: PlayerRetentionService,
  ) {
    this.terminateSessionTimeoutSec = config.get(['core', 'TERMINATE_SESSION_TIMEOUT_SEC']);
  }

  public async userJoinedHandlerCommon(data: PlayerJoinedMessageDto): Promise<void> {
    const {
      sessionId,
      session: cachedSession,
      correlationId,
    } = data;
    if (!sessionId) {
      throw new RpcException('No sessionId on connected');
    }
    const session = await this.sessionRepository.findOneOrFail({
      where: { id: sessionId },
      relations: ['rounds'],
    });

    await this.monitoringService.sendEventLogMessage({
      eventType: EventType.CONNECTED,
      source: EventSource.PLAYER,
      params: {
        sessionId,
        machineId: cachedSession.machine?.id,
        machineSerial: cachedSession.machine?.serial,
      },
    });

    if (session.isDisconnected) {
      if (session.status === SessionStatus.VIEWER
        || session.status === SessionStatus.VIEWER_BET_BEHIND) {
        await this.workerClient.timeoutStop({
          timeoutType: TimeoutType.TERMINATE_SESSION,
          sessionId,
          payload: { gameId: cachedSession.gameId },
        }, correlationId);
      }
      const offlineTime = moment()
        .diff(session.lastDisconnectDate, 'seconds');
      await this.sessionRepository.createQueryBuilder()
        .update()
        .set({
          offlineDuration: () => `${this.sessionRepository.metadata
            .findColumnWithPropertyName('offlineDuration').databaseName} + ${offlineTime}`,
          isDisconnected: false,
        })
        .where('id = :sessionId', { sessionId })
        .execute();
    }

    let timeoutType: TimeoutType;
    switch (session.status) {
      case SessionStatus.PLAYING:
      case SessionStatus.AUTOPLAY:
        timeoutType = TimeoutType.IDLE;
        break;
      case SessionStatus.RE_BUY:
        timeoutType = TimeoutType.REBUY;
        break;
      default:
    }
    if (timeoutType) {
      const currentTimer = await this.workerClient.getTimeoutExpiration({
        sessionId,
        timeoutType,
      });
      currentTimer && this.playerPublisher
        .setCountdown(sessionId, currentTimer.diff(new Date(), 'second'));
    }

    await this.queueManager.notifyQueueUpdate(cachedSession.queue.id, cachedSession);
  }

  public async userDisconnectHandler(data: SessionAwareDto): Promise<void> {
    const {
      sessionId,
      session: cachedSession,
      correlationId,
    } = data;
    if (!sessionId) {
      throw new RpcException('No sessionId on disconnect');
    }
    const session = await this.sessionRepository.findOneBy({ id: sessionId });
    if (!session) {
      this.logger.debug('Session is not found on user disconnect', { sessionId });
      return;
    }
    await this.sessionRepository.update(sessionId, {
      isDisconnected: true,
      lastDisconnectDate: new Date(),
    });
    this.monitoringService.sendEventLogMessage({
      eventType: EventType.DISCONNECTED,
      source: EventSource.PLAYER,
      params: {
        sessionId,
        machineId: cachedSession?.machine?.id,
        machineSerial: cachedSession?.machine?.serial,
      },
    });

    if (session.gameId !== GameId.CLAW_ROULETTE
      && (session.status === SessionStatus.VIEWER
        || session.status === SessionStatus.VIEWER_BET_BEHIND)) {
      await this.workerClient.timeoutStart({
        timeoutType: TimeoutType.TERMINATE_SESSION,
        sessionId,
        timeoutSec: this.terminateSessionTimeoutSec,
        payload: { reason: SessionEndReason.VIEWER_DISCONNECTED, gameId: session.gameId },
      }, correlationId);
    }
  }

  public async pusherPlayerQuit(data: SessionAwareDto): Promise<void> {
    const {
      session: cachedSession,
      sessionId,
      correlationId,
    } = data;
    await this.monitoringService.sendEventLogMessage({
      eventType: EventType.QUIT,
      source: EventSource.PLAYER,
      params: {
        sessionId,
        machineSerial: cachedSession?.machine?.serial,
      },
    });
    const session = await this.sessionRepository.findOneOrFail({
      where: { id: sessionId },
      relations: ['rounds'],
    });
    const queuePos = await this.sessionRepository.getQueuePosition(sessionId, cachedSession.queue.id);
    const safeToKick = !session.isActivePlayingStatus() && queuePos !== 0;
    const isNextToEngage = !session.isActivePlayingStatus() && queuePos === 0;
    const nonActiveBB = (session.status === SessionStatus.QUEUE_BET_BEHIND
        || session.status === SessionStatus.VIEWER_BET_BEHIND)
      && !session.getActiveRound();
    if (safeToKick || nonActiveBB) {
      await this.sessionService.finalizeSession(sessionId, SessionEndReason.QUIT);
      await this.queueManager.notifyQueueUpdate(cachedSession.queue.id, cachedSession);
    } else if (session.status === SessionStatus.RE_BUY) {
      // emulating rebuy timeout expiration
      await this.workerClient.timeoutStop({
        timeoutType: TimeoutType.REBUY,
        sessionId,
        payload: { gameId: session.gameId },
      }, correlationId);
      this.robotPublisher.sendDisengageMessage(sessionId, cachedSession.machine.serial);
    } else if (session.status !== SessionStatus.FORCED_AUTOPLAY && !isNextToEngage) {
      if (session.status === SessionStatus.AUTOPLAY) {
        const { autoplay } = await this.sessionDataManager.getSessionData(sessionId);
        autoplay.forced = true;
        await this.sessionDataManager.updateSessionData({ autoplay }, sessionId);
      } else {
        await this.monitoringService.sendEventLogMessage({
          eventType: EventType.START_AUTO_MODE,
          source: EventSource.GAME,
          params: {
            sessionId,
            machineSerial: cachedSession?.machine?.serial,
            reason: 'Player quit',
            stopCriteria: '',
          },
        });
        await this.robotPublisher.sendAutoplayMessage(cachedSession?.machine?.serial, sessionId, AutoSwingMode.AUTO);
      }
      await this.sessionRepository.update(sessionId, { status: SessionStatus.FORCED_AUTOPLAY });
    }
  }

  public async leaveQueue(data: SessionAwareDto): Promise<void> {
    const {
      session: cachedSession,
      sessionId,
    } = data;
    const session = await this.sessionRepository.findOneByOrFail({ id: sessionId });
    if (session.status !== SessionStatus.QUEUE && session.status !== SessionStatus.QUEUE_BET_BEHIND) {
      throw new RpcException(`Unexpected status to leave the queue: ${session.status}`);
    }
    const newStatus = session.status === SessionStatus.QUEUE
      ? SessionStatus.VIEWER
      : SessionStatus.VIEWER_BET_BEHIND;
    await this.sessionRepository.update(session.id, {
      status: newStatus,
      roundsLeft: 0,
      buyDate: null,
    }, data => this.playerPublisher.sessionState(session.id, { status: data.status }));
    await this.queueManager.notifyQueueUpdate(cachedSession.queue.id);
  }

  public async cancelStacks(cachedSession: SessionEntity): Promise<void> {
    if (!cachedSession) {
      this.logger.warn('cancelStacks session not found');
    }
    const session = await this.sessionRepository.findOneByOrFail({ id: cachedSession.id })
      .catch(reason => {
        throw new RpcException(reason);
      });
    if (session.status !== SessionStatus.PLAYING
      && session.status !== SessionStatus.AUTOPLAY
      && session.status !== SessionStatus.FORCED_AUTOPLAY) {
      throw new RpcException(`Unexpected status to cancel stacks: ${session.status}`);
    }
    await this.sessionRepository.update(session.id, { roundsLeft: session.pendingScatter });
    this.playerPublisher.sessionState(session.id,
      {
        status: session.status,
        roundsLeft: session.pendingScatter,
      });
  }

  public async enableAutoplayHandler({
    sessionId,
    session: { machine: { serial } },
    autoplay,
  }: EnableAutoplayMessageDto): Promise<void> {
    const freshSession = await this.sessionRepository.findOneOrFail({
      where: { id: sessionId },
      relations: ['player'],
    });
    if (freshSession.status !== SessionStatus.PLAYING) {
      this.logger.warn('Wrong status on enable autoplay', { status: freshSession.status });
      return;
    }
    const { settings: { [GameId.COIN_PUSHER_V1]: { autoSwingMode } } } = freshSession.player;

    const tiltMode = freshSession.configuration.gameMode === CoinPusherGameMode.AUTO_FIRE ? AutoSwingMode.MANUAL : autoSwingMode;

    await this.robotPublisher.sendAutoplayMessage(serial, sessionId, tiltMode);

    await this.monitoringService.sendEventLogMessage({
      eventType: EventType.START_AUTO_MODE,
      source: EventSource.GAME,
      params: {
        sessionId,
        machineSerial: serial,
        stopCriteria: autoplay || 'No criteria set',
        autoSwingMode: tiltMode,
      },
    });
    await this.sessionRepository.update(
      sessionId,
      { status: SessionStatus.AUTOPLAY },
      data => this.playerPublisher.sessionState(sessionId, { status: data.status }),
    );
    await this.sessionDataManager.updateSessionData({
      autoplay,
    }, sessionId);
  }

  public async disableAutoplayHandler(data: SessionAwareDto): Promise<void> {
    const {
      sessionId,
      session,
    } = data;
    const freshSession = await this.sessionRepository.findOneOrFail({
      where: { id: sessionId },
      relations: ['rounds'],
    });

    const { autoplay } = await this.sessionDataManager.getSessionData(session.id);

    if (freshSession.status === SessionStatus.FORCED_AUTOPLAY
      || freshSession.status !== SessionStatus.AUTOPLAY
      || autoplay?.forced) {
      return;
    }

    await this.robotPublisher.sendStopAutoplayMessage(session.machine.serial, session.id);
    await this.monitoringService.sendEventLogMessage({
      eventType: EventType.STOP_AUTO_MODE,
      source: EventSource.GAME,
      params: {
        sessionId: session.id,
        machineSerial: session.machine?.serial,
        reason: 'Manual stop',
      },
    });
    await this.sessionRepository.update(
      session.id,
      { status: SessionStatus.PLAYING },
      data => this.playerPublisher.sessionState(freshSession.id, { status: data.status }),
    );
    await this.sessionDataManager.removeSessionData(['autoplay'], session.id);
  }

  public async enableBetBehindHandler(data: BbEnableMessageDto): Promise<void> {
    const {
      session: cachedSession,
      betBehind: config,
      sessionId,
    } = data;
    const session = await this.sessionRepository.findOneByOrFail({ id: sessionId });
    const { betBehind: sessionBbConfig } = session.configuration;

    const bbCount = await this.sessionRepository.countBb(cachedSession.queue.id);
    const bbLimitReached = bbCount + 1 > sessionBbConfig.maxBetBehindPlayers;

    if (!sessionBbConfig.isEnabled || bbLimitReached) {
      this.logger.warn('Can\'t start BB as it is disabled or limited', { sessionId });
      this.playerPublisher.notification(sessionId,
        {
          notificationId: NotificationType.BB_NOT_AVAILABLE,
          level: NotificationLevel.INFO,
          title: 'Bet behind is not available',
          message: 'Bet behind feature is not available at the moment, try again later',
        });
      return;
    }

    if (session.status !== SessionStatus.VIEWER && session.status !== SessionStatus.QUEUE) {
      throw new RpcException(`Can't enable Bet Behind. Unexpected sessions status=${session.status}, sessionId=${session.id}`);
    }
    const status = session.status === SessionStatus.QUEUE
      ? SessionStatus.QUEUE_BET_BEHIND
      : SessionStatus.VIEWER_BET_BEHIND;
    await this.sessionRepository.update(
      session.id,
      { status },
      () => this.playerPublisher.sessionState(session.id, { status }),
    );
    await this.sessionDataManager.updateSessionData({ betBehind: config }, session.id);
    await this.monitoringService.sendEventLogMessage({
      eventType: EventType.BET_BEHIND_SETUP,
      source: EventSource.GAME,
      params: {
        sessionId: session.id,
        machineSerial: session.machine?.serial,
        settings: config,
      },
    });
  }

  public async disableBetBehindHandler(sessionId: number): Promise<void> {
    const session = await this.sessionRepository.findOneOrFail({
      where: { id: sessionId },
      relations: ['rounds'],
    });
    if (session.status !== SessionStatus.VIEWER_BET_BEHIND
      && session.status !== SessionStatus.QUEUE_BET_BEHIND) {
      throw new RpcException(`Can't disable Bet Behind. Unexpected sessions status=${session.status}, sessionId=${session.id}`);
    }
    const activeBbRound = session.rounds?.find(round => round.status === RoundStatus.ACTIVE
      && round.type === RoundType.BET_BEHIND);
    if (!activeBbRound) {
      const status = session.status === SessionStatus.QUEUE_BET_BEHIND
        ? SessionStatus.QUEUE
        : SessionStatus.VIEWER;
      await this.sessionRepository.update(
        session.id,
        { status },
        data => this.playerPublisher.sessionState(session.id, { status: data.status }),
      );
    }
    await this.monitoringService.sendEventLogMessage({
      eventType: EventType.BET_BEHIND_STOPPED,
      source: EventSource.GAME,
      params: {
        sessionId: session.id,
        machineSerial: session.machine?.serial,
        reason: 'Stopped by user',
      },
    });
    await this.sessionDataManager.removeSessionData(['betBehind'], session.id);
  }

  @CacheClear(args => sessionCacheKeyFactory(args[0].sessionId))
  public async handleQueueBalanceDecision(data: QueueBalanceDto): Promise<void> {
    const {
      session: cachedSession,
      decision,
      sessionId,
      correlationId,
    } = data;
    const session = await this.sessionRepository.findOneByOrFail({ id: sessionId });
    if (!session.offeredQueueId) {
      throw new RpcException('No target queue to switch to');
    }
    await this.monitoringService.sendEventLogMessage({
      eventType: EventType.SWITCH_QUEUE,
      source: EventSource.PLAYER,
      params: {
        sessionId,
        machineSerial: cachedSession.machine?.serial,
        decision,
      },
    });
    switch (decision) {
      case 'accept': {
        if (session.status !== SessionStatus.QUEUE) {
          throw new RpcException('Session cant switch from non-queue status');
        }
        const newQueue = await this.queueRepository.findOneOrFail({
          where: { id: session.offeredQueueId },
          relations: ['machine', 'machine.group'],
        });
        await this.sessionRepository.update(sessionId,
          {
            queue: newQueue,
            machine: newQueue.machine,
            group: newQueue.machine.group,
            offeredQueueId: null,
          });
        this.commandPublisher.sendCommand<QueueUpdatesCommand>({
          type: CommandType.QUEUE_UPDATES,
          gameId: GameId.COIN_PUSHER_V1,
          queueId: cachedSession.queue.id,
          session,
        }, correlationId);
        this.commandPublisher.sendCommand<QueueUpdatesCommand>({
          type: CommandType.QUEUE_UPDATES,
          gameId: GameId.COIN_PUSHER_V1,
          queueId: newQueue.id,
          session,
        }, correlationId);
        this.playerPublisher.forceReconnect(sessionId);
        if (newQueue.machine.status === MachineStatus.READY) {
          await this.workerClient.timeoutStart({
            timeoutType: TimeoutType.ENGAGE_NEXT_SESSION,
            sessionId,
            machineSerial: newQueue.machine.serial,
            timeoutSec: 5,
            payload: { gameId: session.gameId },
          }, correlationId);
        }
        break;
      }
      case 'reject':
        break;
      case 'skip':
      default:
        await this.sessionRepository.update(sessionId, { offeredQueueId: null });
    }
  }

  public async handleListBets(session: SessionEntity): Promise<void> {
    const result = await this.getBetsList(session);
    this.playerPublisher.sendBets(session.id, result);
  }

  @Cache({ ttl: 10 }, args => (`change-bet-${args[0].id}`))
  private async getBetsList(session: SessionEntity): Promise<CoinPusherLobbyRes> {
    const {
      operator,
      player: {
        cid,
        isVoucherAwarded,
      },
    } = session;
    const groups = await this.groupRepository.getLobbyAndChangeBetGroupData(operator.id, cid);
    const groupsMapped = await firstValueFrom(from(groups)
      .pipe(
        concatMap(async group => {
          const config = { ...group.machineConfig, ...group.groupConfig };
          if (Number(group.groupId) === Number(session.group.id)
            || Number(group.spilloverGroupId) === Number(session.group.id)
            || config.stackBuyLimit <= session.totalStacksUsed) {
            return EMPTY;
          }

          const highestPhantomValue = await this.rngPhantomPrizeRepository.getHighestPhantomValue(group.prizeGroup, config.rtpSegment);
          const highestChipValue = await this.rngChipPrizeRepository.getHighestChipValue(group.prizeGroup, config.rtpSegment);

          const payTable = [];
          highestPhantomValue && payTable.push(highestPhantomValue);
          highestChipValue && payTable.push(highestChipValue);

          return of({
            groupId: group.groupId,
            groupName: group.groupName,
            groupDisplayName: group.groupDisplayName,
            queueLength: group.queueLength,
            betInCash: toCash(group.denominator, session.currencyConversionRate),
            currency: session.currency,
            color: group.color,
            hasVoucher: Boolean(group.hasVoucher || (!isVoucherAwarded && group.isNewPlayerVoucher)),
            payTable,
          });
        }),
        mergeMap(value => value),
        toArray(),
      ));
    return {
      groups: groupsMapped,
    };
  }

  public async sendVoucher(session: SessionEntity): Promise<void> {
    if (!session) {
      return;
    }
    const voucher = await this.getVoucher(session);
    if (voucher) {
      this.playerPublisher.sendVoucher(session.id, {
        voucherId: voucher.voucherId,
        expirationDate: moment(voucher.expirationDate)
          .diff(moment(), 'year') > 25
          ? undefined
          : voucher.expirationDate,
      });
    }
  }

  @Cache({ ttl: 2 }, args => (`get-voucher-${args[0].id}`))
  private async getVoucher(session: SessionEntity): Promise<VoucherDto> {
    const {
      group,
      player,
      operator,
    } = session;
    const vouchers = await this.voucherRepository.getVouchersForSession(operator.id, group.id, player.cid);
    return vouchers[0];
  }

  public async readyForRound(data: SessionAwareDto): Promise<void> {
    const {
      sessionId,
      correlationId,
    } = data;

    const session = await this.sessionRepository.findOne({
      where: { id: sessionId },
      relations: ['rounds'],
    });

    if (!session) {
      this.logger.warn('readyRorRound skip: session not found');
      return;
    }

    if (session.roundsLeft === 0) {
      this.logger.debug('readyRorRound skip: last round');
      return;
    }

    const { isPlayerIdl } = await this.sessionDataManager.getSessionData(sessionId);
    if (session.status === SessionStatus.FORCED_AUTOPLAY || isPlayerIdl) {
      this.logger.debug('readyRorRound skip: forced autoplay round');
      return;
    }

    const activeRound = session.getActiveRound();
    if (!activeRound || activeRound.coins > 0) {
      this.logger.debug('readyRorRound skip: No active round or round is in progress');
      return;
    }

    await this.workerClient.timeoutStop({
      timeoutType: TimeoutType.ROUND_END_DELAY,
      sessionId,
      payload: { gameId: session.gameId },
    }, correlationId);
    this.commandPublisher.sendCommand({
      type: CommandType.ROUND_END,
      gameId: GameId.COIN_PUSHER_V1,
      sessionId,
    }, correlationId);
  }

  public async videoFailed(data: VideoFailedDto): Promise<void> {
    const {
      sessionId,
      correlationId,
      session: cachedSession,
      connectionSpeedKbps,
    } = data;
    await this.sessionDataManager.updateSessionData({ videoFailed: true }, sessionId);
    const { transaction } = await this.sessionDataManager.getSessionData(sessionId);
    await this.monitoringService.sendEventLogMessage({
      eventType: EventType.VIDEO_FAILED,
      source: EventSource.PLAYER,
      params: {
        sessionId,
        connectionSpeedKbps,
        machineSerial: cachedSession?.machine?.serial,
        round: transaction?.roundId && Number(transaction.roundId),
      },
    });
    const session = await this.sessionRepository.findOneByOrFail({ id: sessionId });
    if (!transaction && !session.isEngaged()) {
      this.commandPublisher.terminateSession({
        type: CommandType.TERMINATE_SESSION,
        gameId: GameId.COIN_PUSHER_V1,
        sessionId,
        terminate: true,
        reason: SessionEndReason.VIDEO_FAILED,
      }, correlationId);
    }
  }

  public async updatePlayerSettingHandler({
    settings: updateSettings,
    session,
    gameId,
  }: SettingsUpdateMessageDto): Promise<void> {
    if (!session) {
      this.logger.warn('updatePlayerSettingHandler session not found');
      return;
    }

    const { player: { cid, operatorId } } = session;

    const { settings } = await this.playerRepository.findOneOrFail({
      where: {
        cid,
        operatorId,
      },
      select: ['settings'],
    });
    settings[gameId] = updateSettings;
    await this.playerRepository.update({
      cid,
      operatorId,
    },
    { settings });
  }

  public async returnToLobby({ session }: Pick<SessionAwareDto, 'session'>): Promise<void> {
    const { loginOptions } = await this.sessionDataManager.getSessionData(session.id);
    const playerRetentionData = await this.playerRetentionService.getPlayerRetentionData(session, loginOptions);
    await this.playerPublisher.notifyReturnToLobby(session.id, playerRetentionData);
  }

  public async userJoinedHandlerRoulette(data: PlayerJoinedMessageDto): Promise<void> {
    const {
      sessionId,
      session: cachedSession,
    } = data;
    if (!sessionId) {
      throw new RpcException('No sessionId on connected');
    }
    const session = await this.sessionRepository.findOneByOrFail({ id: sessionId });

    await this.monitoringService.sendEventLogMessage({
      eventType: EventType.CONNECTED,
      source: EventSource.PLAYER,
      params: {
        sessionId,
        machineId: cachedSession.machine?.id,
        machineSerial: cachedSession.machine?.serial,
      },
    });

    if (session.isDisconnected) {
      const offlineTime = moment()
        .diff(session.lastDisconnectDate, 'seconds');
      await this.sessionRepository.createQueryBuilder()
        .update()
        .set({
          offlineDuration: () => `${this.sessionRepository.metadata
            .findColumnWithPropertyName('offlineDuration').databaseName} + ${offlineTime}`,
          isDisconnected: false,
        })
        .where('id = :sessionId', { sessionId })
        .execute();
    }

    const gameState = await this.gameStateManager.getGameState(cachedSession.machine.serial);
    if (!gameState) {
      throw new RpcException('No bet state');
    }
    const { currencyConversionRate } = cachedSession;
    const currentBet = await this.betManager.getBet(cachedSession.machine.serial, sessionId);

    await this.commandPublisher.sendRouletteCommand<RouletteEventCommand>({
      type: CommandType.ROULETTE_EVENT,
      serial: cachedSession.machine.serial,
      eventType: RouletteEventType.USER_JOIN,
    });

    if (!currentBet) {
      if (gameState.currentPhase.phase === GamePhase.BETS_OPEN
        && gameState.currentPhase.status === PhaseStatus.IN_PROGRESS) {
        this.playerPublisher.gamePhase(sessionId, gameState.currentPhase);
      } else {
        this.playerPublisher.gamePhase(sessionId, { phase: GamePhase.GAME_INIT });
      }
      return;
    }

    this.playerPublisher.gamePhase(sessionId, gameState.currentPhase);
    const betInCash = this.betManager.getBetInCash(currentBet.bet, currencyConversionRate);
    await this.playerPublisher.rouletteCurrentBet(sessionId, betInCash);
  }
}
