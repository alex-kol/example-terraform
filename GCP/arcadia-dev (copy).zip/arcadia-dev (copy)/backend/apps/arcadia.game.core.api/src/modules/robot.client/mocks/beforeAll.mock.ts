import { connectionNames, getRepositoryToken, RoundRepository } from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { Test } from '@nestjs/testing';
import { RobotClientService } from '../robot.client.service';
import { ServerRMQ } from '@lib/rmq.server';
import { repoMockFactory } from '../../../util/repoMockFactory';
import { WorkerClientService } from '../../worker.client/worker.client.service';

export const robotRmqServerMock = {
  sendMessage: () => null,
  setupChannel: () => null,
};

export async function makeTestModule() {
  const moduleFixture = await Test.createTestingModule({
    imports: [],
    providers: [
      RobotClientService,
      {
        useValue: robotRmqServerMock,
        provide: ServerRMQ,
      },
      {
        provide: MAIN_LOGGER,
        useValue: { log: () => null }
      },
      {
        provide: getRepositoryToken(RoundRepository, connectionNames.DATA),
        useValue: {
          ...repoMockFactory(),
          setAutoplay: () => null
        },
      },
      {
        provide: WorkerClientService,
        useValue: {
          timeoutStart: () => null,
          timeoutStop: () => null
        },
      }
    ],
  })
    .compile();
  return moduleFixture;
}
