import { ConfigService } from '@lib/config';
import {
  connectionNames,
  CurrencyConversionRepository,
  getRepositoryToken,
  GroupRepository,
  MachineRepository,
  OperatorRepository,
  PlayerRepository,
  RngChipPrizeRepository,
  RoundRepository,
  SessionRepository,
} from '@lib/dal';
import { VideoApiClientService } from '@lib/video.api';
import { Test } from '@nestjs/testing';
import { repoMockFactory } from '../../../util/repoMockFactory';
import { ConfigValidator } from '../../config.validator/config.validator';
import { IpChecker } from '../../ip.checker/ip.checker';
import { OperatorApiClientService } from '../../operator.api.client/operator.api.client.service';
import { PlayerClientService } from '../../player.client/player.client.service';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { SessionDataManager } from '../../session.data.manager/session.data.manager';
import { SessionService } from '../../session/session.service';
import { AuthService } from '../auth.service';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';

export async function makeTestModule() {
  const sessionRepository = {
    ...repoMockFactory(),
    findOne: () => ({
      player: {
        cid: '<cid>',
        lastSessionDate: new Date()
      },
      totalBets: 322,
      totalWinning: 322,
    }),
    manager: {
      createQueryBuilder: function () {
        return this;
      },
      where: function () {
        return this;
      },
      andWhere: function () {
        return this;
      },
      getOne: function () {
        return null;
      },
    }
  };
  const moduleFixture = await Test.createTestingModule({
    imports: [],
    providers: [
      AuthService,
      {
        useValue: {
          ...repoMockFactory(),
          getMachineForNewSession: () => null
        },
        provide: getRepositoryToken(MachineRepository, connectionNames.DATA),
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(GroupRepository, connectionNames.DATA),
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(RoundRepository, connectionNames.DATA),
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(PlayerRepository, connectionNames.DATA),
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(OperatorRepository, connectionNames.DATA),
      },
      {
        useValue: sessionRepository,
        provide: getRepositoryToken(SessionRepository, connectionNames.DATA),
      },
      {
        useValue: {
          ...repoMockFactory(),
          getCurrencyConversion: () => {
          }
        },
        provide: getRepositoryToken(CurrencyConversionRepository, connectionNames.DATA),
      },
      {
        useValue: {
          ...repoMockFactory(),
          getAllPrizes: () => {
          },
          getPayTable: () => null
        },
        provide: getRepositoryToken(RngChipPrizeRepository, connectionNames.DATA),
      },
      {
        useValue: {
          create: () => {
          },
          getAutoplayConfig: () => {
          },
          createSession: () => null
        },
        provide: SessionService,
      },
      {
        useValue: {
          getBalance: () => null,
          auth: () => null,
        },
        provide: OperatorApiClientService,
      },
      {
        useValue: {
          create: () => {
          }
        },
        provide: PlayerClientService,
      },
      {
        useValue: {
          create: () => {
          },
          sendStopMessage: () => {
          }
        },
        provide: RobotClientService,
      },
      {
        useValue: {
          create: () => {
          },
          sendEventLogMessage: () => {
          }
        },
        provide: MonitoringWorkerClientService,
      },
      {
        useValue: {
          getCameraStreamsFormatted: () => {
          },
          getCameraStreams: () => {
          }
        },
        provide: VideoApiClientService,
      },
      {
        useValue: {
          get: (args: any) => {
            switch (args[1]) {
              case 'GC_CURRENCY_WHITELIST':
                return 'EUR,USD';
              case 'STREAM_AUTH_SECRET':
              case 'ROBOTS_AUTH_SECRET':
                return 'muchsecret';
              default:
                return '<config>';
            }
          },
        },
        provide: ConfigService,
      },
      {
        useValue: {
          get: () => null,
          set: () => null,
          del: () => null,
        },
        provide: RedisCacheService,
      },
      {
        useValue: {
          setToken: () => null,
          setSessionToken: () => null,
          getSessionData: () => null,
        },
        provide: SessionDataManager,
      },
      {
        useValue: {
          verifyIp: () => true,
        },
        provide: IpChecker,
      },
      {
        useValue: {
          getValidatedConfig: () => null,
        },
        provide: ConfigValidator,
      },
    ],
  })
    .compile();
  return moduleFixture;
}
