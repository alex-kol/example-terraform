import { IsIn, IsString } from 'class-validator';
import { SessionAwareDto } from '../../../dto/session.aware.dto';

export class QueueBalanceDto extends SessionAwareDto {
  @IsString()
  @IsIn(['accept', 'reject', 'skip'])
  public decision?: 'accept' | 'reject' | 'skip';

  public machineId?: number;

  public machineName?: string;

  public queuePosition?: number;
}
