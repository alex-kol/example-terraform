import { CommandType, EventSource, PlayerMessageType } from '@lib/common';
import {
  BallRepository, EventType, GameId, MachineRepository, QueueRepository, SessionRepository,
} from '@lib/dal';
import { FileManagerService } from '@lib/file.manager';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Inject, Injectable } from '@nestjs/common';
import {
  count, filter, firstValueFrom, lastValueFrom, mergeMap,
} from 'rxjs';
import { tap, toArray } from 'rxjs/operators';
import { Logger } from 'winston';
import { CommandPublisher } from '../../command/command.publisher';
import { PhaseEndCommand } from '../../command/dto/phase.end.command';
import { RouletteEventCommand } from '../../command/dto/roulette.event.command';
import { CoreMessage } from '../../messaging/robot.handling/enum/core.message';
import { PlayerClientService } from '../../player.client/player.client.service';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { SessionDataManager } from '../../session.data.manager/session.data.manager';
import { BetManager } from '../bet.manager';
import { RESULT_HISTORY_LENGTH } from '../constants/state.machine.config';
import { GamePhase, PhaseStatus } from '../enums';
import { CommonContext, PhaseResult, TableImageDto } from '../types';
import { PhaseHandler } from './phase.handler';

@Injectable()
export class PickNumberPhaseHandler extends PhaseHandler {
  constructor(
    commandPublisher: CommandPublisher,
    betManager: BetManager,
    robotPublisher: RobotClientService,
    private readonly playerPublisher: PlayerClientService,
    private readonly ballRepo: BallRepository,
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    sessionRepo: SessionRepository,
    machineRepo: MachineRepository,
    queueRepo: QueueRepository,
    private readonly fileManagerService: FileManagerService,
    private readonly monitoringService: MonitoringWorkerClientService,
    private readonly sessionDataManager: SessionDataManager,
  ) {
    super(
      commandPublisher,
      betManager,
      sessionRepo,
      machineRepo,
      robotPublisher,
      queueRepo,
    );
  }

  public async onStart({ serial }: CommonContext): Promise<PhaseResult> {
    const message = { phase: GamePhase.PICK_NUMBER };
    await this.robotPublisher.sendRouletteDisplayMessage(serial, message);
    this.robotPublisher.sendRobotMessage({
      action: CoreMessage.START_ROUND,
      config: {
        timeout: 30,
        rotateTime: 5,
        maxAttempts: 3,
      },
    }, serial);
    await firstValueFrom(this.betManager.getMachineBets(serial)
      .pipe(
        tap(({ sessionId }) => this.playerPublisher.gamePhase(sessionId, message)),
        count(),
      ));
    return { status: PhaseStatus.IN_PROGRESS };
  }

  public async onComplete({
    serial,
    resultHistory,
  }: CommonContext): Promise<void> {
    this.robotPublisher.sendRouletteDisplayMessage(serial, {
      phase: GamePhase.PICK_NUMBER,
      resultHistory,
    });
    this.playerPublisher.broadcastToQueue(
      serial,
      PlayerMessageType.RESULT_HISTORY,
      { history: resultHistory },
    );
  }

  public onError(context: CommonContext): Promise<void> {
    return Promise.resolve();
  }

  public async roundResult(
    context: CommonContext,
    { data: { rfid } }: RouletteEventCommand<{ rfid: string }>,
  ): Promise<void> {
    const winField = await this.ballRepo.getBallLabel(rfid, context.serial);

    /* if (!winField) {
      context.status = StateMachineStatus.ERROR;
      const machine = await this.machineRepo.findOneOrFail(context.machineId, { relations: ['group'] });
      await this.groupTerminator.groupHardStop(machine.group.id, {
        reason: ShutdownReason.CHIP_VALUE_CALC_FAILED,
        machineIds: [machine.id],
      }, correlationId);
      throw new RpcException('Invalid ball');
    } */

    const { resultHistory } = context;
    resultHistory.unshift(winField);
    if (resultHistory.length > RESULT_HISTORY_LENGTH) {
      resultHistory.splice(RESULT_HISTORY_LENGTH, resultHistory.length - RESULT_HISTORY_LENGTH);
    }
    this.commandPublisher.sendRouletteCommand<PhaseEndCommand>({
      type: CommandType.PHASE_END,
      serial: context.serial,
      phase: GamePhase.PICK_NUMBER,
    });
  }

  public async playerQuit(
    context: CommonContext,
    event: RouletteEventCommand<{ sessionId: number }>,
  ): Promise<void> {
    this.logger.warn('Roulette event ignored', {
      serial: context.serial,
      sessionId: event.data.sessionId,
      event: event.eventType,
      handler: PickNumberPhaseHandler.name,
    });
  }

  public async tableImage(
    context: CommonContext,
    event: RouletteEventCommand<TableImageDto>,
  ): Promise<void> {
    const betsObs = await this.betManager.getMachineBets(context.serial);
    const bets = await lastValueFrom(betsObs.pipe(
      mergeMap(async ({ sessionId }) => {
        const sessionData = await this.sessionDataManager.getSessionData(sessionId);
        const roundId = sessionData?.transaction?.roundId;
        if (!roundId) {
          this.logger.error('tableImage handler', { sessionId, ...event, errorMessage: 'Bet without transaction' });
        }
        return { roundId, sessionId };
      }),
      filter(e => !!e.roundId),
      toArray(),
    ));

    if (!bets.length) {
      return;
    }

    const fileId = await this.fileManagerService.saveFile(
      Buffer.from(event.data.image, 'base64'),
      'image/jpg',
      `roulette/tableImages/${event.data.tag}`);

    bets.forEach(({ sessionId, roundId }) => this.monitoringService.sendEventLogMessage(
      {
        eventType: EventType.TABLE_IMAGE,
        source: EventSource.ROBOT,
        params: {
          sessionId,
          machineSerial: context.serial,
          tag: event.data.tag,
          gameId: GameId.CLAW_ROULETTE,
          fileId,
          roundId,
        },
      }));
  }
}
