import { CoreWorkerMessageType } from '@lib/dal';
import { PlayerClientService } from '../player.client/player.client.service';
import { makeTestModule } from './mocks/beforeAll.mock';
import { WorkerClientService } from './worker.client.service';

jest.mock('../logger/logger.service');

xdescribe('Worker Client Service (Unit)', () => {
  let workerClientService: WorkerClientService;
  let sendWorkerMessageSpy: any;
  let playerClientService: PlayerClientService;

  beforeAll(async () => {
    const moduleFixture = await makeTestModule();
    workerClientService = moduleFixture.get<WorkerClientService>(WorkerClientService);
    playerClientService = moduleFixture.get<PlayerClientService>(PlayerClientService);
    sendWorkerMessageSpy = jest.spyOn(workerClientService, 'sendWorkerMessage');
  });
});
