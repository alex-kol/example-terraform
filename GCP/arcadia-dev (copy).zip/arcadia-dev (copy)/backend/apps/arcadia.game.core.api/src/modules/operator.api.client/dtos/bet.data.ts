import { BalanceData } from './balance.data';

export class BetData extends BalanceData {
  transactionId?: string;
}
