import {
  LoggerInterceptor,
  NewrelicAndMessagePattern,
  PlayerMessageType,
  RmqQueueName,
  rmqRoutingGenerate,
  RpcMainExceptionFilter,
  rpcValidationExceptionFactory,
} from '@lib/common';
import { GameId } from '@lib/dal';
import {
  Controller, Scope, UseFilters, UseInterceptors, UsePipes, ValidationPipe,
} from '@nestjs/common';
import { Payload } from '@nestjs/microservices';

import { BuyStacksClawHandler } from './buy.stacks.сlaw.handler';
import { SessionInjectorPipe } from '../../../messaging/session.injector.pipe';
import { BuyMessageDto } from '../../../messaging/player.handling/dto/buy.message.dto';

@Controller({
  path: 'v1/player-rs',
  scope: Scope.REQUEST,
})
@UseInterceptors(LoggerInterceptor)
@UseFilters(RpcMainExceptionFilter)
@UsePipes(new ValidationPipe({
  transform: true,
  whitelist: true,
  exceptionFactory: rpcValidationExceptionFactory,
}))
export class PlayerRequestController {
  constructor(
    private readonly buyStacksClawHandler: BuyStacksClawHandler,
  ) {
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.BUY_STACKS, GameId.CLAW))
  public buyStacks(@Payload() data: BuyMessageDto): Promise<void> {
    return this.buyStacksClawHandler.handle(data);
  }
}
