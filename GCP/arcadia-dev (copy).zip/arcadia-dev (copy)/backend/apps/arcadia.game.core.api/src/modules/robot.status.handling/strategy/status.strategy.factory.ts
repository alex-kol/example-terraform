import { MachineEntity, MachineStatus } from '@lib/dal';
import { Injectable } from '@nestjs/common';
import { ModuleRef } from '@nestjs/core';
import { RobotReportedStatus } from '../robot.reported.status';
import { StatusHandlerStrategy } from './status.handler.strategy';
import { statusStrategyIdFactory } from './status.strategy.id.factory';
import { StatusStrategyType } from './status.strategy.type';

@Injectable()
export class StatusStrategyFactory {
  constructor(private readonly moduleRef: ModuleRef) {
  }

  public getStrategy(machine: MachineEntity, robotStatus: RobotReportedStatus): StatusHandlerStrategy {
    const {
      status: machineStatus,
      gameId,
    } = machine;
    let strategy: StatusStrategyType;
    switch (robotStatus) {
      case RobotReportedStatus.STOPPED:
        if (machineStatus === MachineStatus.SHUTTING_DOWN) {
          strategy = StatusStrategyType.SHUTDOWN;
        } else if (machineStatus === MachineStatus.OFFLINE
          || machineStatus === MachineStatus.STOPPED
          || machineStatus === MachineStatus.ON_HOLD) {
          strategy = StatusStrategyType.STARTUP;
        } else {
          strategy = StatusStrategyType.ERROR;
        }
        break;
      case RobotReportedStatus.TESTING:
        if (machineStatus === MachineStatus.STOPPED) {
          strategy = StatusStrategyType.STARTUP;
        } else {
          strategy = StatusStrategyType.ERROR;
        }
        break;
      case RobotReportedStatus.SEEDING:
        if (machineStatus === MachineStatus.SEEDING) {
          strategy = StatusStrategyType.GAMEPLAY;
        } else {
          strategy = StatusStrategyType.ERROR;
        }
        break;
      case RobotReportedStatus.IDLE:
        if (machineStatus === MachineStatus.PREPARING) {
          strategy = StatusStrategyType.STARTUP;
        } else if (machineStatus === MachineStatus.READY
          || machineStatus === MachineStatus.SEEDING
          || MachineStatus.IN_PLAY) {
          strategy = StatusStrategyType.GAMEPLAY;
        } else {
          strategy = StatusStrategyType.ERROR;
        }
        break;
      case RobotReportedStatus.STOPPING:
        strategy = StatusStrategyType.SHUTDOWN;
        break;
      case RobotReportedStatus.MANUAL_PLAY:
      case RobotReportedStatus.AUTO_PLAY:
        if (machineStatus === MachineStatus.IN_PLAY || machineStatus === MachineStatus.READY) {
          strategy = StatusStrategyType.GAMEPLAY;
        } else {
          strategy = StatusStrategyType.ERROR;
        }
        break;
      case RobotReportedStatus.IN_ROUND:
        strategy = StatusStrategyType.GAMEPLAY;
        break;
      default:
        strategy = StatusStrategyType.ERROR;
    }
    return this.moduleRef.get(statusStrategyIdFactory(gameId, strategy));
  }
}
