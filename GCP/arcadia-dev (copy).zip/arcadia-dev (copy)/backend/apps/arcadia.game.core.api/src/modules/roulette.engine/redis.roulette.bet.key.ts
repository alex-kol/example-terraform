const PREFIX = 'roulette-bet-key';
const DELIMITER = ':';

export function getRouletteBetKeyPattern(serial: string): string {
  return `${PREFIX}${DELIMITER}${serial}`;
}
