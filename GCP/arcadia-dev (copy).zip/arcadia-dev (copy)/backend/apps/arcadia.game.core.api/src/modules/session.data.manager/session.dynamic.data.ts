import {
  AutoplayConfiguration, BetBehindConfiguration, ClawPhase, SessionEndReason,
} from '@lib/dal';
import { LoginOptions } from '../auth/interfaces';
import { RouletteBet } from '../roulette.engine/types';
import { TransactionData } from './transaction.data';

export class SessionDynamicData {
  autoplay?: AutoplayConfiguration;
  betBehind?: BetBehindConfiguration;
  loginOptions?: LoginOptions;
  endReason?: SessionEndReason;
  transaction?: TransactionData;
  lastBet?: RouletteBet;
  lastWinInCash?: number;
  videoFailed?: boolean;
  isPlayerIdl?: boolean;
  clawPhase?: ClawPhase;
}
