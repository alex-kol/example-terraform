import { PlayerMessageType } from '@lib/common';
import { SessionEntity } from '@lib/dal';
import { Injectable } from '@nestjs/common';
import { Emitter } from '@socket.io/redis-emitter';
import { AuthResponseDto, CoinPusherLobbyRes } from '../auth/responses';
import { AutoplayDto } from '../messaging/player.handling/dto/autoplay.dto';
import { QueueBalanceDto } from '../messaging/player.handling/dto/queueBalanceDto';
import { RoundStartedDto } from '../messaging/player.handling/dto/round.started.dto';
import { ChipMessageInterface, PhantomMessageInterface, PlayerBalanceMessageInterface } from '../messaging/player.handling/interfaces';
import { RouletteBetResponse } from '../messaging/player.handling/interfaces/roulette.bet.response';
import { VoucherDto } from '../messaging/robot.handling/dto/voucher.dto';
import { getRobotQueueRoom, sessionRoomNameFactory } from '../messaging/room.name.template';
import { QueueMessageDto } from '../queue.manager/dto/queue.message.dto';
import { GamePhase } from '../roulette.engine/enums';
import { RoundResult } from '../roulette.engine/phase.handler/roulette.win.calculator';
import { PlayerNotification } from './player.notification';
import { RoundEndedDto } from '../messaging/player.handling/dto/round.ended.dto';

@Injectable()
export class PlayerClientService {
  constructor(private readonly emitter: Emitter) {
  }

  public broadcastToQueue<T extends Record<string, any> = Record<string, any>>(machineSerial: string, messageType: PlayerMessageType, data: T): void {
    this.emitter.to(getRobotQueueRoom(machineSerial))
      .emit(messageType, data);
  }

  public sessionState(sessionId: string | number, data: Partial<SessionEntity>): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.SESSION_STATE, data);
  }

  public gamePhase(sessionId: string | number, data: { phase: GamePhase, endTimestamp?: string }): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.GAME_PHASE, data);
  }

  public notifySessionResult(sessionId: string | number, totalWin: number): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.SESSION_RESULT, { totalWin });
  }

  public notifyWin(sessionId: string | number, data: ChipMessageInterface | { currencyValue: number, phantomWinValues: number[] }): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.WIN, data);
  }

  public notifyRouletteWin(sessionId: string | number, roundResult: RoundResult): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.WIN, roundResult);
  }

  public notifyTotalWin(sessionId: string | number, totalWin: number): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.TOTAL_WIN, { totalWin });
  }

  public notifyQueueUpdate(machineSerial: string, data: QueueMessageDto): void {
    this.emitter.to(getRobotQueueRoom(machineSerial))
      .emit(PlayerMessageType.QUEUE, data);
  }

  public broadcastRemainingCoins(machineSerial: string, remainingCoins: number): void {
    this.emitter.to(getRobotQueueRoom(machineSerial))
      .emit(PlayerMessageType.REMAINING_COINS, { remainingCoins });
  }

  public notifyBuyResult(sessionId: string | number, queueToken: string, rounds: number): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.BUY_STACKS, {
        queueToken,
        rounds,
      });
  }

  public queueBalance(sessionId: string | number, data: QueueBalanceDto): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.QUEUE_BALANCE, data);
  }

  public notifyRebuy(sessionId: number, timeoutSec: number): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.RE_BUY, { timeoutSec });
  }

  public notification(sessionId: string | number, data: PlayerNotification): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.NOTIFICATION, data);
  }

  public notifyAutoplay(sessionId: string | number, data: AutoplayDto): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.AUTOPLAY, data);
  }

  public notifyPhantom(sessionId: string | number, data: PhantomMessageInterface): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.PHANTOM, data);
  }

  public sendBets(sessionId: string | number, data: CoinPusherLobbyRes): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.BETS, data);
  }

  public rouletteCurrentBet(sessionId: number, data: RouletteBetResponse): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.BETS, data);
  }

  public sendVoucher(sessionId: string | number, data: VoucherDto): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.VOUCHER, data);
  }

  public notifyReturnToLobby(sessionId: string | number, data?: AuthResponseDto): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.RETURN_TO_LOBBY, data);
  }

  public setCountdown(sessionId: string | number, timeoutSec: number): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.SET_COUNTDOWN, { timeoutSec });
  }

  public notifyBalance(sessionId: string | number, data: PlayerBalanceMessageInterface): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.BALANCE, data);
  }

  public notifyRoundStart(sessionId: string | number, data: RoundStartedDto): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.ROUND_START, data);
  }

  public notifyRoundEnd(sessionId: string | number, data: RoundEndedDto): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.ROUND_END, data);
  }

  public forceReconnect(sessionId: string | number): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.FORCE_RECONNECT);
  }

  public sendInvitationBetBehind(sessionIds: Array<string | number>): void {
    if (sessionIds?.length) {
      this.emitter.to(sessionIds.map(id => sessionRoomNameFactory(id)))
        .emit(PlayerMessageType.READY_BET_BEHIND);
    }
  }

  public forceClientClose(sessionId: string | number): void {
    this.emitter.to(sessionRoomNameFactory(sessionId))
      .emit(PlayerMessageType.FORCE_CLIENT_CLOSE);
  }
}
