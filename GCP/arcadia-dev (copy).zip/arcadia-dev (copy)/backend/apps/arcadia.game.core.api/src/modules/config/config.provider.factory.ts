/* eslint-disable max-lines */
import { DnsResolver, JoiExtended as Joi } from '@lib/common';
import {
  cmsValidationSchema,
  ConfigLoader,
  dbAuditValidationSchema,
  dbConfigsValidationSchema,
  dbMasterValidationSchema,
  dbSlaveValidationSchema,
  EnvConfigLoader,
  GsmConfigLoader,
  initValidationSchema,
  redisValidationSchema,
  rmqValidationSchema,
  ValidationOptions,
} from '@lib/config';
import { Provider } from '@nestjs/common';
import { FactoryProvider, ValueProvider } from '@nestjs/common/interfaces/modules/provider.interface';
import { concatMap, from, lastValueFrom } from 'rxjs';
import { map, toArray } from 'rxjs/operators';

const afterValidateMapper = async (currentData: Record<string, string>) => ({
  ...currentData,
  OPERATOR_SERVICE_API_URL: await new DnsResolver(currentData.OPERATOR_SERVICE_API_URL, currentData.NODE_ENV as any).resolve(),
});

export const configProviderFactory = (): Array<ValueProvider | FactoryProvider> => {
  const envProvider: Provider = {
    provide: 'INIT_CONFIG',
    useValue: new EnvConfigLoader({
      tag: 'CORE',
      filePath: './.env',
      validation: {
        schema: Joi.object(initValidationSchema),
        options: {
          stripUnknown: false,
          allowUnknown: true,
        },
      },
    }),
  };

  const gsmProvider: Provider = {
    provide: 'CORE',
    useFactory: async (initLoader: ConfigLoader) => {
      const initConfig = await initLoader.getConfig();
      const validationOptions: ValidationOptions = {
        schema: Joi.object({
          ...initValidationSchema,
          ...dbMasterValidationSchema,
          ...dbSlaveValidationSchema,
          ...dbConfigsValidationSchema,
          ...redisValidationSchema,
          ...rmqValidationSchema,
          ...cmsValidationSchema,
          ...dbAuditValidationSchema,
          EXTERNAL_REDIS_HOST: Joi.string()
            .hostname()
            .required(),
          EXTERNAL_RABBITMQ_HOST: Joi.string()
            .hostname()
            .required(),
          OPERATOR_SERVICE_API_URL: Joi.string()
            .required(),
          CLIENT_IO_HAPROXY_URL: Joi.string()
            .required(),
          SESSION_AUTH_SECRET: Joi.string()
            .required(),
          ROBOTS_AUTH_SECRET: Joi.string()
            .required(),
          RNG_HOST: Joi.string()
            .hostname()
            .required(),
          RNG_PORT: Joi.number()
            .default(3000),
          STREAM_AUTH_SECRET: Joi.string()
            .required(),
          STREAM_AUTH_TEST_TOKEN_OK: Joi.string()
            .required(),
          STREAM_AUTH_TEST_TOKEN_BAD: Joi.string()
            .required(),
          ROBOT_OFFLINE_DURATION_THRESHOLD_SEC: Joi.number()
            .integer()
            .required(),
          CLIENT_FE_BASE_URL: Joi.string()
            .required(),
          ROBOT_FILES_API_URL: Joi.string()
            .required(),
          ROUND_END_DELAY_SECONDS: Joi.number()
            .integer()
            .default(10),
          PHANTOM_WIDGET_ANIMATION_DURATION_MS: Joi.number()
            .integer()
            .default(5000),
          URL_CREATOR_IP_WHITELIST: Joi.jsonStringToArray()
            .items(Joi.string()
              .ip())
            .min(1)
            .required(),
          CAMERA_API_TOKEN_TTL_SECONDS: Joi.number()
            .integer()
            .default(3600),
          VALIDATED_CONFIG_TTL_SEC: Joi.number()
            .integer()
            .default(30),
          ALLOW_PARALLEL_SESSIONS: Joi.boolean()
            .default(false),
          ROBOT_ENGAGE_TIMEOUT_SEC: Joi.number()
            .integer()
            .default(10),
          TERMINATE_SESSION_TIMEOUT_SEC: Joi.number()
            .integer()
            .positive()
            .default(30),
          LAUNCH_GAME_IP_WHITELIST: Joi.jsonStringToArray()
            .items(Joi.string()
              .ip())
            .default(['127.0.0.1']),
          CHIPS_DROP_ALERT_LIMIT: Joi.number()
            .integer()
            .positive()
            .default(400),
          MAX_SESSIONS_THRESHOLD: Joi.number()
            .integer()
            .positive()
            .required(),
          ROULETTE_BET_OPEN_DURATION_SEC: Joi.number()
            .integer()
            .positive()
            .default(15),
          ROULETTE_SHOW_RESULTS_DURATION_SEC: Joi.number()
            .integer()
            .positive()
            .default(5),
          REFURBISH_TTL_MIN: Joi.number()
            .integer()
            .positive()
            .default(5),
        })
          .pattern(/^CAMERA_API_PASS_/, Joi.string()),
        options: {
          stripUnknown: true,
          allowUnknown: false,
        },
      };
      if (initConfig.USE_GCP_SM !== true) {
        initLoader.setValidation(validationOptions);
        initLoader.setMapper(afterValidateMapper);
        return initLoader;
      }
      const gsmConfig = {
        envToConfigMap: {
          SYSTEM_LOG_LEVEL: 'SYSTEM_LOG_LEVEL',
          DB_SLAVE_PORT: 'DB_SLAVE_PORT',
          DB_SLAVE_USER: 'DB_SLAVE_USER',
          DB_SLAVE_PSW: 'DB_SLAVE_PSW',
          DB_SLAVE_NAME: 'DB_SLAVE_NAME',
          DB_SLAVE_HOST: 'DB_SLAVE_HOST',
          DB_MASTER_PORT: 'DB_MASTER_PORT',
          DB_MASTER_USER: 'DB_MASTER_USER',
          DB_MASTER_PSW: 'DB_MASTER_PSW',
          DB_MASTER_NAME: 'DB_MASTER_NAME',
          DB_MASTER_HOST: 'DB_MASTER_HOST',
          DB_AUDIT_HOST: 'DB_AUDIT_HOST',
          DB_AUDIT_PORT: 'DB_AUDIT_PORT',
          DB_AUDIT_USER: 'DB_AUDIT_USER',
          DB_AUDIT_PSW: 'DB_AUDIT_PSW',
          DB_AUDIT_NAME: 'DB_AUDIT_NAME',
          DB_LOGS: 'GCA_DB_LOGS',
          DB_CONNECTION_LIMIT: 'GCA_DB_CONNECTION_LIMIT',
          DB_RETRY_ATTEMPTS: 'DB_RETRY_ATTEMPTS',
          DB_MAX_QUERY_EXECUTION_TIME: 'DB_MAX_QUERY_EXECUTION_TIME',
          REDIS_HOST: 'REDIS_HOST',
          EXTERNAL_REDIS_HOST: 'EXTERNAL_REDIS_HOST',
          REDIS_PORT: 'REDIS_PORT',
          RABBITMQ_HOST: 'RABBITMQ_HOST',
          RABBITMQ_PORT: 'RABBITMQ_PORT',
          EXTERNAL_RABBITMQ_HOST: 'EXTERNAL_RABBITMQ_HOST',
          RABBITMQ_USERNAME: 'RABBITMQ_USERNAME',
          RABBITMQ_PASSWORD: 'RABBITMQ_PASSWORD',
          CLIENT_IO_HAPROXY_URL: 'GCA_CLIENT_IO_HAPROXY_URL',
          OPERATOR_SERVICE_API_URL: 'GCA_OPERATOR_SERVICE_API_URL',
          ROBOTS_AUTH_SECRET: 'GCA_ROBOTS_AUTH_SECRET',
          SESSION_AUTH_SECRET: 'SESSION_AUTH_SECRET',
          RNG_HOST: 'RNG_HOST',
          RNG_PORT: 'RNG_PORT',
          STREAM_AUTH_SECRET: 'STREAM_AUTH_SECRET',
          STREAM_AUTH_TEST_TOKEN_OK: 'STREAM_AUTH_TEST_TOKEN_OK',
          STREAM_AUTH_TEST_TOKEN_BAD: 'STREAM_AUTH_TEST_TOKEN_BAD',
          ROBOT_OFFLINE_DURATION_THRESHOLD_SEC: 'ROBOT_OFFLINE_DURATION_THRESHOLD_SEC',
          CLIENT_FE_BASE_URL: 'CLIENT_FE_BASE_URL',
          ROUND_END_DELAY_SECONDS: 'ROUND_END_DELAY_SECONDS',
          PHANTOM_WIDGET_ANIMATION_DURATION_MS: 'PHANTOM_WIDGET_ANIMATION_DURATION_MS',
          URL_CREATOR_IP_WHITELIST: 'URL_CREATOR_IP_WHITELIST',
          CAMERA_API_TOKEN_TTL_SECONDS: 'CG_CAMERA_API_TOKEN_TTL_SECONDS',
          VALIDATED_CONFIG_TTL_SEC: 'VALIDATED_CONFIG_TTL_SEC',
          ALLOW_PARALLEL_SESSIONS: 'ALLOW_PARALLEL_SESSIONS',
          ROBOT_ENGAGE_TIMEOUT_SEC: 'ROBOT_ENGAGE_TIMEOUT_SEC',
          TERMINATE_SESSION_TIMEOUT_SEC: 'TERMINATE_SESSION_TIMEOUT_SEC',
          LAUNCH_GAME_IP_WHITELIST: 'LAUNCH_GAME_IP_WHITELIST',
          CHIPS_DROP_ALERT_LIMIT: 'CHIPS_DROP_ALERT_LIMIT',
          MAX_SESSIONS_THRESHOLD: 'MAX_SESSIONS_THRESHOLD',
          CMS_FILE_URL: 'CMS_FILE_URL',
          BUCKET_NAME: 'BUCKET_NAME',
          ROULETTE_BET_OPEN_DURATION_SEC: 'ROULETTE_BET_OPEN_DURATION_SEC',
          ROULETTE_SHOW_RESULTS_DURATION_SEC: 'ROULETTE_SHOW_RESULTS_DURATION_SEC',
          REFURBISH_TTL_MIN: 'REFURBISH_TTL_MIN',
          ROBOT_FILES_API_URL: 'ROBOT_FILES_API_URL',
        },
      };
      return new GsmConfigLoader({
        tag: 'CORE',
        gsmConfig,
        include: [initLoader],
        validation: validationOptions,
        afterValidateMapper,
      });
    },
    inject: ['INIT_CONFIG'],
  };

  const configProvidersProvider: Provider = {
    provide: 'CONFIG_PROVIDERS',
    useFactory: (coreLoader: ConfigLoader) => [coreLoader],
    inject: ['CORE'],
  };

  const initConfigProvider: Provider = {
    provide: 'PRELOADED_CONFIG',
    useFactory: async (loaders: ConfigLoader[]) => lastValueFrom(from(loaders)
      .pipe(
        concatMap(async loader => {
          const loadedConfig = await loader.getConfig();
          return [loader.tag, loadedConfig] as [string, Record<string, any>];
        }),
        toArray(),
        map(value => new Map(value)),
      )),
    inject: ['CONFIG_PROVIDERS'],
  };

  return [envProvider, gsmProvider, configProvidersProvider, initConfigProvider];
};
