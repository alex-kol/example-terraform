import { AutoSwingMode, RoundRepository, ShutdownReason } from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { ServerRMQ } from '@lib/rmq.server';
import { Inject, Injectable } from '@nestjs/common';
import { Logger } from 'winston';
import { getRobotQueueName } from '../../util';
import { CoreMessage } from '../messaging/robot.handling/enum/core.message';
import { GamePhase } from '../roulette.engine/enums';
import { CoreToRobotMessage } from './robot.interface';

@Injectable()
export class RobotClientService {
  constructor(
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly serverRMQ: ServerRMQ,
    private readonly roundRepo: RoundRepository,
  ) {
  }

  public sendRobotMessage(message: CoreToRobotMessage, robotSerial: string): void {
    this.logger.debug('Core -> Robot', {
      ...message,
      machineSerial: robotSerial,
    });
    this.serverRMQ.sendMessage(message, getRobotQueueName(robotSerial));
  }

  public async sendAllowCoinsMessage(coins: number, robotSerial: string, sessionId: number): Promise<void> {
    const message: CoreToRobotMessage = {
      action: CoreMessage.ALLOW_DISPENSING,
      coins,
      session: sessionId,
    };
    await this.sendRobotMessage(message, robotSerial);
  }

  public async sendEngageMessage(sessionId: number, robotSerial: string, burstShoot?: number): Promise<void> {
    const message: CoreToRobotMessage = {
      action: CoreMessage.ENGAGE,
      session: sessionId,
      burstShoot,
    };
    await this.sendRobotMessage(message, robotSerial);
  }

  public sendDisengageMessage(sessionId: number, robotSerial: string): void {
    const message: CoreToRobotMessage = {
      action: CoreMessage.BREAKUP,
      session: sessionId,
    };
    this.sendRobotMessage(message, robotSerial);
  }

  public async sendChipValidationMessage(rfid: string, valid: boolean, robotSerial: string, chipType?: string): Promise<void> {
    const message: CoreToRobotMessage = {
      action: CoreMessage.CHIP_VALIDATION,
      rfid,
      status: valid ? 'valid' : 'invalid',
      chipType,
    };
    await this.sendRobotMessage(message, robotSerial);
  }

  public sendPushMessage(dispenserId: string, robotSerial: string): void {
    const message: CoreToRobotMessage = {
      action: CoreMessage.PUSH,
      dispenser: dispenserId,
    };
    this.sendRobotMessage(message, robotSerial);
  }

  public async sendSeedMessage(robotSerial: string, toPush: string[], reshuffleCoins: number): Promise<void> {
    const message: CoreToRobotMessage = {
      action: CoreMessage.SEED,
      dispensers: toPush,
      reshuffleCoins,
    };
    await this.sendRobotMessage(message, robotSerial);
  }

  public async sendStopMessage(serial: string, reason: ShutdownReason): Promise<void> {
    const message: CoreToRobotMessage = {
      action: CoreMessage.STOP,
      reason,
    };
    await this.sendRobotMessage(message, serial);
  }

  public async sendAutoplayMessage(serial: string, sessionId: number, mode: AutoSwingMode): Promise<void> {
    await this.roundRepo.setAutoplay(sessionId);
    await this.sendRobotMessage({
      action: CoreMessage.AUTO,
      session: sessionId,
      mode,
    }, serial);
  }

  public async sendStopAutoplayMessage(serial: string, sessionId: number): Promise<void> {
    await this.sendRobotMessage({
      action: CoreMessage.STOP_AUTO,
      session: sessionId,
    }, serial);
  }

  public sendRouletteDisplayMessage(serial: string, data: { phase: GamePhase } & Record<string, any>): void {
    this.sendRobotMessage({
      action: CoreMessage.ROULETTE_DISPLAY,
      ...data,
    }, serial);
  }

  public sendBallConfig(serial: string, data: { missing: string[], label: string, rejectedReason: string }): void {
    this.sendRobotMessage({
      action: CoreMessage.BALL_CONFIG,
      ...data,
    }, serial);
  }

  public forcedPickup(serial: string, sessionId: number): void {
    this.sendRobotMessage({
      action: CoreMessage.FORCED_PICKUP,
      session: sessionId,
    }, serial);
  }
}
