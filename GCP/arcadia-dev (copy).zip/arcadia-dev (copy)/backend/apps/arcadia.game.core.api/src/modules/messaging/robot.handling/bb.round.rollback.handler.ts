/* eslint-disable max-lines */
import { CommandType, EventSource } from '@lib/common';
import {
  AlertSeverity,
  AlertSource,
  AlertType,
  CancelBetOnSessionOptions,
  EventType,
  GameId,
  PlayerRepository,
  RoundEntity,
  RoundRepository,
  RoundStatus,
  RoundType,
  SessionEndReason,
  SessionStatus,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Inject, Injectable, Scope } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import BigNumber from 'bignumber.js';
import { DataSource } from 'typeorm';
import { Logger } from 'winston';
import { CommandPublisher } from '../../command/command.publisher';
import { BbRollbackCommand } from '../../command/dto/bb.rollback.command';
import { FinalizeSessionCommand } from '../../command/dto/finalize.session.command';
import { SessionContextHandler } from '../../command/session.context.handler';
import { OperatorApiClientService } from '../../operator.api.client/operator.api.client.service';
import { NotificationLevel } from '../../player.client/notification.level';
import { NotificationType } from '../../player.client/notification.type';
import { PlayerClientService } from '../../player.client/player.client.service';
import { SessionDataManager } from '../../session.data.manager/session.data.manager';

@Injectable({ scope: Scope.REQUEST })
export class BbRoundRollbackHandler extends SessionContextHandler<BbRollbackCommand> {
  private roundRepo: RoundRepository;
  private playerRepo: PlayerRepository;
  private reason: SessionEndReason;
  private activeRound: RoundEntity;
  private finalizeCommand: FinalizeSessionCommand = null;

  constructor(
    @Inject(MAIN_LOGGER) logger: Logger,
    private readonly operatorClient: OperatorApiClientService,
    private readonly commandPublisher: CommandPublisher,
    private readonly monitoringWorkerClient: MonitoringWorkerClientService,
    private readonly sessionDataManager: SessionDataManager,
    private readonly playerClient: PlayerClientService,
    dataSource: DataSource,
  ) {
    super(logger, dataSource);
  }

  protected async init(data: BbRollbackCommand): Promise<void> {
    await super.init(data);

    this.reason = data.reason;

    // transactional repos
    this.roundRepo = new RoundRepository(this.entityManager);
    this.playerRepo = new PlayerRepository(this.entityManager);

    this.session = await this.sessionRepository.findOneOrFail({
      where: { id: this.cachedSession.id },
      relations: ['rounds'],
    });
    if (this.session.status !== SessionStatus.VIEWER_BET_BEHIND
      && this.session.status !== SessionStatus.QUEUE_BET_BEHIND) {
      throw new RpcException(`Session is not BB, sessionId: ${this.session.id}, `
        + `status: ${this.session.status}, correlationId: ${this.correlationId}`);
    }
    this.activeRound = this.session.rounds?.find(round => (round.status === RoundStatus.ACTIVE || round.status === RoundStatus.PAUSED)
      && round.type === RoundType.BET_BEHIND);
    if (!this.activeRound) {
      throw new RpcException(`No active round to rollback!, sessionId: ${this.session.id}, correlationId: ${this.correlationId}`);
    }
  }

  protected async handleEvent(): Promise<void> {
    await this.terminateRound();
    const sessionCancelBetPayload: CancelBetOnSessionOptions = {
      sessionId: this.session.id,
      betInValue: this.activeRound.bet,
      betInCash: this.activeRound.betInCash,
      wins: this.activeRound.wins,
      winInCash: this.activeRound.winInCash,
      roundsLeft: Number(this.session.roundsLeft),
    };
    await this.sessionRepository.cancelBet(sessionCancelBetPayload);
    await this.playerRepo.cancelBet(this.cachedPlayer.cid, this.cachedOperator.id, this.activeRound.bet, this.activeRound.wins);
    this.monitoringWorkerClient.sendEventLogMessage({
      eventType: EventType.CANCEL_BET,
      source: EventSource.GAME,
      params: {
        sessionId: this.session.id,
        round: this.activeRound.id,
        machineId: this.cachedMachine.id,
        machineSerial: this.cachedMachine.serial,
        reason: this.reason,
      },
    });
    this.playerClient.notifyTotalWin(this.sessionId, new BigNumber(this.session.totalWinInCash)
      .minus(this.activeRound.winInCash)
      .dp(2)
      .toNumber());
    this.playerClient.notification(this.session.id,
      {
        notificationId: NotificationType.ROUND_TERMINATED,
        level: NotificationLevel.WARNING,
        title: 'Round terminated',
        message: 'Current round has been terminated',
      });
    try {
      const {
        loginOptions: {
          sessionToken,
          extGameId,
        },
        transaction: { transactionId },
      } = await this.sessionDataManager.getSessionData(this.session.id);
      const cancelBetResult = await this.operatorClient.cancelBet({
        accessToken: sessionToken,
        operator: this.cachedOperator,
        cid: this.cachedPlayer.cid,
        amount: this.activeRound.betInCash,
        roundId: this.activeRound.id,
        transactionId,
        correlationId: this.correlationId,
        gameId: this.session.gameId,
        extGameId,
      });
      await this.roundRepo.update(this.activeRound.id,
        {
          finalBalance: cancelBetResult.balance,
        });
    } catch (e) {
      await this.onTransactionError(e);
    }
  }

  private async terminateRound(): Promise<void> {
    await this.roundRepo.update(this.activeRound.id,
      {
        status: RoundStatus.TERMINATED,
        endDate: new Date(),
        wins: 0,
        winInCash: 0,
        bet: 0,
        betInCash: 0,
      });
    await this.monitoringWorkerClient.sendEventLogMessage({
      eventType: EventType.BB_ROUND_TERMINATED,
      source: EventSource.GAME,
      params: {
        sessionId: this.session.id,
        operatorId: this.cachedOperator.id,
        groupId: this.cachedGroup.id,
        machineSerial: this.cachedMachine.serial,
        machineId: this.cachedMachine.id,
        playerCid: this.cachedPlayer.cid,
        round: this.activeRound.id,
      },
    });
  }

  private async onTransactionError(error: Error) {
    this.logger.error('Cancel bet failed', {
      sessionId: this.session.id,
      roundId: this.activeRound.id,
      correlationId: this.correlationId,
      errorMessage: error.message,
    });
    this.monitoringWorkerClient.sendAlertMessage({
      alertType: AlertType.ERROR,
      source: AlertSource.GAME_CORE,
      severity: AlertSeverity.HIGH,
      description: `Cancel bet failed: ${error.message}`,
      gameId: this.cachedMachine.gameId,
      details: {
        sessionId: this.session.id,
        roundId: this.activeRound.id,
        machineId: this.cachedMachine.id,
        machineName: this.cachedMachine.name,
        machineSerial: this.cachedMachine.serial,
      },
    });
    this.finalizeCommand = {
      type: CommandType.FINALIZE_SESSION,
      gameId: GameId.COIN_PUSHER_V1,
      sessionId: this.session.id,
      terminate: true,
      reason: SessionEndReason.WALLET_TRANSACTION_ERROR,
    };
  }

  protected async onCommit(): Promise<void> {
    if (this.finalizeCommand) {
      this.commandPublisher.finalizeSession(this.finalizeCommand, this.correlationId);
    }
  }
}
