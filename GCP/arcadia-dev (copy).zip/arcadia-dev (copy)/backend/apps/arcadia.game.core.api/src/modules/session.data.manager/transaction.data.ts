export class TransactionData {
  roundId: string;
  transactionId: string;
  scatterRounds?: string[];
}
