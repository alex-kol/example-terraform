import { CommandType, RmqQueueName } from '@lib/common';
import { GameId, SessionEndReason } from '@lib/dal';
import { CommandPublisher } from './command.publisher';
import { EngageSessionCommand } from './dto/engage.session.command';
import { FinalizeSessionCommand } from './dto/finalize.session.command';
import { eventBusRmqServerMock, makeTestModule } from './mocks/beforeAll.mock';

jest.mock('../logger/logger.service');

describe('Event Bus Publisher (Unit)', () => {
  let eventBusPublisher: CommandPublisher;

  beforeAll(async () => {
    const moduleFixture = await makeTestModule();
    eventBusPublisher = moduleFixture.get<CommandPublisher>(CommandPublisher);
  });

  describe('sendEvent', () => {
    it('should send message using rabbitMQ', async () => {
      const sendMessageSpy = jest.spyOn(eventBusRmqServerMock, 'sendMessage');
      await eventBusPublisher.sendCommand({
        type: CommandType.CHANGE_QUEUE,
        gameId: GameId.COMMON
      }, '<corr>');

      expect(sendMessageSpy)
        .toBeCalledWith({
          type: CommandType.CHANGE_QUEUE,
          gameId: GameId.COMMON,
          correlationId: '<corr>'
        }, RmqQueueName.CORE_COMMAND_QUEUE);
    });
  });

  describe('sendFinalizeSession', () => {
    it('should send finalize session event', async () => {
      const payload: FinalizeSessionCommand = {
        terminate: true,
        type: CommandType.FINALIZE_SESSION,
        reason: SessionEndReason.FINALIZE_SESSION,
      };
      const sendEventSpy = jest.spyOn(eventBusPublisher, 'sendCommand');

      await eventBusPublisher.finalizeSession(payload, '<corr>');

      expect(sendEventSpy)
        .toBeCalledWith(payload, '<corr>');
    });
  });

  describe('engageNextSession', () => {
    it('should send engage next session event', async () => {
      const payload: EngageSessionCommand = {
        machineId: 1,
        type: CommandType.ENGAGE_SESSION,
      };
      const sendEventSpy = jest.spyOn(eventBusPublisher, 'sendCommand');

      await eventBusPublisher.engageNextSession(payload, '<corr>');

      expect(sendEventSpy)
        .toBeCalledWith(payload, '<corr>');
    });
  });
});
