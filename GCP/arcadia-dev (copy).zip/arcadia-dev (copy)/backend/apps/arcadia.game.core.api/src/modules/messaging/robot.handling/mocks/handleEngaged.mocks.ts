import { RoundStatus } from '@lib/dal';

export const handleEngagedSessionMock = {
  id: 51,
  rounds: [{
    status: RoundStatus.ACTIVE,
    coins: 10,
  }],
  machine: {
    serial: '<serial>',
  },
  player: {
    cid: '<cid>',
  },
  queue: {
    id: 75,
  },
  group: { idleTimeout: 100, graceTimeout: 100 },
  getActiveRound: () => ({ coins: 1 }),
};

export function shouldSendAutoplaySessionDisconnected(spyTargets: any): void {
  jest.spyOn(spyTargets.sessionRepository, 'findOneOrFail').mockResolvedValue({ ...handleEngagedSessionMock, isDisconnected: true });
}

export function shouldStartIdleNotifyQueue(spyTargets: any): void {
  jest.spyOn(spyTargets.sessionRepository, 'findOneOrFail').mockResolvedValue(handleEngagedSessionMock);
}
