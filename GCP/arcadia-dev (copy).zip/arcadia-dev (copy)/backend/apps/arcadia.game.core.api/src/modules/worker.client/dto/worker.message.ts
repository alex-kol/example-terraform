import { CoreWorkerMessageType, TimeoutOptions } from '@lib/common';

export type CoreToWorkerMessage = { type: CoreWorkerMessageType, correlationId?: string }
  & Partial<TimeoutOptions>;
