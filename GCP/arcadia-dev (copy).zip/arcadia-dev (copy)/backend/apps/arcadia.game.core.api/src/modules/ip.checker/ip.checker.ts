import { MAIN_LOGGER } from '@lib/logger';
import { Inject, Injectable } from '@nestjs/common';
import { Logger } from 'winston';
import { GeoIpClient } from './geo.ip.client';

@Injectable()
export class IpChecker {
  constructor(
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly geoClient: GeoIpClient,
  ) {
  }

  public async verifyIp(ipAddress: string, countryWhitelist?: string[]): Promise<boolean> {
    if (!countryWhitelist) {
      return true;
    }
    try {
      const geoData = await this.geoClient.getGeoByIp(ipAddress);
      this.logger.debug('Verify IP', { ipAddress, geoData });
      const allowed = countryWhitelist.includes(geoData.countryCode); // ISO 3166 Country Codes
      if (!allowed) {
        this.logger.warn('IP address is forbidden', { ipAddress });
        return false;
      }
      return true;
    } catch (err) {
      this.logger.error('IP address check failed', { ipAddress, error: err.message });
      return false;
    }
  }
}