import {
  AuthPlayerDto, ConversionDto, LoggerInterceptor, OperatorTag, UrlCreatorResp,
} from '@lib/common';
import { GameId } from '@lib/dal';
import {
  Body, Controller, Headers, NotFoundException, Post, UseInterceptors,
} from '@nestjs/common';
import { ModuleRef } from '@nestjs/core';
import { ApiBadRequestResponse, ApiTags } from '@nestjs/swagger';
import { CORRELATION_ID_HEADER } from '../../constants/logging.constants';
import { AuthService } from './auth.service';
import {
  LaunchGameDto, ReconnectDto, VerifyAuthTokenDto, VideoStreamAuthDto,
} from './dtos';
import { GameAuthHandler } from './interfaces';
import { LaunchUrlCreator } from './launch.url/launch.url.creator';
import { LaunchParams } from './launch.url/types';
import { urlCreatorTokenFactory } from './launch.url/url.creator.token.factory';
import {
  AuthResponseDto, LobbyDataRes, ReconnectVerifyRes, VerifyRes,
} from './responses';
import { gameProviderKeyFactory } from './util/game.provider.key.factory';

@ApiTags('Player Auth')
@Controller('v1/auth')
@UseInterceptors(LoggerInterceptor)
@ApiBadRequestResponse({ description: 'Bad request' })
export class AuthController {
  constructor(
    private readonly authService: AuthService,
    private readonly moduleRef: ModuleRef,
  ) {
  }

  @Post()
  public authPlayer(@Body() data: AuthPlayerDto, @Headers(CORRELATION_ID_HEADER) corrId: string): Promise<AuthResponseDto> {
    return this.authService.authPlayer(corrId, data);
  }

  @Post('/verify')
  public exchangeValidationToken(@Body() data: VerifyAuthTokenDto): Promise<VerifyRes> {
    return this.getGameAuthService(data.gameId)
      .loginPlayer(data.token, data.groupId, data.footprint);
  }

  @Post('/reconnect')
  public reconnect(@Body() data: ReconnectDto): Promise<ReconnectVerifyRes> {
    return this.getGameAuthService(data.gameId)
      .verifyReconnect(data.sessionId, data.footprint);
  }

  @Post('/lobby')
  public lobby(@Body() data: ConversionDto): Promise<{ groups: LobbyDataRes[] }> {
    return this.getGameAuthService(data.gameId)
      .handleLobby(data);
  }

  @Post('/videoStreamAuth')
  public videoStreamAuth(@Body() data: VideoStreamAuthDto): Promise<void> {
    return this.authService.videoStreamAuth(data.token);
  }

  @Post('/launchUrl/create')
  public createLaunchUrl(@Body() data: Record<string, any> & LaunchParams): Promise<UrlCreatorResp> {
    if (!Object.values(OperatorTag)
      .includes(data.operator)) {
      throw new NotFoundException('Operator not found');
    }
    const urlCreator: LaunchUrlCreator = this.moduleRef
      .get(urlCreatorTokenFactory(data.operator), { strict: false });
    return urlCreator.getLaunchUrl(data);
  }

  @Post('/launchGameValidation')
  public launchGameValidation(@Body() data: LaunchGameDto): Promise<any> {
    return this.authService.validateGameLaunch(data);
  }

  private getGameAuthService(gameId: GameId): GameAuthHandler {
    return this.moduleRef.get(gameProviderKeyFactory(gameId));
  }
}
