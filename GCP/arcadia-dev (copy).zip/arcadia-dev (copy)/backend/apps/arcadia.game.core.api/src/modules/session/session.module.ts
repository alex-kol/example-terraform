import { ChipRepository, SessionRepository } from '@lib/dal';
import { MonitoringWorkerClientModule } from '@lib/monitoring.worker.client';
import { Module } from '@nestjs/common';
import { RmqMessageLock } from '@lib/rmq.server/service.factory';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { PlayerRetentionService } from '../auth/player.retention.service';
import { SessionDataManagerModule } from '../session.data.manager/session.data.manager.module';
import { WorkerClientModule } from '../worker.client/worker.client.module';
import { SessionController } from './session.controller';
import { SessionService } from './session.service';
import { FINALIZE_SESSION_LOCK_INJECT_TOKEN, FINALIZE_SESSION_LOCK_PREFIX, FINALIZE_SESSION_LOCK_TTL } from './constants';

@Module({
  imports: [
    SessionDataManagerModule,
    MonitoringWorkerClientModule,
    WorkerClientModule,
  ],
  providers: [
    SessionService,
    SessionRepository,
    PlayerRetentionService,
    ChipRepository,
    {
      provide: FINALIZE_SESSION_LOCK_INJECT_TOKEN,
      useFactory: redis => new RmqMessageLock({
        ttlSec: FINALIZE_SESSION_LOCK_TTL,
        lockKeyPrefix: FINALIZE_SESSION_LOCK_PREFIX,
        redisCacheProvider: {
          provide: 'RMQ_CACHE',
          useFactory: cache => cache,
          inject: [RedisCacheService],
        },
        lockStrategy: session => session.id,
      }, redis),
      inject: [RedisCacheService],
    },
  ],
  controllers: [SessionController],
  exports: [SessionService],
})
export class SessionModule {
}
