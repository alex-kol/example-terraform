import {
  CommandType,
  EventSource,
  LoggerInterceptor,
  NewrelicAndMessagePattern,
  PlayerMessageType,
  RmqQueueName,
  rmqRoutingGenerate,
  RobotMessageType,
  RpcMainExceptionFilter,
  rpcValidationExceptionFactory,
} from '@lib/common';
import { EventType, GameId } from '@lib/dal';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import {
  Controller, UseFilters, UseInterceptors, UsePipes, ValidationPipe,
} from '@nestjs/common';
import { Payload } from '@nestjs/microservices';
import { CommandPublisher } from '../command/command.publisher';
import { PhaseEndCommand } from '../command/dto/phase.end.command';
import { RouletteEventCommand } from '../command/dto/roulette.event.command';
import { SessionAwareDto } from '../dto/session.aware.dto';
import { SessionInjectorPipe } from '../messaging/session.injector.pipe';
import { RouletteEventType } from './enums';
import { RouletteStateMachine } from './roulette.state.machine';
import {
  BetEvent, RouletteBetDto, RouletteResultDto, TableImageDto,
} from './types';

@Controller('v1/roulette')
@UseInterceptors(LoggerInterceptor)
@UseFilters(RpcMainExceptionFilter)
@UsePipes(new ValidationPipe({
  transform: true,
  whitelist: true,
  exceptionFactory: rpcValidationExceptionFactory,
}))
export class RouletteController {
  constructor(
    private readonly rouletteStateMachine: RouletteStateMachine,
    private readonly commandPublisher: CommandPublisher,
    private readonly monitoringService: MonitoringWorkerClientService,
  ) {
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.CORE_COMMAND_QUEUE, CommandType.PHASE_END, GameId.CLAW_ROULETTE))
  public async phaseEnd(@Payload() data: PhaseEndCommand): Promise<void> {
    await this.rouletteStateMachine.phaseEnd(data.serial, data.phase);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.CORE_COMMAND_QUEUE, CommandType.ROULETTE_EVENT, GameId.CLAW_ROULETTE))
  public eventHandler(@Payload() data: RouletteEventCommand): Promise<void> {
    return this.rouletteStateMachine.onEvent(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.RESULT, GameId.CLAW_ROULETTE))
  public async rouletteResult(@Payload() data: RouletteResultDto): Promise<void> {
    await this.rouletteStateMachine.onEvent({
      type: CommandType.ROULETTE_EVENT,
      eventType: RouletteEventType.ROUND_RESULT,
      serial: data.serial,
      data: { rfid: data.rfid },
    });
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.QUIT, GameId.CLAW_ROULETTE))
  public playerQuit(@Payload() data: SessionAwareDto): void {
    const {
      sessionId,
      session: { machine: { serial } },
    } = data;
    this.monitoringService.sendEventLogMessage({
      eventType: EventType.QUIT,
      source: EventSource.PLAYER,
      params: {
        sessionId,
        machineSerial: serial,
      },
    });
    this.commandPublisher.sendRouletteCommand<RouletteEventCommand<{ sessionId: number }>>({
      type: CommandType.ROULETTE_EVENT,
      eventType: RouletteEventType.PLAYER_QUIT,
      serial,
      data: { sessionId },
    });
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.PLACE_BET, GameId.CLAW_ROULETTE))
  public placeBet(@Payload() {
    sessionId,
    position,
    bet,
    session: {
      machine: { serial },
      configuration: { betLimits },
      currencyConversionRate,
    },
  }: RouletteBetDto): void {
    this.commandPublisher.sendRouletteCommand<RouletteEventCommand<BetEvent>>({
      type: CommandType.ROULETTE_EVENT,
      eventType: RouletteEventType.PLACE_BET,
      serial,
      data: {
        sessionId,
        bet: { [position]: [bet] },
        betLimits,
        currencyConversionRate,
      },
    });
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.REMOVE_BET, GameId.CLAW_ROULETTE))
  public removeBet(@Payload() {
    sessionId,
    session: {
      machine: { serial },
      currencyConversionRate,
    },
  }: SessionAwareDto): void {
    this.commandPublisher.sendRouletteCommand<RouletteEventCommand<BetEvent>>({
      type: CommandType.ROULETTE_EVENT,
      eventType: RouletteEventType.REMOVE_BET,
      serial,
      data: {
        sessionId,
        currencyConversionRate,
      },
    });
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.CANCEL_BET, GameId.CLAW_ROULETTE))
  public cancelBet(@Payload() {
    sessionId,
    session: {
      machine: { serial },
    },
  }: SessionAwareDto): void {
    this.commandPublisher.sendRouletteCommand<RouletteEventCommand<{ sessionId: number }>>({
      type: CommandType.ROULETTE_EVENT,
      eventType: RouletteEventType.CANCEL_BET,
      serial,
      data: { sessionId },
    });
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.PLAYER_TO_CORE_QUEUE, PlayerMessageType.DOUBLE_BET, GameId.CLAW_ROULETTE))
  public async doubleBet(@Payload() {
    sessionId,
    session: {
      machine: { serial },
      configuration: { betLimits },
      currencyConversionRate,
    },
  }: SessionAwareDto): Promise<void> {
    this.commandPublisher.sendRouletteCommand<RouletteEventCommand<BetEvent>>({
      type: CommandType.ROULETTE_EVENT,
      eventType: RouletteEventType.DOUBLE_BET,
      serial,
      data: {
        sessionId,
        betLimits,
        currencyConversionRate,
      },
    });
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.TABLE_IMAGE, GameId.CLAW_ROULETTE))
  public async tableImage(@Payload() data: TableImageDto): Promise<void> {
    const event: RouletteEventCommand<TableImageDto> = {
      type: CommandType.ROULETTE_EVENT,
      eventType: RouletteEventType.TABLE_IMAGE,
      serial: data.serial,
      data,
    };
    await this.rouletteStateMachine.onEvent(event);
  }
}
