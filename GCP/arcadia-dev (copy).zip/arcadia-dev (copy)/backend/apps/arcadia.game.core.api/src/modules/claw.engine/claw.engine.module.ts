import {
  BallRepository,
  GroupRepository,
  MachineRepository,
  PlayerRepository,
  QueueRepository,
  RngPhantomPrizeRepository,
  RoundArchiveRepository,
  RoundRepository,
  SessionRepository,
  VoucherRepository,
} from '@lib/dal';
import { MonitoringWorkerClientModule } from '@lib/monitoring.worker.client';
import { Module } from '@nestjs/common';
import { OperatorApiClientModule } from '../operator.api.client/operator.api.client.module';
import { QueueManagerModule } from '../queue.manager/queue.manager.module';
import { RobotClientModule } from '../robot.client/robot.client.module';
import { RoundModule } from '../round/round.module';
import { SessionDataManagerModule } from '../session.data.manager/session.data.manager.module';
import { SessionModule } from '../session/session.module';
import { WorkerClientModule } from '../worker.client/worker.client.module';
import { RobotMessageService } from './messaging/robot.handling/robot.message.service';
import { RobotMessageController } from './messaging/robot.handling/robot.message.controller';
import { PlayerRequestController } from './messaging/player.handling/player.request.controller';
import { BuyStacksClawHandler } from './messaging/player.handling/buy.stacks.сlaw.handler';
import { SessionInjectorPipe } from '../messaging/session.injector.pipe';
import { ConversionTrackerModule } from '../conversion.tracker/conversion.tracker.module';
import { PlayerClientModule } from '../player.client/player.client.module';
import { RobotRequestController } from './messaging/robot.handling/robot.request.controller';
import { ResultHandler } from './messaging/robot.handling/result.handler';
import { PlayerMessageService } from './messaging/player.handling/player.message.service';
import { PlayerMessageController } from './messaging/player.handling/player.message.controller';
import { RoundEndHandler } from './messaging/robot.handling/round.end.handler';
import { RngServiceClientModule } from '../rng.service.client/rng.service.client.module';
import { GroupTerminatorModule } from '../group.terminator/group.terminator.module';
import { ConfigValidatorModule } from '../config.validator/config.validator.module';

@Module({
  imports: [
    SessionModule,
    QueueManagerModule,
    OperatorApiClientModule,
    MonitoringWorkerClientModule,
    WorkerClientModule,
    RobotClientModule,
    RoundModule,
    SessionDataManagerModule,
    ConversionTrackerModule,
    PlayerClientModule,
    RngServiceClientModule,
    GroupTerminatorModule,
    ConfigValidatorModule,
  ],
  providers: [
    SessionInjectorPipe,
    RobotMessageService,
    SessionRepository,
    MachineRepository,
    QueueRepository,
    PlayerRepository,
    RoundRepository,
    RoundArchiveRepository,
    GroupRepository,
    VoucherRepository,
    BuyStacksClawHandler,
    ResultHandler,
    BallRepository,
    PlayerMessageService,
    RoundEndHandler,
    RngPhantomPrizeRepository,
  ],
  controllers: [
    RobotMessageController,
    PlayerRequestController,
    PlayerMessageController,
    RobotRequestController,
  ],
  exports: [],
})
export class ClawEngineModule {
}
