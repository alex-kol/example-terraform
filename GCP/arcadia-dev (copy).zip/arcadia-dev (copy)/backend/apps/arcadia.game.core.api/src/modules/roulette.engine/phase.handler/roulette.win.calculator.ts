import { RouletteField } from '@lib/dal';
import BigNumber from 'bignumber.js';
import { toCash } from '../../../util/toCash';
import { winMultiplierMap } from '../constants/win.multiplier.map';
import { winPositionTypeMap } from '../constants/win.position.type.map';
import { BetPosition, BetType } from '../enums';
import { RouletteBet } from '../types';

export type RoundResult = {
  winDetails: { position: BetPosition, type: BetType, winInValue: number, winInCash: number }[],
  totalWinInValue: number,
  totalWinInCash: number,
};

export function rouletteWinCalculator(bet: RouletteBet, result: RouletteField, conversionRate: number): RoundResult {
  const pattern = `\\b${result}\\b`;
  const roundResult = (Object.entries(bet) as [BetPosition, number[]][])
    .reduce((acc: {
      winDetails: { position: BetPosition, type: BetType, winInValue: number, winInCash: number }[],
      totalWinInValue: BigNumber,
      totalWinInCash: BigNumber,
    }, [position, bets]) => {
      if (!position.match(pattern)) {
        return acc;
      }
      const betAtPosition = bets.reduce((acc, bet) => acc.plus(bet), new BigNumber(0));
      const winInValue = betAtPosition.multipliedBy(winMultiplierMap[winPositionTypeMap[position]])
        .dp(2)
        .toNumber();
      const winInCash = toCash(winInValue, conversionRate);
      acc.winDetails.push({
        position,
        type: winPositionTypeMap[position],
        winInValue,
        winInCash,
      });
      acc.totalWinInValue = acc.totalWinInValue.plus(winInValue);
      acc.totalWinInCash = acc.totalWinInCash.plus(winInCash);
      return acc;
    }, {
      winDetails: [],
      totalWinInValue: new BigNumber(0),
      totalWinInCash: new BigNumber(0),
    });
  return {
    ...roundResult,
    totalWinInValue: roundResult.totalWinInValue.dp(2)
      .toNumber(),
    totalWinInCash: roundResult.totalWinInCash.dp(2)
      .toNumber(),
  };
}
