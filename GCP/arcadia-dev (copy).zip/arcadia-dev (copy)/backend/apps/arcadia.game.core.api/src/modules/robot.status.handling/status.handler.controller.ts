import {
  LoggerInterceptor,
  NewrelicAndMessagePattern,
  RmqQueueName,
  rmqRoutingGenerate,
  RobotMessageType,
  RpcMainExceptionFilter,
  rpcValidationExceptionFactory,
} from '@lib/common';
import { GameId } from '@lib/dal';
import {
  Controller, UseFilters, UseInterceptors, UsePipes, ValidationPipe,
} from '@nestjs/common';
import { Payload } from '@nestjs/microservices';
import { RobotStatusDto } from './dto/robot.status.dto';
import { StatusHandlerService } from './status.handler.service';

@Controller('v1/robots/status')
@UseInterceptors(LoggerInterceptor)
@UseFilters(RpcMainExceptionFilter)
@UsePipes(new ValidationPipe({
  transform: true,
  whitelist: true,
  exceptionFactory: rpcValidationExceptionFactory,
}))
export class StatusHandlerController {
  constructor(
    private readonly statusHandler: StatusHandlerService,
  ) {
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.STATUS, GameId.COMMON))
  async handleStatus(@Payload() data: RobotStatusDto): Promise<void> {
    await this.statusHandler.handleStatus(data.status.application, data.serial);
  }
}
