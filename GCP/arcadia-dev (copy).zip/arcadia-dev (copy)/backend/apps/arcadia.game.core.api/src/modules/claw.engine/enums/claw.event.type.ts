export enum ClawEventType {
  ROUND_RESULT = 'roundResult',
  PLAYER_QUIT = 'playerQuit',
  SOFT_STOP = 'softStop',
  HARD_STOP = 'hardStop',
  PLACE_BET = 'placeBet',
  REMOVE_BET = 'removeBet',
  CANCEL_BET = 'cancelBet',
  USER_JOIN = 'userJoin',
  REASSIGN = 'reassign',
  TABLE_IMAGE = 'tableImage',
}