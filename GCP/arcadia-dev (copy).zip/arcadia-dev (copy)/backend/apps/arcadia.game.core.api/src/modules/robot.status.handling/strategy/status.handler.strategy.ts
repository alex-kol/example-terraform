import { MachineEntity } from '@lib/dal';
import { RpcException } from '@nestjs/microservices';
import { Logger } from 'winston';
import { RobotReportedStatus } from '../robot.reported.status';

export abstract class StatusHandlerStrategy {
  protected constructor(protected readonly logger: Logger) {
  }

  public async onStopped(machine: MachineEntity): Promise<void> {
    this.throwUnexpectedStatus(RobotReportedStatus.STOPPED, machine);
  }

  public async onTesting(machine: MachineEntity): Promise<void> {
    this.throwUnexpectedStatus(RobotReportedStatus.TESTING, machine);
  }

  public async onStopping(machine: MachineEntity): Promise<void> {
    this.throwUnexpectedStatus(RobotReportedStatus.STOPPING, machine);
  }

  public async onIdle(machine: MachineEntity): Promise<void> {
    this.logger.debug('On idle status', { machineSerial: machine.serial });
  }

  public async onManualPlay(machine: MachineEntity): Promise<void> {
    this.logger.debug('On manual-play status', { machineSerial: machine.serial });
  }

  public async onAutoPlay(machine: MachineEntity): Promise<void> {
    this.logger.debug('On auto-play status', { machineSerial: machine.serial });
  }

  public async onSeeding(machine: MachineEntity): Promise<void> {
    this.throwUnexpectedStatus(RobotReportedStatus.SEEDING, machine);
  }

  public abstract toString(): string;

  protected throwUnexpectedStatus(status: RobotReportedStatus, machine: MachineEntity): never {
    throw new RpcException(`Unexpected status! Strategy: ${this.toString()}, status: ${status}, machineSerial: ${machine.serial}`);
  }
}
