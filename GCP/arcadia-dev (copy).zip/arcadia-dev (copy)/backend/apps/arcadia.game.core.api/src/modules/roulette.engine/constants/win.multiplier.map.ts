import { BetType } from '../enums';

export const winMultiplierMap: Record<BetType, number> = {
  [BetType.STRAIGHT]: 36,
  [BetType.SPLIT]: 18,
  [BetType.STREET]: 12,
  [BetType.BASKET]: 12,
  [BetType.CORNER]: 9,
  [BetType.FIRST_FOUR]: 9,
  [BetType.TOP_LINE]: 7,
  [BetType.SIX]: 6,
  [BetType.COLUMN]: 3,
  [BetType.DOZEN]: 3,
  [BetType.RED]: 2,
  [BetType.BLACK]: 2,
  [BetType.EVEN]: 2,
  [BetType.ODD]: 2,
  [BetType.HIGH]: 2,
  [BetType.LOW]: 2,
};
