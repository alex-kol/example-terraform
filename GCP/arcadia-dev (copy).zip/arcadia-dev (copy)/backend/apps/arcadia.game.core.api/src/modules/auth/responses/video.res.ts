import { VideoCropConfiguration } from '@lib/dal';
import { StreamResponse } from '@lib/video.api';

export class VideoRes {
  streams: StreamResponse[];
  streamAuthToken: string;
  cropConfig: VideoCropConfiguration;
}
