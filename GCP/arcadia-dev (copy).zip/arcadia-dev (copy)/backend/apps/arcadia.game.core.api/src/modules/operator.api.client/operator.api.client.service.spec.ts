import { HttpService } from '@nestjs/axios';
import { of } from 'rxjs';
import { OperatorApiClientService } from './operator.api.client.service';
import { makeTestModule } from './mocks/beforeAll.mock';
import { AuthData } from './dtos/auth.data';
import { BalanceData } from './dtos/balance.data';
import { dataToAxiosResponse } from '../../util/dataToAxiosResponse';

jest.mock('../logger/logger.service');

describe('Operator Api Client Service (Unit)', () => {
  let operatorApiClientService: OperatorApiClientService;
  let httpService: HttpService;

  beforeAll(
    async () => {
      const moduleFixture = await makeTestModule();
      operatorApiClientService = moduleFixture.get<OperatorApiClientService>(OperatorApiClientService);
      httpService = moduleFixture.get<HttpService>(HttpService);
    },
  );

  describe('authPlayer', () => {
    it('should return player data', async () => {
      const playerData: AuthData = {
        cid: '<cid>',
        playerToken: '<token>',
        name: '<name>',
        currencyCode: 'EUR',
        balance: 500,
      };
      const postSpy = jest.spyOn(httpService, 'post').mockReturnValue(of(dataToAxiosResponse(playerData)));
      const result = await operatorApiClientService.auth('<operatorConnector>', '<authToken>', '<corr>');
      expect(postSpy).toBeCalledWith('operator/<operatorConnector>/auth', { authToken: '<authToken>' },
          { headers: { correlation: '<corr>' } });
      expect(result).toMatchObject(playerData);
    });
  });

  describe('playerBalance', () => {
    it('should return player balance', async () => {
      const playerBalance: BalanceData = {
        balance: 322,
      };
      const getSpy = jest.spyOn(httpService, 'post').mockReturnValue(of(dataToAxiosResponse(playerBalance)));
      const balance = await operatorApiClientService.balance('<corr>', '<opId>', '<cid>', '<token>');
      expect(getSpy).toBeCalledWith('operator/<opId>/balance', {
        cid: '<cid>',
        sessionToken: '<token>',
      }, { headers: { correlation: '<corr>' } });
      expect(balance).toMatchObject(playerBalance);
    });
  });

  describe('bet', () => {
    it('should return bet data', async () => {
      const betData = {
        cid: '<cid>',
        wager: '<wager>',
        roundId: '<rId>',
        sessionToken: '<token>',
      };
      const postSpy = jest.spyOn(httpService, 'post').mockReturnValue(of(dataToAxiosResponse(betData)));
      const response = await operatorApiClientService.bet(
        '<connector>',
        '<cid>',
        50,
        '<token>',
        betData.roundId,
        '<corr>',
      );
      expect(postSpy).toBeCalledWith('operator/<connector>/bet', {
          isRetry: false,
          cid: '<cid>',
          amount: 50,
          roundId: betData.roundId,
          sessionToken: betData.sessionToken,
        },
        {
          headers: { correlation: '<corr>' },
        },
      );
      expect(response).toMatchObject(betData);
    });
  });

  describe('cancelBet', () => {
    it('should cancel bet', async () => {
      const responseData = {
        cid: '<cid>',
        status: '<status>',
      };
      const postSpy = jest.spyOn(httpService, 'post').mockReturnValue(of(dataToAxiosResponse(responseData)));
      const result = await operatorApiClientService
          .cancelBet('<opId>', '<cid>', 50, '<token>', '<rId>', '<tId>', '<corr>');
      expect(postSpy).toBeCalledWith('operator/<opId>/cancelBet', {
            cid: '<cid>',
            amount: 50,
            isRoundFinish: true,
            roundId: '<rId>',
            sessionToken: '<token>',
            transactionId: '<tId>',
            isRetry: false,
          },
          {
            headers: { correlation: '<corr>' },
          },
      );
      expect(result).toMatchObject(responseData);
    });
  });

  describe('payout', () => {
    it('should perform payout', async done => {
      const responseData = {
        cid: '<cid>',
        payout: 100,
      };
      const postSpy = jest.spyOn(httpService, 'post').mockReturnValue(of(dataToAxiosResponse(responseData)));
      const result = await operatorApiClientService
          .payout('<corr>', '<opId>', '<cid>', responseData.payout, '<token>', '<rId>', '<tId>');
      expect(postSpy).toBeCalledWith('operator/<opId>/payout', {
            cid: '<cid>',
            amount: responseData.payout,
            isRoundFinish: true,
            roundId: '<rId>',
            sessionToken: '<token>',
            transactionId: '<tId>',
            isRetry: false,
          },
          {
            headers: { correlation: '<corr>' },
          },
      );
      expect(result).toMatchObject(responseData);
      done();
    });
  });
});
