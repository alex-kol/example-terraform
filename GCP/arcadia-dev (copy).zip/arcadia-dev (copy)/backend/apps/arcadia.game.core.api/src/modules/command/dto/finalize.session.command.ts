import { SessionEndReason } from '@lib/dal';
import { IsBoolean, IsEnum, IsOptional } from 'class-validator';
import { BaseCommand } from './base.command';

export class FinalizeSessionCommand extends BaseCommand {
  @IsEnum(SessionEndReason)
  public reason: SessionEndReason;

  @IsOptional()
  @IsBoolean()
  public terminate?: boolean;

  @IsOptional()
  @IsBoolean()
  public showSessionResult?: boolean;
}
