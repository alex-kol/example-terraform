import { GameId } from '@lib/dal';

export const gameProviderKeyFactory = (gameId: GameId) => `${gameId}_AUTH_STRATEGY_INJECT_TOKEN`;
