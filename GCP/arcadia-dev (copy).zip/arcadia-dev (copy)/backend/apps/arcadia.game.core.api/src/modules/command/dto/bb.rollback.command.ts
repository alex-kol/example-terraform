import { SessionEndReason } from '@lib/dal';
import { IsEnum } from 'class-validator';
import { BaseCommand } from './base.command';

export class BbRollbackCommand extends BaseCommand {
  @IsEnum(SessionEndReason)
  public reason: SessionEndReason;
}
