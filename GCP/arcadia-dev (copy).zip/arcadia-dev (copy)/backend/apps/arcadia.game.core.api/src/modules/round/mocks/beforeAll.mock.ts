import { MAIN_LOGGER } from '@lib/logger';
import { Test } from '@nestjs/testing';
import {
  connectionNames,
  getRepositoryToken,
  PlayerRepository,
  RoundArchiveRepository,
  RoundRepository,
  SeedHistoryRepository,
  SessionRepository,
} from '@lib/dal';
import { repoMockFactory } from '../../../util/repoMockFactory';
import { CommandPublisher } from '../../command/command.publisher';
import { OperatorApiClientService } from "../../operator.api.client/operator.api.client.service";
import { PlayerClientService } from '../../player.client/player.client.service';
import { RngClientService } from '../../rng.service.client/rng.client.service';
import { RngHelper } from '../../rng.service.client/rng.helper';
import { SessionDataManager } from '../../session.data.manager/session.data.manager';
import { RoundServiceFactory } from '../round.service.factory';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';

export const repoMock =  repoMockFactory();
export async function makeTestModule() {
  const moduleFixture = await Test.createTestingModule({
    imports: [],
    providers: [
      RoundServiceFactory,
      RngHelper,
      {
        useValue: {},
        provide: PlayerClientService,
      },
      {
        useValue: {},
        provide: MAIN_LOGGER,
      },
      {
        useValue: {},
        provide: CommandPublisher,
      },
      {
        useValue: {},
        provide: MonitoringWorkerClientService,
      },
      {
        useValue: {},
        provide: SessionDataManager,
      },
      {
        useValue: {},
        provide: OperatorApiClientService,
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(SessionRepository, connectionNames.DATA),
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(PlayerRepository, connectionNames.DATA),
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(RoundRepository, connectionNames.DATA),
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(RoundArchiveRepository, connectionNames.DATA),
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(SeedHistoryRepository, connectionNames.DATA),
      },
      {
        useValue: { getCustomRepository: () => repoMock },
        provide: 'DATAEntityManager',
      },
      {
        useValue: {},
        provide: RngClientService,
      },
    ],
  }).compile();
  return moduleFixture;
}
