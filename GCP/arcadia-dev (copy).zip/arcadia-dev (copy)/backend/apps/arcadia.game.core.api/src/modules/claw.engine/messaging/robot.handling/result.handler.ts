/* eslint-disable max-lines */
import { AlertDescription, EventSource, TimeoutType } from '@lib/common';
import {
  AlertSeverity,
  AlertSource,
  AlertType,
  BallEntity,
  BallRepository,
  ClawPhase,
  EventType,
  MachineRepository,
  PlayerRepository,
  RngPhantomPrizeRepository,
  RoundEntity,
  RoundRepository,
  ShutdownReason,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Inject, Injectable, Scope } from '@nestjs/common';
import BigNumber from 'bignumber.js';
import { DataSource } from 'typeorm';
import { Logger } from 'winston';
import { from, lastValueFrom, of } from 'rxjs';
import {
  concatMap, repeat, take, toArray,
} from 'rxjs/operators';
import { SessionContextHandler } from '../../../command/session.context.handler';
import { ClawResultDto } from '../../types/claw.result.dto';
import { toCash } from '../../../../util';
import { PlayerClientService } from '../../../player.client/player.client.service';
import { GroupTerminatorService } from '../../../group.terminator/group.terminator.service';
import { RngClientService } from '../../../rng.service.client/rng.client.service';
import { WorkerClientService } from '../../../worker.client/worker.client.service';
import { ROUND_END_TTL_SEC } from '../../constants';
import { SessionDataManager } from '../../../session.data.manager/session.data.manager';

@Injectable({ scope: Scope.REQUEST })
export class ResultHandler extends SessionContextHandler<ClawResultDto> {
  // transactional repos
  private roundRepo: RoundRepository;
  private playerRepo: PlayerRepository;

  private rfid: string;
  private serial: string;
  private activeRound: RoundEntity;
  private ball: BallEntity;
  private isNoPickup: boolean;

  constructor(
    @Inject(MAIN_LOGGER) logger: Logger,
    private readonly playerClient: PlayerClientService,
    private readonly monitoringClient: MonitoringWorkerClientService,
    private readonly machineRepository: MachineRepository,
    private readonly ballRepository: BallRepository,
    private readonly groupTerminatorService: GroupTerminatorService,
    private readonly rngClientService: RngClientService,
    private readonly workerClientService: WorkerClientService,
    protected readonly sessionDataManager: SessionDataManager,
    private readonly rngPhantomPrizeRepository: RngPhantomPrizeRepository,
    dataSource: DataSource,
  ) {
    super(logger, dataSource);
  }

  protected async init(data: ClawResultDto): Promise<void> {
    await super.init(data);

    this.rfid = data.rfid;
    this.serial = data.serial;

    // transactional repos init
    this.roundRepo = new RoundRepository(this.entityManager);
    this.playerRepo = new PlayerRepository(this.entityManager);

    this.session = await this.sessionRepository.findOneOrFail({
      where: { id: this.sessionId },
      relations: ['rounds'],
    });
    this.isNoPickup = !data.rfid.length;
  }

  protected async handleEvent(): Promise<void> {
    const machine = await this.machineRepository.findOneOrFail({
      where: { serial: this.serial },
      relations: ['group', 'site'],
    });
    const ball = this.isNoPickup ? this.ballRepository.create(
      {
        rfid: this.rfid, label: 'np', machine, site: { id: machine.site.id },
      })
      : await this.ballRepository.findOne({
        where: { rfid: this.rfid },
        relations: ['machine', 'site'],
      });
    if (!ball || ball.machine.id !== machine.id || ball.site.id !== machine.site.id) {
      this.logger.warn('Invalid ball dropped', { ball });
      await this.monitoringClient.sendAlertMessage({
        alertType: AlertType.MAINTENANCE,
        source: AlertSource.GAME_CORE,
        severity: AlertSeverity.MEDIUM,
        description: AlertDescription.INVALID_BALL_DROPPED,
        gameId: machine.gameId,
        details: {
          sessionId: this.sessionId,
          rfid: ball?.rfid,
          label: ball?.label,
          machineId: machine.id,
          machineName: machine.name,
          machineSerial: machine.serial,
        },
      });
      await this.monitoringClient.sendEventLogMessage({
        eventType: EventType.ILLEGAL_BALL_DROP,
        source: EventSource.GAME,
        params: {
          sessionId: this.sessionId,
          round: this.activeRound?.id,
          groupId: this.cachedGroup.id,
          machineSerial: machine.serial,
          machineId: machine.id,
          operatorId: this.cachedOperator.id,
          rfid: this.rfid,
        },
      });
      await this.groupTerminatorService.groupHardStop(
        machine.gameId,
        machine.group.id,
        { reason: ShutdownReason.ILLEGAL_BALL_DROP, machineIds: [machine.id] },
      );
      return;
    }

    this.cachedMachine = machine;
    this.ball = ball;
    this.activeRound = this.session.getActiveRound();

    await this.monitoringClient.sendEventLogMessage({
      eventType: EventType.BALL_GRAB,
      source: EventSource.ROBOT,
      params: {
        rfid: ball.rfid,
        label: ball.label,
        round: this.activeRound?.id,
        sessionId: this.sessionId,
        machineSerial: this.cachedMachine.serial,
        playerCid: this.cachedPlayer.cid,
        groupId: this.cachedGroup.id,
        machineId: this.cachedMachine.id,
        operatorId: this.cachedOperator.id,
      },
    });

    if (!this.activeRound) {
      this.logger.warn('Ball grab out of active round', {
        sessionId: this.sessionId,
        rfid: this.ball.rfid,
      });
      return;
    }

    const prizeValue = await this.rngClientService.clawPhantom(
      this.cachedGroup.prizeGroup, this.session.configuration.rtpSegment, ball.label);

    const winInCash = toCash(new BigNumber(prizeValue).multipliedBy(this.cachedGroup.denominator), this.session.currencyConversionRate);
    await this.countWins(2, winInCash);
    const phantomWinValues = await this.getWheelData(
      this.cachedGroup.denominator,
      this.cachedGroup.prizeGroup,
      this.session.currencyConversionRate,
      this.ball,
    );
    await this.monitoringClient.sendEventLogMessage({
      eventType: EventType.PRIZE,
      source: EventSource.GAME,
      params: {
        sum: 2,
        sumInCash: winInCash,
        currency: this.session.currency,
        sessionId: this.sessionId,
        machineSerial: this.cachedMachine.serial,
        playerCid: this.cachedPlayer.cid,
      },
    });

    const winData: { currencyValue: number, phantomWinValues: number[], type: string } = {
      currencyValue: winInCash,
      phantomWinValues,
      type: ball.label,
    };

    this.playerClient.notifyWin(this.sessionId, winData);
    const totalWinInCash = new BigNumber(this.session.totalWinInCash).plus(winInCash)
      .dp(2)
      .toNumber();
    await this.playerClient.notifyTotalWin(this.sessionId, totalWinInCash);

    await this.workerClientService.timeoutStart({
      timeoutType: TimeoutType.ROUND_END_DELAY,
      sessionId: this.sessionId,
      timeoutSec: ROUND_END_TTL_SEC,
      payload: { gameId: this.cachedMachine.gameId },
    }, this.correlationId);

    await this.workerClientService.timeoutStop({
      timeoutType: TimeoutType.WAITING_RESULT,
      sessionId: this.sessionId,
      payload: { gameId: this.cachedMachine.gameId },
    }, this.correlationId);

    await this.sessionDataManager.updateSessionData({ clawPhase: ClawPhase.STARTING_ROUND }, this.sessionId);
  }

  private async countWins(winInValue: number, winInCash: number) {
    await this.sessionRepository.countWin(this.cachedSession.id, winInValue, winInCash);
    await this.roundRepo.countWin(this.activeRound.id, winInValue, winInCash);
    await this.playerRepo.countWin(this.cachedPlayer.cid, this.cachedOperator.id, winInValue);
  }

  private async getWheelData(
    denominator: number,
    prizeGroup: string,
    currencyConvRate: number,
    ball: BallEntity,
    wheelSize = 30,
  ): Promise<number[]> {
    const phantomPrizes = await this.rngPhantomPrizeRepository.getPhantomPrizes(prizeGroup, ball.label);

    if (!phantomPrizes?.length) {
      return [];
    }
    const prizes: { prizeValue: number; probability: number; }[] = phantomPrizes
      .map(value => ({
        prizeValue: toCash(new BigNumber(value.prize_value).multipliedBy(denominator)
          .dp(2), currencyConvRate),
        probability: Number(value.probability),
      }))
      .sort((a, b) => a.probability - b.probability);
    const result = await lastValueFrom(from(prizes)
      .pipe(
        concatMap(prize => {
          const quantity = Math.round(prize.probability * wheelSize) || 1;
          return of(prize.prizeValue)
            .pipe(repeat(quantity));
        }),
        take(wheelSize),
        toArray(),
      ));
    while (result.length < wheelSize) {
      result.push(result[result.length - 1]);
    }
    return result;
  }
}
