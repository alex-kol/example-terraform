import {
  CoreWorkerMessageType,
  LoggerInterceptor,
  NewrelicAndMessagePattern,
  RmqQueueName,
  rmqRoutingGenerate,
  RpcMainExceptionFilter,
  rpcValidationExceptionFactory,
  TimeoutOptions,
} from '@lib/common';
import { GameId } from '@lib/dal';
import {
  Controller, UseFilters, UseInterceptors, UsePipes, ValidationPipe,
} from '@nestjs/common';
import { Payload } from '@nestjs/microservices';
import { RobotMessage } from '../messaging/robot.handling/dto';
import { SessionInjectorPipe } from '../messaging/session.injector.pipe';
import { QueueChangeOfferDto } from '../worker.client/dto';
import { WorkerMessageService } from './worker.message.service';

@Controller('/v1/worker')
@UseInterceptors(LoggerInterceptor)
@UseFilters(RpcMainExceptionFilter)
@UsePipes(new ValidationPipe({
  transform: true,
  whitelist: true,
  exceptionFactory: rpcValidationExceptionFactory,
}))
export class WorkerController {
  constructor(
    private readonly workerMessageService: WorkerMessageService,
  ) {
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.WORKER_TO_CORE_QUEUE, CoreWorkerMessageType.TIMEOUT_EXPIRED, GameId.COMMON))
  public async timeoutExpired(@Payload() data: TimeoutOptions): Promise<void> {
    await this.workerMessageService.timeoutExpired(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.WORKER_TO_CORE_QUEUE, CoreWorkerMessageType.PING_OUTDATED, GameId.COMMON))
  async pingOutdatedHandler(@Payload() data: RobotMessage): Promise<void> {
    await this.workerMessageService.handlePingOutdated(data.serial, data.correlationId);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.WORKER_TO_CORE_QUEUE, CoreWorkerMessageType.QUEUE_CHANGE_OFFERS, GameId.COIN_PUSHER_V1))
  public async queueChangeOffersHandler(@Payload() data: QueueChangeOfferDto): Promise<void> {
    await this.workerMessageService.handleQueueChangeOffer(data);
  }
}
