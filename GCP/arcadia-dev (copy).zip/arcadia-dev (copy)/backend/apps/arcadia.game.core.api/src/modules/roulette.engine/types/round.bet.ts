import { RouletteBet } from './roulette.bet';

export interface RoundBet {
  bet: RouletteBet;
  history: RouletteBet[];
}
