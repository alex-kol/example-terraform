import { PlayerId } from '@lib/dal';

export function conversionTrackingKeyFactory(player: PlayerId): string {
  return `conversion-tracker-${player.cid}-${player.operatorId}`;
}