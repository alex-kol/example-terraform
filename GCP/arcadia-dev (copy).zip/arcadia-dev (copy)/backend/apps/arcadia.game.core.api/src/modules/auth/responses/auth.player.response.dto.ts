import { GameId, LobbyConfiguration } from '@lib/dal';
import { ApiProperty, ApiResponseProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { AssetResponse } from './asset.response';
import { PlayerSettingsDto } from '../../messaging/player.handling/dto/player.settings.dto';

export class AuthResponseDto {
  @ApiResponseProperty()
  public url: string;

  @ApiResponseProperty()
  public token: string;

  @ApiResponseProperty()
  public currency: string;

  @ApiResponseProperty()
  public playerId: string;

  @ApiResponseProperty()
  @Type(() => PlayerSettingsDto)
  public settings: PlayerSettingsDto;

  @ApiResponseProperty()
  public gameId: GameId;

  @ApiResponseProperty()
  public homeUrl?: string;

  @ApiResponseProperty()
  public cashierUrl?: string;

  @ApiProperty({
    isArray: true,
    type: AssetResponse,
  })
  public assets?: AssetResponse[];

  @ApiProperty({
    isArray: true,
    type: LobbyConfiguration,
  })
  public lobbyConfiguration?: LobbyConfiguration;

  @ApiProperty()
  public sessionId?: number;

  @ApiProperty()
  public footprint?: string;
}
