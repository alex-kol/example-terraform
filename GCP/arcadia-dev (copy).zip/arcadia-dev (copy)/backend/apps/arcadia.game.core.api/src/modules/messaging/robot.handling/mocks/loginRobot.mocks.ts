export const loginRobotMachineMock = {
  id: 1,
  serial: '<serial>',
};

export function shouldReturnLoginData(spyTargets: any): void {
  jest.spyOn(spyTargets.machineRepository, 'findOneOrFail').mockResolvedValue(loginRobotMachineMock);
  jest.spyOn(spyTargets.queueRepository, 'getFreeQueue').mockResolvedValue({ id: 42 });
  jest.spyOn(spyTargets.configService, 'getRabbitMQConfig').mockReturnValue('<user>:<password>@<host>:<port>');
  jest.spyOn(spyTargets.configService, 'getRedisConfig').mockReturnValue({});
}