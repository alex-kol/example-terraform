import { GameId } from '@lib/dal';

export function gameStateKeyFactory(serial: string): string {
  return `${GameId.CLAW_ROULETTE}-${serial}-game-state-key`;
}