import { CommandType, EventSource } from '@lib/common';
import {
  BallRepository,
  EventType,
  GameId,
  GroupEntity,
  MachineEntity,
  MachineRepository,
  MachineStatus,
  RouletteField,
  RouletteType,
} from '@lib/dal';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Injectable, NotAcceptableException } from '@nestjs/common';
import { CommandPublisher } from '../../command/command.publisher';
import { RouletteEventCommand } from '../../command/dto/roulette.event.command';
import { ConfigValidator } from '../../config.validator/config.validator';
import { GroupTerminatorService } from '../../group.terminator/group.terminator.service';
import { CoreMessage } from '../../messaging/robot.handling/enum/core.message';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { CoreToRobotMessage } from '../../robot.client/robot.interface';
import { RouletteEventType } from '../../roulette.engine/enums';
import { GroupStopDto, MachineStartDto } from '../dto';
import { BoHandlerStrategy } from './bo.handler.strategy';

@Injectable()
export class ClawRouletteBoHandlerStrategy extends BoHandlerStrategy {
  constructor(
    private readonly machineRepo: MachineRepository,
    private readonly ballRepository: BallRepository,
    private readonly monitoringWorkerClient: MonitoringWorkerClientService,
    private readonly robotClient: RobotClientService,
    private readonly configValidator: ConfigValidator,
    private readonly groupTerminator: GroupTerminatorService,
    private readonly commandPublisher: CommandPublisher,
  ) {
    super();
  }

  public async machineReassign(machine: MachineEntity, toGroup: GroupEntity): Promise<void> {
    await this.machineRepo.update(machine.id, { reassignTo: toGroup.id });
    await this.commandPublisher.sendRouletteCommand<RouletteEventCommand>(
      {
        type: CommandType.ROULETTE_EVENT,
        serial: machine.serial,
        eventType: RouletteEventType.REASSIGN,
      },
    );
  }

  public async groupSoftStopHandler(groupId: number, machineIds?: number[], correlationId?: string): Promise<void> {
    await this.groupTerminator.groupSoftStop(GameId.CLAW_ROULETTE, groupId, machineIds, correlationId);
  }

  public async machineStartHandler(machine: MachineEntity, group: GroupEntity, params: MachineStartDto): Promise<void> {
    if (machine.cameras.length !== 1) {
      throw new NotAcceptableException('Camera is not assigned');
    }

    const config = await this.configValidator.getValidatedConfig(machine.serial);

    const runMessage: CoreToRobotMessage = {
      action: CoreMessage.RUN,
      clearTable: params.resetTableState,
      resetDispensers: params.resetDispensers,
      ballCount: config.rouletteType === RouletteType.AMERICAN ? 38 : 37,
    };

    await this.validateRouletteBalls(machine);

    await this.machineRepo.update(machine.id,
      {
        status: MachineStatus.STOPPED,
        shutdownReason: null,
        startedDate: new Date(),
      });
    const { action, ...paramsForEvent } = runMessage;
    this.monitoringWorkerClient.sendEventLogMessage({
      eventType: EventType.RUN,
      source: EventSource.GAME,
      params: {
        machineId: machine.id,
        machineSerial: machine.serial,
        groupId: group.id,
        ...paramsForEvent,
      },
    });
    this.robotClient.sendRobotMessage(runMessage, machine.serial);
  }

  public async groupHardStopHandler(groupId: number, data: GroupStopDto, correlationId?: string): Promise<void> {
    await this.groupTerminator.groupHardStop(GameId.CLAW_ROULETTE, groupId, data, correlationId);
  }

  private async validateRouletteBalls(machine: MachineEntity): Promise<void> {
    const config = await this.configValidator.getValidatedConfig(machine.serial);
    const { rouletteType } = config;
    const validLabels = new Set<string>(Object.values(RouletteField));

    if (rouletteType !== RouletteType.AMERICAN) {
      validLabels.delete(RouletteField.FIELD_00);
    }

    const assignedBalls = await this.ballRepository.findBy({
      machine: { id: machine.id },
      site: { id: machine.site.id },
      gameId: machine.gameId,
    });
    assignedBalls.forEach(ball => validLabels.delete(ball.label));

    if (validLabels.size) {
      throw new NotAcceptableException('Machine hasn\'t valid ball count with unique labels');
    }
  }
}
