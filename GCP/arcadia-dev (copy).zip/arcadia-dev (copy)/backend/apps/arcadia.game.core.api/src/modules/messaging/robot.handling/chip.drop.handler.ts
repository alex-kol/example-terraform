/* eslint-disable max-lines */
import {
  AlertDescription, CommandType, EventSource, RmqQueueName, RobotMessageType, TimeoutOptions, TimeoutType,
} from '@lib/common';
import { ConfigService } from '@lib/config';
import {
  AlertAction,
  AlertSeverity,
  AlertSource,
  AlertType,
  ChipEntity,
  ChipRepository,
  EventType,
  GameId,
  MachineRepository,
  PlayerRepository,
  RngChipPrizeRepository,
  RoundEntity,
  RoundRepository,
  SessionStatus,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { ServerRMQ } from '@lib/rmq.server';
import { Inject, Injectable, Scope } from '@nestjs/common';
import BigNumber from 'bignumber.js';
import moment from 'moment';
import { count, firstValueFrom, from } from 'rxjs';
import { concatMap } from 'rxjs/operators';
import { DataSource } from 'typeorm';
import { Logger } from 'winston';
import { PHANTOM_CHIP_TYPE_NAME } from '../../../constants/phantom.type';
import { toCash } from '../../../util';
import { CommandPublisher } from '../../command/command.publisher';
import { BetBehindWinCommand } from '../../command/dto/bet.behind.win.command';
import { SessionContextHandler } from '../../command/session.context.handler';
import { PlayerClientService } from '../../player.client/player.client.service';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { SessionDataManager } from '../../session.data.manager/session.data.manager';
import { WorkerClientService } from '../../worker.client/worker.client.service';
import { AutoplayStatus } from '../player.handling/enum/autoplay.status';
import { ChipMessageInterface, PhantomMessageInterface } from '../player.handling/interfaces';
import { RobotChipDropDto } from './dto';
import { CoreMessage } from './enum/core.message';

@Injectable({ scope: Scope.REQUEST })
export class ChipDropHandler extends SessionContextHandler<RobotChipDropDto> {
  // transactional repos
  private roundRepo: RoundRepository;
  private chipRepo: ChipRepository;
  private playerRepo: PlayerRepository;

  private rfid: string;
  private serial: string;
  private duration: number;
  private gameId: GameId;
  private chip: ChipEntity;
  private activeRound: RoundEntity;
  private readonly roundEndDelaySec: number;
  private bbSessions: number[];
  private readonly chipsDropAlertLimit: number;
  private readonly phantomWidgetAnimationDurationSec: number;
  private readonly bigWinAnimationDelay = 3;

  constructor(
    @Inject(MAIN_LOGGER) logger: Logger,
    private readonly config: ConfigService,
    private readonly robotClient: RobotClientService,
    private readonly playerClient: PlayerClientService,
    private readonly monitoringClient: MonitoringWorkerClientService,
    private readonly workerClient: WorkerClientService,
    private readonly machineRepo: MachineRepository,
    private readonly prizeRepo: RngChipPrizeRepository,
    private readonly commandPublisher: CommandPublisher,
    private readonly sessionDataManager: SessionDataManager,
    private readonly serverRMQ: ServerRMQ,
    dataSource: DataSource,
  ) {
    super(logger, dataSource);
    this.roundEndDelaySec = Number(this.config.get(['core', 'ROUND_END_DELAY_SECONDS']));
    this.chipsDropAlertLimit = Number(this.config.get(['core', 'CHIPS_DROP_ALERT_LIMIT']));
    this.phantomWidgetAnimationDurationSec = Number(this.config.get(['core', 'PHANTOM_WIDGET_ANIMATION_DURATION_MS'])) / 1000;
  }

  protected async init(data: RobotChipDropDto): Promise<void> {
    await super.init(data);

    // message payload
    this.rfid = data.rfid;
    this.serial = data.serial;
    this.duration = data.duration;
    this.gameId = data.gameId;

    // transactional repos init
    this.roundRepo = new RoundRepository(this.entityManager);
    this.chipRepo = new ChipRepository(this.entityManager);
    this.playerRepo = new PlayerRepository(this.entityManager);

    this.session = await this.sessionRepository.findOneOrFail({
      where: { id: this.sessionId },
      relations: ['rounds'],
    });
  }

  protected async handleEvent(): Promise<void> {
    const [machine, chip] = await Promise.all([
      this.machineRepo.findOneOrFail({
        where: { serial: this.serial },
        relations: ['group', 'site'],
      }),
      this.chipRepo.findOne({
        where: { rfid: this.rfid },
        relations: ['type', 'machine', 'site'],
      }),
    ]);
    await this.machineRepo.incrementChipDropCount(machine.id);
    if (!chip) {
      this.logger.warn('Chip not found', { rfid: this.rfid });
      await this.monitoringClient.sendAlertMessage({
        alertType: AlertType.MAINTENANCE,
        severity: AlertSeverity.MEDIUM,
        source: AlertSource.GAME_CORE,
        description: AlertDescription.UNKNOWN_CHIP_DROPPED,
        gameId: machine.gameId,
        details: {
          rfid: this.rfid,
          machineId: machine.id,
          machineName: machine.name,
          machineSerial: machine.serial,
        },
      });
      return;
    }

    this.cachedMachine = machine;
    this.chip = chip;
    this.activeRound = this.session.getActiveRound();

    if (this.rescheduleCheck()) {
      this.logger.debug('Rescheduling drop', {
        sessionId: this.sessionId,
        rfid: this.rfid,
      });
      await this.rescheduleDrop();
      return;
    }

    await this.unregisterChip();

    if (!await this.validateChipDrop()) {
      this.logger.warn('Invalid chip dropped', { chip });
      await this.monitoringClient.sendAlertMessage({
        alertType: AlertType.MAINTENANCE,
        source: AlertSource.GAME_CORE,
        severity: AlertSeverity.MEDIUM,
        description: AlertDescription.INVALID_CHIP_DROPPED,
        gameId: machine.gameId,
        details: {
          sessionId: this.sessionId,
          rfid: chip.rfid,
          chipType: chip.type.name,
          machineId: machine.id,
          machineName: machine.name,
          machineSerial: machine.serial,
        },
      });
      await this.monitoringClient.sendEventLogMessage({
        eventType: EventType.ILLEGAL_CHIP_DROP,
        source: EventSource.GAME,
        params: {
          sessionId: this.sessionId,
          round: this.activeRound?.id,
          groupId: this.cachedGroup.id,
          machineSerial: machine.serial,
          machineId: machine.id,
          operatorId: this.cachedOperator.id,
          duration: this.duration,
          rfid: this.rfid,
        },
      });
      return;
    }

    await this.monitoringClient.sendEventLogMessage({
      eventType: EventType.CHIP_DROP,
      source: EventSource.ROBOT,
      params: {
        rfid: chip.rfid,
        type: chip.type.name,
        value: chip.value,
        isScatter: chip.isScatter,
        round: this.activeRound?.id,
        sessionId: this.session.id,
        machineSerial: this.cachedMachine.serial,
        playerCid: this.cachedPlayer.cid,
        groupId: this.cachedGroup.id,
        machineId: this.cachedMachine.id,
        operatorId: this.cachedOperator.id,
        duration: this.duration,
      },
    });

    if (!this.activeRound) {
      this.logger.warn('Chip drop out of active round', {
        sessionId: this.session.id,
        rfid: this.chip.rfid,
      });
      return;
    }

    await this.resetRoundEndDelay();

    this.bbSessions = await this.sessionRepository
      .getBetBehindersFromQueue(this.cachedSession.queue.id, true);

    await this.phantomChipDropHandler();

    if (this.isCountWin()) {
      const winInCash = toCash(this.chip.value, this.session.currencyConversionRate);
      await this.autoplayWinLimitCheck(winInCash);
      await this.countWins(this.chip.value, winInCash);
      await this.monitoringClient.sendEventLogMessage({
        eventType: EventType.PRIZE,
        source: EventSource.GAME,
        params: {
          sum: this.chip.value,
          sumInCash: winInCash,
          currency: this.session.currency,
          sessionId: this.session.id,
          machineSerial: this.cachedMachine.serial,
          playerCid: this.cachedPlayer.cid,
        },
      });
      const winData: ChipMessageInterface = {
        currencyValue: winInCash,
        type: this.chip.type.name,
      };
      this.robotClient.sendRobotMessage(
        { action: CoreMessage.PRIZE, ...winData },
        this.cachedMachine.serial,
      );
      this.playerClient.notifyWin(this.session.id, winData);
      const totalWinInCash = new BigNumber(this.session.totalWinInCash).plus(winInCash)
        .dp(2)
        .toNumber();
      await this.playerClient.notifyTotalWin(this.session.id, totalWinInCash);
      await this.notifyBbWins();
    }

    if (machine.chipsDropCount > this.chipsDropAlertLimit) {
      await this.monitoringClient.sendAlertMessage({
        alertType: AlertType.MAINTENANCE,
        source: AlertSource.GAME_CORE,
        severity: AlertSeverity.MEDIUM,
        description: AlertDescription.CHIP_DRAWER_IS_FULL,
        action: AlertAction.EMPTY_DISPENSER_WAIST,
        gameId: machine.gameId,
        details: {
          machineId: machine.id,
          machineName: machine.name,
          machineSerial: machine.serial,
        },
      });
    }
  }

  private async resetRoundEndDelay(): Promise<void> {
    const options: TimeoutOptions = {
      timeoutType: TimeoutType.ROUND_END_DELAY,
      sessionId: this.sessionId,
      timeoutSec: this.roundEndDelaySec,
      payload: { gameId: this.session.gameId },
    };

    if (this.chip.type.name === PHANTOM_CHIP_TYPE_NAME) {
      options.timeoutSec += this.phantomWidgetAnimationDurationSec;
      if (this.isPhantomValueChip() && this.isBigWin()) {
        options.timeoutSec += this.bigWinAnimationDelay;
      }
    }

    const existingRoundEndDelayTimeout = await this.workerClient.getTimeoutExpiration(options);
    if (existingRoundEndDelayTimeout) {
      const remainingSec = existingRoundEndDelayTimeout.diff(moment(), 'second');
      options.timeoutSec = remainingSec > 0 ? remainingSec + options.timeoutSec : options.timeoutSec;
      await this.workerClient.timeoutStart(options, this.correlationId);
      return;
    }

    const existingAnimationTimeout = await this.workerClient.getTimeoutExpiration({
      timeoutType: TimeoutType.ANIMATION_IN_QUEUE,
      sessionId: this.sessionId,
    });
    if (existingAnimationTimeout) {
      options.timeoutSec += existingAnimationTimeout.diff(moment(), 'second');
    }

    if (this.activeRound.coins === 0 && this.session.roundsLeft === 0) {
      existingAnimationTimeout && await this.workerClient.timeoutStop({
        timeoutType: TimeoutType.ANIMATION_IN_QUEUE,
        sessionId: this.sessionId,
        payload: { gameId: this.session.gameId },
      });
      await this.workerClient.timeoutStart(options, this.correlationId);
    } else {
      options.timeoutType = TimeoutType.ANIMATION_IN_QUEUE;
      await this.workerClient.timeoutStart(options, this.correlationId);
    }
  }

  private async notifyBbWins(): Promise<void> {
    this.bbSessions.forEach(sessionId => this.commandPublisher.sendCommand<BetBehindWinCommand>({
      type: CommandType.BET_BEHIND_WIN,
      gameId: GameId.COIN_PUSHER_V1,
      sessionId,
      chip: this.chip,
      chipType: this.chip.type,
    }, this.correlationId));
  }

  private async countWins(winInValue: number, winInCash: number) {
    await this.sessionRepository.countWin(this.cachedSession.id, winInValue, winInCash);
    await this.roundRepo.countWin(this.activeRound.id, winInValue, winInCash);
    await this.playerRepo.countWin(this.cachedPlayer.cid, this.cachedOperator.id, winInValue);
  }

  private isCountWin(): boolean {
    return this.chip.value > 0 && !this.chip.isScatter;
  }

  private async unregisterChip() {
    await this.chipRepo.update(this.chip.rfid,
      {
        machine: null,
        isScatter: false,
        value: 0,
      });
  }

  private async validateChipDrop(): Promise<boolean> {
    const prize = await this.prizeRepo.getChipPrize(
      this.cachedGroup.prizeGroup,
      this.chip.type.id,
      this.session.configuration.rtpSegment,
    );
    return prize
      && this.chip.machine?.id === this.cachedMachine.id
      && this.chip.site.id === this.cachedMachine.site.id;
  }

  private async phantomChipDropHandler(): Promise<void> {
    if (this.chip.type.name !== PHANTOM_CHIP_TYPE_NAME) {
      return;
    }
    let phantomMessage: PhantomMessageInterface;
    let timeoutIncrement = 5;
    if (this.isPhantomValueChip()) {
      if (this.isBigWin()) {
        timeoutIncrement += this.bigWinAnimationDelay;
      }
      timeoutIncrement += this.phantomWidgetAnimationDurationSec;
      const winInCash = toCash(this.chip.value, this.session.currencyConversionRate);
      phantomMessage = { value: winInCash };
      await this.monitoringClient.sendEventLogMessage({
        eventType: EventType.PHANTOM_PAYOUT,
        source: EventSource.GAME,
        params: {
          sum: this.chip.value,
          sumInCash: winInCash,
          currency: this.session.currency,
          sessionId: this.session.id,
          machineSerial: this.cachedMachine.serial,
          machineId: this.cachedMachine.id,
          groupId: this.cachedGroup.id,
          operatorId: this.cachedOperator.id,
          round: this.activeRound.id,
        },
      });
    } else {
      timeoutIncrement += 2;
      await this.sessionRepository.registerScatter(this.session.id);
      this.session.pendingScatter += 1;
      await this.registerBbScatter();
      phantomMessage = { value: -1 };
    }
    this.playerClient.notifyPhantom(this.session.id, phantomMessage);
    this.bbSessions
      .forEach(sessionId => this.playerClient.notifyPhantom(sessionId, phantomMessage));

    if (this.session.status !== SessionStatus.FORCED_AUTOPLAY) {
      await this.workerClient.timeoutIncrement({
        timeoutType: TimeoutType.IDLE,
        sessionId: this.sessionId,
        timeoutSec: timeoutIncrement,
        payload: { gameId: this.session.gameId },
      },
      this.correlationId,
      options => this.playerClient.setCountdown(this.sessionId, options.timeoutSec),
      );
    }
  }

  private async registerBbScatter(): Promise<void> {
    await firstValueFrom(from(this.bbSessions)
      .pipe(
        concatMap(async id => {
          const { betBehind } = await this.sessionDataManager.getSessionData(id);
          if (betBehind) {
            await this.sessionRepository.increment({ id }, 'pendingScatter', 1);
            betBehind.stopAfterRounds += 1;
            await this.sessionDataManager.updateSessionData({ betBehind }, id);
          }
          return id;
        }),
        count(),
      ));
  }

  private isPhantomValueChip(): boolean {
    return this.chip.type.name === PHANTOM_CHIP_TYPE_NAME
      && !this.chip.isScatter
      && this.chip.value > 0;
  }

  private async autoplayWinLimitCheck(winInCash: number) {
    const { autoplay } = await this.sessionDataManager.getSessionData(this.session.id);
    if (this.session.status !== SessionStatus.AUTOPLAY || !autoplay) {
      return;
    }
    const threshold = new BigNumber(toCash(this.session.denominator, this.session.currencyConversionRate))
      .multipliedBy(autoplay.singleWinThreshold)
      .dp(2);
    if (threshold.isLessThan(winInCash)) {
      await this.disableAutoplay('Win amount is over threshold');
    }
  }

  private async disableAutoplay(reason: string) {
    await this.monitoringClient.sendEventLogMessage({
      eventType: EventType.STOP_AUTO_MODE,
      source: EventSource.GAME,
      params: {
        sessionId: this.session.id,
        machineSerial: this.cachedMachine.serial,
        playerCid: this.cachedPlayer.cid,
        reason,
      },
    });
    this.playerClient
      .notifyAutoplay(this.session.id, { status: AutoplayStatus.FORCED_DISABLE });
    await this.robotClient.sendStopAutoplayMessage(this.cachedMachine.serial, this.session.id);

    await this.sessionRepository.update(
      this.session.id,
      { status: SessionStatus.PLAYING },
      data => this.playerClient.sessionState(this.session.id, { status: data.status }),
    );
    await this.sessionDataManager.removeSessionData(['autoplay'], this.session.id);
  }

  private rescheduleCheck(): boolean {
    const isPlaying = this.session.status === SessionStatus.PLAYING
      || this.session.status === SessionStatus.AUTOPLAY
      || this.session.status === SessionStatus.FORCED_AUTOPLAY;

    return isPlaying && !this.activeRound && this.session.roundsLeft > 0;
  }

  private rescheduleDrop(): void {
    const payload: RobotChipDropDto = {
      type: RobotMessageType.CHIP_DROP,
      serial: this.cachedMachine.serial,
      gameId: this.gameId,
      sessionId: this.sessionId,
      rfid: this.rfid,
      duration: this.duration,
      correlationId: this.correlationId,
    };
    this.serverRMQ.sendMessage(payload, RmqQueueName.ROBOT_TO_CORE_QUEUE);
  }

  private isBigWin(): boolean {
    return Boolean(this.sessionConfig.bigWinThreshold)
      && this.sessionConfig.bigWinThreshold <= this.chip.value;
  }
}
