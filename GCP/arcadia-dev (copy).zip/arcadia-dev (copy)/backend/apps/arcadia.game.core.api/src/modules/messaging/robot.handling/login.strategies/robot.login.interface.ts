import { MachineEntity } from '@lib/dal';
import { RobotLoginDto } from '../dto/robot.login.dto';
import { RobotLoginRes } from '../responses/robot.login.res';

export abstract class RobotLoginInterface {
  abstract loginRobot(machine: MachineEntity, loginData: RobotLoginDto): Promise<RobotLoginRes>;
}