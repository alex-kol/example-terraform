import { ApiProperty } from '@nestjs/swagger';

export class VideoApiCredResp {
  @ApiProperty()
  public baseUrl: string;

  @ApiProperty()
  public token: string;
}
