import { ChipEntity, ChipTypeEntity } from '@lib/dal';
import { IsDefined } from 'class-validator';
import { BaseCommand } from './base.command';

export class BetBehindWinCommand extends BaseCommand {
  @IsDefined()
  public chip: ChipEntity;

  @IsDefined()
  public chipType: ChipTypeEntity;
}
