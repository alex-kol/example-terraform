/* eslint-disable max-lines */
import { CommandType, TimeoutType } from '@lib/common';
import {
  GameId,
  GroupRepository,
  GroupStatus,
  MachineEntity,
  MachineRepository,
  MachineStatus,
  QueueEntity,
  QueueRepository,
  QueueStatus,
  SeedHistoryRepository,
  SessionEndReason,
  SessionEntity,
  ShutdownReason,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { Inject, Injectable } from '@nestjs/common';
import { Logger } from 'winston';
import {
  concatMap, filter, from, lastValueFrom,
} from 'rxjs';
import { GroupStopDto } from '../../bo.handler/dto';
import { CommandPublisher } from '../../command/command.publisher';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { WorkerClientService } from '../../worker.client/worker.client.service';
import { GroupTerminator } from './group.terminator';
import { ChipWatcherService } from '../../chip.watcher/chip.watcher.service';

@Injectable()
export class CoinPusherV1GroupTerminator extends GroupTerminator {
  constructor(
    private readonly machineRepository: MachineRepository,
    private readonly queueRepository: QueueRepository,
    private readonly groupRepository: GroupRepository,
    private readonly seedHistoryRepository: SeedHistoryRepository,
    private readonly robotClient: RobotClientService,
    private readonly workerClient: WorkerClientService,
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly commandPublisher: CommandPublisher,
    private readonly chipWatcherService : ChipWatcherService,
  ) {
    super();
  }

  public async groupSoftStop(
    groupId: number, machineIds?: number[], correlationId?: string,
  ): Promise<void> {
    const wholeGroup = !machineIds?.length;
    const machines = await this.machineRepository.getByGroupAndIds(groupId, machineIds);
    if (!machines?.length) {
      if (wholeGroup) {
        await this.groupRepository.update(groupId, { status: GroupStatus.OFFLINE });
      }
      this.logger.warn('No machines to stop on dry');
      return;
    }

    const {
      toStop,
      toDry,
      toKick,
    } = machines.reduce(
      (accum: { toDry: QueueEntity[]; toStop: MachineEntity[]; toKick: SessionEntity[]; }, machine) => {
        const { queue } = machine;
        if (!queue || queue.status === QueueStatus.DRYING || queue.status === QueueStatus.STOPPED) {
          return accum;
        }
        if (queue.sessions?.length) {
          const {
            active,
            kick,
          } = queue.sessions.reduce(
            (acc: { active: SessionEntity[], kick: SessionEntity[] }, session) => {
              if (session.getActiveRound()) {
                acc.active.push(session);
              } else {
                acc.kick.push(session);
              }
              return acc;
            }, {
              active: [],
              kick: [],
            });
          if (active.length) {
            accum.toDry.push(queue);
          } else {
            accum.toStop.push(machine);
          }
          accum.toKick.push(...kick);
        } else {
          accum.toStop.push(machine);
        }
        return accum;
      }, {
        toDry: [],
        toStop: [],
        toKick: [],
      });

    if (toDry.length) {
      const queueIds = toDry.map(value => value.id);
      this.logger.debug('Start drying queues', { queueIds, correlationId });
      await this.queueRepository.update(queueIds, { status: QueueStatus.DRYING });
      if (wholeGroup) {
        await this.groupRepository.update(groupId, { status: GroupStatus.DRYING });
      }
    } else if (wholeGroup) {
      await this.groupRepository.update(groupId, { status: GroupStatus.OFFLINE });
    }
    if (toStop.length) {
      await this.queueRepository.update(toStop.map(machine => machine.queue.id),
        { status: QueueStatus.STOPPED });
      const machineIds = toStop.map(machine => machine.id);
      this.logger.debug('Stopping machines', { machineIds, correlationId });
      await this.machineRepository.update(machineIds, {
        status: MachineStatus.SHUTTING_DOWN,
        shutdownReason: ShutdownReason.USER_REQUEST,
      });
      toStop.forEach(machine => this.robotClient.sendStopMessage(machine.serial, ShutdownReason.USER_REQUEST));
    }
    toKick.forEach(session => {
      this.commandPublisher.queueChange({
        type: CommandType.CHANGE_QUEUE,
        gameId: GameId.COIN_PUSHER_V1,
        sessionId: session.id,
        ignoreMachines: machineIds,
        ignoreGroups: machineIds?.length ? undefined : [groupId],
      }, correlationId);
    });
  }

  public async groupHardStop(
    groupId: number,
    data: GroupStopDto,
    correlationId?: string,
  ): Promise<void> {
    if (!data.machineIds?.length) {
      await this.groupRepository.update(groupId, { status: GroupStatus.OFFLINE });
    }
    const machines = await this.groupRepository.getGroupHardStopData(groupId, data.machineIds);
    if (!machines?.length) {
      this.logger.warn('No machines to stop on shutdown');
      return;
    }

    const queueIdsToUpdate = machines.reduce((ids, machine) => {
      if (machine.queue) {
        ids.push(machine.queue.id);
      }
      return ids;
    }, []);

    if (queueIdsToUpdate.length) {
      await this.queueRepository.update(queueIdsToUpdate, { status: QueueStatus.STOPPED });
    }

    const {
      toShutDown,
      sessions,
      needUpdateSeedHistory,
    } = machines
      .reduce((acc: { toShutDown: MachineEntity[], sessions: SessionEntity[], needUpdateSeedHistory: MachineEntity[] }, machine) => {
        if (machine.isRefurbish) {
          this.chipWatcherService.clearRefurbishData(machine.id);
        }
        if (machine.status !== MachineStatus.STOPPED && machine.status !== MachineStatus.OFFLINE) {
          acc.toShutDown.push(machine);
        }
        if (machine.queue?.sessions?.length) {
          acc.sessions.push(...machine.queue.sessions);
        }
        if (machine.status === MachineStatus.SEEDING && data.reason === ShutdownReason.MACHINE_IS_NOT_RESPONDING) {
          acc.needUpdateSeedHistory.push(machine);
        }
        return acc;
      }, {
        toShutDown: [],
        sessions: [],
        needUpdateSeedHistory: [],
      });
    if (toShutDown.length) {
      await this.machineRepository.update(toShutDown.map(machine => machine.id),
        {
          status: MachineStatus.SHUTTING_DOWN,
          shutdownReason: data.reason,
        });
      toShutDown.forEach(machine => this.robotClient.sendStopMessage(machine.serial, data.reason));
    }

    needUpdateSeedHistory.length && await lastValueFrom(from(needUpdateSeedHistory).pipe(
      concatMap(async machine => {
        const seedHistory = await this.seedHistoryRepository.getLastHistoryRecord(machine.id);
        seedHistory || await this.chipWatcherService.clearSeededChipList(machine.id);
        return seedHistory;
      }),
      filter(seedHistory => !!seedHistory),
      concatMap(async seedHistory => {
        const validSeedHistory = await this.chipWatcherService.getAllSeededChips(seedHistory.machineId);
        if (!validSeedHistory) {
          return this.seedHistoryRepository.delete(seedHistory.id);
        }
        seedHistory.seed = validSeedHistory;
        seedHistory.isCompleted = true;
        return this.seedHistoryRepository.save(seedHistory, { reload: false, transaction: false });
      }),
    ), { defaultValue: true });

    sessions.forEach(session => {
      const sessionId = Number(session.id);
      this.workerClient.timeoutStop({
        timeoutType: TimeoutType.IDLE,
        sessionId,
        payload: { gameId: session.gameId },
      }, correlationId);
      this.workerClient.timeoutStop({
        timeoutType: TimeoutType.REBUY,
        sessionId,
        payload: { gameId: session.gameId },
      }, correlationId);
      this.commandPublisher.terminateSession({
        type: CommandType.TERMINATE_SESSION,
        gameId: GameId.COIN_PUSHER_V1,
        sessionId,
        terminate: false,
        reason: SessionEndReason.MACHINE_STOP,
      }, correlationId);
    });
  }
}
