import { Length } from 'class-validator';
import { RobotMessage } from './robot.message';

export class AddBallDto extends RobotMessage {
  @Length(1, 128)
  public rfid: string;
}
