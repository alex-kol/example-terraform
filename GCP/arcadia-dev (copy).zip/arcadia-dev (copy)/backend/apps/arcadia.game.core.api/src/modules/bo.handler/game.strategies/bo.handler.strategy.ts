import { GroupEntity, MachineEntity } from '@lib/dal';
import { GroupStopDto, MachineStartDto } from '../dto';

export abstract class BoHandlerStrategy {
  abstract machineReassign(machine: MachineEntity, toGroup: GroupEntity): Promise<void>;

  abstract groupSoftStopHandler(groupId: number, machineIds?: number[], correlationId?: string): Promise<void>;

  abstract machineStartHandler(machine: MachineEntity, group: GroupEntity, params: MachineStartDto): Promise<void>;

  abstract groupHardStopHandler(groupId: number, data: GroupStopDto, correlationId?: string): Promise<void>
}