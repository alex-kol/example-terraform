/* eslint-disable max-lines */
import { CommandType, MachineReassignDto } from '@lib/common';
import {
  GameId,
  GroupRepository,
  GroupStatus,
  MachineRepository,
  MachineStatus,
  SessionEndReason,
  SessionRepository,
  ShutdownReason,
} from '@lib/dal';
import {
  BadRequestException, Injectable, NotAcceptableException, NotFoundException,
} from '@nestjs/common';
import { ModuleRef } from '@nestjs/core';
import { CommandPublisher } from '../command/command.publisher';
import { GroupTerminatorService } from '../group.terminator/group.terminator.service';
import { CoreMessage } from '../messaging/robot.handling/enum/core.message';
import { RobotClientService } from '../robot.client/robot.client.service';
import { GroupStopDto, MachineStartDto, MachineStartResponseDto } from './dto';
import { BoHandlerStrategy } from './game.strategies';
import { boHandlerStrategyKeyFactory } from './util/bo.handler.strategy.key.factory';

@Injectable()
export class BoHandlerService {
  constructor(
    private readonly machineRepo: MachineRepository,
    private readonly groupRepo: GroupRepository,
    private readonly sessionRepository: SessionRepository,
    private readonly robotClient: RobotClientService,
    private readonly groupTerminator: GroupTerminatorService,
    private readonly commandPublisher: CommandPublisher,
    private readonly moduleRef: ModuleRef,
  ) {
  }

  public async groupSoftStopHandler(
    groupId: number, machineIds?: number[], correlationId?: string,
  ): Promise<void> {
    const group = await this.groupRepo.findOneBy({ id: groupId });
    await this.getHandlerStrategy(group.gameId)
      .groupSoftStopHandler(groupId, machineIds, correlationId);
  }

  public async groupHardStopHandler(groupId: number, data: GroupStopDto, correlationId?: string): Promise<void> {
    const group = await this.groupRepo.findOneBy({ id: groupId });
    await this.getHandlerStrategy(group.gameId)
      .groupHardStopHandler(groupId, data, correlationId);
  }

  public async machineStartHandler(
    machineId: number, params: MachineStartDto, correlationId?: string,
  ): Promise<MachineStartResponseDto> {
    const machine = await this.machineRepo.findOneOrFail({
      where: { id: machineId },
      relations: ['group', 'site', 'cameras'],
    });
    const {
      group,
      gameId,
    } = machine;
    if (!group || (group.status !== GroupStatus.IDLE && group.status !== GroupStatus.IN_PLAY)) {
      throw new NotAcceptableException(`No group or unexpected group status: ${group?.status}`);
    }
    if (machine.status !== MachineStatus.ON_HOLD && machine.status !== MachineStatus.STOPPED) {
      throw new NotAcceptableException(`Unexpected machine status: ${machine.status}`);
    }

    await this.getHandlerStrategy(gameId)
      .machineStartHandler(machine, group, params);

    return {
      machineId,
      correlationId,
    };
  }

  public async machineReassign(machineId: number, data: MachineReassignDto): Promise<MachineReassignDto> {
    const { groupId } = data;
    const [machine, toGroup] = await Promise.all([
      this.machineRepo.findOne({
        where: { id: machineId },
        relations: ['chips', 'chips.type', 'queue', 'queue.sessions', 'queue.sessions.rounds', 'group'],
      }),
      this.groupRepo.findOneBy({ id: groupId }),
    ]);
    if (!machine) {
      throw new NotFoundException('Machine not found!');
    }
    if (!toGroup) {
      throw new NotFoundException('Group not found!');
    }
    if (machine.group.id === groupId) {
      throw new NotAcceptableException('Cant reassign to the same group!');
    }
    if (machine.gameId !== toGroup.gameId) {
      throw new BadRequestException('Group and machine have different gameId');
    }

    await this.getHandlerStrategy(machine.gameId)
      .machineReassign(machine, toGroup);
    return { groupId };
  }

  public async machineReboot(machineId: number): Promise<any> {
    const machine = await this.machineRepo.findOneOrFail({
      where: { id: machineId },
      relations: ['group'],
    });
    if (machine.status === MachineStatus.IN_PLAY) {
      throw new NotAcceptableException(`Unsafe reboot from status: ${machine.status}`);
    }
    await this.groupTerminator.groupHardStop(machine.gameId, machine.group.id, {
      reason: ShutdownReason.NOC_MACHINE_REBOOT,
      machineIds: [machine.id],
    });
    this.robotClient.sendRobotMessage({ action: CoreMessage.REBOOT }, machine.serial);
    return { machineId };
  }

  public async terminateSession(
    sessionId: number, correlationId: string, reason: SessionEndReason = SessionEndReason.BO_TERMINATE_REQUEST,
  ): Promise<number> {
    const session = await this.sessionRepository.findOneOrFail({
      where: { id: sessionId },
      select: ['gameId'],
    });
    await this.commandPublisher.terminateSession({
      type: CommandType.TERMINATE_SESSION,
      gameId: session.gameId,
      sessionId,
      correlationId,
      terminate: true,
      reason,
    });

    return sessionId;
  }

  private getHandlerStrategy(gameId: GameId): BoHandlerStrategy {
    return this.moduleRef.get(boHandlerStrategyKeyFactory(gameId));
  }
}
