import { GameId } from '@lib/dal';

export const boHandlerStrategyKeyFactory = (gameId: GameId) => `${gameId}_BO_HANDLER_STRATEGY`;
