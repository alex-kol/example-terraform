import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsBoolean, IsNumber, IsOptional } from 'class-validator';

export class SoundsConfigDto {
  @ApiProperty()
  @IsBoolean()
  public isAllSoundsMuted: boolean;

  @ApiProperty()
  @IsBoolean()
  public isMusicSoundsMuted: boolean;

  @ApiProperty()
  @IsBoolean()
  public isGameSoundsMuted: boolean;

  @ApiProperty()
  @IsNumber()
  public musicSoundsVolume: number;

  @ApiProperty()
  @IsNumber()
  public gameSoundsVolume: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  public isBackgroundSoundsMuted?: boolean;
}
