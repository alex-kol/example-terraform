import { FailedTransactionRepository, PlayerRepository, SessionRepository } from '@lib/dal';
import { Injectable } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { RetryTransactionCommand } from '../command/dto/retry.transaction.command';

@Injectable()
export class RetryScheduler {
  constructor(
    private readonly failedTransactionRepo: FailedTransactionRepository,
    private readonly playerRepo: PlayerRepository,
    private readonly sessionRepo: SessionRepository,
  ) {
  }

  public async scheduleRetry(data: RetryTransactionCommand): Promise<void> {
    const {
      operatorId,
      amountInCash,
      originalTransactionId,
      status,
      transactionType,
      playerCid,
      retries,
      roundId,
      sessionToken,
      gameId,
      extGameId,
    } = data;
    let transaction = await this.failedTransactionRepo.findOneBy({
      roundId,
      type: transactionType,
    });
    if (transaction) {
      throw new RpcException(`Transaction already exists, roundId: ${roundId}, type: ${transactionType}`);
    }
    const player = await this.playerRepo.findOneOrFail({
      where: {
        cid: playerCid,
        operatorId,
      },
      relations: ['operator'],
    });
    const sessionData = await this.sessionRepo.getSessionIdByPlayer(playerCid, operatorId);
    transaction = this.failedTransactionRepo.create({
      amountInCash,
      sessionToken,
      roundId,
      originalTransactionId,
      type: transactionType,
      status,
      gameId,
      extGameId,
      retries,
      player,
      operator: player.operator,
      sessionId: sessionData?.sessionId,
    });
    await this.failedTransactionRepo.save(transaction, {
      transaction: false,
      reload: false,
    });
  }
}
