import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { Injectable } from '@nestjs/common';
import { REBUY_SKIP_TTL, SESSION_TOKEN_TTL } from './constants';
import { rebuyExpSkipKeyFactory } from './rebuy.exp.skip.key.factory';
import { SessionDynamicData } from './session.dynamic.data';

@Injectable()
export class SessionDataManager {
  private readonly getSessionDataKey = (sessionId: string | number): string => `session-dynamic-data-key-${sessionId}`;

  constructor(private readonly cacheManager: RedisCacheService) {
  }

  public async getSessionData(sessionId: number): Promise<SessionDynamicData> {
    const key = this.getSessionDataKey(sessionId);
    const data = await this.cacheManager.get<SessionDynamicData>(key);
    return data || {};
  }

  public async isAutoplay(sessionId: number): Promise<boolean> {
    const { autoplay } = await this.getSessionData(sessionId);
    return !!autoplay;
  }

  public async dropSessionData(sessionId: number): Promise<void> {
    const key = this.getSessionDataKey(sessionId);
    await this.cacheManager.del(key);
  }

  public async updateSessionData(data: Partial<SessionDynamicData>, sessionId: number): Promise<void> {
    const key = this.getSessionDataKey(sessionId);
    const sessionData = await this.getSessionData(sessionId);
    await this.cacheManager.set<SessionDynamicData>(
      key,
      { ...sessionData, ...data },
      { ttl: SESSION_TOKEN_TTL },
    );
  }

  public async removeSessionData(keys: Array<keyof SessionDynamicData>, sessionId: number): Promise<void> {
    const key = this.getSessionDataKey(sessionId);
    const sessionData = await this.getSessionData(sessionId);
    keys.forEach(key => delete sessionData[key]);
    await this.cacheManager.set(key, sessionData, { ttl: SESSION_TOKEN_TTL });
  }

  public async getRebuyExpirationSkip(sessionId: number): Promise<boolean> {
    const result = await this.cacheManager.get<boolean>(rebuyExpSkipKeyFactory(sessionId));
    return !!result;
  }

  public async setRebuyExpirationSkip(sessionId: number): Promise<void> {
    await this.cacheManager.set(rebuyExpSkipKeyFactory(sessionId), true, { ttl: REBUY_SKIP_TTL });
  }
}
