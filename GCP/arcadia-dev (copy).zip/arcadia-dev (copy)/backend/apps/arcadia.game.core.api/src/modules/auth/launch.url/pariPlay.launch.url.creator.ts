import { deleteUndefinedValue, OperatorTag, UserLoginDto } from '@lib/common';
import { ConfigService } from '@lib/config';
import { OperatorEntity, OperatorRepository, OperatorStatus } from '@lib/dal';
import { Injectable, NotAcceptableException } from '@nestjs/common';
import { StandardLanguageMapper } from './languages';
import { LaunchUrlCreator } from './launch.url.creator';
import { pariPlayLaunchParamsValidationSchema } from './params.validation.schemas';
import { PariPlayLaunchParams } from './types';

@Injectable()
export class PariPlayLaunchUrlCreator extends LaunchUrlCreator<PariPlayLaunchParams> {
  protected readonly paramsValidationSchema = pariPlayLaunchParamsValidationSchema;

  constructor(
    config: ConfigService,
    private readonly operatorRepo: OperatorRepository,
    private readonly standardLanguageMapper: StandardLanguageMapper,
  ) {
    super(config);
  }

  protected getId(): string {
    return OperatorTag.PARIPLAY;
  }

  protected getOperator(): Promise<OperatorEntity> {
    const { apiConnectorId, externalId } = this.getConnectorIdAndExternalId();
    return this.operatorRepo.findOneByOrFail({
      apiConnectorId,
      externalId: externalId ?? null,
      isDeleted: false,
      status: OperatorStatus.ENABLED,
    })
      .catch(() => {
        throw new NotAcceptableException('Operator not found');
      });
  }

  protected validateCaller(): Promise<void> {
    return Promise.resolve();
  }

  protected mapParams(): UserLoginDto {
    const {
      token,
      gameCode,
      languageCode,
      isReal,
      homeUrl,
    } = this.params;

    const { externalId } = this.getConnectorIdAndExternalId();
    const result: UserLoginDto = {
      operatorId: this.operator.id,
      accessToken: token,
      gameId: gameCode,
      language: this.standardLanguageMapper.getLanguageCode(languageCode),
      isReal: isReal === 'true',
      homeUrl,
      events: OperatorTag.PARIPLAY,
      externalId,
    };
    deleteUndefinedValue(result);
    return result;
  }

  private getConnectorIdAndExternalId(): { apiConnectorId: string, externalId?: string } {
    const [apiConnectorId, externalId = undefined] = this.params.operator.split(':');
    return { apiConnectorId, externalId };
  }
}
