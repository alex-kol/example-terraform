/* eslint-disable max-lines */
import { CommandType, EventSource, TimeoutType } from '@lib/common';
import { ConfigService } from '@lib/config';
import {
  AlertSeverity,
  AlertSource,
  AlertType,
  BallRepository,
  EventType,
  GameId,
  GroupRepository,
  GroupStatus,
  MachineEntity,
  MachineRepository,
  MachineStatus,
  QueueRepository,
  QueueStatus,
  RoundType,
  SessionEndReason,
  SessionRepository,
  SessionStatus,
  ShutdownReason,
  VoucherStatus,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { Alert, MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { Inject, Injectable, NotAcceptableException } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import moment from 'moment';
import { v4 as uuidv4 } from 'uuid';
import { Logger } from 'winston';
import { RedisList } from '@lib/redis.cache/redis.list';
import { SessionService } from '../../../session/session.service';
import { RobotClientService } from '../../../robot.client/robot.client.service';
import { PlayerClientService } from '../../../player.client/player.client.service';
import { WorkerClientService } from '../../../worker.client/worker.client.service';
import { QueueManagerService } from '../../../queue.manager/queue.manager.service';
import { RoundServiceFactory } from '../../../round/round.service.factory';
import { CommandPublisher } from '../../../command/command.publisher';
import { AddBallDto, RobotMessage } from '../../../messaging/robot.handling/dto';
import { SessionDataManager } from '../../../session.data.manager/session.data.manager';
import { RoundContext } from '../../../round/round.context';
import { engageLockKeyFactory } from '../../../../util';
import { ConversionTracker } from '../../../conversion.tracker/conversion.tracker';
import { EntrySource } from '../../../conversion.tracker/entry.source';
import { CoreMessage } from '../../../messaging/robot.handling/enum/core.message';
import { RngClientService } from '../../../rng.service.client/rng.client.service';
import { ForcedGrabDto } from '../../types/forced.grab.dto';
import { WAITING_RESULT_TTL_SEC } from '../../constants';
import { ConfigValidator } from '../../../config.validator/config.validator';

@Injectable()
export class RobotMessageService {
  private readonly robotEngageTimeoutSec: number;
  private readonly terminateSessionTimeoutSec: number;

  constructor(
    private readonly machineRepository: MachineRepository,
    private readonly sessionRepository: SessionRepository,
    private readonly ballRepository: BallRepository,
    private readonly groupRepository: GroupRepository,
    private readonly queueRepository: QueueRepository,
    private readonly sessionService: SessionService,
    private readonly robotClient: RobotClientService,
    private readonly playerClient: PlayerClientService,
    private readonly workerClient: WorkerClientService,
    private readonly monitoringClient: MonitoringWorkerClientService,
    private readonly configService: ConfigService,
    private readonly queueManager: QueueManagerService,
    public readonly cacheManager: RedisCacheService,
    public readonly redisList: RedisList,
    private readonly roundServiceFactory: RoundServiceFactory,
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly commandPublisher: CommandPublisher,
    private readonly sessionDataManager: SessionDataManager,
    private readonly conversionTracker: ConversionTracker,
    private readonly playerPublisher: PlayerClientService,
    private readonly rngClientService: RngClientService,
    private readonly configValidator: ConfigValidator,
  ) {
    this.robotEngageTimeoutSec = this.configService.get(['core', 'ROBOT_ENGAGE_TIMEOUT_SEC']);
    this.terminateSessionTimeoutSec = this.configService.get(['core', 'TERMINATE_SESSION_TIMEOUT_SEC']);
  }

  public async handleEngaged(data: RobotMessage): Promise<void> {
    const {
      sessionId,
      session: cachedSession,
      correlationId,
    } = data;
    const sessionFormDb = await this.sessionRepository.findOneOrFail({
      where: { id: sessionId },
      relations: ['rounds'],
    });
    sessionFormDb.id = Number(sessionFormDb.id);
    const { machine } = data.session;
    await this.sessionRepository.update(sessionId, {
      queueDuration: moment()
        .diff(sessionFormDb.createDate, 'seconds') - sessionFormDb.viewerDuration,
    });

    const isAutoplayRoundStart = await this.sessionDataManager.isAutoplay(sessionId);
    const ctx: RoundContext = new RoundContext(
      sessionFormDb,
      cachedSession.queue,
      machine,
      cachedSession.player,
      cachedSession.group,
      cachedSession.operator,
      isAutoplayRoundStart,
      [],
      correlationId,
    );

    const round = sessionFormDb.getActiveRound();
    const roundStartMessage = await this.roundServiceFactory.getStarter(machine.gameId, ctx)
      .getRoundStartedMessage(round);

    const pickup = await this.rngClientService.clawRound(cachedSession.group.prizeGroup, cachedSession.configuration.rtpSegment);
    this.robotClient.sendRobotMessage(
      {
        action: CoreMessage.START_ROUND,
        pickup,
      },
      machine.serial,
    );
    this.playerPublisher.notifyRoundStart(sessionId, roundStartMessage);
    this.monitoringClient.sendEventLogMessage({
      eventType: EventType.START_ROUND,
      source: EventSource.GAME,
      params: {
        type: round.type,
        sessionId,
        machineSerial: machine.serial,
        round: round.id,
        pickup,
      },
    });

    await this.monitoringClient.sendEventLogMessage({
      eventType: EventType.ENGAGED,
      source: EventSource.ROBOT,
      params: {
        sessionId,
        machineSerial: data.serial,
      },
    });

    await this.queueManager.notifyQueueUpdate(data.session.queue.id, sessionFormDb);
    await this.releaseEngageLock(machine.id);
    // delay for better start/stop correlation under load
    await new Promise<void>(resolve => {
      setTimeout(async () => {
        await this.workerClient.timeoutStop({
          timeoutType: TimeoutType.ENGAGE,
          sessionId,
          payload: { gameId: cachedSession.gameId },
        }, correlationId);
        resolve();
      }, 200);
    });
    this.logger.info('Machine engaged game session', {
      sessionId,
      serial: machine.serial,
    });
  }

  public async handleDisengaged({
    sessionId,
    serial,
    correlationId,
    session: injectedSession,
  }: RobotMessage): Promise<void> {
    if (!sessionId || !injectedSession?.queue) {
      throw new RpcException('No-session disengage');
    }

    const session = await this.sessionRepository.findOne({
      where: { id: sessionId },
      relations: ['machine'],
    });
    if (!session) {
      this.logger.error('No session found on disengage', { sessionId });
      this.commandPublisher.engageNextSession({
        type: CommandType.ENGAGE_SESSION,
        gameId: GameId.CLAW,
        machineId: session.machine.id,
      });
      return;
    }

    const {
      queue,
      player,
    } = injectedSession;

    const { machine } = session;
    this.monitoringClient.sendEventLogMessage({
      eventType: EventType.BREAKUP,
      source: EventSource.ROBOT,
      params: {
        sessionId,
        machineSerial: serial,
        playerCid: player?.cid,
      },
    });
    const terminate = session.status === SessionStatus.TERMINATING;
    if (terminate) {
      await this.workerClient.timeoutStop({
        timeoutType: TimeoutType.DISENGAGE,
        sessionId,
        payload: { gameId: session.gameId },
      }, correlationId);
    }
    await this.workerClient.timeoutStop({
      timeoutType: TimeoutType.REBUY,
      sessionId,
      payload: { gameId: session.gameId },
    }, correlationId);

    const {
      endReason,
      loginOptions,
    } = await this.sessionDataManager.getSessionData(sessionId);
    delete loginOptions.sessionToken;
    await this.conversionTracker.createTracker(player, EntrySource.RETENTION, loginOptions);
    await this.sessionService
      .finalizeSession(session.id, endReason || SessionEndReason.NORMAL, terminate);

    if (machine.status === MachineStatus.READY || machine.status === MachineStatus.IN_PLAY) {
      await this.machineRepository.update(machine.id, { status: MachineStatus.READY });
      await this.queueManager.notifyQueueUpdate(queue.id);
      this.commandPublisher.engageNextSession({
        type: CommandType.ENGAGE_SESSION,
        gameId: GameId.CLAW,
        machineId: session.machine.id,
      });
    }
  }

  public async engageNextSession(
    machineId: number,
    reBuySessionId?: number,
    correlationId: string = uuidv4(),
  ): Promise<void> {
    const lock = await this.acquireEngageLock(machineId);
    if (!lock) {
      this.logger.debug('Engage skipped due to lock', { machineId });
      return;
    }

    let releaseLock = true;
    try {
      const machine = await this.machineRepository.getMachineToEngage(machineId);
      if (!machine) {
        throw new RpcException(`Machine not found, cant engage: machineId=${machineId}`);
      }
      const {
        queue,
        group,
      } = machine;
      const nextSession = await this.sessionRepository.getNextSessionForQueue(queue.id);
      if (!nextSession) {
        if (machine.queue.status === QueueStatus.DRYING) {
          if (machine.reassignTo) {
            await this.reassignClawMachine(machine.id);
          } else {
            await this.stopQueueAndGroup(machine, queue.id);
          }
          return;
        }
        if (machine.status !== MachineStatus.READY) {
          await this.machineRepository.update(machine.id, { status: MachineStatus.READY });
        }
        return;
      }

      nextSession.id = Number(nextSession.id);
      const isRebuy = nextSession.id === reBuySessionId;
      if (!this.canEngageNewSession(machine, isRebuy)) {
        this.logger.warn('Skip engage new session', {
          machineSerial: machine.serial,
          machineStatus: machine.status,
          queueStatus: queue.status,
          nextSessionId: nextSession.id,
          reBuySessionId: reBuySessionId || null,
        });
        return;
      }

      if (machine.queue.status === QueueStatus.DRYING && !isRebuy) {
        if (machine.reassignTo) {
          await this.reassignClawMachine(machine.id);
        } else {
          await this.stopQueueAndGroup(machine, queue.id);
        }
        return;
      }

      if (nextSession.isDisconnected && !isRebuy) {
        await this.sessionRepository.update(nextSession.id, {
          status: SessionStatus.VIEWER,
          roundsLeft: 0,
          buyDate: null,
        }, data => this.playerClient.sessionState(nextSession.id, { status: data.status }));
        await this.sessionDataManager.removeSessionData(['autoplay', 'betBehind'],
          nextSession.id,
        );
        await this.workerClient.timeoutStart({
          timeoutType: TimeoutType.TERMINATE_SESSION,
          sessionId: nextSession.id,
          timeoutSec: this.terminateSessionTimeoutSec,
          payload: { reason: SessionEndReason.VIEWER_DISCONNECTED, gameId: machine.gameId },
        });
        this.commandPublisher.engageNextSession({
          type: CommandType.ENGAGE_SESSION,
          gameId: machine.gameId,
          machineId,
        }, correlationId);
        return;
      }

      nextSession.machine = machine;

      const {
        player,
        operator,
        vouchers = [],
      } = nextSession;
      const pendingVouchers = vouchers.filter(({ status }) => status === VoucherStatus.PENDING)
        .sort((a, b) => (a.expirationDate || new Date()).valueOf() - (b.expirationDate || new Date()).valueOf());
      const isAutoplayRoundStart = await this.sessionDataManager.isAutoplay(nextSession.id);
      const ctx: RoundContext = new RoundContext(
        nextSession,
        queue,
        machine,
        player,
        group,
        operator,
        isAutoplayRoundStart,
        pendingVouchers,
        correlationId,
      );
      try {
        await this.roundServiceFactory.getStarter(machine.gameId, ctx)
          .startRound(pendingVouchers.length ? RoundType.VOUCHER : RoundType.REGULAR);
      } catch (err) {
        if (nextSession.status === SessionStatus.RE_BUY) {
          this.commandPublisher.terminateSession({
            type: CommandType.TERMINATE_SESSION,
            gameId: machine.gameId,
            sessionId: nextSession.id,
            terminate: true,
            reason: SessionEndReason.WALLET_TRANSACTION_ERROR,
          }, correlationId);
        } else {
          await this.sessionService
            .finalizeSession(nextSession.id, SessionEndReason.WALLET_TRANSACTION_ERROR, true);
          this.commandPublisher.engageNextSession({
            type: CommandType.ENGAGE_SESSION,
            gameId: machine.gameId,
            machineId,
          }, correlationId);
        }
        return;
      }
      await this.sessionRepository.update(
        nextSession.id,
        { status: SessionStatus.PLAYING },
        data => this.playerClient.sessionState(nextSession.id, { status: data.status }),
      );
      if (nextSession.status !== SessionStatus.RE_BUY) {
        await this.workerClient.timeoutStart({
          timeoutType: TimeoutType.ENGAGE,
          sessionId: nextSession.id,
          timeoutSec: this.robotEngageTimeoutSec,
          payload: { gameId: nextSession.gameId },
        }, correlationId);
        await this.machineRepository.update(machine.id, { status: MachineStatus.IN_PLAY });
        releaseLock = false;
        await this.monitoringClient.sendEventLogMessage({
          eventType: EventType.ENGAGE_ROBOT,
          source: EventSource.GAME,
          params: {
            sessionId: nextSession.id,
            machineSerial: machine.serial,
          },
        });
        await this.robotClient.sendEngageMessage(nextSession.id, machine.serial);
      }
    } finally {
      if (releaseLock) {
        await this.releaseEngageLock(machineId);
      }
    }
  }

  public async addBallClaw({
    serial,
    rfid,
  }: AddBallDto): Promise<void> {
    const [machine, ball] = await Promise.all([
      this.machineRepository.findOne({
        where: { serial },
        relations: ['group', 'site'],
      }),
      this.ballRepository.findOne({
        where: { rfid },
        relations: ['machine', 'site'],
      }),
    ]);

    const alert: Alert = {
      alertType: AlertType.ERROR,
      source: AlertSource.GAME_CORE,
      severity: AlertSeverity.MEDIUM,
      description: null,
      gameId: machine.gameId,
      details: {
        machineSerial: serial,
        rfid,
      },
    };

    const response = {
      rejectedReason: null as string,
      label: ball?.label ?? null,
      missing: [] as string[],
    };

    if (!machine) {
      alert.description = 'Ball didn\'t assigned. Machine not found';
      response.rejectedReason = alert.description;
      return this.sendAddBallRobotMessage(serial, response, alert);
    }

    if (!ball || ball.site.id !== machine.site.id) {
      alert.description = 'Ball didn\'t assigned. Ball not found';
      response.rejectedReason = alert.description;
      return this.sendAddBallRobotMessage(serial, response, alert);
    }

    if (
      machine.status === MachineStatus.READY
      || machine.status === MachineStatus.PREPARING
      || machine.status === MachineStatus.IN_PLAY
      || machine.status === MachineStatus.SEEDING
    ) {
      alert.description = 'Ball didn\'t assigned. Machine not stopped';
      response.rejectedReason = alert.description;
      return this.sendAddBallRobotMessage(serial, response, alert);
    }

    if (
      ball.machine
      && (ball.machine.status === MachineStatus.READY
        || ball.machine.status === MachineStatus.PREPARING
        || ball.machine.status === MachineStatus.IN_PLAY
        || ball.machine.status === MachineStatus.SEEDING)
    ) {
      alert.description = 'Ball reassigned from ready/playing machine';
      response.rejectedReason = alert.description;
      return this.sendAddBallRobotMessage(serial, response, alert);
    }

    const andWarnAlert = ball.machine && ball.machine.id !== machine.id;

    if (andWarnAlert) {
      ball.machine = machine;

      await this.ballRepository.save(ball, {
        transaction: true,
        reload: false,
      });
    }

    if (andWarnAlert) {
      alert.alertType = AlertType.WARNING;
      alert.description = 'Ball reassigned from stopped/offline machine';
    }

    return this.sendAddBallRobotMessage(serial, response, andWarnAlert && alert);
  }

  public async forcedPickup(options: ForcedGrabDto): Promise<void> {
    const {
      sessionId,
      session: cachedSession,
      reason,
      correlationId,
    } = options;
    const session = await this.sessionRepository.findOne({
      where: { id: sessionId },
      relations: ['rounds'],
    });
    if (!session) {
      throw new RpcException('No session on idle timeout');
    }

    const activeRound = session.getActiveRound();
    if (!activeRound) {
      this.logger.warn('idle timeout skipped', { sessionId });
      return;
    }

    const {
      machine,
    } = cachedSession;

    await this.playerClient.sessionState(sessionId, { status: SessionStatus.FORCED_AUTOPLAY });

    await this.workerClient.timeoutStart({
      timeoutType: TimeoutType.WAITING_RESULT,
      sessionId,
      timeoutSec: WAITING_RESULT_TTL_SEC,
      payload: {
        reason: ShutdownReason.WAITING_RESULT, gameId: machine.gameId,
      },
    },
    correlationId,
    () => this.robotClient.forcedPickup(machine.serial, sessionId),
    );

    await this.monitoringClient.sendEventLogMessage({
      eventType: EventType.FORCED_GRAB,
      source: EventSource.GAME,
      params: {
        sessionId,
        machineSerial: machine?.serial,
        reason,
        stopCriteria: '',
      },
    });
  }

  public async reassignClawMachine(machineId: number): Promise<void> {
    const machine = await this.machineRepository.findOneOrFail({
      where: { id: machineId },
      relations: ['queue'],
    });
    if (!machine.reassignTo) {
      throw new NotAcceptableException('No reassign target');
    }
    await this.changeQueue(machine);
    const toGroup = await this.groupRepository.findOneByOrFail({ id: machine.reassignTo });

    const goToGame = machine.status !== MachineStatus.SHUTTING_DOWN
      && machine.status !== MachineStatus.STOPPED
      && machine.status !== MachineStatus.OFFLINE;

    await this.machineRepository.manager.transaction(async entityManager => {
      const machineRepo = new MachineRepository(entityManager);
      await machineRepo.update(machine.id,
        {
          group: toGroup,
          configuration: machine.configuration,
          status: goToGame ? MachineStatus.READY : machine.status,
          reassignTo: null,
        });
      if (goToGame) {
        await new QueueRepository(entityManager)
          .update(machine.queue.id, { status: QueueStatus.READY });
      } else {
        await new QueueRepository(entityManager)
          .update(machine.queue.id, { status: QueueStatus.STOPPED });
      }
    });
    await this.configValidator.dropCache(machine.serial);

    await this.monitoringClient.sendAlertMessage({
      alertType: AlertType.INFORMATION,
      severity: AlertSeverity.LOW,
      source: AlertSource.GAME_CORE,
      description: 'Machine reassign complete',
      gameId: machine.gameId,
      details: {
        machineId: machine.id,
        machineName: machine.name,
        machineSerial: machine.serial,
        groupId: toGroup.id,
      },
    });
  }

  private async acquireEngageLock(machineId: number): Promise<boolean> {
    const key = engageLockKeyFactory(machineId);
    const lock = await this.cacheManager.store.getClient()
      .set(key, `${machineId}`, 'EX', 10, 'NX');
    return !!lock;
  }

  private async releaseEngageLock(machineId: number): Promise<void> {
    await this.cacheManager.del(engageLockKeyFactory(machineId));
  }

  private canEngageNewSession(machine: MachineEntity, isRebuy: boolean): boolean {
    return machine.status === MachineStatus.READY || (machine.status === MachineStatus.IN_PLAY && isRebuy);
  }

  private sendAddBallRobotMessage(
    serial: string,
    message: { missing: string[], label: string, rejectedReason: string },
    alert?: Alert,
  ): void {
    this.robotClient.sendBallConfig(serial, message);
    alert && this.monitoringClient.sendAlertMessage(alert);
  }

  private async changeQueue(machine: MachineEntity) {
    const { queue } = machine;
    const toKick = await this.sessionRepository.findBy({ queue: { id: queue.id } });
    if (toKick?.length) {
      toKick.forEach(session => this.commandPublisher.queueChange({
        type: CommandType.CHANGE_QUEUE,
        gameId: GameId.CLAW,
        sessionId: session.id,
        ignoreMachines: [machine.id],
      }));
    }
  }

  private async stopQueueAndGroup(machine: MachineEntity, queueId: number) {
    await this.changeQueue(machine);
    const {
      drying,
      other,
    } = await this.machineRepository.getQueueStatusesForGroup(machine.group.id);
    if (machine.group.status === GroupStatus.DRYING
      && drying === 1
      && other === 0) {
      await this.groupRepository.update(machine.group.id, { status: GroupStatus.OFFLINE });
    }
    await this.queueRepository.update(queueId, { status: QueueStatus.STOPPED });
    await this.machineRepository.update(machine.id, {
      status: MachineStatus.SHUTTING_DOWN,
      shutdownReason: ShutdownReason.USER_REQUEST,
    });
    await this.robotClient.sendStopMessage(machine.serial, ShutdownReason.NOC_MACHINE_SHUTDOWN);
  }
}
