export enum EntrySource {
  EXTERNAL_LOBBY = 'externalLobby',
  RETENTION = 'retention',
  CHANGE_BET = 'changeBet',
}