import { ConfigService } from '@lib/config';
import {
  connectionNames,
  getRepositoryToken,
  GroupRepository,
  MachineRepository,
  QueueRepository,
  RngChipPrizeRepository,
  RoundRepository,
  SessionRepository,
  VoucherRepository,
} from '@lib/dal';
import { VideoApiClientService } from '@lib/video.api';
import { HttpModule } from '@nestjs/axios';
import { Test } from '@nestjs/testing';
import { repoMockFactory } from '../../../../util/repoMockFactory';
import { CommandPublisher } from '../../../command/command.publisher';
import { OperatorApiClientService } from '../../../operator.api.client/operator.api.client.service';
import { PlayerClientService } from '../../../player.client/player.client.service';
import { QueueManagerService } from '../../../queue.manager/queue.manager.service';
import { RobotClientService } from '../../../robot.client/robot.client.service';
import { SessionDataManager } from '../../../session.data.manager/session.data.manager';
import { SessionService } from '../../../session/session.service';
import { WorkerClientService } from '../../../worker.client/worker.client.service';
import { PlayerMessageService } from '../player.message.service';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';

export async function makeTestModule() {
  const moduleFixture = await Test.createTestingModule({
    imports: [HttpModule],
    providers: [
      PlayerMessageService,
      {
        useValue: {
          ...repoMockFactory(),
          getBetList: () => null
        },
        provide: getRepositoryToken(GroupRepository, connectionNames.DATA),
      },
      {
        useValue: {
          ...repoMockFactory(),
          manager: {
            transaction: () => {
            }
          }
        },
        provide: getRepositoryToken(RoundRepository, connectionNames.DATA),
      },
      {
        useValue: {
          create: () => {
          },
          saveAndArchive: () => {
          },
          finalizeSessions: () => null,
          terminateSessions: () => {
          },
        },
        provide: SessionService,
      },
      {
        useValue: {
          getBalance: () => null,
          cancelWager: () => null,
          balance: () => null,
        },
        provide: OperatorApiClientService,
      },
      {
        useValue: {
          timeoutStart: () => {
          },
          timeoutStop: () => {
          },
          stopGraceTimeout: () => {
          },
        },
        provide: WorkerClientService,
      },
      {
        useValue: {
          notifyQueueUpdate: () => null,
          sendNewQueueData: () => null,
          assignSessionToQueue: () => null
        },
        provide: QueueManagerService,
      },
      {
        useValue: {
          ...repoMockFactory(),
          createQueryBuilder: () => {
          }
        },
        provide: getRepositoryToken(SessionRepository, connectionNames.DATA),
      },
      {
        useValue: {
          ...repoMockFactory(),
          createQueryBuilder: () => {
          },
          getLobbyAndChangeBetGroupData: () => null
        },
        provide: getRepositoryToken(MachineRepository, connectionNames.DATA),
      },
      {
        useValue: {
          ...repoMockFactory(),
          getVoucherForSession: () => null
        },
        provide: getRepositoryToken(VoucherRepository, connectionNames.DATA),
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(QueueRepository, connectionNames.DATA),
      },
      {
        useValue: {
          ...repoMockFactory(),
          getPayTable: () => null
        },
        provide: getRepositoryToken(RngChipPrizeRepository, connectionNames.DATA),
      },
      {
        useValue: {
          get: () => null,
          set: () => null,
          del: () => null,
        },
        provide: RedisCacheService,
      },
      {
        useValue: {
          sendNotification: () => null,
          forceReconnect: () => null,
          sendBets: () => null,
          notifyBuyResult: () => null,
          notifyQueueChangeOffer: () => null,
          notifyAutoplay: () => null,
          queueBalance: () => null,
          sendError: () => null,
        },
        provide: PlayerClientService,
      },
      {
        useValue: { sendEventLogMessage: () => null },
        provide: MonitoringWorkerClientService,
      },
      {
        useValue: {
          removeSessionData: () => null,
          getSessionToken: () => null,
          updateSessionData: () => null
        },
        provide: SessionDataManager,
      },
      {
        useValue: {
          sendAutoplayMessage: () => null,
          sendStopAutoplayMessage: () => null,
          sendDisengageMessage: () => null,
          sendAllowCoinsMessage: () => null,
        },
        provide: RobotClientService,
      },
      {
        useValue: {},
        provide: VideoApiClientService,
      },
      {
        useValue: { engageNextSession: () => null },
        provide: CommandPublisher,
      },
      ConfigService,
    ],
  })
    .compile();
  return moduleFixture;
}
