import { Configuration } from '@lib/dal';
import Joi from 'joi';
import { commonSchema } from './common.schema';

export const clawSchema = Joi.object<Configuration>({
  ...commonSchema,
  rebuyTimeout: Joi
    .number()
    .integer()
    .positive()
    .default(60),
  idleTimeout: Joi
    .number()
    .integer()
    .positive()
    .required(),
});
