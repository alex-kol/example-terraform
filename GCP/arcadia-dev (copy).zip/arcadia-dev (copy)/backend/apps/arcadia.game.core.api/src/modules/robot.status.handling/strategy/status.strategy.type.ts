export enum StatusStrategyType {
  STARTUP = 'startup',
  SHUTDOWN = 'shutdown',
  GAMEPLAY = 'gameplay',
  ERROR = 'error',
}