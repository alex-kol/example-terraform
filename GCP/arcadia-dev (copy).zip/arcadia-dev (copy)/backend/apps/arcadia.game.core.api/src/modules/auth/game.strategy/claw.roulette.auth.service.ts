/* eslint-disable max-lines */
import {
  Cache, CacheClear, ConversionDto, EventSource,
} from '@lib/common';
import {
  CurrencyConversionRepository,
  EventType,
  GameId,
  GroupEntity,
  GroupRepository,
  MachineEntity,
  MachineRepository,
  OperatorRepository,
  PlayerEntity,
  PlayerId,
  PlayerRepository,
  RouletteField,
  SessionRepository,
  SessionStatus,
  VoucherRepository,
} from '@lib/dal';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import {
  HttpStatus, Injectable, NotAcceptableException, NotFoundException, UnauthorizedException,
} from '@nestjs/common';
import * as _ from 'lodash';
import moment from 'moment';
import { LOBBY_LONG_POLLING_INTERVAL_SEC } from '../../../constants/game.client';
import { NotificationException } from '../../../filters/notification.exception';
import { toCash } from '../../../util';
import { ConfigValidator } from '../../config.validator/config.validator';
import { ConversionTracker } from '../../conversion.tracker/conversion.tracker';
import { IpChecker } from '../../ip.checker/ip.checker';
import { getRobotDirectRoom, getRobotQueueRoom, sessionRoomNameFactory } from '../../messaging/room.name.template';
import { NotificationLevel } from '../../player.client/notification.level';
import { NotificationType } from '../../player.client/notification.type';
import { PlayerClientService } from '../../player.client/player.client.service';
import { BetManager } from '../../roulette.engine/bet.manager';
import { winMultiplierMap } from '../../roulette.engine/constants/win.multiplier.map';
import { GameStateManager } from '../../roulette.engine/game.state.manager';
import { SessionDataManager } from '../../session.data.manager/session.data.manager';
import { sessionCacheKeyFactory } from '../../session/session.cache.key.factory';
import { getSessionHash } from '../../session/session.hash';
import { SessionService } from '../../session/session.service';
import { AuthService } from '../auth.service';
import { GROUP_NOT_ASSIGNED, GROUP_WITHOUT_MACHINE } from '../constants';
import { LoginReconnectDto } from '../dtos';
import { GameAuthHandler } from '../interfaces';
import { ClawRouletteLobbyRes, ClawRouletteReconnectVerifyRes, ClawRouletteVerifyRes } from '../responses';

@Injectable()
export class ClawRouletteAuthService extends GameAuthHandler {
  constructor(
    private readonly machineRepository: MachineRepository,
    private readonly groupRepository: GroupRepository,
    private readonly playerRepository: PlayerRepository,
    private readonly operatorRepository: OperatorRepository,
    private readonly sessionRepository: SessionRepository,
    private readonly currencyConversionRepository: CurrencyConversionRepository,
    private readonly voucherRepository: VoucherRepository,
    private readonly sessionService: SessionService,
    private readonly monitoringClient: MonitoringWorkerClientService,
    private readonly sessionDataManager: SessionDataManager,
    private readonly ipChecker: IpChecker,
    private readonly configValidator: ConfigValidator,
    private readonly conversionTracker: ConversionTracker,
    private readonly authService: AuthService,
    private readonly betManager: BetManager,
    private readonly gameStateManager: GameStateManager,
    private readonly playerClientService: PlayerClientService,
  ) {
    super();
  }

  public async loginPlayer(token: string, groupId: number, footprint: string): Promise<ClawRouletteVerifyRes> {
    const player = await this.authService.getPlayerForSession(token);
    const { operator } = player;

    const gto = operator.groupToOperator?.find(gto => gto.group?.id === groupId);
    if (!gto) {
      throw new NotAcceptableException(GROUP_NOT_ASSIGNED);
    }

    const {
      group,
      machine,
    } = await this.getTargetForSession(groupId, player);
    if (!machine) {
      throw new NotAcceptableException(GROUP_WITHOUT_MACHINE);
    }

    const sessionConfig = await this.configValidator.getValidatedConfig(machine.serial, operator.id);
    const {
      sessionOptions,
      loginOptions,
    } = await this.authService.getSessionOptions(token);

    sessionOptions.configuration = sessionConfig;
    sessionOptions.footprint = footprint;
    const { currencies } = sessionConfig;
    if (!currencies.includes(sessionOptions.currency.toUpperCase())) {
      throw new NotificationException({
        notificationId: NotificationType.CURRENCY_NOT_SUPPORTED,
        level: NotificationLevel.ERROR,
        title: 'Error',
        message: `Currency "${sessionOptions.currency}" is not supported!`,
        command: 'goToLobby',
      }, HttpStatus.NOT_ACCEPTABLE);
    }
    if (!(await this.ipChecker.verifyIp(sessionOptions.playerIP as string,
      sessionOptions.configuration.countryWhitelist))) {
      throw new NotificationException({
        notificationId: NotificationType.IP_ADDRESS_FORBIDDEN,
        level: NotificationLevel.ERROR,
        title: 'Error',
        message: 'IP-address is forbidden!',
        command: 'goToLobby',
      }, HttpStatus.NOT_ACCEPTABLE);
    }
    const convRate = await this.currencyConversionRepository.getCurrencyConversion(sessionOptions.currency);
    sessionOptions.currencyConversionRate = Number(convRate.rate);

    const streams = await this.authService.getCamerasStreams(machine);

    const session = await this.sessionService.createSession({
      ...sessionOptions,
      operator,
      player,
      group,
      machine,
      queue: machine.queue,
      denominator: group.denominator,
      cameraIds: machine.cameras.map(({ cameraId }) => cameraId).join(','),
    });
    await this.conversionTracker.closeTracker(player, {
      sessionId: session.id,
      groupId: group.id,
    });
    const updateUserData: Partial<PlayerEntity> = { lastSessionDate: new Date() };
    if (player.firstSessionDate === null) {
      updateUserData.firstSessionDate = new Date();
    }

    if (gto.isNewPlayerVoucher && !player.isVoucherAwarded) {
      const checkExistVoucher = await this.voucherRepository.findOneBy({
        group: { id: group.id },
        operator: { id: operator.id },
        player: {
          cid: player.cid,
          operatorId: player.operatorId,
        },
      });
      if (!checkExistVoucher) {
        const voucher = this.voucherRepository.create({
          expirationDate: moment()
            .add(1, 'week')
            .toDate(),
          operator,
          player,
          group,
          session,
        });
        await this.voucherRepository.insert(voucher);
      }
      updateUserData.isVoucherAwarded = true;
    }

    await this.playerRepository.update({
      cid: player.cid,
      operatorId: operator.id,
    }, updateUserData);
    await this.sessionDataManager.updateSessionData({ loginOptions }, session.id);
    this.monitoringClient.sendEventLogMessage({
      eventType: EventType.SESSION_CREATED,
      source: EventSource.GAME,
      params: {
        sessionId: session.id,
        machineSerial: machine.serial,
        groupId: group.id,
        videoUrl: JSON.stringify(streams),
      },
    });
    return this.loginReconnectDataMapper({
      session,
      player,
      machine,
      group,
      operator,
      streams,
    });
  }

  @Cache({ ttl: LOBBY_LONG_POLLING_INTERVAL_SEC - 1 }, args => (`lobby-request-${args[0].token}`))
  public async handleLobby({
    token,
    clicks,
    swipes,
  }: ConversionDto): Promise<ClawRouletteLobbyRes> {
    const {
      operatorId,
      cid,
    } = await this.authService.verifyAuthToken(token);
    const operator = await this.operatorRepository.findOneByOrFail({ id: operatorId })
      .catch(() => {
        throw new NotFoundException(`Operator id=${operatorId} not found!`);
      });
    const { sessionOptions } = await this.authService.getSessionOptions(token)
      .catch(() => {
        throw new UnauthorizedException('Token is stale or not valid!');
      });

    await this.conversionTracker.track({
      cid,
      operatorId,
    }, {
      clicks,
      swipes,
    });

    const convRate = await this.currencyConversionRepository.getCurrencyConversion(sessionOptions.currency);
    const { isVoucherAwarded } = await this.playerRepository.findOne({
      select: ['isVoucherAwarded'],
      where: {
        cid,
        operatorId,
      },
    });

    const groups = await this.groupRepository.getLobbyCommonData(operator.id, cid, GameId.CLAW_ROULETTE);
    return {
      groups: groups.map(group => ({
        groupId: group.groupId,
        groupName: group.groupName,
        groupDisplayName: group.groupDisplayName,
        queueLength: group.sessionCount,
        currency: convRate.currency,
        color: group.color,
        hasVoucher: Boolean(group.hasVoucher || (!isVoucherAwarded && group.isNewPlayerVoucher)),
      })),
    };
  }

  @CacheClear(args => sessionCacheKeyFactory(args[0]))
  public async verifyReconnect(sessionId: number, footprint: string): Promise<ClawRouletteReconnectVerifyRes> {
    const session = await this.sessionRepository.findOne({
      where: {
        id: sessionId,
        footprint,
      },
      relations: ['machine', 'machine.dispensers', 'machine.dispensers.chipType',
        'group', 'operator', 'player', 'rounds', 'machine.site', 'machine.cameras'],
    });
    if (!session
      || session.status === SessionStatus.TERMINATED
      || session.status === SessionStatus.TERMINATING
      || session.status === SessionStatus.COMPLETED) {
      const activeOrArchived = session || await this.authService.getArchiveSession(sessionId);
      if (activeOrArchived) {
        throw new NotificationException({
          notificationId: NotificationType.SESSION_COMPLETED,
          level: NotificationLevel.INFO,
          title: 'Session completed',
          message: 'Your session has been completed in autoplay mode',
          command: 'goToLobby',
          data: {
            totalWinInCash: activeOrArchived.totalWinInCash,
            currency: activeOrArchived.currency,
          },
        }, HttpStatus.GONE);
      }
      throw new NotFoundException('Session not found');
    }

    const {
      group,
      machine,
      player,
      operator,
    } = session;
    const activeRound = session.getActiveRound();

    const streams = await this.authService.getCamerasStreams(machine);

    return this.loginReconnectDataMapper<ClawRouletteReconnectVerifyRes>({
      session,
      player,
      machine,
      group,
      operator,
      streams,
      activeRound,
      isReconnect: true,
    });
  }

  private async loginReconnectDataMapper<T extends ClawRouletteVerifyRes | ClawRouletteReconnectVerifyRes>(
    params: LoginReconnectDto,
  ): Promise<T> {
    const {
      session,
      player,
      machine,
      group,
      operator,
      streams,
      activeRound,
      isReconnect,
    } = params;
    const { configuration: config } = session;

    const chipConfig = config.chipConfig.map(val => ({
      ...val,
      valueInCash: toCash(val.value, session.currencyConversionRate),
    }));
    const minBetTable = toCash(config.betLimits.tableMin, session.currencyConversionRate);
    const maxBetTable = toCash(config.betLimits.tableMax, session.currencyConversionRate);
    const limitsAndPayouts = Object.entries(config.betLimits.maxByType)
      .reduce((acc, [type, limit]) => {
        acc[type] = {
          min: minBetTable,
          max: toCash(limit, session.currencyConversionRate),
          winMultiplier: winMultiplierMap[type],
        };
        return acc;
      }, {
        table: {
          min: minBetTable,
          max: maxBetTable,
        },
      });

    let result: ClawRouletteVerifyRes | ClawRouletteReconnectVerifyRes = {
      playerId: player.cid,
      sessionId: session.id,
      gameId: session.gameId,
      settings: player.settings[session.gameId],
      sessionStatus: session.status,
      balance: await this.authService.getBalance(session, operator, player),
      currency: session.currency,
      locale: session.locale,
      playerDirectRoomId: sessionRoomNameFactory(session.id),
      robotDirectRoomId: getRobotDirectRoom(machine.serial, `${session.id}`),
      robotQueueRoomId: getRobotQueueRoom(machine.serial),
      video: {
        streams,
        streamAuthToken: await this.authService.getStreamAuthToken(session),
        cropConfig: config.videoCrop,
      },
      machineId: machine.id,
      machineName: machine.name,
      groupName: group.name,
      groupDisplayName: group.groupDisplayName,
      activeRound: activeRound && _.pick(activeRound, 'type', 'voucherId', 'bet', 'wins'),
      groupColor: group.color,
      machineSerial: machine.serial,
      operatorId: operator.id,
      groupId: group.id,
      chipConfig,
      currentBets: await this.betManager.getBet(session.machine.serial, session.id),
      ballHistory: await this.getBallHistory(session.machine.serial),
      limitsAndPayouts,
    };

    if (isReconnect) {
      await this.playerClientService.forceClientClose(session.id);
      const { lastWinInCash } = await this.sessionDataManager.getSessionData(session.id);
      result = {
        ...result,
        sessionStatus: session.status,
        rounds: session.roundsLeft,
        queueToken: getSessionHash(session),
        joinRobotDirectRoom: (session.status !== SessionStatus.VIEWER_BET_BEHIND),
        totalWin: session.totalWinInCash,
        lastWinInCash,
      };
    }
    return result as T;
  }

  private async getTargetForSession(groupId: number, player: PlayerId): Promise<{ group: GroupEntity, machine: MachineEntity }> {
    const group = await this.groupRepository.findOneOrFail({
      where: { id: groupId },
      relations: ['groupToOperator', 'groupToOperator.operator'],
    });

    const maxSessionsThreshold = this.authService.getMaxSessionsThreshold(group.configuration.maxSessionsThreshold);
    const machineData = await this.machineRepository.getMachineForNewSession(group.id, maxSessionsThreshold, player);

    if (!machineData) {
      throw new NotAcceptableException('No machine for session');
    }
    return {
      group,
      machine: machineData.machine,
    };
  }

  private async getBallHistory(serial: string): Promise<RouletteField[]> {
    const res = await this.gameStateManager.getGameState(serial);
    return res.context.resultHistory;
  }
}
