import { CommandType } from '@lib/common';
import {
  GameId, MachineRepository, MachineStatus, QueueRepository, QueueStatus, SessionEndReason, SessionRepository,
} from '@lib/dal';
import { RpcException } from '@nestjs/microservices';
import { CommandPublisher } from '../../command/command.publisher';
import { RouletteEventCommand } from '../../command/dto/roulette.event.command';
import { BetManager } from '../bet.manager';
import { CommonContext, PhaseResult, RouletteHardStopData } from '../types';
import { RouletteEventHandler } from './event.handler.interface';
import { StateMachineStatus } from '../enums';
import { RobotClientService } from '../../robot.client/robot.client.service';

export abstract class PhaseHandler implements RouletteEventHandler {
  protected constructor(
    protected readonly commandPublisher: CommandPublisher,
    protected readonly betManager: BetManager,
    protected readonly sessionRepo: SessionRepository,
    protected readonly machineRepo: MachineRepository,
    protected readonly robotPublisher: RobotClientService,
    protected readonly queueRepo: QueueRepository,
  ) {
  }

  public abstract onStart(context: CommonContext): Promise<PhaseResult>;

  public abstract onComplete(context: CommonContext): Promise<void>;

  public abstract onError(context: CommonContext): Promise<void>;

  public async onEvent(context: CommonContext, event: RouletteEventCommand): Promise<void> {
    const handler: (context: CommonContext, event: RouletteEventCommand) => void | Promise<void> = Reflect
      .get(this, event.eventType);
    await handler.call(this, context, event);
  }

  public async playerQuit(
    { serial }: CommonContext,
    { data: { sessionId } }: RouletteEventCommand<{ sessionId: number }>,
  ): Promise<void> {
    this.finalizeSession(serial, sessionId, SessionEndReason.QUIT);
  }

  public roundResult(context: CommonContext, event: RouletteEventCommand): void | Promise<void> {
    throw new RpcException('Event handler not found');
  }

  public placeBet(context: CommonContext, event: RouletteEventCommand): void | Promise<void> {
    throw new RpcException('Event handler not found');
  }

  public removeBet(context: CommonContext, event: RouletteEventCommand): void | Promise<void> {
    throw new RpcException('Event handler not found');
  }

  public async softStop(context: CommonContext): Promise<void> {
    context.softStop = true;
  }

  public async hardStop(context: CommonContext, event: RouletteEventCommand<RouletteHardStopData>): Promise<void> {
    const ids = await this.sessionRepo.getSessionIdsForMachine(context.serial, false);
    await this.machineRepo.update(context.machineId,
      {
        status: MachineStatus.SHUTTING_DOWN,
        shutdownReason: event.data.reason,
      });

    await this.queueRepo.update({ machine: { id: context.machineId } }, { status: QueueStatus.STOPPED });

    context.status = StateMachineStatus.STOPPED;

    await this.onHardStop(context, ids);
    await this.robotPublisher.sendStopMessage(context.serial, event.data.reason);
  }

  public cancelBet(context: CommonContext, event: RouletteEventCommand): void | Promise<void> {
    throw new RpcException('Event handler not found');
  }

  public doubleBet(context: CommonContext, event: RouletteEventCommand): void | Promise<void> {
    throw new RpcException('Event handler not found');
  }

  public userJoin(context: CommonContext, event: RouletteEventCommand): void | Promise<void> {
    return undefined;
  }

  public reassign(context: CommonContext, event: RouletteEventCommand): void | Promise<void> {
    return undefined;
  }

  public tableImage(context: CommonContext, event: RouletteEventCommand): void | Promise<void> {
    throw new RpcException('Event handler not found');
  }

  protected finalizeSession(serial: string, sessionId: number[] | number, reason: SessionEndReason, terminate = false): void {
    const sessionIds = Array.isArray(sessionId) ? sessionId : [sessionId];
    sessionIds.forEach(sessionId => {
      this.betManager.removeBet(serial, sessionId);
      this.commandPublisher.finalizeSession({
        type: CommandType.FINALIZE_SESSION,
        gameId: GameId.CLAW_ROULETTE,
        sessionId,
        terminate,
        reason,
      });
    });
  }

  protected terminateSession(serial: string, sessionId: number[] | number, reason: SessionEndReason): void {
    const sessionIds = Array.isArray(sessionId) ? sessionId : [sessionId];
    sessionIds.forEach(sessionId => {
      this.betManager.removeBet(serial, sessionId);
      this.commandPublisher.terminateSession({
        type: CommandType.TERMINATE_SESSION,
        gameId: GameId.CLAW_ROULETTE,
        terminate: true,
        sessionId,
        reason,
      });
    });
  }

  protected onHardStop(context: CommonContext, ids: number[]): void {
    this.terminateSession(context.serial, ids, SessionEndReason.MACHINE_STOP);
  }
}
