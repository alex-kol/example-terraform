import { CommandType } from '@lib/common';
import { GameId } from '@lib/dal';
import { IsEnum, Length } from 'class-validator';

export class RouletteCommand {
  @IsEnum(CommandType)
  public type: CommandType;

  @Length(3, 100)
  public serial: string;

  @IsEnum(GameId)
  public gameId?: GameId;
}
