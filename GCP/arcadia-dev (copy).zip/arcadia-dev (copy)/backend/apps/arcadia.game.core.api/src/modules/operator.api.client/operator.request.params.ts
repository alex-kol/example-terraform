import { GameId, OperatorEntity } from '@lib/dal';

export class OperatorRequestParams {
  operator: OperatorEntity;
  accessToken: string;
  gameId: GameId;
  extGameId: string;
  correlationId: string;
}