export interface ChipMessageInterface {
  type: string;
  currencyValue?: number;
}
