import {
  CommandType,
  LoggerInterceptor,
  NewrelicAndMessagePattern,
  RmqQueueName,
  rmqRoutingGenerate,
  RobotMessageType,
  RpcMainExceptionFilter,
  rpcValidationExceptionFactory,
} from '@lib/common';
import { GameId } from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import {
  Controller, Inject, Scope, UseFilters, UseInterceptors, UsePipes, ValidationPipe,
} from '@nestjs/common';
import { Payload } from '@nestjs/microservices';
import { Logger } from 'winston';
import { BaseCommand } from '../../command/dto/base.command';
import { BbRollbackCommand } from '../../command/dto/bb.rollback.command';
import { BetBehindWinCommand } from '../../command/dto/bet.behind.win.command';
import { SessionInjectorPipe } from '../session.injector.pipe';
import { BbRoundEndHandler } from './bb.round.end.handler';
import { BbRoundRollbackHandler } from './bb.round.rollback.handler';
import { BbRoundStartHandler } from './bb.round.start.handler';
import { BbWinHandler } from './bb.win.handler';
import { ChipDetectionHandler } from './chip.detection.handler';
import { ChipDropHandler } from './chip.drop.handler';
import { ChipDropNoSessionHandler } from './chip.drop.no.session.handler';
import { CoinShotHandler } from './coin.shot.handler';
import { RobotChipDropDto, RobotCoinDto, RobotMessage } from './dto';
import { RoundEndHandler } from './round.end.handler';

@Controller({
  path: 'v1/transactional',
  scope: Scope.REQUEST,
})
@UseInterceptors(LoggerInterceptor)
@UseFilters(RpcMainExceptionFilter)
@UsePipes(new ValidationPipe({
  transform: true,
  whitelist: true,
  exceptionFactory: rpcValidationExceptionFactory,
}), SessionInjectorPipe)
export class TransactionalController {
  constructor(
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly coinShotHandler: CoinShotHandler,
    private readonly chipDropHandler: ChipDropHandler,
    private readonly chipDropNoSessionHandler: ChipDropNoSessionHandler,
    private readonly chipDetectionHandler: ChipDetectionHandler,
    private readonly bbRoundEndHandler: BbRoundEndHandler,
    private readonly bbRoundStartHandler: BbRoundStartHandler,
    private readonly bbRoundRollbackHandler: BbRoundRollbackHandler,
    private readonly bbWinHandler: BbWinHandler,
    private readonly roundEndHandler: RoundEndHandler,
  ) {
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.COIN, GameId.COIN_PUSHER_V1))
  public async coinShot(@Payload() data: RobotCoinDto): Promise<void> {
    await this.coinShotHandler.handle(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.CHIP_DROP, GameId.COIN_PUSHER_V1))
  public async chipDrop(@Payload() data: RobotChipDropDto): Promise<void> {
    if (!data.sessionId) {
      this.logger.debug('Chip drop out of session', { rfid: data.rfid, machineSerial: data.serial });
      await this.chipDropNoSessionHandler.handle(data);
      return;
    }
    await this.chipDropHandler.handle(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.CHIP_DETECTION, GameId.COIN_PUSHER_V1))
  public async chipDetection(@Payload() data: RobotMessage): Promise<void> {
    if (!data.sessionId) {
      this.logger.debug('Chip detection out of session', { machineSerial: data.serial });
      return;
    }
    await this.chipDetectionHandler.handle(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.CORE_COMMAND_QUEUE, CommandType.BET_BEHIND_ROUND_END, GameId.COIN_PUSHER_V1))
  public async bbRoundEnd(@Payload() data: BaseCommand): Promise<void> {
    await this.bbRoundEndHandler.handle(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.CORE_COMMAND_QUEUE, CommandType.BET_BEHIND_ROUND_START, GameId.COIN_PUSHER_V1))
  public async bbRoundStart(@Payload() data: BaseCommand): Promise<void> {
    await this.bbRoundStartHandler.handle(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.CORE_COMMAND_QUEUE, CommandType.BET_BEHIND_WIN, GameId.COIN_PUSHER_V1))
  public async bbWin(@Payload() data: BetBehindWinCommand): Promise<void> {
    await this.bbWinHandler.handle(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.CORE_COMMAND_QUEUE, CommandType.BET_BEHIND_ROUND_ROLLBACK, GameId.COIN_PUSHER_V1))
  public async bbRoundRollback(@Payload() data: BbRollbackCommand): Promise<void> {
    await this.bbRoundRollbackHandler.handle(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.CORE_COMMAND_QUEUE, CommandType.ROUND_END, GameId.COIN_PUSHER_V1))
  public async roundEnd(@Payload() data: BaseCommand): Promise<void> {
    await this.roundEndHandler.handle(data);
  }
}
