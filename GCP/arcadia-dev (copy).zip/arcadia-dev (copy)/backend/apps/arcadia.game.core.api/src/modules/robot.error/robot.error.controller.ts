import {
  LoggerInterceptor,
  NewrelicAndMessagePattern,
  RmqQueueName,
  rmqRoutingGenerate,
  RobotMessageType,
  RpcMainExceptionFilter,
  rpcValidationExceptionFactory,
} from '@lib/common';
import { GameId } from '@lib/dal';
import {
  Controller, UseFilters, UseInterceptors, UsePipes, ValidationPipe,
} from '@nestjs/common';
import { Payload } from '@nestjs/microservices';
import { RobotErrorHandler } from './robot.error.handler';
import { RobotErrorMessage } from './robot.error.message';

@Controller('v1/robotError')
@UseInterceptors(LoggerInterceptor)
@UseFilters(RpcMainExceptionFilter)
@UsePipes(new ValidationPipe({
  transform: true,
  whitelist: true,
  exceptionFactory: rpcValidationExceptionFactory,
}))
export class RobotErrorController {
  constructor(
    private readonly errorHandler: RobotErrorHandler,
  ) {
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.ERROR, GameId.COMMON))
  public async robotError(@Payload() data: RobotErrorMessage): Promise<void> {
    await this.errorHandler.handleError(data);
  }
}
