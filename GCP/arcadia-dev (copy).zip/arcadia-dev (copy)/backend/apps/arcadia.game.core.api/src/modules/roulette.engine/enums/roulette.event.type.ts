export enum RouletteEventType {
  ROUND_RESULT = 'roundResult',
  PLAYER_QUIT = 'playerQuit',
  SOFT_STOP = 'softStop',
  HARD_STOP = 'hardStop',
  PLACE_BET = 'placeBet',
  REMOVE_BET = 'removeBet',
  CANCEL_BET = 'cancelBet',
  DOUBLE_BET = 'doubleBet',
  USER_JOIN = 'userJoin',
  REASSIGN = 'reassign',
  TABLE_IMAGE = 'tableImage',
}
