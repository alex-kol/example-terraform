import { FailedTransactionRepository, RoundArchiveRepository, TransactionType } from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { Inject, Injectable, UnprocessableEntityException } from '@nestjs/common';
import { v4 as uuidv4 } from 'uuid';
import { Logger } from 'winston';
import { Between } from 'typeorm';
import moment from 'moment';
import { BalanceData } from '../operator.api.client/dtos';
import { OperatorApiClientService } from '../operator.api.client/operator.api.client.service';

@Injectable()
export class TransactionRetryService {
  constructor(
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly failedTransactionRepo: FailedTransactionRepository,
    private readonly roundArchiveRepository: RoundArchiveRepository,
    private readonly operatorApiClient: OperatorApiClientService,
  ) {
  }

  public async retryTransaction(transactionId: number, correlationId: string = uuidv4()): Promise<{ transactionId: number }> {
    const {
      player,
      operator,
      type,
      roundId,
      sessionToken,
      originalTransactionId,
      amountInCash,
      gameId,
      extGameId,
      createDate,
    } = await this.failedTransactionRepo.findOneOrFail({
      where: { id: transactionId },
      relations: ['player', 'operator'],
    });
    try {
      let retryResult: BalanceData;
      switch (type) {
        case TransactionType.BET:
          retryResult = await this.operatorApiClient.bet({
            accessToken: sessionToken,
            operator,
            cid: player.cid,
            amount: amountInCash,
            roundId,
            correlationId,
            isRetry: true,
            gameId,
            extGameId,
          });
          break;
        case TransactionType.CANCEL_BET:
          retryResult = await this.operatorApiClient.cancelBet({
            accessToken: sessionToken,
            operator,
            cid: player.cid,
            amount: amountInCash,
            roundId,
            transactionId: originalTransactionId,
            correlationId,
            isRoundFinish: true,
            isRetry: true,
            gameId,
            extGameId,
          });
          break;
        case TransactionType.PAYOUT:
          retryResult = await this.operatorApiClient.payout({
            accessToken: sessionToken,
            operator,
            cid: player.cid,
            amount: amountInCash,
            roundId,
            transactionId: originalTransactionId,
            correlationId,
            isRoundFinish: true,
            isRetry: true,
            gameId,
            extGameId,
          });
          break;
        default:
      }
      await this.roundArchiveRepository.update(
        {
          id: Number(roundId),
          endDate: Between(moment(createDate).subtract(3, 'hours').toDate(), moment(createDate).add(3, 'hours').toDate()),
        },
        { finalBalance: retryResult.balance },
      );
      return { transactionId };
    } catch (err) {
      this.logger.error('Transaction retry failed', {
        transactionId,
        error: err.response?.data || err.message,
      });
      throw new UnprocessableEntityException(err.response?.data || err.message);
    }
  }
}
