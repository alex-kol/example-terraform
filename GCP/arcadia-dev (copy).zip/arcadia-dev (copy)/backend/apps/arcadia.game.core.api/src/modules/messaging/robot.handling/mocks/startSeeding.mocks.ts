export const startSeedingMachineMock = {
  id: 1,
  serial: '<serial>',
  group: {
    id: 42,
    configuration: {
      minimal_hold: {
        value: 322,
      },
    },
  },
  dispensers: [
    {
      name: 'd1',
      chipType: { name: 'a' },
      capacity: 100,
      level: 99,
    },
    {
      name: 'd2',
      chipType: { name: 'b' },
      capacity: 50,
      level: 99,
    }
  ],
  chips: [
    {
      rfid: '<rfid>',
      type: {
        id: 1,
        name: 'a',
      },
    },
  ],
  configuration: {
    rtpSegment: '<rtpSegment>',
  },
  queue: { status: '<status>' },
};

export function shouldPushChips(spyTargets: any): void {
  jest.spyOn(spyTargets.machineRepository, 'findOneOrFail').mockResolvedValue(startSeedingMachineMock);
  jest.spyOn(spyTargets.rngService, 'seed').mockResolvedValue({ a: 5, b: 10 });
  jest.spyOn(spyTargets.configValidator, 'getValidatedConfig').mockResolvedValue({ minimalHold: { value: 1 }, reshuffleCoinsNonEmpty: 4 });
}
