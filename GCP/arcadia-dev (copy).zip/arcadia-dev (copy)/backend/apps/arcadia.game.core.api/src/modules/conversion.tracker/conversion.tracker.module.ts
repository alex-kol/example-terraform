import { Module } from '@nestjs/common';
import { MonitoringWorkerClientModule } from '@lib/monitoring.worker.client';
import { WorkerClientModule } from '../worker.client/worker.client.module';
import { ConversionTracker } from './conversion.tracker';

@Module({
  imports: [WorkerClientModule, MonitoringWorkerClientModule],
  providers: [ConversionTracker],
  exports: [ConversionTracker],
})
export class ConversionTrackerModule {

}