export class CoinCountTrackingState {
  queueId: number;
  coins: number;
  stackSize: number;
  roundId: number;
  machineSerial: string;
  machineId: number;
  bbRoundDurationInStack: number;
  correlationId: string;
  enabledBetBehind: boolean;
}
