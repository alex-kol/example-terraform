import {
  AlertDescription, CommandType, EventSource, TimeoutType,
} from '@lib/common';
import {
  AlertAction,
  AlertSeverity,
  AlertSource,
  AlertType,
  EventType,
  GameId,
  MachineRepository,
  SessionEndReason,
  ShutdownReason,
} from '@lib/dal';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { Injectable } from '@nestjs/common';
import { engageLockKeyFactory } from '../../util';
import { CommandPublisher } from '../command/command.publisher';
import { GroupTerminatorService } from '../group.terminator/group.terminator.service';
import { WorkerClientService } from '../worker.client/worker.client.service';
import { RobotError } from './robot.error';
import { RobotErrorMessage } from './robot.error.message';

@Injectable()
export class RobotErrorHandler {
  constructor(
    private readonly machineRepository: MachineRepository,
    private readonly groupTerminator: GroupTerminatorService,
    private readonly monitoringClient: MonitoringWorkerClientService,
    private readonly workerClient: WorkerClientService,
    private readonly commandPublisher: CommandPublisher,
    private readonly cacheManager: RedisCacheService,
  ) {
  }

  public async handleError({
    serial,
    module,
    error,
    details,
    sessionId,
    gameId,
    correlationId,
  }: RobotErrorMessage): Promise<void> {
    const machine = await this.machineRepository.findOneOrFail({
      where: { serial },
      relations: ['group'],
    });

    this.monitoringClient.sendRobotEventLogMessage({
      eventType: EventType.ROBOT_ERROR,
      source: EventSource.ROBOT,
      params: {
        gameId,
        sessionId,
        machineSerial: serial,
        additionalInfo: {
          module,
          error,
          details,
        },
      },
    });
    this.monitoringClient.sendAlertMessage({
      alertType: AlertType.MAINTENANCE,
      severity: AlertSeverity.HIGH,
      source: AlertSource.GAME_CORE,
      description: `Robot error: ${module} - ${error}`,
      gameId: machine.gameId,
      details: {
        machineId: machine.id,
        machineName: machine.name,
        machineSerial: machine.serial,
        module,
        error,
        details,
      },
    });

    switch (error) {
      case RobotError.CHIP_DROPPED_AGAIN:
        break;
      case RobotError.DOOR_OPENED:
        break;
      case RobotError.NO_ENGAGEMENT:
        await this.monitoringClient.sendEventLogMessage({
          eventType: EventType.LOST_CONNECTION,
          source: EventSource.ROBOT,
          params: {
            sessionId,
            machineSerial: machine.serial,
          },
        });
        if (sessionId) {
          await this.workerClient.timeoutStop({
            timeoutType: TimeoutType.ENGAGE,
            sessionId,
            payload: { gameId: machine.gameId },
          }, correlationId);
          this.commandPublisher.terminateSession({
            type: CommandType.TERMINATE_SESSION,
            gameId: GameId.COIN_PUSHER_V1,
            sessionId,
            terminate: true,
            reason: SessionEndReason.NO_ENGAGEMENT,
          }, correlationId);
        }
        await this.cacheManager.del(engageLockKeyFactory(machine.id));
        break;
      case RobotError.NETWORKING:
        if (details.text === 'Clear table') {
          this.monitoringClient.sendAlertMessage({
            alertType: AlertType.INFORMATION,
            severity: AlertSeverity.CRITICAL,
            source: AlertSource.GAME_CORE,
            description: AlertDescription.NETWORK_ERROR_DURING_DISPENSING,
            gameId: machine.gameId,
            action: AlertAction.DISMISS,
            details: {
              machineId: machine.id,
              machineName: machine.name,
              machineSerial: machine.serial,
              attribution: 'Clear table',
            },
          });
        } else {
          break;
        }
      // eslint-disable-next-line no-fallthrough
      case RobotError.DISPENSING_FAILED:
      case RobotError.MOTOR_OVERLOAD:
      case RobotError.MOTOR_FAILURE:
      case RobotError.ACTION_TIMEOUT:
      case RobotError.CPU_OVERHEAT:
      default:
        await this.groupTerminator.groupHardStop(machine.gameId, machine.group.id, {
          reason: ShutdownReason.ROBOT_ERROR,
          machineIds: [machine.id],
        }, correlationId);
    }
  }
}
