import { EventSource, TimeoutType } from '@lib/common';
import { ConfigService } from '@lib/config';
import {
  EventType, GameId, MachineRepository, QueueRepository, SessionEndReason, SessionRepository,
} from '@lib/dal';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Injectable } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import BigNumber from 'bignumber.js';
import moment from 'moment';
import {
  concatMap, count, firstValueFrom, from,
} from 'rxjs';
import { reduce } from 'rxjs/operators';
import { toCash } from '../../../util';
import { CommandPublisher } from '../../command/command.publisher';
import { RouletteEventCommand } from '../../command/dto/roulette.event.command';
import { NotificationLevel } from '../../player.client/notification.level';
import { NotificationType } from '../../player.client/notification.type';
import { PlayerClientService } from '../../player.client/player.client.service';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { SessionDataManager } from '../../session.data.manager/session.data.manager';
import { WorkerClientService } from '../../worker.client/worker.client.service';
import { BetManager } from '../bet.manager';
import { winPositionTypeMap } from '../constants/win.position.type.map';
import { BetPosition, GamePhase, PhaseStatus } from '../enums';
import {
  BetEvent, CommonContext, PhaseResult, RouletteBet,
} from '../types';
import { PhaseHandler } from './phase.handler';

@Injectable()
export class BetsOpenPhaseHandler extends PhaseHandler {
  private readonly rouletteBetOpenDurationSec: number;

  constructor(
    commandPublisher: CommandPublisher,
    betManager: BetManager,
    private readonly workerClient: WorkerClientService,
    private readonly playerPublisher: PlayerClientService,
    machineRepo: MachineRepository,
    sessionRepo: SessionRepository,
    robotPublisher: RobotClientService,
    private readonly monitoringPublisher: MonitoringWorkerClientService,
    private readonly sessionDataManager: SessionDataManager,
    queueRepo: QueueRepository,
    private readonly configService: ConfigService,
  ) {
    super(
      commandPublisher,
      betManager,
      sessionRepo,
      machineRepo,
      robotPublisher,
      queueRepo,
    );
    this.rouletteBetOpenDurationSec = this.configService.get(['core', 'ROULETTE_BET_OPEN_DURATION_SEC']);
  }

  public async onStart({ serial }: CommonContext): Promise<PhaseResult> {
    await this.robotPublisher.sendRouletteDisplayMessage(serial, { phase: GamePhase.BETS_OPEN });
    const ids = await this.sessionRepo.getSessionIdsForMachine(serial, true);
    const endTimestamp = moment()
      .add(this.rouletteBetOpenDurationSec, 'second')
      .toISOString();
    const message = {
      phase: GamePhase.BETS_OPEN,
      endTimestamp,
    };
    ids.forEach(id => this.playerPublisher.gamePhase(id, message));
    await this.workerClient.timeoutStart({
      timeoutType: TimeoutType.PHASE_END,
      machineSerial: serial,
      payload: { phase: GamePhase.BETS_OPEN, gameId: GameId.CLAW_ROULETTE },
      timeoutSec: this.rouletteBetOpenDurationSec,
    });
    return {
      status: PhaseStatus.IN_PROGRESS,
      endTimestamp,
    };
  }

  public async onComplete({
    serial,
    machineId,
  }: CommonContext): Promise<void> {
    const [sessions, betters] = await Promise.all([
      this.sessionRepo.findBy({ machine: { id: machineId } }),
      firstValueFrom(this.betManager.getMachineBets(serial)
        .pipe(
          reduce((acc, bet) => {
            const totalBet = Object.values(bet.bet)
              .flat()
              .reduce((acc, value) => acc.plus(value), new BigNumber(0));
            acc.set(bet.sessionId, totalBet);
            return acc;
          }, new Map<number, BigNumber>()),
        ),
      ),
    ]);

    await firstValueFrom(from(sessions)
      .pipe(
        concatMap(async ({
          id: sessionId,
          configuration,
          isDisconnected,
        }) => {
          const bet = betters.get(Number(sessionId));
          if (!bet) {
            this.playerPublisher.gamePhase(sessionId, { phase: GamePhase.GAME_INIT });
            return sessionId;
          }
          if (isDisconnected) {
            await this.betManager.removeBet(serial, sessionId);
            return sessionId;
          }
          if (bet.lt(configuration.betLimits.tableMin)) {
            await this.betManager.removeBet(serial, sessionId);
            this.playerPublisher.gamePhase(sessionId, { phase: GamePhase.GAME_INIT });
            this.playerPublisher.notification(sessionId, {
              notificationId: NotificationType.BET_CANCEL,
              level: NotificationLevel.WARNING,
              title: 'Bet cancelled',
              message: 'Your bet violates table limits',
            });
            return sessionId;
          }
          this.playerPublisher.gamePhase(sessionId, { phase: GamePhase.BETS_CLOSED });
          return sessionId;
        }),
        count(),
      ));
  }

  public onError(): Promise<void> {
    return Promise.resolve();
  }

  public async placeBet({ serial }: CommonContext, {
    data: {
      sessionId,
      bet,
      currencyConversionRate,
      betLimits,
    },
  }: RouletteEventCommand<BetEvent>): Promise<void> {
    const roundBet = await this.betManager.getBet(serial, sessionId);
    let currentBet = roundBet?.bet;
    const history = roundBet?.history ?? [];
    history.unshift(bet);
    if (currentBet) {
      (Object.entries(bet) as [BetPosition, number[]][])
        .forEach(([position, bets]) => {
          if (currentBet[position]) {
            currentBet[position].push(...bets);
          } else {
            currentBet[position] = bets;
          }
        });
    } else {
      currentBet = bet;
    }

    const betsInCash: Record<string, number> = {};
    const totalBet = Object.entries(currentBet)
      .map(([position, bets]) => {
        const betSum = bets.reduce((acc, bet) => acc.plus(bet), new BigNumber(0));
        if (betSum.gt(betLimits.maxByType[winPositionTypeMap[position]])) {
          this.playerPublisher.notification(sessionId, {
            notificationId: NotificationType.BET_LIMIT_EXCEEDED,
            level: NotificationLevel.WARNING,
            title: 'Bet limit exceeded',
            message: 'One or more of your bets has exceeded the table limits',
          });
          throw new RpcException('Position bet limit exceeded');
        }
        betsInCash[position] = toCash(betSum, currencyConversionRate);
        return betSum;
      })
      .reduce((acc, bet) => acc.plus(bet), new BigNumber(0));

    if (totalBet.gt(betLimits.tableMax)) {
      this.playerPublisher.notification(sessionId,
        {
          notificationId: NotificationType.BET_LIMIT_EXCEEDED,
          level: NotificationLevel.WARNING,
          title: 'Bet limit exceeded',
          message: 'One or more of your bets has exceeded the table limits',
        });
      throw new RpcException('Total bet limit exceeded');
    }

    await this.betManager.setBet(serial, sessionId, {
      bet: currentBet,
      history,
    });

    this.monitoringPublisher.sendEventLogMessage({
      eventType: EventType.BET_PLACED,
      source: EventSource.GAME,
      params: {
        sessionId,
        machineSerial: serial,
        bet,
      },
    });
    this.playerPublisher.rouletteCurrentBet(sessionId, {
      bet: betsInCash,
      totalInCash: toCash(totalBet, currencyConversionRate),
    });
  }

  public async doubleBet(context: CommonContext, event: RouletteEventCommand<BetEvent>): Promise<void> {
    let repeatOrDouble: RouletteBet;
    const roundBet = await this.betManager.getBet(context.serial, event.data.sessionId);
    if (roundBet) {
      repeatOrDouble = roundBet.bet;
    } else {
      const { lastBet } = await this.sessionDataManager.getSessionData(event.data.sessionId);
      repeatOrDouble = lastBet;
    }
    if (repeatOrDouble) {
      // eslint-disable-next-line no-param-reassign
      event.data.bet = repeatOrDouble;
      await this.placeBet(context, event);
    } else {
      throw new RpcException('Nothing to double');
    }
  }

  public async removeBet({ serial }: CommonContext, {
    data: {
      sessionId,
      currencyConversionRate,
    },
  }: RouletteEventCommand<BetEvent>): Promise<void> {
    const roundBet = await this.betManager.getBet(serial, sessionId);
    if (!roundBet) {
      throw new RpcException('No bet');
    }
    const {
      bet: currentBet,
      history,
    } = roundBet;
    const bet = history.shift();

    (Object.entries(bet) as [BetPosition, number[]][])
      .forEach(([position, betsToRemove]) => {
        const existingBets = currentBet[position];
        if (existingBets) {
          betsToRemove.forEach(bet => {
            const index = existingBets.lastIndexOf(bet);
            (index !== -1) && existingBets.splice(index, 1);
          });
          if (existingBets.length) {
            currentBet[position] = existingBets;
          } else {
            delete currentBet[position];
          }
        }
      });

    const betInCash = this.betManager.getBetInCash(currentBet, currencyConversionRate);

    if (betInCash.totalInCash) {
      await this.betManager.setBet(serial, sessionId, {
        bet: currentBet,
        history,
      });
    } else {
      await this.betManager.removeBet(serial, sessionId);
    }

    this.monitoringPublisher.sendEventLogMessage({
      eventType: EventType.BET_REMOVED,
      source: EventSource.GAME,
      params: {
        sessionId,
        machineSerial: serial,
        bet,
      },
    });
    this.playerPublisher.rouletteCurrentBet(sessionId, betInCash);
  }

  public async cancelBet(
    { serial }: CommonContext,
    { data: { sessionId } }: RouletteEventCommand<{ sessionId: number }>,
  ): Promise<void> {
    const roundBet = await this.betManager.getBet(serial, sessionId);
    await this.betManager.removeBet(serial, sessionId);
    this.monitoringPublisher.sendEventLogMessage({
      eventType: EventType.BET_REMOVED,
      source: EventSource.GAME,
      params: {
        sessionId,
        machineSerial: serial,
        bet: roundBet?.bet,
      },
    });
    this.playerPublisher.rouletteCurrentBet(sessionId, {
      bet: null,
      totalInCash: 0,
    });
  }

  protected onHardStop(context: CommonContext, ids: number[]): void {
    this.finalizeSession(context.serial, ids, SessionEndReason.MACHINE_STOP);
  }
}
