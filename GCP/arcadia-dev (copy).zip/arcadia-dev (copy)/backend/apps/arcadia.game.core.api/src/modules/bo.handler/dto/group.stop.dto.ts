import { ShutdownReason } from '@lib/dal';
import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray, IsEnum, IsInt, IsOptional,
} from 'class-validator';

export class GroupStopDto {
  @ApiProperty()
  @IsOptional()
  @IsArray()
  @IsInt({ each: true })
  public machineIds: number[];

  @ApiProperty()
  @IsOptional()
  @IsEnum(ShutdownReason)
  public reason: ShutdownReason;
}
