import { CommandType, EventSource } from '@lib/common';
import {
  EventType, GameId, MachineEntity, MachineRepository, MachineStatus, SessionEndReason, SessionStatus,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Inject, Injectable, Scope } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { Logger } from 'winston';
import { CommandPublisher } from '../command/command.publisher';
import { ChangeQueueCommand } from '../command/dto/change.queue.command';
import { QueueUpdatesCommand } from '../command/dto/queue.updates.command';
import { SessionContextHandler } from '../command/session.context.handler';
import { PlayerClientService } from '../player.client/player.client.service';
import { SessionDataManager } from '../session.data.manager/session.data.manager';

@Injectable({ scope: Scope.REQUEST })
export class QueueChangeHandler extends SessionContextHandler<ChangeQueueCommand> {
  private ignoreMachines: number[];
  private ignoreGroups: number[];
  private newMachine: MachineEntity;
  private gameId: GameId;

  constructor(
    @Inject(MAIN_LOGGER) logger: Logger,
    private readonly machineRepo: MachineRepository,
    private readonly monitoringService: MonitoringWorkerClientService,
    private readonly playerClientService: PlayerClientService,
    private readonly sessionDataManager: SessionDataManager,
    private readonly commandPublisher: CommandPublisher,
    dataSource: DataSource,
  ) {
    super(logger, dataSource);
  }

  protected async init(data: ChangeQueueCommand): Promise<void> {
    await super.init(data);

    this.gameId = data.gameId;

    this.ignoreMachines = data.ignoreMachines;
    this.ignoreGroups = data.ignoreGroups;

    this.session = await this.sessionRepository.findOneByOrFail({ id: this.sessionId });
  }

  protected async handleEvent(): Promise<void> {
    const newMachine = await this.machineRepo.getShortestQueueMachine(
      this.cachedOperator.id, this.session.denominator, this.gameId, this.ignoreMachines, this.ignoreGroups,
    );
    if (!newMachine) {
      this.commandPublisher.finalizeSession({
        type: CommandType.FINALIZE_SESSION,
        gameId: this.gameId,
        sessionId: this.session.id,
        terminate: true,
        reason: SessionEndReason.MACHINE_STOP,
      }, this.correlationId);
      return;
    }
    this.newMachine = newMachine;

    let status = SessionStatus.VIEWER;
    let buyDate: Date = null;
    let { roundsLeft } = this.session;
    switch (this.session.status) {
      case SessionStatus.QUEUE:
      case SessionStatus.QUEUE_BET_BEHIND:
      case SessionStatus.PLAYING:
      case SessionStatus.FORCED_AUTOPLAY:
      case SessionStatus.AUTOPLAY:
        status = SessionStatus.QUEUE;
        buyDate = new Date();
        if (roundsLeft === 0) {
          roundsLeft = 1;
        }
        break;
      case SessionStatus.RE_BUY:
      case SessionStatus.VIEWER:
      case SessionStatus.VIEWER_BET_BEHIND:
        status = SessionStatus.VIEWER;
        roundsLeft = 0;
        buyDate = null;
        break;
      default:
    }
    await this.sessionRepository.update(this.session.id, {
      machine: newMachine,
      queue: newMachine.queue,
      group: newMachine.group,
      status,
      roundsLeft,
      buyDate,
      isDisconnected: true,
      lastDisconnectDate: new Date(),
    });
    await this.sessionDataManager.removeSessionData(['autoplay', 'betBehind'], this.session.id);
    this.playerClientService.forceReconnect(this.session.id);
    this.monitoringService.sendEventLogMessage({
      eventType: EventType.SWITCH_QUEUE,
      source: EventSource.GAME,
      params: {
        sessionId: this.session.id,
        machineSerial: newMachine.serial,
        gameId: this.gameId,
      },
    });
    this.commandPublisher.sendCommand<QueueUpdatesCommand>({
      type: CommandType.QUEUE_UPDATES,
      gameId: this.gameId,
      queueId: Number(this.cachedSession.queue.id),
      session: this.cachedSession,
    }, this.correlationId);
  }

  protected async onCommit(): Promise<void> {
    if (this.newMachine?.status === MachineStatus.READY) {
      this.commandPublisher.engageNextSession(
        {
          type: CommandType.ENGAGE_SESSION,
          gameId: this.gameId,
          machineId: this.newMachine.id,
          sessionId: this.sessionId, // needed for session locks
        },
        this.correlationId,
      );
    }
  }
}
