/* eslint-disable max-lines */
import { CommandType, EventSource, TimeoutType } from '@lib/common';
import {
  AlertSeverity,
  AlertSource,
  AlertType,
  EventType,
  GameId,
  PlayerRepository,
  RoundRepository,
  RoundStatus,
  SessionEndReason,
  SessionStatus,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Inject, Injectable, Scope } from '@nestjs/common';
import { DataSource, In } from 'typeorm';
import { Logger } from 'winston';
import { CommandPublisher } from '../command/command.publisher';
import { FinalizeSessionCommand } from '../command/dto/finalize.session.command';
import { SessionContextHandler } from '../command/session.context.handler';
import { OperatorApiClientService } from '../operator.api.client/operator.api.client.service';
import { PlayerClientService } from '../player.client/player.client.service';
import { RobotClientService } from '../robot.client/robot.client.service';
import { SessionDataManager } from '../session.data.manager/session.data.manager';
import { SessionDynamicData } from '../session.data.manager/session.dynamic.data';
import { WorkerClientService } from '../worker.client/worker.client.service';

@Injectable({ scope: Scope.REQUEST })
export class ClawSessionTerminator extends SessionContextHandler<FinalizeSessionCommand> {
  // transactional repos
  private roundRepo: RoundRepository;
  private playerRepo: PlayerRepository;

  private sessionData: SessionDynamicData = null;
  private terminate: boolean;
  private reason: SessionEndReason;

  constructor(
      @Inject(MAIN_LOGGER) logger: Logger,
      private readonly operatorClient: OperatorApiClientService,
      private readonly commandPublisher: CommandPublisher,
      private readonly monitoringWorkerClient: MonitoringWorkerClientService,
      private readonly coreWorkerClient: WorkerClientService,
      private readonly sessionDataManager: SessionDataManager,
      private readonly robotPublisher: RobotClientService,
      private readonly playerPublisher: PlayerClientService,
      dataSource: DataSource,
  ) {
    super(logger, dataSource);
  }

  public async init(data: FinalizeSessionCommand): Promise<void> {
    await super.init(data);
    this.terminate = !!data.terminate;
    this.reason = data.reason;

    // transactional repos init
    this.roundRepo = new RoundRepository(this.entityManager);
    this.playerRepo = new PlayerRepository(this.entityManager);

    this.session = await this.sessionRepository.findOneOrFail({
      where: { id: this.sessionId },
      relations: ['rounds'],
    });
    this.sessionData = await this.sessionDataManager.getSessionData(this.sessionId);
  }

  public async handleEvent(): Promise<void> {
    if (!this.sessionData.transaction) {
      if (this.terminate || this.session.isEngaged()) {
        await this.finalize();
      } else {
        this.changeQueue();
      }
      return;
    }
    await this.coreWorkerClient.timeoutStop({
      timeoutType: TimeoutType.ROUND_END_DELAY,
      sessionId: this.sessionId,
      payload: { gameId: this.cachedGroup.gameId },
    }, this.correlationId);

    const {
      loginOptions: {
        sessionToken,
        extGameId,
      },
      transaction: {
        roundId,
        transactionId,
        scatterRounds = [],
      },
    } = this.sessionData;

    const {
      bet,
      betInCash,
      win,
      winInCash,
    } = await this.roundRepo.getTransactionData([roundId, ...scatterRounds]);

    await this.terminateRounds([roundId, ...scatterRounds]);

    await this.sessionRepository.cancelBet({
      sessionId: this.sessionId,
      betInValue: bet,
      betInCash,
      wins: win,
      winInCash,
    });
    await this.playerRepo.cancelBet(this.cachedPlayer.cid, this.cachedOperator.id, bet, win);

    let finalBalance: number;

    try {
      finalBalance = (await this.operatorClient.cancelBet({
        accessToken: sessionToken,
        operator: this.cachedOperator,
        cid: this.cachedPlayer.cid,
        amount: betInCash,
        gameId: this.session.gameId,
        roundId,
        transactionId,
        extGameId,
        correlationId: this.correlationId,
      })).balance;
    } catch (e) {
      await this.onCancelBetError(e);
      return;
    }
    await this.roundRepo.update(roundId, { finalBalance });
    await this.sessionDataManager.removeSessionData(['transaction'], this.sessionId);
    await this.monitoringWorkerClient.sendEventLogMessage({
      eventType: EventType.CANCEL_BET,
      source: EventSource.GAME,
      params: {
        sessionId: this.sessionId,
        round: Number(roundId),
        machineId: this.cachedMachine.id,
        machineSerial: this.cachedMachine.serial,
        reason: this.reason,
      },
    });

    await this.finalize();
  }

  private async finalize(): Promise<void> {
    if (this.session.isEngaged()) {
      await this.disengage();
    } else {
      this.commandPublisher.finalizeSession({
        type: CommandType.FINALIZE_SESSION,
        gameId: GameId.CLAW,
        sessionId: this.sessionId,
        terminate: true,
        reason: this.reason,
      }, this.correlationId);
    }
  }

  private changeQueue(): void {
    this.commandPublisher.queueChange({
      type: CommandType.CHANGE_QUEUE,
      gameId: GameId.CLAW,
      sessionId: this.sessionId,
      ignoreMachines: [this.cachedMachine.id],
    }, this.correlationId);
  }

  private async disengage(): Promise<void> {
    await this.sessionRepository.update(
      this.sessionId,
      { status: SessionStatus.TERMINATING },
      data => this.playerPublisher.sessionState(this.sessionId, { status: data.status }),
    );
    await this.sessionDataManager.updateSessionData({ endReason: this.reason }, this.sessionId);
    this.robotPublisher.sendDisengageMessage(this.sessionId, this.cachedMachine.serial);
    await this.coreWorkerClient.timeoutStart({
      timeoutType: TimeoutType.DISENGAGE,
      sessionId: this.sessionId,
      timeoutSec: 5,
      payload: {
        groupId: this.cachedGroup.id, machineId: this.cachedMachine.id, gameId: this.cachedMachine.gameId,
      },
    }, this.correlationId);
  }

  private async terminateRounds(roundIds: string[]): Promise<void> {
    const ids = roundIds.map(r => Number(r));
    await this.roundRepo.update({ id: In(ids) }, {
      status: RoundStatus.TERMINATED,
      endDate: new Date(),
      wins: 0,
      winInCash: 0,
      bet: 0,
      betInCash: 0,
    });

    ids.forEach(roundId => this.monitoringWorkerClient.sendEventLogMessage({
      eventType: EventType.ROUND_TERMINATED,
      source: EventSource.GAME,
      params: {
        sessionId: this.sessionId,
        operatorId: this.cachedOperator.id,
        groupId: this.cachedGroup.id,
        machineSerial: this.cachedMachine.serial,
        machineId: this.cachedMachine.id,
        playerCid: this.cachedPlayer.cid,
        round: roundId,
      },
    }));
  }

  private async onCancelBetError(error: Error) {
    this.logger.error('Cancel bet failed', {
      sessionId: this.sessionId,
      roundId: this.sessionData.transaction.roundId,
      correlationId: this.correlationId,
      error: error.message,
    });
    if (this.session.isEngaged()) {
      await this.disengage();
    } else {
      this.commandPublisher.finalizeSession({
        type: CommandType.FINALIZE_SESSION,
        sessionId: this.sessionId,
        gameId: GameId.CLAW,
        terminate: true,
        reason: SessionEndReason.WALLET_TRANSACTION_ERROR,
      }, this.correlationId);
    }
    await this.monitoringWorkerClient.sendAlertMessage({
      alertType: AlertType.ERROR,
      source: AlertSource.GAME_CORE,
      severity: AlertSeverity.HIGH,
      description: 'Cancel bet failed',
      gameId: this.cachedMachine.gameId,
      details: {
        sessionId: this.sessionId,
        roundId: this.sessionData.transaction.roundId,
        machineId: this.cachedMachine.id,
        machineName: this.cachedMachine.name,
        machineSerial: this.cachedMachine.serial,
        error: error.message,
      },
    });
  }
}
