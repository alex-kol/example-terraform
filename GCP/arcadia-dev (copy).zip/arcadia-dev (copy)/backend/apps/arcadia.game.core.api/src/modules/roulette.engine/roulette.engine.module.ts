import { ConfigService } from '@lib/config';
import {
  BallRepository,
  GroupRepository,
  MachineRepository,
  PlayerRepository,
  QueueRepository,
  RoundRepository,
  SessionRepository,
} from '@lib/dal';
import { FileManagerModule, StorageType } from '@lib/file.manager';
import { MonitoringWorkerClientModule } from '@lib/monitoring.worker.client';
import { Module } from '@nestjs/common';
import { FactoryProvider } from '@nestjs/common/interfaces/modules/provider.interface';
import { ConfigValidatorModule } from '../config.validator/config.validator.module';
import { OperatorApiClientModule } from '../operator.api.client/operator.api.client.module';
import { RobotClientModule } from '../robot.client/robot.client.module';
import { RoundModule } from '../round/round.module';
import { SessionDataManagerModule } from '../session.data.manager/session.data.manager.module';
import { SessionModule } from '../session/session.module';
import { WorkerClientModule } from '../worker.client/worker.client.module';
import { BetManager } from './bet.manager';
import { GamePhase, StateMachineStatus } from './enums';
import { GameStateManager } from './game.state.manager';
import { BetsOpenPhaseHandler } from './phase.handler/bets.open.phase.handler';
import { getPhaseInjectToken } from './phase.handler/get.phase.inject.token';
import { InitPhaseHandler } from './phase.handler/init.phase.handler';
import { PickNumberPhaseHandler } from './phase.handler/pick.number.phase.handler';
import { ProcessBetsPhaseHandler } from './phase.handler/process.bets.phase.handler';
import { ProcessWinsPhaseHandler } from './phase.handler/process.wins.phase.handler';
import { ShowResultsPhaseHandler } from './phase.handler/show.results.phase.handler';
import { RouletteController } from './roulette.controller';
import { RouletteStateMachine } from './roulette.state.machine';
import { CommonContext } from './types';

const transitions: FactoryProvider<Map<GamePhase, GamePhase | ((context: CommonContext) => GamePhase)>> = {
  provide: 'TRANSITIONS',
  useFactory: () => {
    const transitions: Map<GamePhase, GamePhase | ((context: CommonContext) => GamePhase)> = new Map();

    transitions.set(GamePhase.GAME_INIT,
      context => (context.status === StateMachineStatus.PAUSED ? GamePhase.GAME_INIT : GamePhase.BETS_OPEN));
    transitions.set(GamePhase.BETS_OPEN, GamePhase.PROCESS_BETS);
    transitions.set(GamePhase.PROCESS_BETS, GamePhase.PICK_NUMBER);
    transitions.set(GamePhase.PICK_NUMBER, GamePhase.PROCESS_WINS);
    transitions.set(GamePhase.PROCESS_WINS, GamePhase.SHOW_RESULTS);
    transitions.set(GamePhase.SHOW_RESULTS, GamePhase.GAME_INIT);

    return transitions;
  },
};

@Module({
  imports: [
    WorkerClientModule,
    MonitoringWorkerClientModule,
    SessionModule,
    RoundModule,
    RobotClientModule,
    OperatorApiClientModule,
    SessionDataManagerModule,
    ConfigValidatorModule,
    MonitoringWorkerClientModule,
    FileManagerModule.register(
      {
        storageType: StorageType.GOOGLE_CLOUD,
        bucketNameProvider: {
          provide: 'BUCKET_NAME',
          useFactory: (config: ConfigService) => config.get(['core', 'BUCKET_NAME']),
          inject: [ConfigService],
        },
      }),
  ],
  providers: [
    SessionRepository,
    RoundRepository,
    PlayerRepository,
    MachineRepository,
    BallRepository,
    GroupRepository,
    QueueRepository,
    {
      provide: getPhaseInjectToken(GamePhase.GAME_INIT),
      useClass: InitPhaseHandler,
    },
    {
      provide: getPhaseInjectToken(GamePhase.BETS_OPEN),
      useClass: BetsOpenPhaseHandler,
    },
    {
      provide: getPhaseInjectToken(GamePhase.PROCESS_BETS),
      useClass: ProcessBetsPhaseHandler,
    },
    {
      provide: getPhaseInjectToken(GamePhase.PICK_NUMBER),
      useClass: PickNumberPhaseHandler,
    },
    {
      provide: getPhaseInjectToken(GamePhase.PROCESS_WINS),
      useClass: ProcessWinsPhaseHandler,
    },
    {
      provide: getPhaseInjectToken(GamePhase.SHOW_RESULTS),
      useClass: ShowResultsPhaseHandler,
    },
    transitions,
    GameStateManager,
    BetManager,
    RouletteStateMachine,
  ],
  controllers: [RouletteController],
  exports: [RouletteStateMachine, GameStateManager, BetManager],
})
export class RouletteEngineModule {

}
