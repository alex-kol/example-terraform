import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean } from 'class-validator';

export class MachineStartDto {
  @ApiProperty()
  @IsBoolean()
  public resetTableState: boolean;

  @ApiProperty()
  @IsBoolean()
  public resetDispensers: boolean;
}
