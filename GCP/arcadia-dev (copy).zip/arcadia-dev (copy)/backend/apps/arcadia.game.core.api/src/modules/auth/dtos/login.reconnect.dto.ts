import {
  GroupEntity, MachineEntity, OperatorEntity, PlayerEntity, RoundEntity, SessionEntity,
} from '@lib/dal';
import { StreamResponse } from '@lib/video.api';

export class LoginReconnectDto {
  session: SessionEntity;
  player: PlayerEntity;
  machine: MachineEntity;
  group: GroupEntity;
  operator: OperatorEntity;
  streams: StreamResponse[];
  activeRound?: RoundEntity;
  isReconnect?: boolean = false;
}
