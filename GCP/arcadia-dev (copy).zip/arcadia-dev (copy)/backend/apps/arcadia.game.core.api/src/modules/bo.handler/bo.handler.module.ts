import {
  BallRepository,
  ChipRepository,
  ChipTypeRepository,
  FailedTransactionRepository,
  GameId,
  GroupRepository,
  MachineDispenserRepository,
  MachineRepository,
  QueueRepository,
  RngChipPrizeRepository,
  RoundArchiveRepository,
  SeedHistoryRepository,
  SessionRepository,
  SiteRepository,
} from '@lib/dal';
import { MonitoringWorkerClientModule } from '@lib/monitoring.worker.client';
import { Module } from '@nestjs/common';
import { ConfigValidatorModule } from '../config.validator/config.validator.module';
import { GroupTerminatorModule } from '../group.terminator/group.terminator.module';
import { MessagingModule } from '../messaging/messaging.module';
import { OperatorApiClientModule } from '../operator.api.client/operator.api.client.module';
import { RobotClientModule } from '../robot.client/robot.client.module';
import { BoHandlerController } from './bo.handler.controller';
import { BoHandlerService } from './bo.handler.service';
import { ClawBoHandlerStrategy, ClawRouletteBoHandlerStrategy, CoinPusherV1BoHandlerStrategy } from './game.strategies';
import { TransactionRetryService } from './transaction.retry.service';
import { boHandlerStrategyKeyFactory } from './util/bo.handler.strategy.key.factory';
import { ChipWatcherModule } from '../chip.watcher/chip.watcher.module';

@Module({
  imports: [
    MonitoringWorkerClientModule,
    RobotClientModule,
    MessagingModule,
    GroupTerminatorModule,
    ConfigValidatorModule,
    OperatorApiClientModule,
    ChipWatcherModule,
  ],
  controllers: [BoHandlerController],
  providers: [
    BoHandlerService,
    TransactionRetryService,
    MachineRepository,
    QueueRepository,
    GroupRepository,
    MachineDispenserRepository,
    ChipRepository,
    ChipTypeRepository,
    RngChipPrizeRepository,
    SiteRepository,
    FailedTransactionRepository,
    SeedHistoryRepository,
    BallRepository,
    SessionRepository,
    RoundArchiveRepository,
    {
      provide: boHandlerStrategyKeyFactory(GameId.COIN_PUSHER_V1),
      useClass: CoinPusherV1BoHandlerStrategy,
    },
    {
      provide: boHandlerStrategyKeyFactory(GameId.CLAW_ROULETTE),
      useClass: ClawRouletteBoHandlerStrategy,
    },
    {
      provide: boHandlerStrategyKeyFactory(GameId.CLAW),
      useClass: ClawBoHandlerStrategy,
    },
  ],
  exports: [BoHandlerService],
})
export class BoHandlerModule {

}
