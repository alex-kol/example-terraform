import { GamePhase } from '../enums';

export function getPhaseInjectToken(phase: GamePhase): string {
  return `roulette-phase-handler-inject-token:${phase}`;
}
