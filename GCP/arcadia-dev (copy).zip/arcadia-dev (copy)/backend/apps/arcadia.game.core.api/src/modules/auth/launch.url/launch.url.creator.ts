import { UrlCreatorResp, UserLoginDto } from '@lib/common';
import { ConfigService } from '@lib/config';
import { OperatorEntity } from '@lib/dal';
import { BadRequestException, UnauthorizedException } from '@nestjs/common';
import Joi from 'joi';
import { URL, URLSearchParams } from 'url';
import { LaunchParams } from './types';

export abstract class LaunchUrlCreator<T extends LaunchParams = any> {
  protected abstract readonly paramsValidationSchema: Joi.ObjectSchema<T>;

  protected readonly baseLaunchUrl: string;
  protected readonly ipWhitelist: Set<string>;

  protected params: T;
  protected operator: OperatorEntity;

  protected constructor(protected readonly config: ConfigService) {
    this.ipWhitelist = new Set(this.config.get<string[]>(['core', 'URL_CREATOR_IP_WHITELIST']));
    this.baseLaunchUrl = this.config.get(['core', 'CLIENT_FE_BASE_URL']);
  }

  protected abstract getId(): string;

  protected abstract getOperator(): Promise<OperatorEntity>;

  protected abstract mapParams(): UserLoginDto;

  public async getLaunchUrl(params: Record<string, any>): Promise<UrlCreatorResp> {
    this.params = this.validateParams(params);
    this.operator = await this.getOperator();
    await this.validateCaller();
    return {
      launchUrl: this.buildUrl(),
      embedderUrls: this.operator.embedderUrls ? this.operator.embedderUrls.split(',') : undefined,
    };
  }

  protected buildUrl(): string {
    const responseParams = this.mapParams();
    const url = new URL(this.baseLaunchUrl);
    url.pathname = `/${responseParams.gameId}/launchGame`;
    url.search = new URLSearchParams(Object.entries(responseParams)).toString();
    return url.toString();
  }

  protected validateParams(params: Record<string, any>): T {
    const {
      error,
      value,
    } = this.paramsValidationSchema.validate(
      params,
      {
        stripUnknown: true,
        allowUnknown: false,
      },
    );
    if (error) {
      throw new BadRequestException(
        `${params.operator} launch URL creation params validation failed: ${error.message}`,
      );
    }

    return value;
  }

  protected async validateCaller(): Promise<void> {
    const { callerIp } = this.params;
    if (!callerIp || !this.ipWhitelist.has(callerIp)) {
      throw new UnauthorizedException('IP address is forbidden');
    }
  }
}
