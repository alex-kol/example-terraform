import * as CacheManager from 'cache-manager';
import { CACHE_MANAGER } from '@nestjs/common';
import {
  connectionNames,
  SessionEntity,
  SessionRepository,
  getRepositoryToken,
  PlayerEntity,
  GroupEntity,
  MachineEntity,
  QueueEntity,
  SessionEndReason,
} from '@lib/dal';
import { PlayerClientService } from '../player.client/player.client.service';
import { makeTestModule } from './mocks/beforeAll.mock';
import { SessionService } from './session.service';
import { OperatorEntity } from '@lib/dal';
import { REDIS_CACHE } from '../../constants/redis.constants';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';

type CacheType = ReturnType<typeof CacheManager.caching>;

describe('Session Service (Unit)', () => {
  let sessionService: SessionService;
  let cacheManager: CacheType;
  let sessionRepository: SessionRepository;
  let playerClientService: PlayerClientService;
  let redisCache;
  let monitoringClient: MonitoringWorkerClientService;

  beforeAll(async () => {
    const moduleFixture = await makeTestModule();
    sessionService = moduleFixture.get<SessionService>(SessionService);
    cacheManager = moduleFixture.get<CacheType>(CACHE_MANAGER);
    redisCache = moduleFixture.get<CacheType>(REDIS_CACHE);
    sessionRepository = moduleFixture.get<SessionRepository>(getRepositoryToken(SessionRepository, connectionNames.DATA));
    monitoringClient = moduleFixture.get<MonitoringWorkerClientService>(MonitoringWorkerClientService);

    playerClientService = moduleFixture.get<PlayerClientService>(PlayerClientService);
  });

  describe('findByIdCached', () => {
    it('should return session from cache', async () => {
      const sessionMock = new SessionEntity();
      jest.spyOn(redisCache, 'get').mockResolvedValueOnce(sessionMock);
      const result = await sessionService.findByIdCached(1);
      expect(result).toMatchObject(sessionMock);
    });
    it('should return session from db', async () => {
      const sessionMock = new SessionEntity();
      jest.spyOn(cacheManager, 'get').mockResolvedValueOnce(null);
      jest.spyOn(sessionRepository, 'findOne').mockResolvedValue(sessionMock);
      const result = await sessionService.findByIdCached(1);
      expect(result).toMatchObject(sessionMock);
    });
  });

  describe('create', () => {
    it('should create session', async () => {
      const playerMock = new PlayerEntity();
      const groupMock = new GroupEntity();
      const machineMock = new MachineEntity();
      const queueMock = new QueueEntity();
      // @ts-ignore
      machineMock.queue = queueMock;
      const expectedSession: any = {
        os: '<os>',
        sessionDescription: {},
        playerIP: () => '',
        player: playerMock,
        group: groupMock,
        machine: machineMock,
        queue: queueMock,
      };
      const objectContaining = {
        os: expect.any(String),
        sessionDescription: expect.any(Object),
        playerIP: expect.any(Function),
        player: expect.any(Object),
        group: expect.any(Object),
        machine: expect.any(Object),
        queue: expect.any(Object),
      };
      jest.spyOn(sessionRepository, 'create').mockImplementation((e: any) => (e as any));
      const saveSpy = jest.spyOn(sessionRepository, 'save').mockImplementation((e: any) => Promise.resolve(e));
      const savedSession = await sessionService.createSession(expectedSession);
      expect(savedSession).toStrictEqual(expect.objectContaining(objectContaining));
      expect(saveSpy).toBeCalledWith(expect.objectContaining(objectContaining), { transaction: false });
    });
  });

  describe('finalizeSessions', () => {
    it('should archive sessions and return players to lobby', async done => {
      const sessionMock = new SessionEntity();
      sessionMock.id = 5;
      sessionMock.player = new PlayerEntity();
      sessionMock.player.cid = '12';
      sessionMock.group = new GroupEntity();
      sessionMock.operator = new OperatorEntity();
      sessionMock.machine = new MachineEntity();
      sessionMock.queue = new QueueEntity();
      sessionMock.rounds = [];
      jest.spyOn(sessionRepository, 'findByIds').mockResolvedValue([sessionMock]);
      const playerPublisher = jest.spyOn(playerClientService, 'notification');
      const sessionRepositoryFindOne = jest.spyOn(sessionRepository, 'findOneOrFail').mockResolvedValue(sessionMock);
      const notifyReturnToLobbySpy = jest.spyOn(playerClientService, 'notifyReturnToLobby');
      const sendEventLogMessage = jest.spyOn(monitoringClient, 'sendEventLogMessage');
      await sessionService.finalizeSession(1, SessionEndReason.FINALIZE_SESSION, true);
      setTimeout(() => {
        expect(notifyReturnToLobbySpy).toBeCalledWith(sessionMock.id);
        expect(playerPublisher).toBeCalled();
        expect(sendEventLogMessage).toBeCalled();
        expect(sessionRepositoryFindOne).toBeCalled();
        done();
      }, 2000);
    });
  });
});
