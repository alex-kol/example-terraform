import { GameId } from '@lib/dal';
import { IsObject, Length } from 'class-validator';

export class LaunchGameDto {
  @Length(3)
  public callerIp: string;

  @IsObject()
  public params: { operatorId: string | number, gameId: GameId } & Record<string, any>;
}
