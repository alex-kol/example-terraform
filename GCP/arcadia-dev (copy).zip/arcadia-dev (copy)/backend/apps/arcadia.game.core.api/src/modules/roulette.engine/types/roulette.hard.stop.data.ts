import { ShutdownReason } from '@lib/dal';

export class RouletteHardStopData {
  reason: ShutdownReason;
}