import { MachineEntity, MachineStatus } from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { Inject, Injectable } from '@nestjs/common';
import { Logger } from 'winston';
import { RobotReportedStatus } from '../robot.reported.status';
import { StatusHandlerStrategy } from './status.handler.strategy';

@Injectable()
export class GameplayStatusStrategy extends StatusHandlerStrategy {
  constructor(
    @Inject(MAIN_LOGGER) logger: Logger,
  ) {
    super(logger);
  }

  public async onSeeding(machine: MachineEntity): Promise<void> {
    if (machine.status !== MachineStatus.SEEDING) {
      this.throwUnexpectedStatus(RobotReportedStatus.SEEDING, machine);
    }
  }

  public toString(): string {
    return GameplayStatusStrategy.name;
  }
}