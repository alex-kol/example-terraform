import { Global, Module } from '@nestjs/common';
import { CommandPublisher } from './command.publisher';

@Global()
@Module({
  providers: [CommandPublisher],
  exports: [CommandPublisher],
})
export class CommandModule {

}