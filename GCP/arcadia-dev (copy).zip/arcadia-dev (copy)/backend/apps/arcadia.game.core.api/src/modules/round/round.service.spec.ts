import {
  GroupEntity,
  MachineEntity,
  OperatorEntity,
  PlayerEntity,
  QueueEntity,
  RoundEntity,
  RoundStatus,
  RoundType,
  SessionEntity,
  VoucherEntity,
} from '@lib/dal';
import { CoinPusherRoundStarter } from './coin.pusher.round.starter';
import { makeTestModule, repoMock } from './mocks/beforeAll.mock';
import { RngHelper } from '../rng.service.client/rng.helper';
import { RoundContext } from './round.context';
import { RoundServiceFactory } from './round.service.factory';

describe('Round Service (Unit)', () => {
  let roundService: CoinPusherRoundStarter;
  let rngHelper: RngHelper;
  let roundServiceFactory: RoundServiceFactory;

  beforeAll(async () => {
    const moduleFixture = await makeTestModule();
    roundServiceFactory = moduleFixture.get<RoundServiceFactory>(RoundServiceFactory);
    rngHelper = moduleFixture.get<RngHelper>(RngHelper);
  });

  describe('createRound', () => {
    const machineId = 12;
    const voucherId = 13;
    let session;
    const groupMock = { stackSize: 5, denominator: 55 };
    const createRoundService = () => {
      session = new SessionEntity();
      const queue = new QueueEntity();
      const machine = new MachineEntity();
      machine.id = machineId;
      const player = new PlayerEntity();
      const group = new GroupEntity();
      group.stackSize = groupMock.stackSize;
      group.denominator = groupMock.denominator;
      const operator = new OperatorEntity();
      const pendingVoucher = new VoucherEntity();
      pendingVoucher.id = voucherId;
      const ctx: RoundContext = new RoundContext(session, queue, machine, player, group, operator,
        false, pendingVoucher, 'correlationId');
      roundService = roundServiceFactory.create(ctx);
    }
    it('should create round', async () => {
      createRoundService();
      const roundMock = new RoundEntity();
      const machineMock = { id: machineId };
      jest.spyOn(rngHelper, 'calcRtp').mockResolvedValue(null);
      // @ts-ignore
      const createSpy = jest.spyOn(repoMock, 'create').mockReturnValue(roundMock);
      const saveSpy = jest.spyOn(repoMock, 'save');
      // @ts-ignore
      await roundService.createRound(RoundType.REGULAR, 55, groupMock);
      expect(saveSpy).toBeCalledTimes(1);
      expect(createSpy).toBeCalledWith({
        type: RoundType.REGULAR,
        status: RoundStatus.ACTIVE,
        coins: groupMock.stackSize,
        bet: groupMock.denominator,
        session,
        betInCash: {
          denominator: 55,
          stackSize: 5,
        },
        rtp: null,
        machineId: machineMock.id,
        isAutoplay: false,
        voucherId,
      });
    });
  });
});
