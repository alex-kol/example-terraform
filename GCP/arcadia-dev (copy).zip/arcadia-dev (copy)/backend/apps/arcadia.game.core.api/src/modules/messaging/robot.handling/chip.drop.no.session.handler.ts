/* eslint-disable max-lines */
import { AlertDescription, EventSource } from '@lib/common';
import { ConfigService } from '@lib/config';
import {
  AlertAction,
  AlertSeverity,
  AlertSource,
  AlertType,
  ChipEntity,
  ChipRepository,
  EventType,
  GroupEntity,
  MachineDispenserEntity,
  MachineEntity,
  MachineRepository,
  MachineStatus,
  RngChipPrizeRepository,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Inject, Injectable, Scope } from '@nestjs/common';
import { Logger } from 'winston';
import { CommandHandler } from '../../command/command.handler';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { RobotChipDropDto } from './dto';
import { ChipWatcherService } from '../../chip.watcher/chip.watcher.service';

@Injectable({ scope: Scope.REQUEST })
export class ChipDropNoSessionHandler extends CommandHandler<RobotChipDropDto> {
  private rfid: string;
  private serial: string;
  private duration: number;
  private chip: ChipEntity;
  private machine: MachineEntity;
  private dispensers: MachineDispenserEntity[];
  private group: GroupEntity;
  private rtpSegment: string;
  private readonly chipsDropAlertLimit: number;

  constructor(
    @Inject(MAIN_LOGGER) logger: Logger,
    private readonly robotClient: RobotClientService,
    private readonly monitoringClient: MonitoringWorkerClientService,
    private readonly chipRepo: ChipRepository,
    private readonly machineRepo: MachineRepository,
    private readonly prizeRepo: RngChipPrizeRepository,
    private readonly chipWatcherService: ChipWatcherService,
    private readonly config: ConfigService,
  ) {
    super(logger);
    this.chipsDropAlertLimit = Number(this.config.get(['core', 'CHIPS_DROP_ALERT_LIMIT']));
  }

  protected async init(data: RobotChipDropDto): Promise<void> {
    await super.init(data);

    // message payload
    this.rfid = data.rfid;
    this.serial = data.serial;
    this.duration = data.duration;

    const [machine, chip] = await Promise.all([
      this.machineRepo.findOneOrFail({
        where: { serial: this.serial },
        relations: ['group', 'site', 'dispensers', 'dispensers.chipType'],
      }),
      this.chipRepo.findOne({
        where: { rfid: this.rfid },
        relations: ['type', 'machine', 'site'],
      }),
    ]);
    await this.machineRepo.incrementChipDropCount(machine.id);
    if (!chip) {
      this.logger.warn('Chip not found', { rfid: this.rfid });
      await this.monitoringClient.sendAlertMessage({
        alertType: AlertType.MAINTENANCE,
        severity: AlertSeverity.MEDIUM,
        source: AlertSource.GAME_CORE,
        description: AlertDescription.UNKNOWN_CHIP_DROPPED,
        gameId: machine.gameId,
        details: {
          rfid: this.rfid,
          machineId: machine.id,
          machineName: machine.name,
          machineSerial: machine.serial,
        },
      });
      return;
    }
    this.chip = chip;
    this.machine = machine;
    this.dispensers = machine.dispensers || [];
    this.group = machine.group;
    this.rtpSegment = this.group.configuration?.rtpSegment
      || this.machine.configuration?.rtpSegment;

    if (machine.chipsDropCount > this.chipsDropAlertLimit) {
      await this.monitoringClient.sendAlertMessage({
        alertType: AlertType.MAINTENANCE,
        source: AlertSource.GAME_CORE,
        severity: AlertSeverity.MEDIUM,
        description: AlertDescription.CHIP_DRAWER_IS_FULL,
        action: AlertAction.EMPTY_DISPENSER_WAIST,
        gameId: machine.gameId,
        details: {
          machineId: machine.id,
          machineName: machine.name,
          machineSerial: machine.serial,
        },
      });
    }
  }

  protected async handleEvent(): Promise<void> {
    await this.unregisterChip();

    if (!await this.validateChipDrop()) {
      this.logger.warn('Invalid chip dropped', { chip: this.chip });
      await this.monitoringClient.sendAlertMessage({
        alertType: AlertType.MAINTENANCE,
        source: AlertSource.GAME_CORE,
        severity: AlertSeverity.MEDIUM,
        description: AlertDescription.INVALID_CHIP_DROPPED,
        gameId: this.machine.gameId,
        details: {
          rfid: this.chip.rfid,
          chipType: this.chip.type.name,
          machineId: this.machine.id,
          machineName: this.machine.name,
          machineSerial: this.serial,
          sessionId: null,
        },
      });
      await this.monitoringClient.sendEventLogMessage({
        eventType: EventType.ILLEGAL_CHIP_DROP,
        source: EventSource.GAME,
        params: {
          rfid: this.rfid,
          duration: this.duration,
          machineId: this.machine.id,
          machineSerial: this.serial,
          groupId: this.group.id,
          sessionId: null,
        },
      });
      return;
    }

    await this.monitoringClient.sendEventLogMessage({
      eventType: EventType.CHIP_DROP_NO_SESSION,
      source: EventSource.ROBOT,
      params: {
        rfid: this.chip.rfid,
        type: this.chip.type.name,
        value: this.chip.value,
        duration: this.duration,
        machineId: this.machine.id,
        machineSerial: this.serial,
        groupId: this.group.id,
        sessionId: null,
      },
    });

    const targetDispenser = this.dispensers
      .filter(dispenser => dispenser.chipType.name === this.chip.type.name)
      .sort((a, b) => b.level - a.level)[0];
    if (targetDispenser?.level) {
      if (this.machine.status === MachineStatus.STOPPED
        || this.machine.status === MachineStatus.SHUTTING_DOWN
        || (this.machine.status === MachineStatus.PREPARING && !this.machine.isRefurbish)) {
        this.logger.warn('Chip pushed to refurbish list',
          {
            machineId: this.machine.id, machineSerial: this.machine.serial, rfid: this.chip.rfid, chipTypeId: this.chip.type.id,
          });
        await this.chipWatcherService.pushRefurbishChipToList(
          { value: this.chip.value, isScatter: this.chip.isScatter },
          this.machine.id,
          this.chip.type.id,
        );
      } else {
        this.machine.status !== MachineStatus.PREPARING && await this.robotClient.sendPushMessage(targetDispenser.name, this.serial);
      }
    }
  }

  private async unregisterChip() {
    await this.chipRepo.update(this.rfid, {
      machine: null,
      isScatter: false,
      value: 0,
    });
  }

  private async validateChipDrop(): Promise<boolean> {
    const prize = await this.prizeRepo.getChipPrize(this.group.prizeGroup, this.chip.type.id, this.rtpSegment);
    return prize
      && this.chip.machine?.id === this.machine.id
      && this.chip.site.id === this.machine.site.id;
  }
}
