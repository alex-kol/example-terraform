import { OperatorTag } from '@lib/common';
import { ConfigService } from '@lib/config';
import { OperatorRepository } from '@lib/dal';
import { Injectable } from '@nestjs/common';
import { StandardLanguageMapper } from './languages';
import { SolidGamingLaunchUrlCreator } from './solid.gaming.launch.url.creator';

@Injectable()
export class PlainGamingLaunchUrlCreator extends SolidGamingLaunchUrlCreator {
  constructor(
    config: ConfigService,
    operatorRepo: OperatorRepository,
    solidGamingLanguage: StandardLanguageMapper,
  ) {
    super(config, operatorRepo, solidGamingLanguage);
  }

  protected getId(): OperatorTag {
    return OperatorTag.PLAIN_GAMING;
  }
}
