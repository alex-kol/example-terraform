import { CommandType } from '@lib/common';
import { MachineRepository } from '@lib/dal';
import { Inject, Injectable } from '@nestjs/common';
import { ModuleRef } from '@nestjs/core';
import { RpcException } from '@nestjs/microservices';
import { CommandPublisher } from '../command/command.publisher';
import { PhaseEndCommand } from '../command/dto/phase.end.command';
import { RouletteEventCommand } from '../command/dto/roulette.event.command';
import { GamePhase, PhaseStatus, StateMachineStatus } from './enums';
import { GameStateManager } from './game.state.manager';
import { getPhaseInjectToken } from './phase.handler/get.phase.inject.token';
import { PhaseHandler } from './phase.handler/phase.handler';
import { CommonContext, RouletteGameState } from './types';

@Injectable()
export class RouletteStateMachine {
  constructor(
    @Inject('TRANSITIONS')
    private readonly transitions: Map<GamePhase, GamePhase | ((context: CommonContext) => GamePhase)>,
    private readonly moduleRef: ModuleRef,
    private readonly gameStateManager: GameStateManager,
    private readonly commandPublisher: CommandPublisher,
    private readonly machineRepo: MachineRepository,
  ) {
  }

  public async start(serial: string): Promise<void> {
    const machine = await this.machineRepo.findOneByOrFail({ serial });
    const state: RouletteGameState = {
      currentPhase: {
        phase: GamePhase.GAME_INIT,
        status: PhaseStatus.IN_PROGRESS,
      },
      context: {
        machineId: machine.id,
        serial,
        status: StateMachineStatus.RUNNING,
        resultHistory: [],
        softStop: false,
      },
    };
    await this.gameStateManager.setGameState(serial, state);
    await this.phaseTransition(state);
  }

  public async stop(serial: string): Promise<void> {
    const state = await this.gameStateManager.getGameState(serial);
    state.context.status = StateMachineStatus.STOPPED;
    await this.gameStateManager.setGameState(serial, state);
  }

  public async phaseEnd(serial: string, phase: GamePhase): Promise<void> {
    const state = await this.gameStateManager.getGameState(serial);
    if (state.context.status === StateMachineStatus.ERROR) {
      throw new RpcException('Phase end interrupted on error');
    }
    if (state.currentPhase.phase !== phase
      || state.currentPhase.status !== PhaseStatus.IN_PROGRESS) {
      throw new RpcException('Unexpected phase end');
    }
    const phaseHandler: PhaseHandler = await this.moduleRef.get(getPhaseInjectToken(phase));
    await phaseHandler.onComplete(state.context);
    state.currentPhase.status = PhaseStatus.COMPLETE;

    const switchTo = this.getPhaseSwitch(state);
    if (!switchTo) {
      await this.gameStateManager.setGameState(serial, state);
      return;
    }

    state.currentPhase = {
      phase: switchTo,
      status: PhaseStatus.IN_PROGRESS,
    };

    await this.phaseTransition(state);
  }

  private async phaseTransition(state: RouletteGameState): Promise<void> {
    const { currentPhase } = state;
    const phaseHandler: PhaseHandler = await this.moduleRef
      .get(getPhaseInjectToken(currentPhase.phase));
    const {
      status,
      endTimestamp,
    } = await phaseHandler.onStart(state.context);
    currentPhase.endTimestamp = endTimestamp;
    await this.gameStateManager.setGameState(state.context.serial, state);
    if (status === PhaseStatus.COMPLETE) {
      this.commandPublisher.sendRouletteCommand<PhaseEndCommand>({
        type: CommandType.PHASE_END,
        serial: state.context.serial,
        phase: currentPhase.phase,
      });
    }
  }

  private getPhaseSwitch({
    currentPhase,
    context,
  }: RouletteGameState): GamePhase | null {
    const transition = this.transitions.get(currentPhase.phase);
    if (!transition) {
      throw new RpcException('no phase to switch to');
    }
    const switchTo = typeof transition === 'function' ? transition(context) : transition;
    if (switchTo === GamePhase.BETS_OPEN && context.status === StateMachineStatus.STOPPED) {
      return GamePhase.GAME_INIT;
    }
    return switchTo;
  }

  public async onEvent(event: RouletteEventCommand): Promise<void> {
    const state = await this.gameStateManager.getGameState(event.serial);
    const handler: PhaseHandler = await this.moduleRef.get(getPhaseInjectToken(state.currentPhase.phase));
    await handler.onEvent(state.context, event);
    await this.gameStateManager.setGameState(event.serial, state);
  }
}
