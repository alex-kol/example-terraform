import { ApiProperty } from '@nestjs/swagger';

export class LobbyDataRes {
  @ApiProperty()
  public groupId: number;

  @ApiProperty()
  public groupName: string;

  @ApiProperty()
  public groupDisplayName: string;

  @ApiProperty()
  public queueLength: number;

  @ApiProperty()
  public currency: string;

  @ApiProperty()
  public color: string;

  @ApiProperty()
  public hasVoucher: boolean;
}
