import { ApiPropertyOptional, ApiResponseProperty } from '@nestjs/swagger';

export class MachineStartResponseDto {
  @ApiResponseProperty()
  public machineId: number;

  @ApiPropertyOptional()
  public correlationId?: string;
}
