import {
  AutoplayConfiguration, BetBehindConfiguration, CoinPusherGameMode, Configuration, PhantomWidgetType,
} from '@lib/dal';
import Joi from 'joi';
import { commonSchema } from './common.schema';

export const coinPusherSchema = Joi.object<Configuration>({
  ...commonSchema,
  autoplay: Joi.object<AutoplayConfiguration>({
    stopAfterRounds: Joi.number()
      .integer()
      .required(),
    hiLimitMultiplier: Joi.number()
      .integer()
      .required(),
    lowLimitMultiplier: Joi.number()
      .integer()
      .required(),
    singleWinThreshold: Joi.number()
      .integer()
      .required(),
  })
    .required(),
  betBehind: Joi.object<BetBehindConfiguration>({
    stopAfterRounds: Joi.number()
      .integer()
      .required(),
    hiLimitMultiplier: Joi.number()
      .integer()
      .required(),
    lowLimitMultiplier: Joi.number()
      .integer()
      .required(),
    singleWinThreshold: Joi.number()
      .integer()
      .required(),
    isEnabled: Joi.boolean()
      .default(false),
    maxBetBehindPlayers: Joi.number()
      .integer()
      .positive()
      .default(5),
  })
    .required(),
  minimalHold: Joi.object({
    count: Joi.number()
      .integer()
      .required(),
    value: Joi.number()
      .required(),
  })
    .required(),
  dispensers: Joi.object()
    .pattern(/[\w_-]{1,100}/, Joi.object({
      capacity: Joi.number()
        .integer()
        .required(),
      alertThreshold: Joi.number()
        .integer()
        .default(10),
      chipType: Joi.string()
        .required(),
    }))
    .required(),
  rtpSegment: Joi.string()
    .required(),
  reshuffleCoinsEmpty: Joi.number()
    .integer()
    .required(),
  reshuffleCoinsNonEmpty: Joi.number()
    .integer()
    .required(),
  burstShoot: Joi.number()
    .integer()
    .positive(),
  phantomWidgetType: Joi.string()
    .valid(...Object.values(PhantomWidgetType))
    .required(),
  slot: Joi.array()
    .items(Joi.string())
    .when('phantomWidgetType', {
      is: PhantomWidgetType.SLOT,
      then: Joi.required(),
    }),
  stackBuyLimit: Joi.number()
    .integer()
    .min(1)
    .max(250)
    .required(),
  maxPayout: Joi.number()
    .integer()
    .min(1)
    .when(Joi.ref('$level'), {
      is: 'operator',
      then: Joi.required(),
    }),
  queueLengthAlertThreshold: Joi.number()
    .integer()
    .positive()
    .default(50),
  currencies: Joi.array()
    .items(Joi.string()
      .regex(/[A-Z]{3}/))
    .when(Joi.ref('$level'), {
      is: 'operator',
      then: Joi.required(),
    }),
  bbRoundDurationInStack: Joi
    .number()
    .integer()
    .min(1)
    .default(0),
  rebuyTimeout: Joi
    .number()
    .integer()
    .positive()
    .default(60),
  tableSpeed: Joi
    .number()
    .integer()
    .min(1)
    .max(10),
  bigWinThreshold: Joi
    .number()
    .positive(),
  toastChipAdded: Joi
    .boolean()
    .default(true),
  gameMode: Joi
    .string()
    .valid(...Object.values(CoinPusherGameMode))
    .default(CoinPusherGameMode.NORMAL),
});