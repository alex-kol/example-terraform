export class PhantomPrizeDto {
  type: 'scatter' | 'value';
  value: number;
}