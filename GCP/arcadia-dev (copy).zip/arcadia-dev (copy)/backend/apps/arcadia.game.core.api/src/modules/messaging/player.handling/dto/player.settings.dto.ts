import { AutoSwingMode, GameSettings } from '@lib/dal';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsBoolean, IsEnum, IsObject, IsOptional, ValidateNested,
} from 'class-validator';
import { SoundsConfigDto } from './sounds.config.dto';

export class PlayerSettingsDto implements GameSettings {
  @ApiProperty()
  @IsObject()
  @Type(() => SoundsConfigDto)
  @ValidateNested()
  public soundsConfig: SoundsConfigDto;

  @ApiProperty()
  @IsBoolean()
  public showTutorial: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(AutoSwingMode)
  public autoSwingMode?: AutoSwingMode;
}
