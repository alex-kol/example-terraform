import { AlertDescription, EventSource, TimeoutType } from '@lib/common';
import { ConfigService } from '@lib/config';
import {
  AlertSeverity,
  AlertSource,
  AlertType,
  CoinPusherGameMode,
  EventType,
  GameId,
  MachineDispenserEntity,
  MachineDispenserRepository,
  RoundEntity,
  RoundRepository,
  SessionStatus,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Inject, Injectable, Scope } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { DataSource } from 'typeorm';
import { Logger } from 'winston';
import moment from 'moment';
import { BetBehindService } from '../../bet.behind/bet.behind.service';
import { SessionContextHandler } from '../../command/session.context.handler';
import { PlayerClientService } from '../../player.client/player.client.service';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { WorkerClientService } from '../../worker.client/worker.client.service';
import { ChipPushPurpose } from '../player.handling/enum/chip.push.purpose';
import { RobotCoinDto } from './dto';
import { SessionDataManager } from '../../session.data.manager/session.data.manager';

@Injectable({ scope: Scope.REQUEST })
export class CoinShotHandler extends SessionContextHandler<RobotCoinDto> {
  private roundRepo: RoundRepository;
  private activeRound: RoundEntity;

  constructor(
    @Inject(MAIN_LOGGER) logger: Logger,
    private readonly dispenserRepo: MachineDispenserRepository,
    private readonly config: ConfigService,
    private readonly robotClient: RobotClientService,
    private readonly playerClient: PlayerClientService,
    private readonly workerClient: WorkerClientService,
    private readonly monitoringClient: MonitoringWorkerClientService,
    private readonly betBehindService: BetBehindService,
    private readonly sessionDataManager: SessionDataManager,
    dataSource: DataSource,
  ) {
    super(logger, dataSource);
  }

  protected async init(data: RobotCoinDto): Promise<void> {
    await super.init(data);

    // transactional repos
    this.roundRepo = new RoundRepository(this.entityManager);

    this.session = await this.sessionRepository.findOneOrFail({
      where: { id: this.cachedSession.id },
      relations: ['rounds', 'machine'],
    });

    this.activeRound = this.session.getActiveRound();
    if (!this.activeRound) {
      throw new RpcException(`Coin shot handler: no active round! SessionId: ${this.session.id}`);
    }
  }

  protected async handleEvent(): Promise<void> {
    if (this.activeRound.coins > 0) {
      await this.roundRepo.decrement({ id: this.activeRound.id }, 'coins', 1);
    }

    const { autoplay } = await this.sessionDataManager.getSessionData(this.sessionId);

    if (this.activeRound.coins === this.cachedGroup.stackSize) {
      const isPlayerIdl = (autoplay && autoplay.forced) || this.session.status === SessionStatus.FORCED_AUTOPLAY;
      this.sessionDataManager.updateSessionData({ isPlayerIdl }, this.sessionId);
    }

    if (this.session.configuration?.gameMode === CoinPusherGameMode.AUTO_FIRE && this.session.gameId === GameId.COIN_PUSHER_V1) {
      const isInvalidCoinShot = !autoplay || ![SessionStatus.FORCED_AUTOPLAY, SessionStatus.AUTOPLAY].includes(this.session.status);
      isInvalidCoinShot && this.monitoringClient.sendAlertMessage({
        alertType: AlertType.WARNING,
        source: AlertSource.GAME_CORE,
        severity: AlertSeverity.HIGH,
        description: AlertDescription.INVALID_MANUAL_COIN_SHOT,
        gameId: this.cachedMachine.gameId,
        details: {
          sessionId: this.session.id,
          roundId: this.activeRound.id,
          machineId: this.cachedMachine.id,
          machineName: this.cachedMachine.name,
          machineSerial: this.cachedMachine.serial,
        },
      });
    }

    this.activeRound.coins -= 1;

    await this.rtpPush();
    this.monitoringClient.sendEventLogMessage({
      eventType: EventType.COIN_DISPENSED,
      source: EventSource.ROBOT,
      params: {
        remainingCoins: this.activeRound.coins,
        sessionId: this.session.id,
        machineSerial: this.cachedMachine.serial,
        playerCid: this.cachedPlayer.cid,
        machineId: this.cachedMachine.id,
      },
    });

    if (this.isRoundEnd()) {
      await this.workerClient.timeoutStop({
        timeoutType: TimeoutType.IDLE,
        sessionId: this.sessionId,
        payload: { gameId: this.session.gameId },
      }, this.correlationId);

      let timeoutSec = this.config.get(['core', 'ROUND_END_DELAY_SECONDS']);
      const existingAnimationTimeout = await this.workerClient.getTimeoutExpiration({
        timeoutType: TimeoutType.ANIMATION_IN_QUEUE,
        sessionId: this.sessionId,
      });
      if (existingAnimationTimeout) {
        await this.workerClient.timeoutStop({
          timeoutType: TimeoutType.ANIMATION_IN_QUEUE,
          sessionId: this.sessionId,
          payload: { gameId: this.session.gameId },
        });
        const animationTtl = existingAnimationTimeout.diff(moment(), 'second');
        if (animationTtl > timeoutSec) {
          timeoutSec = animationTtl;
        }
      }

      await this.workerClient.timeoutStart({
        timeoutType: TimeoutType.ROUND_END_DELAY,
        sessionId: this.sessionId,
        timeoutSec,
        payload: { gameId: this.session.gameId },
      }, this.correlationId);
    } else {
      await this.betBehindService.coinCountTracking({
        queueId: this.cachedSession.queue.id,
        coins: this.activeRound.coins,
        stackSize: this.cachedGroup.stackSize,
        machineSerial: this.cachedMachine.serial,
        machineId: this.cachedMachine.id,
        roundId: this.activeRound.id,
        correlationId: this.correlationId,
        bbRoundDurationInStack: this.cachedSession.configuration.bbRoundDurationInStack,
        enabledBetBehind: this.cachedSession.configuration.betBehind.isEnabled,
      });
    }
    this.playerClient.broadcastRemainingCoins(this.cachedMachine.serial, this.activeRound.coins);
  }

  private isRoundEnd(): boolean {
    return this.activeRound.coins <= 0;
  }

  private async rtpPush(): Promise<void> {
    const afterCoin = this.cachedGroup.stackSize - this.activeRound.coins;
    const toPush = this.activeRound?.rtp?.find(value => value.afterCoin === afterCoin);
    if (!toPush) {
      return;
    }

    const { types } = toPush;
    const dispensers = await this.dispenserRepo.createQueryBuilder('d')
      .leftJoinAndSelect('d.chipType', 'ct')
      .where('d.machine_id = :machineId', { machineId: this.cachedMachine.id })
      .andWhere('ct.name IN (:...types)', { types })
      .getMany();
    const dispenserTypeToNameMap = dispensers.reduce((acc, dispenser) => {
      const dispensers = acc.get(dispenser.chipType.name);
      if (dispensers) {
        dispensers.push(dispenser);
      } else {
        acc.set(dispenser.chipType.name, [dispenser]);
      }
      return acc;
    }, new Map<string, MachineDispenserEntity[]>());
    for (const type of types) {
      const dispensers = dispenserTypeToNameMap.get(type);
      const dispenser = dispensers?.length && dispensers
        .sort((a, b) => b.level - a.level)[0];
      if (dispenser?.level) {
        dispenser.level -= 1;
        this.robotClient.sendPushMessage(dispenser.name, this.cachedMachine.serial);
        this.monitoringClient.sendEventLogMessage({
          source: EventSource.GAME,
          eventType: EventType.PUSH,
          params: {
            machineSerial: this.cachedMachine.serial,
            dispenser: dispenser.name,
            chipTypes: types,
            purpose: ChipPushPurpose.RTP,
          },
        });
      }
    }
  }
}
