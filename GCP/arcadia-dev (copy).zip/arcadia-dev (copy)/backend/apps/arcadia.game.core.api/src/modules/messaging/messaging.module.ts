import {
  BallRepository,
  ChipRepository,
  ChipTypeRepository,
  GameId,
  GroupRepository,
  MachineDispenserRepository,
  MachineRepository,
  PlayerRepository,
  QueueRepository,
  RngChipPrizeRepository,
  RngPhantomPrizeRepository,
  RoundArchiveRepository,
  RoundRepository,
  SeedHistoryRepository,
  SessionRepository,
  VoucherRepository,
} from '@lib/dal';
import { MonitoringWorkerClientModule } from '@lib/monitoring.worker.client';
import { Module } from '@nestjs/common';
import { ThrottlerModule } from '@nestjs/throttler';
import { PlayerRetentionService } from '../auth/player.retention.service';
import { BetBehindModule } from '../bet.behind/bet.behind.module';
import { ConfigValidatorModule } from '../config.validator/config.validator.module';
import { ConversionTrackerModule } from '../conversion.tracker/conversion.tracker.module';
import { GroupTerminatorModule } from '../group.terminator/group.terminator.module';
import { OperatorApiClientModule } from '../operator.api.client/operator.api.client.module';
import { QueueManagerModule } from '../queue.manager/queue.manager.module';
import { RngServiceClientModule } from '../rng.service.client/rng.service.client.module';
import { RobotClientModule } from '../robot.client/robot.client.module';
import { RouletteEngineModule } from '../roulette.engine/roulette.engine.module';
import { RoundModule } from '../round/round.module';
import { SessionDataManagerModule } from '../session.data.manager/session.data.manager.module';
import { SessionModule } from '../session/session.module';
import { WorkerClientModule } from '../worker.client/worker.client.module';
import { PlayerMessageController } from './player.handling/player.message.controller';
import { PlayerMessageService } from './player.handling/player.message.service';
import { PlayerRequestController } from './player.handling/player.request.controller';
import { BuyStacksCoinPusherHandler } from './player.handling/game.strategy/buy.stacks.coin.pusher.handler';
import { BbRoundEndHandler } from './robot.handling/bb.round.end.handler';
import { BbRoundRollbackHandler } from './robot.handling/bb.round.rollback.handler';
import { BbRoundStartHandler } from './robot.handling/bb.round.start.handler';
import { BbWinHandler } from './robot.handling/bb.win.handler';
import { ChipDetectionHandler } from './robot.handling/chip.detection.handler';
import { ChipDropHandler } from './robot.handling/chip.drop.handler';
import { ChipDropNoSessionHandler } from './robot.handling/chip.drop.no.session.handler';
import { CoinShotHandler } from './robot.handling/coin.shot.handler';
import { ClawRouletteLoginStrategy } from './robot.handling/login.strategies/claw.roulette.login.strategy';
import { CoinPusherV1LoginStrategy } from './robot.handling/login.strategies/coin.pusher.v1.login.strategy';
import { RobotMessageController } from './robot.handling/robot.message.controller';
import { RobotMessageService } from './robot.handling/robot.message.service';
import { RoundEndHandler } from './robot.handling/round.end.handler';
import { TransactionalController } from './robot.handling/transactional.controller';
import { robotLoginKeyFactory } from './robot.handling/util/robot.login.key.factory';
import { SessionInjectorPipe } from './session.injector.pipe';
import { ChipWatcherModule } from '../chip.watcher/chip.watcher.module';
import { ClawLoginStrategy } from './robot.handling/login.strategies/claw.login.strategy';

@Module({
  imports: [
    SessionModule,
    QueueManagerModule,
    OperatorApiClientModule,
    RngServiceClientModule,
    MonitoringWorkerClientModule,
    WorkerClientModule,
    RobotClientModule,
    RoundModule,
    SessionDataManagerModule,
    GroupTerminatorModule,
    ConfigValidatorModule,
    BetBehindModule,
    ConversionTrackerModule,
    ThrottlerModule.forRoot({
      ttl: 1,
      limit: 10,
    }),
    RouletteEngineModule,
    ChipWatcherModule,
  ],
  providers: [
    SessionInjectorPipe,
    PlayerMessageService,
    RobotMessageService,
    CoinShotHandler,
    ChipDropHandler,
    ChipDropNoSessionHandler,
    BbRoundStartHandler,
    BbRoundRollbackHandler,
    BbRoundEndHandler,
    BbWinHandler,
    ChipDetectionHandler,
    RoundEndHandler,
    BuyStacksCoinPusherHandler,
    BallRepository,
    SessionRepository,
    ChipRepository,
    MachineRepository,
    QueueRepository,
    PlayerRepository,
    MachineDispenserRepository,
    ChipTypeRepository,
    RoundRepository,
    RoundArchiveRepository,
    SeedHistoryRepository,
    GroupRepository,
    RngChipPrizeRepository,
    VoucherRepository,
    RngPhantomPrizeRepository,
    {
      provide: robotLoginKeyFactory(GameId.COIN_PUSHER_V1),
      useClass: CoinPusherV1LoginStrategy,
    },
    {
      provide: robotLoginKeyFactory(GameId.CLAW_ROULETTE),
      useClass: ClawRouletteLoginStrategy,
    },
    {
      provide: robotLoginKeyFactory(GameId.CLAW),
      useClass: ClawLoginStrategy,
    },
    PlayerRetentionService,
  ],
  controllers: [
    RobotMessageController,
    PlayerMessageController,
    PlayerRequestController,
    TransactionalController,
  ],
  exports: [
    SessionInjectorPipe,
    PlayerMessageService,
    RobotMessageService,
  ],
})
export class MessagingModule {
}
