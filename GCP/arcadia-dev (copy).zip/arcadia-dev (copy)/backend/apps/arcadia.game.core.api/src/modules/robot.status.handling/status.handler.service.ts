import { EventSource } from '@lib/common';
import {
  AlertSeverity, AlertSource, AlertType, EventType, MachineRepository, MachineStatus,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Inject, Injectable } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import moment from 'moment';
import { Logger } from 'winston';
import { CoreMessage } from '../messaging/robot.handling/enum/core.message';
import { RobotClientService } from '../robot.client/robot.client.service';
import { RobotReportedStatus } from './robot.reported.status';
import { StatusStrategyFactory } from './strategy/status.strategy.factory';

@Injectable()
export class StatusHandlerService {
  constructor(
    private readonly machineRepo: MachineRepository,
    private readonly statusStrategyFactory: StatusStrategyFactory,
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly monitoringService: MonitoringWorkerClientService,
    private readonly robotClient: RobotClientService,
  ) {
  }

  public async handleStatus(status: RobotReportedStatus, serial: string): Promise<void> {
    const machine = await this.machineRepo.findOneOrFail({
      where: { serial },
      relations: ['group'],
    })
      .catch(reason => {
        throw new RpcException(reason);
      });
    this.logger.debug('Robot status', {
      robotStatus: status,
      serverStatus: machine.status,
      machineSerial: machine.serial,
    });
    if (machine.status === MachineStatus.OFFLINE
      && moment()
        .diff(machine.pingDate, 'second') > 30) {
      this.robotClient.sendRobotMessage({ action: CoreMessage.REBOOT }, machine.serial);
      this.monitoringService.sendAlertMessage({
        alertType: AlertType.WARNING,
        severity: AlertSeverity.MEDIUM,
        source: AlertSource.GAME_CORE,
        description: 'Status report into offline state, reboot requested',
        gameId: machine.gameId,
        details: {
          machineId: machine.id,
          machineName: machine.name,
          machineSerial: machine.serial,
        },
      });
      return;
    }
    const strategy = this.statusStrategyFactory.getStrategy(machine, status);
    this.logger.debug('Status strategy', {
      strategy: strategy.toString(),
      machineSerial: machine.serial,
    });
    switch (status) {
      case RobotReportedStatus.STOPPED:
        await strategy.onStopped(machine);
        break;
      case RobotReportedStatus.TESTING:
        await strategy.onTesting(machine);
        break;
      case RobotReportedStatus.IDLE:
        await strategy.onIdle(machine);
        break;
      case RobotReportedStatus.STOPPING:
        await this.monitoringService.sendEventLogMessage({
          eventType: EventType.STOPPING,
          source: EventSource.ROBOT,
          params: {
            machineSerial: serial,
          },
        });
        await strategy.onStopping(machine);
        break;
      case RobotReportedStatus.SEEDING:
        await strategy.onSeeding(machine);
        break;
      case RobotReportedStatus.MANUAL_PLAY:
      case RobotReportedStatus.AUTO_PLAY:
      case RobotReportedStatus.IN_ROUND:
      default:
        this.logger.debug('No handler for status', { status });
    }
    await this.machineRepo.update(machine.id, { pingDate: () => 'NOW()' });
  }
}
