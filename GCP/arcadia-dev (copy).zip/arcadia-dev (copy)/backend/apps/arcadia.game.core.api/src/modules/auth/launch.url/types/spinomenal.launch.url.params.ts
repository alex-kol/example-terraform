import { GameId } from '@lib/dal';
import { LaunchParams } from './launch.params';

export class SpinomenalLaunchUrlParams extends LaunchParams {
  gameToken: string;
  partnerId: string;
  authToken?: string;
  gameId: GameId;
  isReal?: boolean;
  languageCode?: string;
  homeUrl?: string;
  cashierUrl?: string;
  jurisdiction?: string;
}
