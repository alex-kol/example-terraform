export class VoucherDto {
  voucherId: number;
  expirationDate?: Date;
}