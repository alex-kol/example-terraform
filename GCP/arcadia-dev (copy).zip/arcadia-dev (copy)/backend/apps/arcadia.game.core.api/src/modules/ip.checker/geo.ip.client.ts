import { HttpService } from '@nestjs/axios';
import { Injectable, NotAcceptableException } from '@nestjs/common';
import * as Joi from 'joi';
import { firstValueFrom } from 'rxjs';
import { map } from 'rxjs/operators';
import { IpGeoResp } from './ip.geo.resp';

const validationSchema: Joi.ObjectSchema = Joi.object({
  ip: Joi.string()
    .required(),
  country_code: Joi.string()
    .length(2)
    .required(),
  country_code3: Joi.string()
    .length(3)
    .required(),
  continent_code: Joi.string(),
  country: Joi.string(),
  region: Joi.string(),
  city: Joi.string(),
});

@Injectable()
export class GeoIpClient {
  constructor(private readonly httpClient: HttpService) {
  }

  public async getGeoByIp(ipAddress: string): Promise<IpGeoResp> {
    const result = await firstValueFrom(this.httpClient.get(`/geo/${ipAddress}.json`)
      .pipe(map(({ data }) => data)));
    const {
      error,
      value,
    } = validationSchema.validate(result, { stripUnknown: true });
    if (error) {
      throw new NotAcceptableException(`Bad Geo IP response, IP: ${ipAddress}, error: ${JSON.stringify(error.details)}`);
    }
    return {
      ip: value.ip,
      countryCode: value.country_code,
      countryCode3: value.country_code3,
      country: value.country,
      region: value.region,
      city: value.city,
      continentCode: value.continent_code,
    };
  }
}
