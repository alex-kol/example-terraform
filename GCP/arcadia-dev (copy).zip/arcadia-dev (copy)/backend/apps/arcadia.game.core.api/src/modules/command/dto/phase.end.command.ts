import { IsEnum } from 'class-validator';
import { GamePhase } from '../../roulette.engine/enums';
import { RouletteCommand } from './roulette.command';

export class PhaseEndCommand extends RouletteCommand {
  @IsEnum(GamePhase)
  public phase: GamePhase;
}
