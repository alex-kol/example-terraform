import { GameId } from '@lib/dal';

export const robotLoginKeyFactory = (gameId: GameId) => `${gameId}_ROBOT_LOGIN_INJECT_TOKEN`;
