import { Test } from '@nestjs/testing';
import { ServerRMQ } from '@lib/rmq.server';
import { CommandPublisher } from '../command.publisher';

export const eventBusRmqServerMock = {
  sendMessage: () => null,
  setupChannel: () => null,
};

export async function makeTestModule() {
  const moduleFixture = await Test.createTestingModule({
    imports: [],
    providers: [
      CommandPublisher,
      {
        useValue: eventBusRmqServerMock,
        provide: ServerRMQ,
      },
    ],
  })
    .compile();
  // @ts-ignore
  return moduleFixture;
}
