export enum PlayerTypeEnum {
    CSRTCPlayer = 'CSRTCPlayer',
    HLSPlayer = 'HLSPlayer'
}
