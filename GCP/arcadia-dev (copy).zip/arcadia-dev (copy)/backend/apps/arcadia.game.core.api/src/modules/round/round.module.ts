import { Module } from '@nestjs/common';
import { MonitoringWorkerClientModule } from '@lib/monitoring.worker.client';
import { OperatorApiClientModule } from '../operator.api.client/operator.api.client.module';
import { RngServiceClientModule } from '../rng.service.client/rng.service.client.module';
import { SessionDataManagerModule } from '../session.data.manager/session.data.manager.module';
import { RoundServiceFactory } from './round.service.factory';
import { RobotClientModule } from '../robot.client/robot.client.module';
import { WorkerClientModule } from '../worker.client/worker.client.module';

@Module({
  imports: [RngServiceClientModule, MonitoringWorkerClientModule, OperatorApiClientModule,
    SessionDataManagerModule, RobotClientModule, WorkerClientModule],
  providers: [RoundServiceFactory],
  exports: [RoundServiceFactory],
})
export class RoundModule {

}