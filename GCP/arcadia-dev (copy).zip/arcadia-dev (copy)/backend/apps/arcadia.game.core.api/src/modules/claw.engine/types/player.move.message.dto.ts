import { IsEnum } from 'class-validator';
import { SessionAwareDto } from '../../dto/session.aware.dto';
import { ClawDirection } from '../enums/claw.direction';

export class PlayerMoveMessageDto extends SessionAwareDto {
  @IsEnum(ClawDirection)
  public direction: string;
}