export class BalanceData {
  balance: number;
}
