import { streamToObs } from '@lib/dal';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { Injectable } from '@nestjs/common';
import BigNumber from 'bignumber.js';
import { Redis } from 'ioredis';
import {
  bufferCount, concatMap, from, Observable,
} from 'rxjs';
import { map } from 'rxjs/operators';
import { toCash } from '../../util';
import { RouletteBetResponse } from '../messaging/player.handling/interfaces/roulette.bet.response';
import { getRouletteBetKeyPattern } from './redis.roulette.bet.key';
import { RedisBet, RouletteBet, RoundBet } from './types';

@Injectable()
export class BetManager {
  private readonly redis: Redis;

  constructor(cacheManager: RedisCacheService) {
    this.redis = cacheManager.store.getClient();
  }

  public async getBet(serial: string, sessionId: number): Promise<RoundBet | null> {
    const bet: string | null = await this.redis.hget(getRouletteBetKeyPattern(serial), `${sessionId}`);
    return bet && JSON.parse(bet);
  }

  public async setBet(serial: string, sessionId: number, bet: RoundBet): Promise<void> {
    await this.redis.hset(getRouletteBetKeyPattern(serial), { [`${sessionId}`]: JSON.stringify(bet) });
  }

  public async removeBet(serial: string, sessionId: number): Promise<void> {
    await this.redis.hdel(getRouletteBetKeyPattern(serial), `${sessionId}`);
  }

  public getMachineBets(serial: string): Observable<RedisBet> {
    const stream = this.redis.hscanStream(getRouletteBetKeyPattern(serial), { count: 20 });
    return streamToObs<string[]>(stream)
      .pipe(
        concatMap(value => from(value)
          .pipe(bufferCount(2))),
        map(([sessionId, betJson]) => ({
          sessionId: Number(sessionId),
          bet: (JSON.parse(betJson) as RoundBet).bet,
        })),
      );
  }

  public async dropBets(serial: string): Promise<void> {
    await this.redis.del(getRouletteBetKeyPattern(serial));
  }

  public getBetInCash(currentBet: RouletteBet, currencyConversionRate: number): RouletteBetResponse {
    if (!currentBet) {
      return {
        bet: {},
        totalInCash: 0,
      };
    }
    let totalBet = new BigNumber(0);
    const betsInCash = Object.entries(currentBet)
      .reduce((acc: Record<string, number>, [position, bets]) => {
        const betSum = bets.reduce((acc, bet) => acc.plus(bet), new BigNumber(0));
        const betSumInCash = toCash(betSum, currencyConversionRate);
        acc[position] = betSumInCash;
        totalBet = totalBet.plus(betSumInCash);
        return acc;
      }, {});
    return {
      bet: betsInCash,
      totalInCash: totalBet.dp(2)
        .toNumber(),
    };
  }
}
