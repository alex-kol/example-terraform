import { Length } from 'class-validator';
import { RobotMessage } from '../../messaging/robot.handling/dto';

export class ClawResultDto extends RobotMessage {
  @Length(0, 128)
  public rfid: string;
}
