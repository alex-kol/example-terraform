import { ConfigService } from '@lib/config';
import { Test } from '@nestjs/testing';
import { ServerRMQ } from '@lib/rmq.server';
import { PlayerClientService } from '../../player.client/player.client.service';
import { WorkerClientService } from '../worker.client.service';

export const workerRmqServerMock = {
  sendMessage: () => null,
};

export async function makeTestModule() {
  const moduleFixture = await Test.createTestingModule({
    imports: [],
    providers: [
      WorkerClientService,
      {
        useValue: { get: () => null },
        provide: ConfigService,
      },
      {
        useValue: workerRmqServerMock,
        provide: ServerRMQ,
      },
      {
        useValue: { notifyIdleTimeoutReset: () => null },
        provide: PlayerClientService,
      },
    ],
  })
    .compile();
  return moduleFixture;
}
