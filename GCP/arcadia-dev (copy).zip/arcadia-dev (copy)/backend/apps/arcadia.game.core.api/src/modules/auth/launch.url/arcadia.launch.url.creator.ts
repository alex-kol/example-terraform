import { deleteUndefinedValue, OperatorTag, UserLoginDto } from '@lib/common';
import { ConfigService } from '@lib/config';
import { OperatorEntity, OperatorRepository, OperatorStatus } from '@lib/dal';
import { Injectable, NotAcceptableException } from '@nestjs/common';
import { StandardLanguageMapper } from './languages';
import { LaunchUrlCreator } from './launch.url.creator';
import { arcadiaLaunchParamsValidationSchema } from './params.validation.schemas';

@Injectable()
export class ArcadiaLaunchUrlCreator extends LaunchUrlCreator {
  protected readonly paramsValidationSchema = arcadiaLaunchParamsValidationSchema;

  constructor(
    config: ConfigService,
    private readonly operatorRepo: OperatorRepository,
    private readonly arcadiaLanguage: StandardLanguageMapper,
  ) {
    super(config);
  }

  protected getId(): string {
    return OperatorTag.ARCADIA;
  }

  protected getOperator(): Promise<OperatorEntity> {
    return this.operatorRepo.findOneByOrFail({
      apiConnectorId: OperatorTag.ARCADIA,
      externalId: this.params.externalId || null,
      isDeleted: false,
      status: OperatorStatus.ENABLED,
    })
      .catch(() => {
        throw new NotAcceptableException('Operator not found or disabled');
      });
  }

  protected mapParams(): UserLoginDto {
    const {
      groupId,
      accessToken,
      homeUrl,
      languageCode,
      gameId,
      cashierUrl,
      jurisdiction,
    } = this.params;
    const result: UserLoginDto = {
      operatorId: this.operator.id,
      accessToken,
      homeUrl,
      groupId,
      gameId,
      language: this.arcadiaLanguage.getLanguageCode(languageCode),
      cashierUrl,
      jurisdiction,
    };
    deleteUndefinedValue(result);
    return result;
  }

  protected async validateCaller(): Promise<void> {
    return Promise.resolve();
  }
}
