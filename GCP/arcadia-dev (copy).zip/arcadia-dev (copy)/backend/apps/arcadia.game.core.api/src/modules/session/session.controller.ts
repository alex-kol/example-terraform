import {
  CommandType,
  LoggerInterceptor,
  NewrelicAndMessagePattern,
  RmqQueueName,
  rmqRoutingGenerate,
  RpcMainExceptionFilter,
  rpcValidationExceptionFactory,
} from '@lib/common';
import { GameId } from '@lib/dal';
import {
  Controller, UseFilters, UseInterceptors, UsePipes, ValidationPipe,
} from '@nestjs/common';
import { Payload } from '@nestjs/microservices';
import { FinalizeSessionCommand } from '../command/dto/finalize.session.command';
import { SessionService } from './session.service';

@Controller({ path: 'v1/session' })
@UseInterceptors(LoggerInterceptor)
@UseFilters(RpcMainExceptionFilter)
@UsePipes(new ValidationPipe({
  transform: true,
  whitelist: true,
  exceptionFactory: rpcValidationExceptionFactory,
}))
export class SessionController {
  constructor(private readonly sessionService: SessionService) {}

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.CORE_COMMAND_QUEUE, CommandType.FINALIZE_SESSION, GameId.COMMON))
  public async finalizeSession(@Payload() data: FinalizeSessionCommand): Promise<void> {
    await this.sessionService.finalizeSession(data.sessionId, data.reason, data.terminate);
  }
}
