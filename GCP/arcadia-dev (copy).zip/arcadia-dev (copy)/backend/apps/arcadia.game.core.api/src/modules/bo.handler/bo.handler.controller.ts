import { MachineReassignDto, LoggerInterceptor } from '@lib/common';
import { MAIN_LOGGER } from '@lib/logger';
import {
  Body, Controller, Headers, Inject, Param, ParseIntPipe, Post, UseInterceptors,
} from '@nestjs/common';
import {
  ApiBadRequestResponse, ApiCreatedResponse, ApiNotAcceptableResponse, ApiTags,
} from '@nestjs/swagger';
import { Logger } from 'winston';
import { CORRELATION_ID_HEADER } from '../../constants/logging.constants';
import { BoHandlerService } from './bo.handler.service';
import {
  GroupStopDto, MachineStartDto, MachineStartResponseDto, TerminateSessionDto,
} from './dto';
import { TransactionRetryService } from './transaction.retry.service';

@ApiTags('Backoffice')
@UseInterceptors(LoggerInterceptor)
@ApiBadRequestResponse({ description: 'Bad request' })
@Controller('v1/backoffice')
export class BoHandlerController {
  constructor(
    private readonly boHandler: BoHandlerService,
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly transactionRetryService: TransactionRetryService,
  ) {
  }

  @ApiCreatedResponse({ description: 'Success' })
  @ApiNotAcceptableResponse({ description: 'Not acceptable' })
  @Post('/group/:id/softStop')
  public groupSoftStop(
    @Param('id', ParseIntPipe) groupId: number,
    @Body() data: GroupStopDto,
    @Headers(CORRELATION_ID_HEADER) corrId: string,
  ): Promise<any> {
    this.logger.debug('Group soft stop', { groupId, data, correlationId: corrId });
    return this.boHandler.groupSoftStopHandler(groupId, data?.machineIds, corrId);
  }

  @ApiCreatedResponse({ description: 'Success' })
  @ApiNotAcceptableResponse({ description: 'Not acceptable' })
  @Post('/group/:id/hardStop')
  public groupHardStop(
    @Param('id', ParseIntPipe) groupId: number,
    @Body() data: GroupStopDto,
    @Headers(CORRELATION_ID_HEADER) corrId: string,
  ): Promise<any> {
    this.logger.debug('Group hard stop', { groupId, data, correlationId: corrId });
    return this.boHandler.groupHardStopHandler(groupId, data, corrId);
  }

  @ApiCreatedResponse({
    description: 'Success',
    type: MachineStartResponseDto,
  })
  @ApiNotAcceptableResponse({ description: 'Not acceptable' })
  @Post('/machine/:id/start')
  public machineStart(
    @Param('id', ParseIntPipe) machineId: number,
    @Body() data: MachineStartDto,
    @Headers(CORRELATION_ID_HEADER) corrId: string,
  ): Promise<MachineStartResponseDto> {
    this.logger.debug('Machine start', { machineId, data, correlationId: corrId });
    return this.boHandler.machineStartHandler(machineId, data, corrId);
  }

  @ApiCreatedResponse({
    description: 'Success',
    type: MachineReassignDto,
  })
  @ApiNotAcceptableResponse({ description: 'Not acceptable' })
  @Post('/machine/:id/reassign')
  public machineReassign(
    @Param('id', ParseIntPipe) machineId: number,
    @Body() data: MachineReassignDto,
    @Headers(CORRELATION_ID_HEADER) corrId: string,
  ): Promise<MachineReassignDto> {
    this.logger.debug('Machine reassign', { machineId, data, correlationId: corrId });
    return this.boHandler.machineReassign(machineId, data);
  }

  @ApiCreatedResponse({ description: 'Success' })
  @ApiNotAcceptableResponse({ description: 'Not acceptable' })
  @Post('/machine/:id/reboot')
  public machineReboot(
    @Param('id', ParseIntPipe) machineId: number,
    @Headers(CORRELATION_ID_HEADER) corrId: string,
  ): Promise<any> {
    this.logger.debug('Machine reboot', { machineId, correlationId: corrId });
    return this.boHandler.machineReboot(machineId);
  }

  @ApiCreatedResponse({ description: 'Success' })
  @ApiNotAcceptableResponse({ description: 'Not acceptable' })
  @Post('/session/:id/terminate')
  public terminateSession(
    @Param('id', ParseIntPipe) sessionId: number,
    @Headers(CORRELATION_ID_HEADER) correlationId: string,
    @Body() { reason }: TerminateSessionDto,
  ): Promise<number> {
    this.logger.debug('Terminate session', { sessionId, correlationId });
    return this.boHandler.terminateSession(sessionId, correlationId, reason);
  }

  @ApiCreatedResponse({ description: 'Success' })
  @Post('/transaction/:id/retry')
  public async retryTransaction(
    @Param('id', ParseIntPipe) transactionId: number,
    @Headers(CORRELATION_ID_HEADER) corrId: string,
  ): Promise<any> {
    this.logger.debug('Retry transaction', { transactionId, correlationId: corrId });
    return this.transactionRetryService.retryTransaction(transactionId, corrId);
  }
}
