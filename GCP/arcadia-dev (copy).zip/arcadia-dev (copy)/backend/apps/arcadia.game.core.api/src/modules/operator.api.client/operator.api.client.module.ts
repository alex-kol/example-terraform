import { keepAliveAgents, OPERATOR_CLIENT_TIMEOUT_MS } from '@lib/common';
import { getOperatorFactoryHttpServiceTimeoutMs } from '@lib/common/utils';
import { ConfigService } from '@lib/config';
import { FailedTransactionRepository, PlayerRepository, SessionRepository } from '@lib/dal';
import { HttpModule } from '@nestjs/axios';
import { Module } from '@nestjs/common';
import { OperatorApiClientService } from './operator.api.client.service';
import { OperatorController } from './operator.controller';
import { RetryScheduler } from './retry.scheduler';

@Module({
  imports: [
    HttpModule.registerAsync({
      useFactory: async configService => {
        getOperatorFactoryHttpServiceTimeoutMs();
        return {
          baseURL: configService.get(['core', 'OPERATOR_SERVICE_API_URL']),
          timeout: OPERATOR_CLIENT_TIMEOUT_MS,
          httpAgent: keepAliveAgents.httpAgent,
          httpsAgent: keepAliveAgents.httpsAgent,
        };
      },
      inject: [ConfigService],
    }),
  ],
  providers: [
    OperatorApiClientService,
    RetryScheduler,
    FailedTransactionRepository,
    PlayerRepository,
    SessionRepository,
  ],
  controllers: [OperatorController],
  exports: [OperatorApiClientService],
})
export class OperatorApiClientModule {
}
