/* eslint-disable max-lines */
import { CommandType, TimeoutType } from '@lib/common';
import {
  GameId,
  GroupRepository,
  GroupStatus,
  MachineEntity,
  MachineRepository,
  MachineStatus,
  QueueEntity,
  QueueRepository,
  QueueStatus,
  SessionEndReason,
  SessionEntity,
  ShutdownReason,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { Inject, Injectable } from '@nestjs/common';
import { Logger } from 'winston';
import { GroupStopDto } from '../../bo.handler/dto';
import { CommandPublisher } from '../../command/command.publisher';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { WorkerClientService } from '../../worker.client/worker.client.service';
import { GroupTerminator } from './group.terminator';

@Injectable()
export class ClawGroupTerminator extends GroupTerminator {
  constructor(
      private readonly machineRepository: MachineRepository,
      private readonly queueRepository: QueueRepository,
      private readonly groupRepository: GroupRepository,
      private readonly robotClient: RobotClientService,
      private readonly workerClient: WorkerClientService,
      @Inject(MAIN_LOGGER) private readonly logger: Logger,
      private readonly commandPublisher: CommandPublisher,
  ) {
    super();
  }

  public async groupSoftStop(
    groupId: number, machineIds?: number[], correlationId?: string,
  ): Promise<void> {
    const wholeGroup = !machineIds?.length;
    const machines = await this.machineRepository.getByGroupAndIds(groupId, machineIds);
    if (!machines?.length) {
      if (wholeGroup) {
        await this.groupRepository.update(groupId, { status: GroupStatus.OFFLINE });
      }
      this.logger.warn('No machines to stop on dry');
      return;
    }

    const {
      toStop,
      toDry,
      toKick,
    } = machines.reduce(
      (accum: { toDry: QueueEntity[]; toStop: MachineEntity[]; toKick: SessionEntity[]; }, machine) => {
        const { queue } = machine;
        if (!queue || queue.status === QueueStatus.DRYING || queue.status === QueueStatus.STOPPED) {
          return accum;
        }
        if (queue.sessions?.length) {
          const {
            active,
            kick,
          } = queue.sessions.reduce(
            (acc: { active: SessionEntity[], kick: SessionEntity[] }, session) => {
              if (session.getActiveRound()) {
                acc.active.push(session);
              } else {
                acc.kick.push(session);
              }
              return acc;
            }, {
              active: [],
              kick: [],
            });
          if (active.length) {
            accum.toDry.push(queue);
          } else {
            accum.toStop.push(machine);
          }
          accum.toKick.push(...kick);
        } else {
          accum.toStop.push(machine);
        }
        return accum;
      }, {
        toDry: [],
        toStop: [],
        toKick: [],
      });

    if (toDry.length) {
      const queueIds = toDry.map(value => value.id);
      this.logger.debug('Start drying queues', { queueIds, correlationId });
      await this.queueRepository.update(queueIds, { status: QueueStatus.DRYING });
      if (wholeGroup) {
        await this.groupRepository.update(groupId, { status: GroupStatus.DRYING });
      }
    } else if (wholeGroup) {
      await this.groupRepository.update(groupId, { status: GroupStatus.OFFLINE });
    }
    if (toStop.length) {
      await this.queueRepository.update(toStop.map(machine => machine.queue.id),
        { status: QueueStatus.STOPPED });
      const machineIds = toStop.map(machine => machine.id);
      this.logger.debug('Stopping machines', { machineIds, correlationId });
      await this.machineRepository.update(machineIds, {
        status: MachineStatus.SHUTTING_DOWN,
        shutdownReason: ShutdownReason.USER_REQUEST,
      });
      toStop.forEach(machine => this.robotClient.sendStopMessage(machine.serial, ShutdownReason.USER_REQUEST));
    }
    toKick.forEach(session => {
      this.commandPublisher.queueChange({
        type: CommandType.CHANGE_QUEUE,
        gameId: GameId.CLAW,
        sessionId: session.id,
        ignoreMachines: machineIds,
        ignoreGroups: machineIds?.length ? undefined : [groupId],
      }, correlationId);
    });
  }

  public async groupHardStop(
    groupId: number,
    data: GroupStopDto,
    correlationId?: string,
  ): Promise<void> {
    if (!data.machineIds?.length) {
      await this.groupRepository.update(groupId, { status: GroupStatus.OFFLINE });
    }
    const machines = await this.groupRepository.getGroupHardStopData(groupId, data.machineIds);
    if (!machines?.length) {
      this.logger.warn('No machines to stop on shutdown');
      return;
    }

    const queueIdsToUpdate = machines.reduce((ids, machine) => {
      if (machine.queue) {
        ids.push(machine.queue.id);
      }
      return ids;
    }, []);

    if (queueIdsToUpdate.length) {
      await this.queueRepository.update(queueIdsToUpdate, { status: QueueStatus.STOPPED });
    }

    const {
      toShutDown,
      sessions,
    } = machines
      .reduce((acc: { toShutDown: MachineEntity[], sessions: SessionEntity[] }, machine) => {
        if (machine.status !== MachineStatus.STOPPED && machine.status !== MachineStatus.OFFLINE) {
          acc.toShutDown.push(machine);
        }
        if (machine.queue?.sessions?.length) {
          acc.sessions.push(...machine.queue.sessions);
        }
        return acc;
      }, {
        toShutDown: [],
        sessions: [],
      });
    if (toShutDown.length) {
      await this.machineRepository.update(toShutDown.map(machine => machine.id),
        {
          status: MachineStatus.SHUTTING_DOWN,
          shutdownReason: data.reason,
        });
      toShutDown.forEach(machine => this.robotClient.sendStopMessage(machine.serial, data.reason));
    }

    sessions.forEach(session => {
      const sessionId = Number(session.id);
      this.workerClient.timeoutStop({
        timeoutType: TimeoutType.REBUY,
        sessionId,
        payload: { gameId: session.gameId },
      }, correlationId);
      this.commandPublisher.terminateSession({
        type: CommandType.TERMINATE_SESSION,
        gameId: GameId.CLAW,
        sessionId,
        terminate: false,
        reason: SessionEndReason.MACHINE_STOP,
      }, correlationId);
    });
  }
}
