/* eslint-disable max-lines */
import { AlertDescription, RmqQueueName } from '@lib/common';
import { ConfigService } from '@lib/config';
import {
  AlertSeverity, AlertSource, AlertType, MachineEntity, MachineRepository, MachineStatus, QueueRepository, QueueStatus,
} from '@lib/dal';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { ServerRMQ } from '@lib/rmq.server';
import { Injectable, NotAcceptableException } from '@nestjs/common';
import { getRobotQueueName } from '../../../../util';
import { RobotLoginDto } from '../dto/robot.login.dto';
import { RobotLoginRes } from '../responses/robot.login.res';
import { RobotLoginInterface } from './robot.login.interface';

@Injectable()
export class ClawLoginStrategy extends RobotLoginInterface {
  readonly monitoringApiUrl: string;

  constructor(
    private readonly machineRepo: MachineRepository,
    private readonly queueRepo: QueueRepository,
    public readonly cacheManager: RedisCacheService,
    private readonly serverRMQ: ServerRMQ,
    private readonly configService: ConfigService,
    private readonly monitoringClient: MonitoringWorkerClientService,
  ) {
    super();
    this.monitoringApiUrl = configService.get(['core', 'ROBOT_FILES_API_URL']);
  }

  public async loginRobot(machine: MachineEntity, {
    serial,
    version,
    demoMode = false,
  }: RobotLoginDto): Promise<RobotLoginRes> {
    if (machine.cameras.length !== 2) {
      this.monitoringClient.sendAlertMessage({
        alertType: AlertType.ALERT,
        severity: AlertSeverity.MEDIUM,
        source: AlertSource.GAME_CORE,
        description: AlertDescription.CAMERA_IS_NOT_ASSIGN_TO_MACHINE_ON_MACHINE_LOGIN,
        gameId: machine.gameId,
        details: {
          machineId: machine.id,
          machineName: machine.name,
          machineSerial: machine.serial,
        },
      });
      throw new NotAcceptableException('Camera is not assigned');
    }

    if (!machine.queue) {
      const queue = await this.queueRepo.getFreeQueue();
      await this.queueRepo.update(queue.id, { machine });
    } else if (machine.queue.status !== QueueStatus.STOPPED) {
      await this.queueRepo.update(machine.queue.id, { status: QueueStatus.STOPPED });
    }

    await this.machineRepo.update(machine.id, {
      status: MachineStatus.OFFLINE,
      lastLoginDate: () => 'NOW()',
      pingDate: () => 'NOW()',
      version,
    });

    const queues = {
      publisher: RmqQueueName.ROBOT_TO_CORE_QUEUE,
      subscriber: getRobotQueueName(serial),
    };
    await this.serverRMQ.purgeQueue(queues.subscriber);

    return {
      queues,
      robotKey: machine.id,
      mgrMessageServer: this.configService.getRabbitMQConfig(!demoMode),
      playerMessageServer: {
        redis: this.configService.getRedisConfig(!demoMode),
        key: 'socket.io',
      },
      gameId: machine.gameId,
      fileApiUrl: this.monitoringApiUrl,
    };
  }
}
