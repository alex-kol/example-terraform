import { CommandType, EventSource } from '@lib/common';
import {
  EventType, GameId, RoundEntity, RoundRepository, RoundStatus, RoundType, SessionRepository,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { Inject } from '@nestjs/common';
import BigNumber from 'bignumber.js';
import { Logger } from 'winston';
import { CommandPublisher } from '../command/command.publisher';
import { RoundStartedDto } from '../messaging/player.handling/dto/round.started.dto';
import { PlayerClientService } from '../player.client/player.client.service';
import { SessionDataManager } from '../session.data.manager/session.data.manager';
import { bbSendInvitationThresholdCoins, betBehindInvitationTtlSec } from './constants';
import { CoinCountTrackingState, Invitation } from './types';
import { getInvitationRedisKey } from './utils';

export class BetBehindService {
  private readonly bbSendInvitationThresholdCoins: number;
  private readonly betBehindInvitationTtlSec: number;

  constructor(
    private readonly sessionRepository: SessionRepository,
    private readonly roundRepository: RoundRepository,
    private readonly playerClientService: PlayerClientService,
    private readonly sessionDataManager: SessionDataManager,
    private readonly commandPublisher: CommandPublisher,
    private readonly monitoringWorkerClientService: MonitoringWorkerClientService,
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly redisCache: RedisCacheService,
  ) {
    this.bbSendInvitationThresholdCoins = bbSendInvitationThresholdCoins;
    this.betBehindInvitationTtlSec = betBehindInvitationTtlSec;
  }

  public async coinCountTracking(
    coinCountTrackingState: CoinCountTrackingState,
  ): Promise<void> {
    if (coinCountTrackingState.roundId) { // TODO: Always true, because logic below to change coinPusher v1 logic.
      return;
    }
    this.logger.debug('bet.behind.service, coinCountTracking', { data: coinCountTrackingState });

    const {
      enabledBetBehind,
      bbRoundDurationInStack,
      stackSize,
      coins,
    } = coinCountTrackingState;

    if (!enabledBetBehind || bbRoundDurationInStack < 1) {
      return;
    }

    const bbStartThresholdCoins = bbRoundDurationInStack * stackSize;
    if (bbStartThresholdCoins + this.bbSendInvitationThresholdCoins === coins) {
      this.logger.debug(
        'bet.behind.service, coinCountTracking, info: sendBetBehindInvitation',
      );
      this.sendBetBehindInvitation(coinCountTrackingState);
      return;
    }

    if (bbStartThresholdCoins === coins) {
      this.logger.debug(
        'bet.behind.service, coinCountTracking, info: startBetBehind',
      );
      this.startBetBehind(coinCountTrackingState);
    }
  }

  private async sendBetBehindInvitation(
    coinCountTrackingState: CoinCountTrackingState,
  ): Promise<void> {
    this.logger.debug('bet.behind.service, sendBetBehindInvitation', { data: coinCountTrackingState });
    const {
      queueId,
      roundId,
      correlationId,
      bbRoundDurationInStack,
    } = coinCountTrackingState;
    const sessionsIds = await this.sessionRepository.getReadyBetBehindFromQueue(queueId, bbRoundDurationInStack);
    await Promise.all(sessionsIds.map(
      id => this.redisCache.set<Invitation>(
        getInvitationRedisKey(id),
        {
          roundId,
          correlationId,
        },
        { ttl: this.betBehindInvitationTtlSec },
      ),
    ));
    this.playerClientService.sendInvitationBetBehind(sessionsIds);
    this.logger.debug('bet.behind.service, sendBetBehindInvitation, info: send invitation', { data: sessionsIds });
  }

  private async startBetBehind(
    coinCountTrackingState: CoinCountTrackingState,
  ): Promise<void> {
    this.logger.debug('bet.behind.service, startBetBehind', { data: coinCountTrackingState });

    const {
      machineId,
      machineSerial,
      coins,
    } = coinCountTrackingState;

    const roundType = RoundType.BET_BEHIND;
    this.playerClientService.broadcastRemainingCoins(machineSerial, coins);

    await this.roundRepository.update(
      {
        status: RoundStatus.PAUSED,
        type: RoundType.BET_BEHIND,
        machineId,
      },
      { status: RoundStatus.ACTIVE },
    );

    const activatedRounds = await this.roundRepository.find({
      where: {
        status: RoundStatus.ACTIVE,
        type: RoundType.BET_BEHIND,
        machineId,
      },
      relations: ['session'],
    });

    this.logger.debug('bet.behind.service, startBetBehind, info: activatedRounds', { data: activatedRounds });

    await Promise.all(activatedRounds.map(async round => {
      this.commandPublisher.sendCommand({
        type: CommandType.BET_BEHIND_ROUND_START,
        gameId: GameId.COIN_PUSHER_V1,
        sessionId: Number(round.session.id),
      });

      this.playerClientService.notifyRoundStart(round.session.id, await this.getRoundStartedMessage(round));

      this.monitoringWorkerClientService.sendEventLogMessage({
        eventType: EventType.START_ROUND,
        source: EventSource.GAME,
        params: {
          type: roundType,
          sessionId: Number(round.session.id),
          machineSerial,
          round: round.id,
        },
      });
    }));
  }

  private async getRoundStartedMessage(
    round: RoundEntity,
  ): Promise<RoundStartedDto> {
    const stackBuyLimit = new BigNumber(round.session.configuration.stackBuyLimit)
      .minus(round.session.totalStacksUsed)
      .minus(1)
      .toNumber();
    const rounds = round.session.roundsLeft;
    const { betBehind } = await this.sessionDataManager.getSessionData(round.session.id);
    const betBehindRounds = betBehind?.stopAfterRounds ? new BigNumber(betBehind.stopAfterRounds)
      .minus(1)
      .toNumber() : 0;
    return {
      type: round.type,
      stackBuyLimit,
      rounds,
      betBehindRounds,
      totalBet: round.betInCash,
    };
  }
}
