import { GameId } from '@lib/dal';
import { LaunchParams } from './launch.params';

export class SolidGamingLaunchUrlParams extends LaunchParams {
  authToken: string;
  gameId: GameId;
  brandId: string;
  language?: string;
  homeUrl?: string;
}
