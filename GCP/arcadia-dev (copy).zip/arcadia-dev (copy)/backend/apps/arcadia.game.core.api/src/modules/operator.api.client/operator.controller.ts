import {
  CommandType,
  LoggerInterceptor,
  NewrelicAndMessagePattern,
  RmqQueueName,
  rmqRoutingGenerate,
  RpcMainExceptionFilter,
  rpcValidationExceptionFactory,
} from '@lib/common';
import { GameId } from '@lib/dal';
import {
  Controller, UseFilters, UseInterceptors, UsePipes, ValidationPipe,
} from '@nestjs/common';
import { Payload } from '@nestjs/microservices';
import { RetryTransactionCommand } from '../command/dto/retry.transaction.command';
import { RetryScheduler } from './retry.scheduler';

@Controller({ path: 'v1/operator' })
@UseInterceptors(LoggerInterceptor)
@UseFilters(RpcMainExceptionFilter)
@UsePipes(new ValidationPipe({
  transform: true,
  whitelist: true,
  exceptionFactory: rpcValidationExceptionFactory,
}))
export class OperatorController {
  constructor(
    private readonly retryScheduler: RetryScheduler,
  ) {}
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.CORE_COMMAND_QUEUE, CommandType.SCHEDULE_TRANSACTION_RETRY, GameId.COMMON))
  public async scheduleTransactionRetry(@Payload() data: RetryTransactionCommand): Promise<void> {
    await this.retryScheduler.scheduleRetry(data);
  }
}
