/* eslint-disable max-lines */
import { CommandType, TimeoutType } from '@lib/common';
import { ConfigService } from '@lib/config';
import {
  ClawPhase, GameId, SessionRepository, ShutdownReason,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { Inject, Injectable } from '@nestjs/common';
import { Logger } from 'winston';
import { SessionAwareDto } from '../../../dto/session.aware.dto';
import { CommandPublisher } from '../../../command/command.publisher';
import { WorkerClientService } from '../../../worker.client/worker.client.service';
import { SessionDataManager } from '../../../session.data.manager/session.data.manager';
import { WAITING_RESULT_TTL_SEC } from '../../constants';
import { PlayerMoveMessageDto } from '../../types/player.move.message.dto';

@Injectable()
export class PlayerMessageService {
  constructor(
    config: ConfigService,
    private readonly workerClient: WorkerClientService,
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly sessionRepository: SessionRepository,
    private readonly commandPublisher: CommandPublisher,
    protected readonly sessionDataManager: SessionDataManager,
  ) {
  }

  public async readyForRound(data: SessionAwareDto): Promise<void> {
    const {
      sessionId,
      correlationId,
    } = data;

    const session = await this.sessionRepository.findOne({
      where: { id: sessionId },
      relations: ['rounds'],
    });

    if (!session) {
      this.logger.warn('readyRorRound skip: session not found');
      return;
    }

    const activeRound = session.getActiveRound();
    if (!activeRound) {
      this.logger.debug('readyRorRound skip: No active round or round is in progress');
      return;
    }

    await this.workerClient.timeoutStop({
      timeoutType: TimeoutType.ROUND_END_DELAY,
      sessionId,
      payload: { gameId: session.gameId },
    }, correlationId);
    this.commandPublisher.sendCommand({
      type: CommandType.ROUND_END,
      gameId: GameId.CLAW,
      sessionId,
    }, correlationId);
  }

  public async move({ sessionId, direction }: PlayerMoveMessageDto): Promise<void> {
    const session = await this.sessionRepository.findOne({
      where: { id: sessionId },
    });

    if (!session) {
      this.logger.warn('move skip: session not found');
    }

    const { clawPhase } = await this.sessionDataManager.getSessionData(sessionId);

    if ([ClawPhase.WAITING_RESULT, ClawPhase.MOVING_FORWARD, ClawPhase.MOVING_RIGHT, ClawPhase.STARTING_ROUND].includes(clawPhase)) {
      this.logger.warn('Incorrect phase for move', { sessionId, clawPhase, direction });
      return;
    }

    if (clawPhase === ClawPhase.WAITING_MOVING_RIGHT) {
      await this.sessionDataManager.updateSessionData({ clawPhase: ClawPhase.MOVING_RIGHT }, sessionId);
      return;
    }

    if (clawPhase === ClawPhase.WAITING_MOVING_FORWARD) {
      await this.sessionDataManager.updateSessionData({ clawPhase: ClawPhase.MOVING_FORWARD }, sessionId);
    }
  }

  public async stop({ sessionId, correlationId }: SessionAwareDto): Promise<void> {
    const session = await this.sessionRepository.findOne({
      where: { id: sessionId },
    });

    if (!session) {
      this.logger.warn('Stop skip: session not found');
    }
    const { clawPhase } = await this.sessionDataManager.getSessionData(sessionId);

    if ([ClawPhase.WAITING_RESULT, ClawPhase.WAITING_MOVING_FORWARD, ClawPhase.WAITING_MOVING_FORWARD, ClawPhase.STARTING_ROUND].includes(clawPhase)) {
      this.logger.warn('Incorrect phase for stop', { sessionId, clawPhase });
      return;
    }

    if (clawPhase === ClawPhase.MOVING_RIGHT) {
      await this.sessionDataManager.updateSessionData({ clawPhase: ClawPhase.WAITING_MOVING_FORWARD }, sessionId);
      return;
    }

    if (clawPhase === ClawPhase.MOVING_FORWARD) {
      await this.sessionDataManager.updateSessionData({ clawPhase: ClawPhase.WAITING_RESULT }, sessionId);
      await this.workerClient.timeoutStart({
        timeoutType: TimeoutType.WAITING_RESULT,
        sessionId,
        timeoutSec: WAITING_RESULT_TTL_SEC,
        payload: {
          reason: ShutdownReason.WAITING_RESULT, gameId: GameId.CLAW,
        },
      },
      correlationId,
      );
    }
  }
}
