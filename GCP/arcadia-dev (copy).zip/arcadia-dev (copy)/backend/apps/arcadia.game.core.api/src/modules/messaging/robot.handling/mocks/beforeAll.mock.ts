import { ConfigService } from '@lib/config';
import {
  ChipRepository,
  ChipTypeRepository,
  connectionNames,
  CurrencyConversionRepository,
  getRepositoryToken,
  GroupRepository,
  MachineDispenserRepository,
  MachineRepository,
  PlayerRepository,
  QueueRepository,
  RngChipPrizeRepository,
  RoundArchiveRepository,
  RoundRepository,
  SeedHistoryRepository,
  SessionRepository,
} from '@lib/dal';
import { HttpModule } from '@nestjs/axios';
import { Test } from '@nestjs/testing';
import { repoMockFactory } from '../../../../util/repoMockFactory';
import { CommandPublisher } from '../../../command/command.publisher';
import { ConfigValidator } from '../../../config.validator/config.validator';
import { GroupTerminatorService } from '../../../group.terminator/group.terminator.service';
import { OperatorApiClientService } from '../../../operator.api.client/operator.api.client.service';
import { PlayerClientService } from '../../../player.client/player.client.service';
import { QueueManagerService } from '../../../queue.manager/queue.manager.service';
import { ServerRMQ } from '@lib/rmq.server';
import { RngClientService } from '../../../rng.service.client/rng.client.service';
import { RobotClientService } from '../../../robot.client/robot.client.service';
import { CoinPusherRoundStarter } from '../../../round/coin.pusher.round.starter';
import { RoundServiceFactory } from '../../../round/round.service.factory';
import { SessionDataManager } from '../../../session.data.manager/session.data.manager';
import { SessionService } from '../../../session/session.service';
import { WorkerClientService } from '../../../worker.client/worker.client.service';
import { RobotMessageService } from '../robot.message.service';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';

export const robotHandlingServerRMQMock = { deleteQueue: () => null };

export async function makeTestModule() {
  const moduleFixture = await Test.createTestingModule({
    imports: [HttpModule],
    providers: [
      RobotMessageService,
      {
        useValue: {
          ...repoMockFactory(),
          getMachineToEngage: () => null
        },
        provide: getRepositoryToken(MachineRepository, connectionNames.DATA),
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(ChipRepository, connectionNames.DATA),
      },
      {
        useValue: {
          ...repoMockFactory(),
          getFreeQueue: () => null
        },
        provide: getRepositoryToken(QueueRepository, connectionNames.DATA),
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(PlayerRepository, connectionNames.DATA),
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(ChipTypeRepository, connectionNames.DATA),
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(RoundArchiveRepository, connectionNames.DATA),
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(SeedHistoryRepository, connectionNames.DATA),
      },
      {
        useValue: repoMockFactory(),
        provide: getRepositoryToken(CurrencyConversionRepository, connectionNames.DATA),
      },
      {
        useValue: {
          ...repoMockFactory(),
          getChipPrize: () => null
        },
        provide: getRepositoryToken(RngChipPrizeRepository, connectionNames.DATA),
      },
      {
        useValue: { decrement: () => null, ...repoMockFactory() },
        provide: getRepositoryToken(MachineDispenserRepository, connectionNames.DATA),
      },
      {
        useValue: {
          ...repoMockFactory(),
          getBetList: () => null
        },
        provide: getRepositoryToken(GroupRepository, connectionNames.DATA),
      },
      {
        useValue: {
          ...repoMockFactory(),
          manager: {
            transaction: () => {
            }
          }
        },
        provide: getRepositoryToken(RoundRepository, connectionNames.DATA),
      },
      {
        useValue: {
          create: () => {
          },
          finalizeSession: () => {
          },
          terminateSessions: () => {
          }
        },
        provide: SessionService,
      },
      {
        useValue: {
          getBalance: () => null,
          cancelWager: () => null,
          wager: () => ({ toPromise: () => null }),
        },
        provide: OperatorApiClientService,
      },
      {
        useValue: {
          startIdleTimeout: () => {
          },
          stopIdleTimeout: () => {
          },
          stopGraceTimeout: () => {
          },
          startEngageTimeout: () => null,
          stopEngageTimeout: () => null,
          timeoutStop: () => null,
          timeoutStart: () => null,
        },
        provide: WorkerClientService,
      },
      {
        useValue: {
          notifyQueueUpdate: () => null,
          getNextSession: () => null,
          sendNewQueueData: () => null,
          assignSessionToQueue: () => null,
          forceChangeMachine: () => null,
        },
        provide: QueueManagerService,
      },
      {
        useValue: {
          ...repoMockFactory(),
          countNewRound: () => null,
          createQueryBuilder: () => null,
          getBetBehindersFromQueue: () => Promise.resolve([]),
          getNextSessionForQueue: () => null,
        },
        provide: getRepositoryToken(SessionRepository, connectionNames.DATA),
      },
      {
        useValue: {
          store: {
            getClient: () => ({
              get: () => null,
              set: () => true,
              del: () => null,
            })
          },
          del: () => null,
        },
        provide: RedisCacheService,
      },
      {
        useValue: {
          sendNotification: () => null,
          notifySessionResult: () => null,
          notifyBuyResult: () => null,
          notifyQueueChangeOffer: () => null,
          notifyForcedAutoplay: () => null,
          notification: () => null,
        },
        provide: PlayerClientService,
      },
      {
        useValue: {
          sendEventLogMessage: () => null,
          sendOutOfSessionEventLogMessage: () => null,
          sendAlertMessage: () => null
        },
        provide: MonitoringWorkerClientService,
      },
      {
        useValue: {
          sendAutoplayMessage: () => null,
          sendStopAutoplayMessage: () => null,
          sendDisengageMessage: () => null,
          sendAllowCoinsMessage: () => null,
          sendTableMessage: () => null,
          sendStopMessage: () => null,
          sendChipValidationMessage: () => null,
          sendEngageMessage: () => null,
          sendPushMessage: () => null,
          sendSeedMessage: () => null,
        },
        provide: RobotClientService,
      },
      {
        useValue: {
          seed: () => Promise.resolve([]),
          phantom: () => null,
        },
        provide: RngClientService,
      },
      {
        useValue: {
          createRound: () => null,
        },
        provide: CoinPusherRoundStarter,
      },
      {
        useValue: { create: () => null },
        provide: RoundServiceFactory,
      },
      {
        useValue: {
          get: (params: string[]) => {
            switch (params[1]) {
              case 'ROBOTS_AUTH_SECRET':
                return '<secret>';
              case 'EXTERNAL_RABBITMQ_HOST':
                return '<host>';
              case 'RABBITMQ_PORT':
                return '<port>';
              case 'RABBITMQ_USERNAME':
                return '<user>';
              case 'RABBITMQ_PASSWORD':
                return '<password>';
              case 'EXTERNAL_REDIS_HOST':
                return '<redisHost>';
              case 'REDIS_PORT':
                return '<port>';
              default:
                return null;
            }
          },
          getRabbitMQConfig: () => null,
          getRedisConfig: () => null,
        },
        provide: ConfigService,
      },
      {
        useValue: { engageNextSession: () => null },
        provide: CommandPublisher,
      },
      {
        useValue: {},
        provide: GroupTerminatorService,
      },
      {
        useValue: {
          removeSessionData: () => null,
          isAutoplay: () => null
        },
        provide: SessionDataManager,
      },
      {
        useValue: {
          getValidatedConfig: () => null,
        },
        provide: ConfigValidator,
      },
      {
        useValue: robotHandlingServerRMQMock,
        provide: ServerRMQ,
      },
    ],
  })
    .compile();
  return moduleFixture;
}
