import { IsObject, IsOptional, Length } from 'class-validator';
import { RobotMessage } from '../messaging/robot.handling/dto';

export class RobotErrorMessage extends RobotMessage {
  @Length(1, 128)
  public module: string;

  @Length(1, 128)
  public error: string;

  @IsOptional()
  @IsObject()
  public details?: Record<string, any>;
}
