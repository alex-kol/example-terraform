import {
  CoreWorkerMessageType, RmqQueueName, TimeoutId, TimeoutOptions, TimeoutType,
} from '@lib/common';
import { MAIN_LOGGER } from '@lib/logger';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { ServerRMQ } from '@lib/rmq.server';
import { Inject, Injectable, NotAcceptableException } from '@nestjs/common';
import moment, { Moment } from 'moment';
import { v4 as UUIDv4 } from 'uuid';
import { Logger } from 'winston';
import { CoreToWorkerMessage } from './dto/worker.message';
import { IncrementableTimeout } from './incrementable.timeout';
import { timeoutCacheKeyFactory } from './timeout.cache.key.factory';

@Injectable()
export class WorkerClientService {
  private readonly cachedTimeouts = new Set([
    TimeoutType.ROUND_END_DELAY,
    TimeoutType.IDLE,
    TimeoutType.REBUY,
    TimeoutType.ANIMATION_IN_QUEUE,
  ]);

  constructor(
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly serverRMQ: ServerRMQ,
    private readonly cacheManager: RedisCacheService,
  ) {
  }

  public sendWorkerMessage(message: CoreToWorkerMessage, correlationId = UUIDv4()): void {
    this.logger.debug('Core -> Worker', {
      correlationId,
      ...message,
    });
    this.serverRMQ.sendMessage(message, RmqQueueName.CORE_TO_WORKER_QUEUE, correlationId);
  }

  public async timeoutStart(
    options: TimeoutOptions,
    correlationId?: string,
    onMessageSend?: (options: TimeoutOptions) => any | Promise<any>,
  ): Promise<void> {
    const message: CoreToWorkerMessage = {
      type: CoreWorkerMessageType.TIMEOUT_START,
      ...options,
      correlationId,
    };
    this.sendWorkerMessage(message, correlationId);
    if (this.cachedTimeouts.has(options.timeoutType)) {
      await this.cacheTimeout(options);
    }

    onMessageSend && await onMessageSend(options);
  }

  public async timeoutIncrement(
    options: TimeoutOptions & { timeoutType: IncrementableTimeout },
    correlationId?: string,
    onMessageSend?: (options: TimeoutOptions) => any | Promise<any>,
  ): Promise<void> {
    if (!this.cachedTimeouts.has(options.timeoutType)) {
      throw new NotAcceptableException(`Timeout "${options.timeoutType}" increment not supported`);
    }
    const existingTimeout = await this.getTimeoutExpiration(options);
    if (!existingTimeout) {
      return;
    }

    // eslint-disable-next-line no-param-reassign
    options.timeoutSec += existingTimeout.diff(moment(), 'second');
    const message: CoreToWorkerMessage = {
      type: CoreWorkerMessageType.TIMEOUT_START,
      ...options,
      correlationId,
    };
    this.sendWorkerMessage(message, correlationId);
    await this.cacheTimeout(options);

    onMessageSend && await onMessageSend(options);
  }

  public async timeoutStop(
    options: TimeoutOptions,
    correlationId?: string,
    onMessageSend?: (options: TimeoutOptions) => any | Promise<any>,
  ): Promise<void> {
    const message: CoreToWorkerMessage = {
      type: CoreWorkerMessageType.TIMEOUT_STOP,
      ...options,
      correlationId,
    };
    this.sendWorkerMessage(message, correlationId);
    onMessageSend && await onMessageSend(options);

    if (this.cachedTimeouts.has(options.timeoutType)) {
      await this.cacheManager.del(timeoutCacheKeyFactory(options));
    }
  }

  public async getTimeoutExpiration(options: TimeoutId): Promise<Moment | void> {
    const timestamp: string = await this.cacheManager.get(timeoutCacheKeyFactory(options));
    return timestamp ? moment(timestamp) : undefined;
  }

  private async cacheTimeout(options: TimeoutOptions): Promise<void> {
    const { timeoutSec = 60 } = options;
    await this.cacheManager.set(timeoutCacheKeyFactory(options), moment()
      .add(timeoutSec, 'second')
      .toISOString(), { ttl: timeoutSec });
  }
}
