import { GameId, RoundEntity, SessionStatus } from '@lib/dal';
import { ApiPropertyOptional, ApiResponseProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { PlayerSettingsDto } from '../../messaging/player.handling/dto/player.settings.dto';
import { VideoRes } from './video.res';

export class VerifyRes {
  @ApiResponseProperty()
  public playerId: string;

  @ApiResponseProperty()
  public sessionId: number;

  @ApiResponseProperty({ enum: SessionStatus })
  public sessionStatus: SessionStatus;

  @ApiResponseProperty()
  public balance: number;

  @ApiResponseProperty()
  public currency: string;

  @ApiResponseProperty()
  public locale: string;

  @ApiResponseProperty()
  public playerDirectRoomId: string;

  @ApiResponseProperty()
  public robotDirectRoomId: string;

  @ApiResponseProperty()
  public robotQueueRoomId: string;

  @ApiResponseProperty()
  public video: VideoRes;

  @ApiResponseProperty()
  public machineId: number;

  @ApiResponseProperty()
  public machineName: string;

  @ApiResponseProperty()
  public groupName: string;

  @ApiResponseProperty()
  public groupDisplayName: string;

  @ApiPropertyOptional()
  public activeRound?: Partial<RoundEntity>;

  @ApiResponseProperty()
  public groupColor: string;

  @ApiResponseProperty()
  @Type(() => PlayerSettingsDto)
  public settings: PlayerSettingsDto;

  @ApiResponseProperty({ enum: GameId })
  public gameId: GameId;

  @ApiResponseProperty()
  public machineSerial: string;

  @ApiResponseProperty()
  public operatorId: number;

  @ApiResponseProperty()
  public groupId: number;

  @ApiPropertyOptional()
  public showTutorial?: boolean;
}
