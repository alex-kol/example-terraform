/* eslint-disable max-lines */
import {
  Cache, CacheClear, EventSource, TimeoutType,
} from '@lib/common';
import {
  ChipRepository,
  EventType,
  RoundArchiveEntity,
  RoundArchiveRepository,
  RoundRepository,
  RoundType,
  SessionArchiveRepository,
  SessionEndReason,
  SessionEntity,
  SessionRepository,
  SessionStatus,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Inject, Injectable } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import moment from 'moment';
import { v4 as uuidv4 } from 'uuid';
import { Logger } from 'winston';
import { RmqMessageLock } from '@lib/rmq.server/service.factory';
import { Lock } from '@lib/rmq.server';
import { SESSION_CACHE_TTL_SEC } from '../../constants/redis.constants';
import { PlayerRetentionService } from '../auth/player.retention.service';
import { NotificationLevel } from '../player.client/notification.level';
import { NotificationType } from '../player.client/notification.type';
import { PlayerClientService } from '../player.client/player.client.service';
import { SessionDataManager } from '../session.data.manager/session.data.manager';
import { WorkerClientService } from '../worker.client/worker.client.service';
import { sessionCacheKeyFactory } from './session.cache.key.factory';
import { FINALIZE_SESSION_LOCK_INJECT_TOKEN } from './constants';

@Injectable()
export class SessionService {
  constructor(
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    @Inject(FINALIZE_SESSION_LOCK_INJECT_TOKEN) private readonly finalizeLock: RmqMessageLock,
    private readonly sessionRepo: SessionRepository,
    private readonly chipRepository: ChipRepository,
    private readonly playerClient: PlayerClientService,
    private readonly sessionDataManager: SessionDataManager,
    private readonly monitoringClient: MonitoringWorkerClientService,
    private readonly workerClient: WorkerClientService,
    private readonly playerRetentionService: PlayerRetentionService,
  ) {
  }

  @Cache({ ttl: SESSION_CACHE_TTL_SEC }, args => sessionCacheKeyFactory(args[0]))
  public findByIdCached(sessionId: number): Promise<SessionEntity | undefined> {
    return this.sessionRepo.findOne({
      where: { id: sessionId },
      relations: ['player', 'group', 'operator', 'machine', 'queue', 'machine.site'],
    });
  }

  public createSession(sessionOptions: Partial<SessionEntity>): Promise<SessionEntity> {
    const session = this.sessionRepo.create({
      ...sessionOptions,
      playerIP: () => `INET6_ATON('${sessionOptions.playerIP}')`,
    });
    return this.sessionRepo.save(session, { transaction: false });
  }

  public async finalizeSession(id: number, reason: SessionEndReason, terminate = false): Promise<void> {
    const lock = await this.awaitFinalizeSessionLock(id);
    try {
      const session = await this.archiveSession(id, terminate, reason);
      const {
        group,
        operator,
        machine,
        player,
      } = session;
      if (session.isDisconnected) {
        await this.workerClient.timeoutStop({
          timeoutType: TimeoutType.TERMINATE_SESSION,
          sessionId: Number(id),
          payload: { gameId: session.gameId },
        }, uuidv4());
      }

      if (reason === SessionEndReason.AMBUSHING_PLAYER) {
        this.playerClient.notification(id, {
          notificationId: NotificationType.AMBUSHING_DETECTED,
          level: NotificationLevel.WARNING,
          title: 'Warning',
          message: 'Ambushing is bad!',
        });
      }

      if (terminate) {
        this.playerClient.notification(id, {
          notificationId: NotificationType.SESSION_TERMINATED,
          level: NotificationLevel.WARNING,
          title: 'Session terminated',
          message: 'Your session has been terminated. Please try again.',
        });
        this.monitoringClient.sendEventLogMessage({
          eventType: EventType.SESSION_TERMINATED,
          source: EventSource.GAME,
          params: {
            sessionId: session.id,
            reason,
            groupId: group.id,
            operatorId: operator.id,
            machineId: machine.id,
            machineSerial: machine.serial,
          },
        });
      }

      const { loginOptions } = await this.sessionDataManager.getSessionData(session.id);
      const playerRetentionData = await this.playerRetentionService.getPlayerRetentionData(session, loginOptions);
      this.playerClient.notifyReturnToLobby(session.id, playerRetentionData);
      this.playerClient.notifySessionResult(session.id, session.totalWinInCash);

      await this.sessionDataManager.dropSessionData(session.id);
      const tableState = await this.chipRepository.getTableState(machine.id);
      await this.monitoringClient.sendEventLogMessage({
        eventType: EventType.END_SESSION,
        source: EventSource.GAME,
        params: {
          reason,
          sessionId: session.id,
          machineSerial: machine.serial,
          roundCount: session.rounds.length,
          operatorId: player.operatorId,
          groupId: group.id,
          playerId: {
            cid: player.cid,
            operatorId: player.operatorId,
          },
          tableState,
          tableChipCount: tableState.length,
        },
      });
      await this.finalizeLock.releaseLock(lock);
    } catch (err) {
      this.logger.error('Session failed to archive', {
        sessionId: id,
        error: err.message,
      });
      await this.finalizeLock.releaseLock(lock);
      throw new RpcException(err.message);
    }
  }

  @CacheClear(args => sessionCacheKeyFactory(args[0]))
  private async archiveSession(sessionId: number, isTerminated: boolean, reason: SessionEndReason): Promise<SessionEntity> {
    let session: SessionEntity = null;

    await this.sessionRepo.manager.transaction('REPEATABLE READ', async manager => {
      const sessionRepo = new SessionRepository(manager);
      session = await sessionRepo.findOneOrFail({
        where: { id: sessionId },
        relations: ['player', 'group', 'operator', 'machine', 'queue', 'rounds', 'machine.site'],
      })
        .catch(() => {
          throw new RpcException(`Session archiving failed: session not found. SessionId: ${sessionId}`);
        });

      const {
        player,
        group,
        operator,
        machine,
        queue,
        rounds,
      } = session;

      const sessionArchiveRepo = new SessionArchiveRepository(manager);
      const roundArchiveRepo = new RoundArchiveRepository(manager);
      let isScatter = false;
      if (rounds?.length) {
        isScatter = !!rounds.find(({ type }) => type === RoundType.SCATTER);
        const roundsArchived: RoundArchiveEntity[] = rounds.map(round => roundArchiveRepo.create({
          id: round.id,
          sessionId: session.id,
          machineId: machine.id,
          bet: round.bet,
          betInCash: round.betInCash,
          startDate: round.createDate,
          endDate: round.endDate || new Date(),
          status: round.status,
          type: round.type,
          wins: round.wins,
          winInCash: round.winInCash,
          isAutoplay: round.isAutoplay,
          voucherId: round.voucherId,
          finalBalance: round.finalBalance,
          transactionId: round.transactionId,
        }));
        await roundArchiveRepo.save(roundsArchived, {
          transaction: false,
          reload: false,
        });
        await new RoundRepository(manager).delete(rounds.map(value => value.id));
      }

      const sessionArchive = sessionArchiveRepo.create({
        id: session.id,
        browser: session.browser,
        configuration: JSON.stringify(session.configuration),
        currency: session.currency,
        currencyConversionRate: session.currencyConversionRate,
        deviceType: session.deviceType,
        duration: moment()
          .diff(session.createDate, 'seconds'),
        startDate: session.createDate,
        groupId: group.id,
        groupName: group.name,
        isScatter,
        lastPurchaseAmount: group.denominator,
        locale: session.locale,
        machineId: machine.id,
        siteId: machine.site.id,
        machineSerial: machine.serial,
        machineName: machine.name,
        operatorId: operator.id,
        cameraIds: session.cameraIds,
        operatorName: operator.name,
        os: session.os,
        playerCid: player.cid,
        playerIP: () => `INET6_ATON('${session.playerIP}')`,
        playerName: player.name || 'no-name',
        queueDuration: session.queueDuration,
        queueId: queue.id,
        stackSize: group.stackSize,
        status: isTerminated ? SessionStatus.TERMINATED : SessionStatus.COMPLETED,
        totalBets: session.totalBets,
        totalBetsInCash: session.totalBetsInCash,
        totalNetCash: session.totalNetCash,
        totalStacksUsed: session.totalStacksUsed,
        totalWinning: session.totalWinning,
        totalWinInCash: session.totalWinInCash,
        viewerDuration: session.viewerDuration,
        denominator: group.denominator,
        offlineDuration: session.offlineDuration,
        isDenominationChanged: session.isDenominationChanged,
        gameId: session.gameId,
        sessionEndReason: reason,
        isTest: player.isTester,
      });
      await sessionArchiveRepo.save(sessionArchive, {
        reload: false,
        transaction: false,
      });
      await sessionRepo.delete(session.id);
    });
    return session;
  }

  private awaitFinalizeSessionLock(id: number): Promise<Lock> {
    return new Promise((res, rej) => {
      let counter = 0;
      const timer = setInterval(
        async () => {
          const lock = await this.finalizeLock.getLock({ id });
          if (lock) {
            clearTimeout(timer);
            res(lock);
            return;
          }
          counter += 1;
          if (counter === 10) {
            clearTimeout(timer);
            rej(new Error('Waiting lock ttl expired'));
          }
        },
        350,
      );
    });
  }
}
