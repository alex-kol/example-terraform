/* eslint-disable max-lines */
import {
  CommandType,
  LoggerInterceptor,
  NewrelicAndMessagePattern,
  RmqQueueName,
  rmqRoutingGenerate,
  RobotMessageType,
  RpcMainExceptionFilter,
  rpcValidationExceptionFactory,
} from '@lib/common';
import { GameId } from '@lib/dal';
import {
  Controller, UseFilters, UseInterceptors, UsePipes, ValidationPipe,
} from '@nestjs/common';
import { Payload } from '@nestjs/microservices';
import { RobotMessageService } from './robot.message.service';
import { EngageSessionCommand } from '../../../command/dto/engage.session.command';
import { AddBallDto, RobotMessage } from '../../../messaging/robot.handling/dto';
import { SessionInjectorPipe } from '../../../messaging/session.injector.pipe';
import { BaseCommand } from '../../../command/dto/base.command';
import { ClawReassignMachineCommand } from '../../../command/dto/claw.reassign.machine.command';

@Controller('v1/robots')
@UseInterceptors(LoggerInterceptor)
@UseFilters(RpcMainExceptionFilter)
@UsePipes(new ValidationPipe({
  transform: true,
  whitelist: true,
  exceptionFactory: rpcValidationExceptionFactory,
}))
export class RobotMessageController {
  constructor(private readonly messageHandler: RobotMessageService) {
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.CORE_COMMAND_QUEUE, CommandType.ENGAGE_SESSION, GameId.CLAW))
  async engageSession(@Payload() data: EngageSessionCommand): Promise<void> {
    await this.messageHandler.engageNextSession(data.machineId, data.reBuySessionId, data.correlationId);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.ENGAGED, GameId.CLAW))
  async engaged(@Payload() data: RobotMessage): Promise<void> {
    await this.messageHandler.handleEngaged(data);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.DISENGAGED, GameId.CLAW))
  async disengaged(@Payload() data: RobotMessage): Promise<void> {
    await this.messageHandler.handleDisengaged(data);
  }

  @UsePipes(SessionInjectorPipe)
  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.CORE_COMMAND_QUEUE, CommandType.IDL_TIMEOUT_EXPIRED, GameId.CLAW))
  async idleTimeoutExpired(@Payload() data: BaseCommand): Promise<void> {
    await this.messageHandler.forcedPickup({ ...data, reason: 'Idl timeout expired' });
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.ROBOT_TO_CORE_QUEUE, RobotMessageType.ADD_BALL, GameId.CLAW))
  public async addBallClaw(@Payload() data: AddBallDto): Promise<void> {
    await this.messageHandler.addBallClaw(data);
  }

  @NewrelicAndMessagePattern(rmqRoutingGenerate(RmqQueueName.CORE_COMMAND_QUEUE, CommandType.MACHINE_REASSIGN, GameId.CLAW))
  async reassignClawMachine(@Payload() data: ClawReassignMachineCommand): Promise<void> {
    await this.messageHandler.reassignClawMachine(data.machineId);
  }
}
