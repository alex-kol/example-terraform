import { IsNumber } from 'class-validator';
import { RobotMessage } from './robot.message';

export class RobotPositionDto extends RobotMessage {
  @IsNumber()
  public angle: number;
}
