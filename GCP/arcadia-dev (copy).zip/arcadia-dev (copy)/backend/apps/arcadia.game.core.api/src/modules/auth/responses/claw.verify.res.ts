import { ApiResponseProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { ClawPhase } from '@lib/dal';
import { IsEnum } from 'class-validator';
import { VerifyRes } from './verify.res';
import { PayTableDto } from '../dtos';

export class ClawVerifyRes extends VerifyRes {
  @ApiResponseProperty()
  @Type(() => PayTableDto)
  public payTable: PayTableDto[];

  @ApiResponseProperty()
  @IsEnum(ClawPhase)
  public sessionPhase: ClawPhase;

  @ApiResponseProperty()
  public betInCash: number;

  @ApiResponseProperty()
  public idleTimeout: number;
}
