export enum NotificationType {
  INSUFFICIENT_FUNDS = 'insufficientFunds',
  BET_FAILED = 'betFailed',
  PAYOUT_FAILED = 'payoutFailed',
  ROUND_LIMIT_REACHED = 'roundLimitReached',
  ROUND_TERMINATED = 'roundTerminated',
  PLAYER_AUTH_FAILED = 'playerAuthFailed',
  PARALLEL_SESSIONS_FORBIDDEN = 'parallelSessionsForbidden',
  CURRENCY_NOT_SUPPORTED = 'currencyNotSupported',
  IP_ADDRESS_FORBIDDEN = 'ipAddressForbidden',
  SESSION_TERMINATED = 'sessionTerminated',
  BUY_BLOCKED = 'buyBlocked',
  SESSION_COMPLETED = 'sessionCompleted',
  BB_NOT_AVAILABLE = 'betBehindNotAvailable',
  PLAYER_BLOCKED = 'playerBlocked',
  AMBUSHING_DETECTED = 'ambushingDetected',
  BET_LIMIT_EXCEEDED = 'betLimitExceeded',
  BET_CANCEL = 'betCancel'
}
