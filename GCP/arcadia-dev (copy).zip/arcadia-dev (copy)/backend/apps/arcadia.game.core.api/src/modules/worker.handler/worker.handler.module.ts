import { MachineRepository, SessionRepository } from '@lib/dal';
import { MonitoringWorkerClientModule } from '@lib/monitoring.worker.client';
import { Module } from '@nestjs/common';
import { ConversionTrackerModule } from '../conversion.tracker/conversion.tracker.module';
import { GroupTerminatorModule } from '../group.terminator/group.terminator.module';
import { QueueManagerModule } from '../queue.manager/queue.manager.module';
import { RobotClientModule } from '../robot.client/robot.client.module';
import { SessionDataManagerModule } from '../session.data.manager/session.data.manager.module';
import { SessionModule } from '../session/session.module';
import { WorkerClientModule } from '../worker.client/worker.client.module';
import { WorkerController } from './worker.controller';
import { WorkerMessageService } from './worker.message.service';

@Module({
  imports: [
    MonitoringWorkerClientModule,
    RobotClientModule,
    WorkerClientModule,
    GroupTerminatorModule,
    SessionModule,
    QueueManagerModule,
    SessionDataManagerModule,
    ConversionTrackerModule,
  ],
  providers: [
    WorkerMessageService,
    SessionRepository,
    MachineRepository,
  ],
  controllers: [WorkerController],
})
export class WorkerHandlerModule {

}
