import { EventSource } from '@lib/common';
import {
  ChipEntity, ChipTypeEntity, EventType, PlayerRepository, RoundEntity, RoundRepository,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Inject, Injectable, Scope } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import BigNumber from 'bignumber.js';
import { DataSource } from 'typeorm';
import { Logger } from 'winston';
import { toCash } from '../../../util';
import { BetBehindWinCommand } from '../../command/dto/bet.behind.win.command';
import { SessionContextHandler } from '../../command/session.context.handler';
import { PlayerClientService } from '../../player.client/player.client.service';
import { SessionDataManager } from '../../session.data.manager/session.data.manager';
import { ChipMessageInterface } from '../player.handling/interfaces';

@Injectable({ scope: Scope.REQUEST })
export class BbWinHandler extends SessionContextHandler<BetBehindWinCommand> {
  private roundRepo: RoundRepository;
  private playerRepo: PlayerRepository;

  private activeRound: RoundEntity;
  private chip: ChipEntity;
  private chipType: ChipTypeEntity;

  constructor(
    @Inject(MAIN_LOGGER) logger: Logger,
    private readonly playerPublisher: PlayerClientService,
    private readonly monitoringClientService: MonitoringWorkerClientService,
    private readonly sessionDataManager: SessionDataManager,
    dataSource: DataSource,
  ) {
    super(logger, dataSource);
  }

  protected async init(data: BetBehindWinCommand): Promise<void> {
    await super.init(data);

    this.chip = data.chip;
    this.chipType = data.chipType;

    // transactional repos init
    this.roundRepo = new RoundRepository(this.entityManager);
    this.playerRepo = new PlayerRepository(this.entityManager);

    this.session = await this.sessionRepository.findOneOrFail({
      where: { id: this.sessionId },
      relations: ['rounds'],
    });

    this.activeRound = this.session.getActiveRound();
    if (!this.activeRound) {
      throw new RpcException(`BB win out of active round. SessionId: ${this.session.id}`);
    }
  }

  protected async handleEvent(): Promise<void> {
    const winInCash = toCash(this.chip.value, this.session.currencyConversionRate);
    await this.winLimitCheck(winInCash);
    await this.countWins(this.chip.value, winInCash);
    await this.monitoringClientService.sendEventLogMessage({
      eventType: EventType.PRIZE,
      source: EventSource.GAME,
      params: {
        sum: this.chip.value,
        sumInCash: winInCash,
        currency: this.session.currency,
        sessionId: this.cachedSession.id,
        machineSerial: this.cachedMachine.serial,
        playerCid: this.cachedPlayer.cid,
      },
    });
    const winData: ChipMessageInterface = {
      currencyValue: winInCash,
      type: this.chipType.name,
    };
    this.playerPublisher.notifyWin(this.session.id, winData);
    const totalWinInCash = new BigNumber(this.session.totalWinInCash).plus(winInCash)
      .dp(2)
      .toNumber();
    this.playerPublisher.notifyTotalWin(this.session.id, totalWinInCash);
  }

  private async winLimitCheck(winInCash: number) {
    const { betBehind } = await this.sessionDataManager.getSessionData(this.session.id);
    if (!betBehind) {
      return;
    }
    const threshold = new BigNumber(toCash(this.session.denominator, this.session.currencyConversionRate))
      .multipliedBy(betBehind.singleWinThreshold)
      .dp(2);
    if (threshold.isLessThan(winInCash)) {
      await this.sessionDataManager.removeSessionData(['betBehind'], this.session.id);
    }
  }

  private async countWins(winInValue: number, winInCash: number) {
    await this.sessionRepository.countWin(this.session.id, winInValue, winInCash);
    await this.roundRepo.countWin(this.activeRound.id, winInValue, winInCash);
    await this.playerRepo.countWin(this.cachedPlayer.cid, this.cachedOperator.id, winInValue);
  }
}
