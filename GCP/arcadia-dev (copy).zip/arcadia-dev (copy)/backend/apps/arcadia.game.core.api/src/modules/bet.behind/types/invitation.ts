export class Invitation {
  roundId: number;
  correlationId: string;
}
