import { SessionEndReason } from '@lib/dal';
import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional } from 'class-validator';

export class TerminateSessionDto {
  @ApiProperty()
  @IsOptional()
  @IsEnum(SessionEndReason)
  public reason?: SessionEndReason;
}
