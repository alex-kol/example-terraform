import { LaunchParams } from './launch.params';

export class CalienteLaunchParams extends LaunchParams {
  authToken: string;
  gameId: string;
  language?: string;
  homeUrl?: string;
  cashierUrl?: string;
  externalId?: string;
  clientType?: string;
}
