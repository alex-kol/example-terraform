import { CommandType } from '@lib/common';
import {
  AlertSeverity, AlertSource, AlertType, GameId, QueueEntity, RoundType, SessionEndReason, SessionStatus, VoucherStatus,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { Inject, Injectable, Scope } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { Logger } from 'winston';
import { CommandPublisher } from '../command/command.publisher';
import { SessionContextHandler } from '../command/session.context.handler';
import { SessionAwareDto } from '../dto/session.aware.dto';
import { NotificationLevel } from '../player.client/notification.level';
import { NotificationType } from '../player.client/notification.type';
import { PlayerClientService } from '../player.client/player.client.service';
import { RoundContext } from '../round/round.context';
import { RoundServiceFactory } from '../round/round.service.factory';
import { SessionDataManager } from '../session.data.manager/session.data.manager';
import { SessionService } from '../session/session.service';
import { Invitation } from './types';
import { getInvitationRedisKey } from './utils';

@Injectable({ scope: Scope.REQUEST })
export class BetBehindReadyHandler extends SessionContextHandler {
  private cachedQueue: QueueEntity;

  constructor(
    @Inject(MAIN_LOGGER) logger: Logger,
    private readonly sessionDataManager: SessionDataManager,
    private readonly redisCache: RedisCacheService,
    private readonly roundServiceFactory: RoundServiceFactory,
    private readonly sessionService: SessionService,
    private readonly playerClientService: PlayerClientService,
    private readonly monitoringWorkerClientService: MonitoringWorkerClientService,
    private readonly commandPublisher: CommandPublisher,
    dataSource: DataSource,
  ) {
    super(logger, dataSource);
  }

  protected async init(data: SessionAwareDto): Promise<void> {
    await super.init(data);
    this.cachedQueue = this.session.queue;
  }

  protected async handleEvent(): Promise<void> {
    await this.confirmInvitation();
  }

  private async confirmInvitation(): Promise<RoundContext> {
    this.logger.debug(
      `bet.behind.service, confirmInvitation, data: sessionId: ${this.sessionId}`,
    );

    const redisInvitationKey = getInvitationRedisKey(this.sessionId);
    const invitationInfo = await this.redisCache.get<Invitation>(redisInvitationKey);
    if (!invitationInfo?.roundId) {
      this.logger.debug(
        `bet.behind.service, confirmInvitation, info: invitation expired, data: sessionId: ${this.sessionId}`,
      );
      return;
    }

    this.redisCache.del(redisInvitationKey);

    this.sessionStateCheck();
    await this.createRound(invitationInfo);
  }

  private sessionStateCheck(): void {
    if (!this.session || this.session.isDeleted) {
      throw new Error('Session not found');
    }

    if (this.session.status !== SessionStatus.QUEUE) {
      throw new Error(`Session status not equal ${SessionStatus.QUEUE}`);
    }
  }

  private async createRound(invitationInfo: Invitation) {
    try {
      const ctx = await this.getRoundCtx(invitationInfo.correlationId);

      const round = await this.roundServiceFactory.getStarter(GameId.COIN_PUSHER_V1, ctx)
        .startRound(RoundType.BET_BEHIND);
      await this.sessionRepository.update(this.session.id, { status: SessionStatus.QUEUE_BET_BEHIND });
      this.logger.debug('bet.behind.service, confirmInvitation, info: created round', { data: round });
    } catch (err) {
      this.logger.error('Round start error', {
        sessionId: this.sessionId,
        error: err.message,
        correlationId: this.correlationId,
        stack: err.stack,
      });
      this.notifyRoundStartError();
      await this.sessionService.finalizeSession(this.sessionId, SessionEndReason.WALLET_TRANSACTION_ERROR, true);
      this.commandPublisher.engageNextSession({
        type: CommandType.ENGAGE_SESSION,
        gameId: GameId.COIN_PUSHER_V1,
        machineId: this.cachedMachine.id,
      }, this.correlationId);
    }
  }

  private notifyRoundStartError(): void {
    this.monitoringWorkerClientService.sendAlertMessage({
      alertType: AlertType.WARNING,
      severity: AlertSeverity.HIGH,
      source: AlertSource.GAME_CORE,
      description: 'Bet call failed during round start',
      gameId: this.cachedMachine.gameId,
      details: {
        sessionId: this.session.id,
        machineId: this.cachedMachine.id,
        machineName: this.cachedMachine.name,
        machineSerial: this.cachedMachine.serial,
      },
    });
    this.playerClientService.notification(this.session.id,
      {
        notificationId: NotificationType.BET_FAILED,
        level: NotificationLevel.ERROR,
        title: 'Wallet error',
        message: 'Bet failed',
      });
  }

  private async getRoundCtx(correlationId: string): Promise<RoundContext> {
    const isAutoplayRoundStart = await this.sessionDataManager.isAutoplay(this.session.id);
    const pendingVouchers = this.session.vouchers.filter(({ status }) => status === VoucherStatus.PENDING);

    return new RoundContext(
      this.session, this.cachedQueue, this.cachedMachine, this.cachedPlayer, this.cachedGroup, this.cachedOperator, isAutoplayRoundStart, pendingVouchers, correlationId);
  }
}
