export interface PhantomMessageInterface {
  value: number;
}
