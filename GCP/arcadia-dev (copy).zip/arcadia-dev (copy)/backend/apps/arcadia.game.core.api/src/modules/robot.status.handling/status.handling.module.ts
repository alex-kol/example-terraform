import {
  ChipRepository, GameId, MachineRepository, QueueRepository, SeedHistoryRepository,
} from '@lib/dal';
import { MonitoringWorkerClientModule } from '@lib/monitoring.worker.client';
import { Module } from '@nestjs/common';
import { ConfigValidatorModule } from '../config.validator/config.validator.module';
import { GroupTerminatorModule } from '../group.terminator/group.terminator.module';
import { MessagingModule } from '../messaging/messaging.module';
import { RobotClientModule } from '../robot.client/robot.client.module';
import { RouletteEngineModule } from '../roulette.engine/roulette.engine.module';
import { SessionModule } from '../session/session.module';
import { StatusHandlerController } from './status.handler.controller';
import { StatusHandlerService } from './status.handler.service';
import { ClawRouletteStartupStatusStrategy } from './strategy/claw.roulette.startup.status.strategy';
import { ErrorStatusStrategy } from './strategy/error.status.strategy';
import { GameplayStatusStrategy } from './strategy/gameplay.status.strategy';
import { ShutdownStatusStrategy } from './strategy/shutdown.status.strategy';
import { StartupStatusStrategy } from './strategy/startup.status.strategy';
import { StatusStrategyFactory } from './strategy/status.strategy.factory';
import { statusStrategyIdFactory } from './strategy/status.strategy.id.factory';
import { StatusStrategyType } from './strategy/status.strategy.type';
import { ChipWatcherModule } from '../chip.watcher/chip.watcher.module';

@Module({
  imports: [SessionModule, MonitoringWorkerClientModule, RobotClientModule, MessagingModule,
    GroupTerminatorModule, ConfigValidatorModule,
    RouletteEngineModule, ChipWatcherModule,
  ],
  providers: [
    StatusStrategyFactory,
    StatusHandlerService,
    {
      provide: statusStrategyIdFactory(GameId.COIN_PUSHER_V1, StatusStrategyType.STARTUP),
      useClass: StartupStatusStrategy,
    },
    {
      provide: statusStrategyIdFactory(GameId.COIN_PUSHER_V1, StatusStrategyType.SHUTDOWN),
      useClass: ShutdownStatusStrategy,
    },
    {
      provide: statusStrategyIdFactory(GameId.COIN_PUSHER_V1, StatusStrategyType.GAMEPLAY),
      useClass: GameplayStatusStrategy,
    },
    {
      provide: statusStrategyIdFactory(GameId.COIN_PUSHER_V1, StatusStrategyType.ERROR),
      useClass: ErrorStatusStrategy,
    },
    {
      provide: statusStrategyIdFactory(GameId.CLAW_ROULETTE, StatusStrategyType.STARTUP),
      useClass: ClawRouletteStartupStatusStrategy,
    },
    {
      provide: statusStrategyIdFactory(GameId.CLAW_ROULETTE, StatusStrategyType.SHUTDOWN),
      useClass: ShutdownStatusStrategy,
    },
    {
      provide: statusStrategyIdFactory(GameId.CLAW_ROULETTE, StatusStrategyType.GAMEPLAY),
      useClass: GameplayStatusStrategy,
    },
    {
      provide: statusStrategyIdFactory(GameId.CLAW_ROULETTE, StatusStrategyType.ERROR),
      useClass: ErrorStatusStrategy,
    },
    {
      provide: statusStrategyIdFactory(GameId.CLAW, StatusStrategyType.STARTUP),
      useClass: ClawRouletteStartupStatusStrategy,
    },
    {
      provide: statusStrategyIdFactory(GameId.CLAW, StatusStrategyType.SHUTDOWN),
      useClass: ShutdownStatusStrategy,
    },
    {
      provide: statusStrategyIdFactory(GameId.CLAW, StatusStrategyType.GAMEPLAY),
      useClass: GameplayStatusStrategy,
    },
    {
      provide: statusStrategyIdFactory(GameId.CLAW, StatusStrategyType.ERROR),
      useClass: ErrorStatusStrategy,
    },
    MachineRepository,
    QueueRepository,
    ChipRepository,
    SeedHistoryRepository,
  ],
  controllers: [StatusHandlerController],
})
export class StatusHandlingModule {

}
