import { GameId } from '@lib/dal';
import { IsEnum, Length } from 'class-validator';
import { SessionAwareDto } from '../../../dto/session.aware.dto';

export class RobotMessage extends SessionAwareDto {
  @Length(1, 100)
  public type: string;

  @Length(1, 256)
  public serial: string;

  @IsEnum(GameId)
  public gameId: GameId;
}
