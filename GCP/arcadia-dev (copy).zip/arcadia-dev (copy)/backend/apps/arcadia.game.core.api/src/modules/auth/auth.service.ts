/* eslint-disable max-lines */
import { AuthPlayerDto, CommandType, genericRetryStrategy } from '@lib/common';
import { jwtSigner, jwtVerifier } from '@lib/common/utils/jwt.promisified';
import { ConfigService } from '@lib/config';
import {
  AlertSeverity,
  AlertSource,
  AlertType,
  AllowedLanguage,
  AutoSwingMode,
  CMSRepository,
  CurrencyConversionRepository,
  GameId,
  MachineEntity,
  MachineToCameraEntity,
  OperatorEntity,
  OperatorRepository,
  OperatorStatus,
  PlayerEntity,
  PlayerRepository,
  PlayerSettings,
  PlayerStatus,
  SessionArchiveEntity,
  SessionArchiveRepository,
  SessionEndReason,
  SessionEntity,
  SessionRepository,
  SessionStatus,
} from '@lib/dal';
import { FileUrl } from '@lib/file.manager';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { StreamResponse, VideoApiClientService } from '@lib/video.api';
import {
  HttpStatus, Inject, Injectable, NotAcceptableException, NotFoundException, UnauthorizedException,
} from '@nestjs/common';
import moment from 'moment';
import { from, lastValueFrom, throwError } from 'rxjs';
import { catchError, concatMap, toArray } from 'rxjs/operators';
import { In, MoreThan, Not } from 'typeorm';
import { v4 as uuidv4 } from 'uuid';
import { Logger } from 'winston';
import { NotificationException } from '../../filters/notification.exception';
import { CommandPublisher } from '../command/command.publisher';
import { ConversionTracker } from '../conversion.tracker/conversion.tracker';
import { EntrySource } from '../conversion.tracker/entry.source';
import { OperatorApiClientService } from '../operator.api.client/operator.api.client.service';
import { NotificationLevel } from '../player.client/notification.level';
import { NotificationType } from '../player.client/notification.type';
import { SessionDataManager } from '../session.data.manager/session.data.manager';
import { AuthTokenPayload } from './auth.token.payload';
import { LaunchGameDto } from './dtos';
import { LoginOptions } from './interfaces';
import { AuthResponseDto } from './responses';
import { PlayerClientService } from '../player.client/player.client.service';

@Injectable()
export class AuthService {
  private readonly sessionAuthSecret: string;
  private readonly streamAuthSecret: string;
  private readonly testAlwaysOkToken: string;
  private readonly testAlwaysBadToken: string;
  private readonly clientIoHaproxyUrl: string;
  private readonly allowParallelSessions: boolean;
  private readonly maxSessionsThresholdEnv: number;

  constructor(
    configService: ConfigService,
    private readonly playerRepository: PlayerRepository,
    private readonly operatorRepository: OperatorRepository,
    private readonly sessionRepository: SessionRepository,
    private readonly sessionArchiveRepository: SessionArchiveRepository,
    private readonly currencyConversionRepo: CurrencyConversionRepository,
    private readonly cmsRepository: CMSRepository,
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly operatorClient: OperatorApiClientService,
    private readonly cacheManager: RedisCacheService,
    private readonly monitoringClient: MonitoringWorkerClientService,
    private readonly videoApiClient: VideoApiClientService,
    private readonly sessionDataManager: SessionDataManager,
    private readonly conversionTracker: ConversionTracker,
    private readonly commandPublisher: CommandPublisher,
    private readonly fileUrl: FileUrl,
    private readonly playerClientService: PlayerClientService,
  ) {
    this.sessionAuthSecret = configService.get(['core', 'SESSION_AUTH_SECRET']);
    this.streamAuthSecret = configService.get(['core', 'STREAM_AUTH_SECRET']);
    this.testAlwaysOkToken = configService.get(['core', 'STREAM_AUTH_TEST_TOKEN_OK']);
    this.testAlwaysBadToken = configService.get(['core', 'STREAM_AUTH_TEST_TOKEN_BAD']);
    this.clientIoHaproxyUrl = configService.get(['core', 'CLIENT_IO_HAPROXY_URL']);
    this.allowParallelSessions = configService.get(['core', 'ALLOW_PARALLEL_SESSIONS']);
    this.maxSessionsThresholdEnv = configService.get(['core', 'MAX_SESSIONS_THRESHOLD']);
  }

  public async authPlayer(correlationId: string, data: AuthPlayerDto): Promise<AuthResponseDto> {
    const {
      accessToken,
      ...urlParams
    } = data;
    const {
      operatorId,
      playerIP,
      os,
      deviceType,
      browser,
      gameId,
      extGameId,
      homeUrl,
      cashierUrl,
      jurisdiction: regulation = null,
      // isReal, externalId,
    } = urlParams;
    const language = data.language || AllowedLanguage.EN_US;

    const operator = await this.operatorRepository.findOneBy({
      id: operatorId,
      isDeleted: false,
      status: OperatorStatus.ENABLED,
    });
    if (!operator) {
      throw new NotAcceptableException('Operator not found or disabled!');
    }

    const {
      cid,
      playerToken,
      currencyCode,
      name,
      // balance,
    } = await this.operatorClient.auth({
      operator,
      accessToken,
      correlationId,
      gameId,
      extGameId,
    })
      .catch(err => {
        this.logger.error('Operator auth failed', { reason: err.message });
        throw new NotificationException({
          notificationId: NotificationType.PLAYER_AUTH_FAILED,
          level: NotificationLevel.ERROR,
          title: 'Error',
          message: 'Player auth failed!',
          command: 'goToLobby',
        }, HttpStatus.UNAUTHORIZED);
      });

    const session = await this.sessionRepository.findOneBy({
      player: { cid, operatorId },
      operator: { id: operatorId },
      gameId,
    });
    const isReconnectSession = await this.isReconnectSession(session);
    let player = await this.playerRepository.findOne({
      where: {
        cid,
        operatorId: operator.id,
      },
      relations: ['operator'],
    });

    const [assets] = await this.cmsRepository.getAllCMSRecords({
      operatorId,
      language: [language],
      regulation: [regulation],
      gameId,
    });

    const payload: AuthTokenPayload = {
      operatorId: operator.id,
      cid,
      gameId,
    };
    const token = await jwtSigner(payload, this.sessionAuthSecret, { expiresIn: '5m' });

    if (isReconnectSession) {
      await this.playerClientService.forceClientClose(session.id);
      const { sessionOptions } = await this.getSessionOptions('', session);
      await this.cacheManager.set<Partial<SessionEntity>>(token, sessionOptions, { ttl: 310 });
      return {
        url: this.clientIoHaproxyUrl,
        token,
        currency: session.currency,
        playerId: player.cid,
        settings: player.settings[gameId],
        assets: assets.map(asset => ({
          fileUrl: this.fileUrl.getFileUrlById(asset.fileId),
          operatorId: asset.operatorId && Number(asset.operatorId),
          groupId: asset.groupId && Number(asset.groupId),
          regulation: asset.regulation,
          language: asset.language,
          assetType: asset.assetType,
          contentType: asset.contentType,
          gameId: asset.gameId,
        })),
        lobbyConfiguration: operator.lobbyConfiguration,
        gameId,
        sessionId: session.id,
        footprint: session.footprint,
      };
    }

    await this.currencyConversionRepo.getCurrencyConversion(currencyCode)
      .catch(reason => {
        throw new NotificationException({
          notificationId: NotificationType.PLAYER_AUTH_FAILED,
          level: NotificationLevel.ERROR,
          title: 'Error',
          message: `Currency '${currencyCode}' is not supported!`,
          command: 'goToLobby',
          data: { error: reason.message },
        }, HttpStatus.UNAUTHORIZED);
      });

    const loginOptions: LoginOptions = {
      sessionToken: playerToken,
      extGameId,
      homeUrl,
      cashierUrl,
    };

    if (!player) {
      const settings: PlayerSettings = {
        [GameId.COIN_PUSHER_V1]: {
          soundsConfig: {
            isAllSoundsMuted: false,
            isMusicSoundsMuted: false,
            isGameSoundsMuted: false,
            musicSoundsVolume: 1,
            gameSoundsVolume: 0.4,
          },
          showTutorial: true,
          autoSwingMode: AutoSwingMode.AUTO,
        },
        [GameId.CLAW_ROULETTE]: {
          soundsConfig: {
            isAllSoundsMuted: false,
            isMusicSoundsMuted: false,
            isGameSoundsMuted: false,
            musicSoundsVolume: 1,
            gameSoundsVolume: 0.4,
          },
          showTutorial: true,
        },
        [GameId.CLAW]: {
          soundsConfig: {
            isAllSoundsMuted: false,
            isMusicSoundsMuted: false,
            isGameSoundsMuted: false,
            musicSoundsVolume: 1,
            gameSoundsVolume: 0.4,
          },
          showTutorial: true,
        },
      };
      player = this.playerRepository.create({
        cid,
        operatorId: operator.id,
        name: name || null,
        lastSessionDate: new Date(),
        settings,
        operator,
      });
      player = await this.playerRepository.save(player, { transaction: false });
    }

    if (player.status === PlayerStatus.BLOCKED) {
      this.logger.error('Player auth failed: player blocked');
      throw new NotificationException({
        notificationId: NotificationType.PLAYER_BLOCKED,
        level: NotificationLevel.ERROR,
        title: 'Error',
        message: 'Player blocked!',
        command: 'goToLobby',
      }, HttpStatus.UNAUTHORIZED);
    }

    const maxConcurrentSessions = Number(operator.configuration.maxConcurrentSessions || 0);
    await this.parallelSessionCheck(player, maxConcurrentSessions, gameId);

    const sessionOptions: Partial<SessionEntity> & { loginOptions: LoginOptions } = {
      playerIP,
      currency: currencyCode,
      os,
      deviceType,
      browser,
      locale: language,
      gameId,
      loginOptions,
    };

    await this.cacheManager.set<Partial<SessionEntity>>(token, sessionOptions, { ttl: 310 });

    await this.conversionTracker.createTracker(player, EntrySource.EXTERNAL_LOBBY, urlParams);

    return {
      url: this.clientIoHaproxyUrl,
      token,
      currency: currencyCode,
      playerId: player.cid,
      settings: player.settings[gameId],
      assets: assets.map(asset => ({
        fileUrl: this.fileUrl.getFileUrlById(asset.fileId),
        operatorId: asset.operatorId && Number(asset.operatorId),
        groupId: asset.groupId && Number(asset.groupId),
        regulation: asset.regulation,
        language: asset.language,
        assetType: asset.assetType,
        contentType: asset.contentType,
        gameId: asset.gameId,
      })),
      lobbyConfiguration: operator.lobbyConfiguration,
      gameId,
      sessionId: null,
      footprint: null,
    };
  }

  public async videoStreamAuth(streamAuthToken: string): Promise<void> {
    if (streamAuthToken === this.testAlwaysOkToken) {
      return;
    }
    if (streamAuthToken === this.testAlwaysBadToken) {
      throw new UnauthorizedException();
    }
    try {
      await jwtVerifier(streamAuthToken, this.streamAuthSecret, { clockTolerance: 2 });
    } catch (err) {
      throw new UnauthorizedException(err.message);
    }
  }

  public async validateGameLaunch(data: LaunchGameDto): Promise<any> {
    // todo: some checks could be added here
    return { status: 'ok' };
  }

  public verifyAuthToken(token: string): Promise<AuthTokenPayload> {
    return jwtVerifier(token, this.sessionAuthSecret, { clockTolerance: 2 })
      .catch(reason => {
        throw new UnauthorizedException('Token verification failed!', reason.message);
      });
  }

  public validateVideoStreams({
    highQuality,
    lowQuality,
  }: StreamResponse): void {
    if (!(highQuality?.status?.isOn && highQuality?.status?.isRecording && lowQuality?.status?.isOn)) {
      throw new NotAcceptableException('Camera status is not acceptable!');
    }
  }

  public async getCamerasStreams(machine: MachineEntity): Promise<StreamResponse[]> {
    return lastValueFrom(from(machine.cameras)
      .pipe(
        concatMap(async (camera: MachineToCameraEntity) => {
          const streams = await this.videoApiClient.getCameraStreams(machine.site, camera);
          this.logger.debug('Stream response', {
            ...streams,
            cameraId: camera.cameraId,
            machineId: machine.id,
          });
          this.validateVideoStreams(streams);
          return streams;
        }),
        genericRetryStrategy(),
        catchError(err => {
          const details = {
            error: err.message,
            cameraIds: machine.cameras.map(c => c.cameraId),
            machineSerial: machine.serial,
            machineName: machine.name,
            siteId: machine.site?.id,
          };
          this.logger.error('Video API Error', details);
          this.monitoringClient.sendAlertMessage(
            {
              alertType: AlertType.ERROR,
              source: AlertSource.GAME_CORE,
              severity: AlertSeverity.CRITICAL,
              description: 'Video API Error',
              gameId: machine.gameId,
              details,
            },
          );
          return throwError(err);
        }),
        toArray(),
      ));
  }

  public async getBalance(
    session: SessionEntity, operator: OperatorEntity, player: PlayerEntity, correlationId = uuidv4(),
  ): Promise<number> {
    try {
      const { loginOptions } = await this.sessionDataManager.getSessionData(session.id);
      const {
        sessionToken,
        extGameId,
      } = loginOptions;
      if (!sessionToken) {
        return null;
      }
      return await this.operatorClient.balance({
        accessToken: sessionToken,
        gameId: session.gameId,
        operator,
        cid: player.cid,
        extGameId,
        correlationId,
      })
        .then(balance => balance.balance);
    } catch (err) {
      this.logger.error('Balance call failed', {
        sessionId: Number(session.id),
        error: err.message,
      });
      return 0;
    }
  }

  public async getSessionOptions(
    token: string, existingSession?: SessionEntity,
  ): Promise<{ sessionOptions: Partial<SessionEntity>, loginOptions: LoginOptions }> {
    if (existingSession) {
      const { loginOptions } = await this.sessionDataManager.getSessionData(existingSession.id);
      return {
        sessionOptions: {
          gameId: existingSession.gameId,
          totalStacksUsed: existingSession.totalStacksUsed,
          playerIP: existingSession.playerIP,
          currency: existingSession.currency,
          os: existingSession.os,
          deviceType: existingSession.deviceType,
          browser: existingSession.browser,
          locale: existingSession.locale,
        },
        loginOptions,
      };
    }
    const options = await this.cacheManager
      .get<Partial<SessionEntity> & { loginOptions: LoginOptions }>(token);
    if (!options) {
      throw new NotFoundException('Session options not found!');
    }
    const {
      loginOptions,
      ...sessionOptions
    } = options;
    return {
      sessionOptions,
      loginOptions,
    };
  }

  public async parallelSessionCheck(player: PlayerEntity, allowedParallelSessionCount: number, gameId: GameId): Promise<void | never> {
    if (!this.allowParallelSessions) {
      const existingSessions = await this.sessionRepository.findBy({
        player: {
          cid: player.cid,
          operatorId: player.operatorId,
        },
        gameId,
        status: Not(In([SessionStatus.FORCED_AUTOPLAY, SessionStatus.TERMINATING, SessionStatus.COMPLETED])),
      });

      const {
        activeSessionsCount,
        noActiveSession,
      } = existingSessions
        .reduce<{ activeSessionsCount: number, noActiveSession: SessionEntity[] }>(
          (acc, session) => {
            if (session.isActivePlayingStatus()) {
              acc.activeSessionsCount += 1;
            } else {
              acc.noActiveSession.push(session);
            }
            return acc;
          },
          {
            activeSessionsCount: 0,
            noActiveSession: [],
          });

      if (activeSessionsCount && activeSessionsCount > allowedParallelSessionCount) {
        throw new NotificationException({
          notificationId: NotificationType.PARALLEL_SESSIONS_FORBIDDEN,
          level: NotificationLevel.WARNING,
          title: 'Warning',
          message: 'You already have a session, parallel sessions are forbidden!',
          command: 'goToLobby',
        }, HttpStatus.NOT_ACCEPTABLE);
      } else {
        noActiveSession.forEach(session => this.commandPublisher.finalizeSession({
          type: CommandType.FINALIZE_SESSION,
          sessionId: Number(session.id),
          gameId,
          reason: SessionEndReason.PARALLEL_SESSION_CHECK,
          terminate: true,
        }));
      }
    }
  }

  public async getPlayerForSession(token: string, existingSession?: SessionEntity): Promise<PlayerEntity> {
    if (existingSession) {
      return this.playerRepository.findOneOrFail({
        where: {
          cid: existingSession.player.cid,
          operatorId: existingSession.operator.id,
        },
        relations: ['operator', 'operator.groupToOperator', 'operator.groupToOperator.group'],
      });
    }
    const {
      cid,
      operatorId,
    } = await this.verifyAuthToken(token);
    return this.playerRepository.findOneOrFail({
      where: {
        cid,
        operatorId,
      },
      relations: ['operator', 'operator.groupToOperator', 'operator.groupToOperator.group'],
    });
  }

  public getStreamAuthToken(session: SessionEntity): Promise<string> {
    return jwtSigner({ sessionId: session.id },
      this.streamAuthSecret,
      { expiresIn: '2h' });
  }

  public getMaxSessionsThreshold(thresholdFromGroup: number): number {
    const parsedThreshold = parseInt(String(thresholdFromGroup), 10);
    return Math.min(this.maxSessionsThresholdEnv, parsedThreshold || Number.MAX_SAFE_INTEGER);
  }

  public async getArchiveSession(sessionId: number): Promise<SessionArchiveEntity> {
    return this.sessionArchiveRepository.findOne({
      where: {
        id: sessionId,
        endDate: MoreThan(moment()
          .subtract(1, 'day')
          .toDate()),
      },
    });
  }

  private async isReconnectSession(session: SessionEntity): Promise<boolean> {
    if (!session) {
      return false;
    }
    const sessionData = await this.sessionDataManager.getSessionData(session.id);
    return sessionData && ![
      SessionStatus.TERMINATING,
      SessionStatus.COMPLETED,
      SessionStatus.TERMINATED,
      SessionStatus.VIEWER_BET_BEHIND,
      SessionStatus.VIEWER,
    ].some(status => status === session.status);
  }
}
