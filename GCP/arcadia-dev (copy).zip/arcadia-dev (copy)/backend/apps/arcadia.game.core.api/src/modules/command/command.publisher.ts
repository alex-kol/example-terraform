import { CommandType, RmqQueueName } from '@lib/common';
import { GameId } from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { ServerRMQ } from '@lib/rmq.server';
import { Inject, Injectable } from '@nestjs/common';
import { v4 as uuidv4 } from 'uuid';
import { Logger } from 'winston';
import { BaseCommand } from './dto/base.command';
import { ChangeQueueCommand } from './dto/change.queue.command';
import { EngageSessionCommand } from './dto/engage.session.command';
import { FinalizeSessionCommand } from './dto/finalize.session.command';
import { RetryTransactionCommand } from './dto/retry.transaction.command';
import { RouletteCommand } from './dto/roulette.command';

@Injectable()
export class CommandPublisher {
  constructor(
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly serverRMQ: ServerRMQ,
  ) {
  }

  public sendCommand<T extends BaseCommand = BaseCommand>(payload: T, correlationId: string = uuidv4()): void {
    this.logger.debug('Send command', {
      ...payload,
      correlationId,
    });
    this.serverRMQ.sendMessage({
      ...payload,
      correlationId,
    }, RmqQueueName.CORE_COMMAND_QUEUE);
  }

  public sendRouletteCommand<T extends RouletteCommand = RouletteCommand>(payload: T, correlationId: string = uuidv4()): void {
    this.logger.debug('Send roulette command', {
      ...payload,
      correlationId,
    });
    this.serverRMQ.sendMessage({
      ...payload,
      gameId: GameId.CLAW_ROULETTE,
      correlationId,
    }, RmqQueueName.CORE_COMMAND_QUEUE);
  }

  public finalizeSession(payload: FinalizeSessionCommand, correlationId?: string): void {
    this.sendCommand({
      ...payload,
      type: CommandType.FINALIZE_SESSION,
    }, correlationId);
  }

  public terminateSession(payload: FinalizeSessionCommand, correlationId?: string): void {
    this.sendCommand({
      ...payload,
      type: CommandType.TERMINATE_SESSION,
    }, correlationId);
  }

  public engageNextSession(payload: EngageSessionCommand, correlationId?: string): void {
    this.sendCommand({
      ...payload,
      type: CommandType.ENGAGE_SESSION,
    }, correlationId);
  }

  public queueChange(payload: ChangeQueueCommand, correlationId?: string): void {
    this.sendCommand({
      ...payload,
      type: CommandType.CHANGE_QUEUE,
    }, correlationId);
  }

  public scheduleTransactionRetry(payload: RetryTransactionCommand, correlationId?: string): void {
    this.sendCommand({
      ...payload,
      type: CommandType.SCHEDULE_TRANSACTION_RETRY,
    }, correlationId);
  }
}
