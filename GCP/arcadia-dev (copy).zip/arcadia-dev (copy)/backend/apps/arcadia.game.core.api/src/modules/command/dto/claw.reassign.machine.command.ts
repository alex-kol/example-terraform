import { Transform } from 'class-transformer';
import { IsInt } from 'class-validator';
import { BaseCommand } from './base.command';

export class ClawReassignMachineCommand extends BaseCommand {
  @Transform(({ value }) => parseInt(value, 10))
  @IsInt()
  public machineId: number;
}