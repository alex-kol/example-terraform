import { EntrySource } from './entry.source';

export class ConversionData {
  playerCid: string;
  operatorId: number;
  source: EntrySource;
  launchParams: Record<string, any>;
  entryTimestamp: Date;
  clicks: number;
  swipes: number;
  sessionId?: number;
  groupId?: number;
}