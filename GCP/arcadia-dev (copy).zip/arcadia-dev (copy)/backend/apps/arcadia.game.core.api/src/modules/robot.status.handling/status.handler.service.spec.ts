import {
  ChipRepository,
  connectionNames,
  getRepositoryToken,
  MachineRepository,
  MachineStatus,
} from '@lib/dal';
import { StatusHandlerService } from './status.handler.service';
import { makeTestModule } from './mocks/beforeAll.mock';
import { RobotReportedStatus } from './robot.reported.status';
import { seedingStrategyOnIdleMachineMock, shouldSendChipMapStartSeeding } from './mocks/seedingStrategyOnIdle.mocks';
import { StatusStrategyFactory } from './strategy/status.strategy.factory';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';

jest.mock('../logger/logger.service');

describe('Status Handler Service (Unit)', () => {
  let statusHandlerService: StatusHandlerService;
  let machineRepository: MachineRepository;
  let chipRepository: ChipRepository;
  let monitoringWorkerClientService: MonitoringWorkerClientService;
  let machineUpdateSpy: any;
  let statusStrategyFactory: StatusStrategyFactory;
  const machineMock = { id: 1, group: { id: 11 } };

  beforeAll(async () => {
    const moduleFixture = await makeTestModule();
    statusHandlerService = moduleFixture.get<StatusHandlerService>(StatusHandlerService);
    machineRepository = moduleFixture.get<MachineRepository>(getRepositoryToken(MachineRepository, connectionNames.DATA));
    chipRepository = moduleFixture.get<ChipRepository>(getRepositoryToken(ChipRepository, connectionNames.DATA));
    monitoringWorkerClientService = moduleFixture.get<MonitoringWorkerClientService>(MonitoringWorkerClientService);
    statusStrategyFactory = moduleFixture.get<StatusStrategyFactory>(StatusStrategyFactory);

    // @ts-ignore
    jest.spyOn(machineRepository, 'findOneOrFail').mockResolvedValue(machineMock);
    machineUpdateSpy = jest.spyOn(machineRepository, 'update');
  });

  describe('handleStatus', () => {
    const onStopped = jest.fn();
    const onTesting = jest.fn();
    const onIdle = jest.fn();
    const onStopping = jest.fn();
    const onSeeding = jest.fn();
    const sendEventLogMessage = jest.fn();

    beforeAll(() => {
      jest.spyOn(statusStrategyFactory, 'getStrategy')
          .mockImplementation(jest.fn().mockReturnValue({
            onStopped,
            onTesting,
            onIdle,
            onStopping,
            onSeeding,
          }));
      jest.spyOn(monitoringWorkerClientService, 'sendEventLogMessage')
          .mockImplementation(sendEventLogMessage);
    })
    it('should update ping date', async () => {
      const currentDate = new Date('2019-05-14T11:01:58.135Z');
      const realDate = Date;
      // @ts-ignore
      global.Date = class extends Date {
        constructor(date) {
          if (date) {
            // @ts-ignore
            return super(date);
          }

          return currentDate;
        }
      };
      await statusHandlerService.handleStatus('unknown' as RobotReportedStatus, '<serial>');
      expect(machineUpdateSpy).toBeCalledWith(1, { pingDate: currentDate });
      global.Date = realDate;
    });
    it('should stop machine for any status in error strategy', async () => {
      await statusHandlerService.handleStatus(RobotReportedStatus.IDLE, '<serial>');
      expect(onIdle).toBeCalledWith(machineMock);
      await statusHandlerService.handleStatus(RobotReportedStatus.STOPPED, '<serial>');
      expect(onStopped).toBeCalledWith(machineMock);
      await statusHandlerService.handleStatus(RobotReportedStatus.TESTING, '<serial>');
      expect(onTesting).toBeCalledWith(machineMock);
      await statusHandlerService.handleStatus(RobotReportedStatus.STOPPING, '<serial>');
      expect(onStopping).toBeCalledWith(machineMock);
      expect(sendEventLogMessage).toBeCalled();
    });
    it('should update machine status in shutdown strategy, onStopped', async () => {
      // @ts-ignore
      jest.spyOn(machineRepository, 'findOneOrFail').mockResolvedValueOnce({ id: 1, status: MachineStatus.SHUTTING_DOWN, group: { id: 11 } });
      await statusHandlerService.handleStatus(RobotReportedStatus.STOPPED, '<serial>');
      expect(onStopped).toBeCalled();
      expect(machineUpdateSpy).toBeCalled();
    });
    it('should send chipmap and start seedind in startup strategy, onIdle', async () => {
      shouldSendChipMapStartSeeding({ machineRepository, chipRepository });
      await statusHandlerService.handleStatus(RobotReportedStatus.IDLE, '<serial>');
      expect(onIdle).toBeCalledWith(seedingStrategyOnIdleMachineMock);
      expect(machineUpdateSpy).toBeCalled();
    });
    it('should update machine status in startup strategy, onTesting', async () => {
      const findOneOrFailReturnedMock = { id: 1, status: MachineStatus.STOPPED };
      // @ts-ignore
      jest.spyOn(machineRepository, 'findOneOrFail').mockResolvedValueOnce(findOneOrFailReturnedMock);
      const machineUpdateSpy = jest.spyOn(machineRepository, 'update');
      await statusHandlerService.handleStatus(RobotReportedStatus.TESTING, '<serial>');
      expect(onTesting).toBeCalledWith(findOneOrFailReturnedMock);
      expect(machineUpdateSpy).toBeCalled();
    });
    it('should update db status and send run message in startup strategy, onStopped', async () => {
      // @ts-ignore
      jest.spyOn(machineRepository, 'findOneOrFail').mockResolvedValueOnce({ id: 1, serial: '<serial>', status: MachineStatus.STOPPED });
      await statusHandlerService.handleStatus(RobotReportedStatus.STOPPED, '<serial>');
      expect(machineUpdateSpy).toBeCalled();
    });
  });
});
