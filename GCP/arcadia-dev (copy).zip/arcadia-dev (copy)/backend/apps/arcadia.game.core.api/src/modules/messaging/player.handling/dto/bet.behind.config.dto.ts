import { BetBehindConfiguration } from '@lib/dal';
import { Transform } from 'class-transformer';
import { IsInt, IsNumber } from 'class-validator';

export class BetBehindConfigDto extends BetBehindConfiguration {
  @Transform(({ value }) => parseInt(value, 10))
  @IsInt()
  public stopAfterRounds: number;

  @Transform(({ value }) => Number(value))
  @IsNumber()
  public singleWinThreshold: number;

  @Transform(({ value }) => Number(value))
  @IsNumber()
  public lowLimitMultiplier: number;

  @Transform(({ value }) => Number(value))
  @IsNumber()
  public hiLimitMultiplier: number;
}
