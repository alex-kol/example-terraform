import { BetLimits } from '@lib/dal';
import { RouletteBet } from './roulette.bet';

export interface BetEvent {
  sessionId: number;
  currencyConversionRate: number;
  bet?: RouletteBet;
  betLimits?: BetLimits;
}
