/* eslint-disable max-lines */
import {
  networkFailureRetry, OperatorApiActionType, OperatorErrorType, OperatorException,
} from '@lib/common';
import { TransactionType } from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { HttpService } from '@nestjs/axios';
import { Inject, Injectable } from '@nestjs/common';
import { firstValueFrom, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Logger } from 'winston';
import { CommandPublisher } from '../command/command.publisher';
import { CidOperatorParams } from './cid.operator.params';
import { AuthData, BalanceData, BetData } from './dtos';
import { operatorErrorMapper } from './operator.error.mapper';
import { OperatorRequestParams } from './operator.request.params';
import { OperatorTransactionParams } from './operator.transaction.params';

@Injectable()
export class OperatorApiClientService {
  private readonly maxRetries: number = 3;

  constructor(
    private readonly apiClient: HttpService,
    private readonly commandPublisher: CommandPublisher,
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
  ) {
  }

  public auth(params: OperatorRequestParams): Promise<AuthData> {
    const {
      accessToken,
      operator,
      correlationId,
      gameId,
      extGameId,
    } = params;
    const body = {
      gameId,
      authToken: accessToken,
      externalId: operator.externalId,
      extGameId,
      operatorId: operator.id,
    };
    return firstValueFrom(this.apiClient.post<AuthData>(
      `operator/${operator.apiConnectorId}/auth`,
      body,
      { headers: { correlation: correlationId } },
    )
      .pipe(
        networkFailureRetry(this.maxRetries, this.logger),
        operatorErrorMapper,
        catchError(err => {
          if (err instanceof OperatorException && err.getResponse().type === OperatorErrorType.NETWORK) {
            this.logger.error('operatorApiError', {
              error: err.message,
              actionType: OperatorApiActionType.AUTH,
              operator: operator.id,
              gameId,
              extGameId,
            });
          }
          return throwError(() => err);
        }),
        map(value => value.data),
      ));
  }

  public balance({
    operator,
    accessToken,
    cid,
    correlationId,
    gameId,
    extGameId,
  }: CidOperatorParams,
  ): Promise<BalanceData> {
    return firstValueFrom(this.apiClient.post<BalanceData>(`operator/${operator.apiConnectorId}/balance`,
      {
        cid,
        sessionToken: accessToken,
        externalId: operator.externalId,
        gameId,
        extGameId,
        operatorId: operator.id,
      },
      { headers: { correlation: correlationId } })
      .pipe(
        networkFailureRetry(this.maxRetries, this.logger),
        operatorErrorMapper,
        catchError(err => {
          if (err instanceof OperatorException && err.getResponse().type === OperatorErrorType.NETWORK) {
            this.logger.error('operatorApiError', {
              error: err.message,
              actionType: OperatorApiActionType.BALANCE,
              operator: operator.id,
              gameId,
              extGameId,
            });
          }
          return throwError(() => err);
        }),
        map(value => value.data),
      ));
  }

  public async bet({
    accessToken,
    operator,
    cid,
    amount,
    roundId,
    correlationId,
    isRetry = false,
    gameId,
    extGameId,
  }: OperatorTransactionParams,
  ): Promise<BetData> {
    return firstValueFrom(this.apiClient.post<BetData>(`operator/${operator.apiConnectorId}/bet`, {
      sessionToken: accessToken,
      externalId: operator.externalId,
      cid,
      amount,
      roundId: `${roundId}`,
      isRetry,
      gameId,
      extGameId,
      operatorId: operator.id,
    }, { headers: { correlation: correlationId } })
      .pipe(
        networkFailureRetry(this.maxRetries, this.logger),
        operatorErrorMapper,
        catchError(err => {
          if (err instanceof OperatorException) {
            const operatorError = err.getResponse();
            if (operatorError.retry === true && !isRetry) {
              this.commandPublisher.scheduleTransactionRetry({
                transactionType: TransactionType.BET,
                operatorId: operator.id,
                playerCid: cid,
                amountInCash: amount,
                sessionToken: accessToken,
                roundId: `${roundId}`,
                gameId,
                extGameId,
              }, correlationId);
            }
            if (operatorError.type === OperatorErrorType.NETWORK) {
              this.logger.error('operatorApiError', {
                error: err.message,
                actionType: OperatorApiActionType.BET,
                operator: operator.id,
                gameId,
                extGameId,
              });
            }
          }
          return throwError(() => err);
        }),
        map(value => value.data),
      ));
  }

  public cancelBet({
    accessToken,
    operator,
    cid,
    amount,
    roundId,
    transactionId,
    correlationId,
    isRoundFinish = true,
    isRetry = false,
    gameId,
    extGameId,
  }: OperatorTransactionParams,
  ): Promise<BalanceData> {
    return firstValueFrom(this.apiClient.post<BalanceData>(`operator/${operator.apiConnectorId}/cancelBet`, {
      sessionToken: accessToken,
      externalId: operator.externalId,
      cid,
      amount,
      roundId: `${roundId}`,
      transactionId,
      isRoundFinish,
      isRetry,
      gameId,
      extGameId,
      operatorId: operator.id,
    }, { headers: { correlation: correlationId } })
      .pipe(
        networkFailureRetry(this.maxRetries, this.logger),
        operatorErrorMapper,
        catchError(err => {
          if (err instanceof OperatorException) {
            const operatorError = err.getResponse();
            if (operatorError.retry === true && !isRetry) {
              this.commandPublisher.scheduleTransactionRetry({
                transactionType: TransactionType.CANCEL_BET,
                operatorId: operator.id,
                playerCid: cid,
                amountInCash: amount,
                sessionToken: accessToken,
                roundId: `${roundId}`,
                originalTransactionId: transactionId,
                gameId,
                extGameId,
              }, correlationId);
            }
            if (operatorError.type === OperatorErrorType.NETWORK) {
              this.logger.error('operatorApiError', {
                error: err.message,
                actionType: OperatorApiActionType.CANCEL_BET,
                operator: operator.id,
                gameId,
                extGameId,
              });
            }
          }
          return throwError(() => err);
        }),
        map(value => value.data),
      ));
  }

  public payout({
    accessToken,
    operator,
    cid,
    amount,
    roundId,
    transactionId,
    correlationId,
    isRoundFinish = true,
    isRetry = false,
    gameId,
    extGameId,
  }: OperatorTransactionParams,
  ): Promise<BalanceData> {
    return firstValueFrom(this.apiClient.post<BalanceData>(`operator/${operator.apiConnectorId}/payout`, {
      sessionToken: accessToken,
      externalId: operator.externalId,
      cid,
      amount,
      roundId: `${roundId}`,
      transactionId,
      isRoundFinish,
      isRetry,
      gameId,
      extGameId,
      operatorId: operator.id,
    }, { headers: { correlation: correlationId } })
      .pipe(
        networkFailureRetry(this.maxRetries, this.logger),
        operatorErrorMapper,
        catchError(err => {
          if (err instanceof OperatorException) {
            const operatorError = err.getResponse();
            if (operatorError.retry === true && !isRetry) {
              this.commandPublisher.scheduleTransactionRetry({
                transactionType: TransactionType.PAYOUT,
                operatorId: operator.id,
                playerCid: cid,
                amountInCash: amount,
                sessionToken: accessToken,
                roundId: `${roundId}`,
                originalTransactionId: transactionId,
                gameId,
                extGameId,
              }, correlationId);
            }
            if (operatorError.type === OperatorErrorType.NETWORK) {
              this.logger.error('operatorApiError', {
                error: err.message,
                actionType: OperatorApiActionType.PAYOUT,
                operator: operator.id,
                gameId,
                extGameId,
              });
            }
          }
          return throwError(() => err);
        }),
        map(value => value.data),
      ));
  }
}
