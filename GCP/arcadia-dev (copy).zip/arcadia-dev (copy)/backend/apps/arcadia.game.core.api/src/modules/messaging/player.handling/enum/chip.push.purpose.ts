export enum ChipPushPurpose {
  SEED = 'seed',
  RTP = 'rtp',
}
