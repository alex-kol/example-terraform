import { LoggingWinston } from '@google-cloud/logging-winston';
import { ConfigService } from '@lib/config';
import { defaultMetaFactory, GLOBAL_LOGGER_CONTEXT, LogConfig } from '@lib/logger';
import { FactoryProvider } from '@nestjs/common/interfaces/modules/provider.interface';
import { transports } from 'winston';
import { SERVICE_NAME } from '../../constants/service';

export const loggerConfig: FactoryProvider<Promise<LogConfig>> = {
  provide: 'config',
  useFactory: async (config: ConfigService): Promise<LogConfig> => {
    const isCloud: boolean = config.get(['core', 'USE_GCP_SM']);
    return {
      level: config.get(['core', 'SYSTEM_LOG_LEVEL']),
      transports: isCloud ? new LoggingWinston({ logName: SERVICE_NAME }) : new transports.Console(),
      defaultMeta: defaultMetaFactory({
        label: SERVICE_NAME,
        context: GLOBAL_LOGGER_CONTEXT,
      }),
    };
  },
  inject: [ConfigService],
};