import { ApiResponseProperty } from '@nestjs/swagger';
import { ClawRouletteVerifyRes } from './claw.roulette.verify.res';

export class ReconnectVerifyRes extends ClawRouletteVerifyRes {
  @ApiResponseProperty()
  public rounds: number;

  @ApiResponseProperty()
  public joinRobotDirectRoom: boolean;

  @ApiResponseProperty()
  public queueToken: string;

  @ApiResponseProperty()
  public totalWin: number;
}
