import { SessionStatus } from '@lib/dal';

export class QueueItemDto {
  queueToken: string;
  stacks: number;
  status: SessionStatus;
}
