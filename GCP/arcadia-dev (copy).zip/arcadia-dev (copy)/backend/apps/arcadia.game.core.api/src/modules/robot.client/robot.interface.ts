import { AutoSwingMode, GameId, ShutdownReason } from '@lib/dal';
import { CoreMessage } from '../messaging/robot.handling/enum/core.message';

export interface CoreToRobotMessage {
  action: CoreMessage;
  client?: string;
  mode?: AutoSwingMode;
  rfid?: string;
  status?: string;
  map?: Record<string, any>;
  session?: number;
  coins?: number;
  table?: string[];
  dispenser?: string;
  dispensers?: string[];
  reshuffleCoins?: number;
  burstShoot?: number;
  reason?: ShutdownReason;
  gameId?: GameId;
  clearTable?: boolean;
  resetDispensers?: boolean;
  config?: Record<string, any>;
  timeout?: number;
  label?: string;
  missing?: string[];
  rejectedReason?: string;
  ballCount?: 37 | 38;
  chipType?: string;
  tableSpeed?: number;
  maxAttempts?: number;
  pickup?: Record<string, boolean>;
}
