import { ApiResponseProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsEnum } from 'class-validator';
import { ClawPhase } from '@lib/dal';
import { ReconnectVerifyRes } from './reconnect.verify.res';
import { PayTableDto } from '../dtos';

export class ClawReconnectVerifyRes extends ReconnectVerifyRes {
  @ApiResponseProperty()
  @Type(() => PayTableDto)
  public payTable: PayTableDto[];

  @ApiResponseProperty()
  @IsEnum(ClawPhase)
  public sessionPhase: ClawPhase;

  @ApiResponseProperty()
  public betInCash: number;

  @ApiResponseProperty()
  public idleTimeout: number;
}
