import { ConfigService } from '@lib/config';
import { MAIN_LOGGER } from '@lib/logger';
import { CacheModule, INestApplication, ValidationPipe } from '@nestjs/common';
import { ClientsModule, Transport, } from '@nestjs/microservices';
import { Test } from '@nestjs/testing';
import { PlayerClientService } from '../../player.client/player.client.service';
import { ServerRMQ } from '../../rmq.server/rmq.server';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { SessionService } from '../../session/session.service';
import { RobotMessageService } from '../robot.handling/robot.message.service';
import { PlayerMessageController } from './player.message.controller';
import { PlayerMessageService } from './player.message.service';
import { RedisCacheService } from '@lib/redis.cache/redis.service';

jest.mock('./player.message.service');
jest.mock('./player.message.service');
jest.mock('../../logger/logger.service');
jest.mock('../../session/session.service');
jest.mock('../robot.handling/robot.message.service');
jest.mock('../../player.client/player.client.service');
jest.mock('../../robot.client/robot.client.service');

describe('Player Message Controller (Unit)', () => {
  let app: INestApplication;
  let rabbitMQStartegy: ServerRMQ;

  beforeAll(async () => {
    const moduleFixture = await Test.createTestingModule({
      imports: [CacheModule.register(),
        ClientsModule.register([{
          name: 'rmqClient',
          transport: Transport.RMQ
        }])],
      controllers: [PlayerMessageController],
      providers: [
        PlayerMessageService,
        PlayerClientService,
        RobotMessageService,
        RobotClientService,
        SessionService,
        ConfigService,
        {
          provide: RedisCacheService,
          useValue: { store: { getClient: () => ({}) } },
        },
        {
          provide: MAIN_LOGGER,
          useExisting: MAIN_LOGGER,
        },
      ],
    })
      .compile();
    app = moduleFixture.createNestApplication();
    const logger = app.get(MAIN_LOGGER);
    const config = app.get(ConfigService);
    const cache = app.get(RedisCacheService);
    const CONSUME_QUEUES = new Set(['test']);
    const ASSERT_QUEUES = new Set(['test']);
    rabbitMQStartegy = new ServerRMQ({
        queueOptions: {
          durable: true,
        },
      },
      CONSUME_QUEUES,
      ASSERT_QUEUES,
      cache,
      logger,
      config);
    app.connectMicroservice({
      strategy: rabbitMQStartegy,
    });
    app.useGlobalPipes(
      new ValidationPipe({
        whitelist: true,
      }),
    );
    await app.init();
  });

  beforeEach(
    () => {
      jest.restoreAllMocks();
    },
  );

  describe('userJoinedHandler', () => {
    it('should throw validation error', async () => {
    }); // TODO: Implement
  });
});
