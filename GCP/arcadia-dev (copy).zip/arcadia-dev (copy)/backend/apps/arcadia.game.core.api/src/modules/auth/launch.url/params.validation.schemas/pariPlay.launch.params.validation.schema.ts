import { GameId } from '@lib/dal';
import * as Joi from 'joi';
import { urlPattern } from '../../../../util';
import { PariPlayLaunchParams } from '../types';

export const pariPlayLaunchParamsValidationSchema = Joi.object<PariPlayLaunchParams>({
  operator: Joi.string()
    .required(),
  token: Joi.string()
    .required(),
  gameCode: Joi.string()
    .valid(...Object.values(GameId))
    .required(),
  languageCode: Joi.string()
    .required(),
  isReal: Joi.string()
    .required(),
  homeUrl: Joi.string()
    .pattern(urlPattern)
    .allow(null)
    .empty(null),
  cashierUrl: Joi.string()
    .pattern(urlPattern)
    .allow(null)
    .empty(null),
  historyUrl: Joi.string()
    .pattern(urlPattern)
    .allow(null)
    .empty(null),
});
