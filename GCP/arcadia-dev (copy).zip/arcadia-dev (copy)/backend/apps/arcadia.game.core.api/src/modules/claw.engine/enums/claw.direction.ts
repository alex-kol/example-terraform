export enum ClawDirection {
  RIGHT = 'right',
  FORWARD = 'forward',
}
