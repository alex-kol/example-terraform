import { TimeoutOptions, TimeoutType } from '@lib/common';
import { ConfigService } from '@lib/config';
import { GameId, RoundEntity } from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { Inject, Injectable, Scope } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import moment from 'moment';
import { DataSource } from 'typeorm';
import { Logger } from 'winston';
import { SessionContextHandler } from '../../command/session.context.handler';
import { WorkerClientService } from '../../worker.client/worker.client.service';
import { RobotMessage } from './dto';

@Injectable({ scope: Scope.REQUEST })
export class ChipDetectionHandler extends SessionContextHandler<RobotMessage> {
  private readonly roundEndDelaySec: number;
  private activeRound: RoundEntity;

  constructor(
    @Inject(MAIN_LOGGER) logger: Logger,
    private readonly config: ConfigService,
    private readonly workerClient: WorkerClientService,
    dataSource: DataSource,
  ) {
    super(logger, dataSource);
    this.roundEndDelaySec = Number(this.config.get(['core', 'ROUND_END_DELAY_SECONDS']));
  }

  protected async init(data: RobotMessage): Promise<void> {
    await super.init(data);

    this.session = await this.sessionRepository.findOneOrFail({
      where: { id: this.sessionId },
      relations: ['rounds'],
    });

    this.activeRound = this.session.getActiveRound();
    if (!this.activeRound) {
      throw new RpcException(`Chip detection out of active round. SessionId: ${this.session.id}`);
    }
  }

  protected async handleEvent(): Promise<void> {
    await this.resetRoundEndDelay();
  }

  private async resetRoundEndDelay(): Promise<void> {
    const options: TimeoutOptions = {
      timeoutType: TimeoutType.ROUND_END_DELAY,
      sessionId: this.sessionId,
      timeoutSec: this.roundEndDelaySec,
      payload: { gameId: GameId.COIN_PUSHER_V1 },
    };
    const existingTimeout = await this.workerClient.getTimeoutExpiration(options);
    if (existingTimeout) {
      const remainingSec = existingTimeout.diff(moment(), 'second');
      if (remainingSec < this.roundEndDelaySec) {
        await this.workerClient.timeoutStart(options, this.correlationId);
      }
      return;
    }
    if (this.activeRound.coins === 0 && this.session.roundsLeft === 0) {
      const existingAnimationTimeout = await this.workerClient.getTimeoutExpiration({
        timeoutType: TimeoutType.ANIMATION_IN_QUEUE,
        sessionId: this.sessionId,
      });
      if (existingAnimationTimeout) {
        await this.workerClient.timeoutStop({
          timeoutType: TimeoutType.ANIMATION_IN_QUEUE,
          sessionId: this.sessionId,
          payload: { gameId: GameId.COIN_PUSHER_V1 },
        });
        const animationTtl = existingAnimationTimeout.diff(moment(), 'second');
        if (animationTtl > options.timeoutSec) {
          options.timeoutSec = animationTtl;
        }
      }
      await this.workerClient.timeoutStart(options, this.correlationId);
    }
  }
}
