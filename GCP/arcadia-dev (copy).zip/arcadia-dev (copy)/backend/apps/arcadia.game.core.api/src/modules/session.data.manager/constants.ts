export const SESSION_TOKEN_TTL = 60 * 60 * 24; // 24h
export const REBUY_SKIP_TTL = 3;
