export enum NotificationLevel {
  ERROR = 'error',
  WARNING = 'warning',
  INFO = 'info'
}