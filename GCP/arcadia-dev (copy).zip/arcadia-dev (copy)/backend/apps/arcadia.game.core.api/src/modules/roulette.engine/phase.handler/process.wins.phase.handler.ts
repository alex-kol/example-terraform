/* eslint-disable max-lines */
import { EventSource } from '@lib/common';
import {
  AlertSeverity,
  AlertSource,
  AlertType,
  EventType,
  MachineRepository,
  PlayerRepository,
  QueueRepository,
  RoundRepository,
  RoundStatus,
  SessionEndReason,
  SessionEntity,
  SessionRepository,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Inject, Injectable } from '@nestjs/common';
import { count, firstValueFrom, mergeMap } from 'rxjs';
import { v4 as UUIDv4 } from 'uuid';
import { Logger } from 'winston';
import { CommandPublisher } from '../../command/command.publisher';
import { RouletteEventCommand } from '../../command/dto/roulette.event.command';
import { OperatorApiClientService } from '../../operator.api.client/operator.api.client.service';
import { NotificationLevel } from '../../player.client/notification.level';
import { NotificationType } from '../../player.client/notification.type';
import { PlayerClientService } from '../../player.client/player.client.service';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { SessionDataManager } from '../../session.data.manager/session.data.manager';
import { SessionDynamicData } from '../../session.data.manager/session.dynamic.data';
import { SessionService } from '../../session/session.service';
import { BetManager } from '../bet.manager';
import { GamePhase, PhaseStatus } from '../enums';
import { CommonContext, PhaseResult } from '../types';
import { PhaseHandler } from './phase.handler';
import { rouletteWinCalculator, RoundResult } from './roulette.win.calculator';

@Injectable()
export class ProcessWinsPhaseHandler extends PhaseHandler {
  constructor(
    commandPublisher: CommandPublisher,
    betManager: BetManager,
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly roundRepo: RoundRepository,
    sessionRepo: SessionRepository,
    private readonly playerRepo: PlayerRepository,
    private readonly sessionService: SessionService,
    private readonly playerPublisher: PlayerClientService,
    private readonly operatorClient: OperatorApiClientService,
    private readonly sessionDataManager: SessionDataManager,
    private readonly monitoringPublisher: MonitoringWorkerClientService,
    robotPublisher: RobotClientService,
    machineRepo: MachineRepository,
    queueRepo: QueueRepository,
  ) {
    super(
      commandPublisher,
      betManager,
      sessionRepo,
      machineRepo,
      robotPublisher,
      queueRepo,
    );
  }

  public async onStart({
    serial,
    resultHistory: [lastResult],
  }: CommonContext): Promise<PhaseResult> {
    this.robotPublisher.sendRouletteDisplayMessage(serial, {
      phase: GamePhase.PROCESS_WINS,
      message: lastResult,
    });

    await firstValueFrom(this.betManager.getMachineBets(serial)
      .pipe(
        mergeMap(async ({
          sessionId,
          bet,
        }) => {
          const session = await this.sessionService.findByIdCached(sessionId);
          if (!session) {
            return 1;
          }
          this.playerPublisher.gamePhase(session.id, { phase: GamePhase.PROCESS_WINS });
          const sessionData = await this.sessionDataManager.getSessionData(session.id);
          const roundResult = rouletteWinCalculator(bet, lastResult, session.currencyConversionRate);
          await this.sessionDataManager.updateSessionData({ lastWinInCash: roundResult.totalWinInCash }, sessionId);
          try {
            await this.roundPayout(session, sessionData, roundResult);
          } catch (err) {
            await this.onPayoutError(session, sessionData, err);
            this.finalizeSession(serial, sessionId, SessionEndReason.WALLET_TRANSACTION_ERROR, true);
          }
          return 1;
        }, 10),
        count(),
      ));
    return { status: PhaseStatus.COMPLETE };
  }

  public async onComplete({ serial }: CommonContext): Promise<void> {
    return Promise.resolve();
  }

  public onError(context: CommonContext): Promise<void> {
    return Promise.resolve();
  }

  private async roundPayout(session: SessionEntity, sessionData: SessionDynamicData, roundResult: RoundResult): Promise<void> {
    const {
      loginOptions: {
        sessionToken,
        extGameId,
      },
      transaction: {
        roundId,
        transactionId,
      },
    } = sessionData;

    await this.countWins(session, roundId, roundResult);

    const { balance } = await this.operatorClient.payout({
      accessToken: sessionToken,
      operator: session.operator,
      cid: session.player.cid,
      amount: roundResult.totalWinInCash,
      roundId,
      transactionId,
      gameId: session.gameId,
      extGameId,
      correlationId: UUIDv4(),
    });

    await this.roundRepo.update(roundId,
      {
        status: RoundStatus.COMPLETED,
        finalBalance: balance,
        endDate: new Date(),
      });
    await this.sessionDataManager.removeSessionData(['transaction'], session.id);
    this.playerPublisher.notifyRouletteWin(session.id, roundResult);
    this.playerPublisher.notifyBalance(session.id, { valueInCash: balance });
    await this.monitoringPublisher.sendEventLogMessage({
      eventType: EventType.PAYOUT,
      source: EventSource.GAME,
      params: {
        sum: roundResult.totalWinInValue,
        sumInCash: roundResult.totalWinInCash,
        winDetails: roundResult.winDetails,
        currency: session.currency,
        sessionId: session.id,
        round: Number(roundId),
        machineSerial: session.machine.serial,
        playerCid: session.player.cid,
        transactionId,
      },
    });
  }

  private async countWins(session: SessionEntity, roundId: string | number,
    {
      totalWinInValue,
      totalWinInCash,
    }: RoundResult): Promise<void> {
    await Promise.all([
      this.sessionRepo.countWin(session.id, totalWinInValue, totalWinInCash),
      this.roundRepo.countWin(roundId, totalWinInValue, totalWinInCash),
      this.playerRepo.countWin(session.player.cid, session.operator.id, totalWinInValue),
    ]);
  }

  private async onPayoutError(session: SessionEntity, sessionData: SessionDynamicData, err: Error): Promise<void> {
    const {
      transaction: {
        roundId,
      },
    } = sessionData;

    this.logger.error('Payout failed', {
      errorMessage: err.message,
      sessionId: session.id,
      roundId,
      stack: err.stack,
    });
    await this.roundRepo.update(roundId, {
      status: RoundStatus.TERMINATED,
      endDate: new Date(),
    });
    this.monitoringPublisher.sendEventLogMessage({
      eventType: EventType.ROUND_TERMINATED,
      source: EventSource.GAME,
      params: {
        sessionId: Number(session.id),
        round: Number(roundId),
        playerCid: session.player.cid,
        operatorId: session.operator.id,
        machineSerial: session.machine.serial,
      },
    });
    this.monitoringPublisher.sendAlertMessage({
      alertType: AlertType.ERROR,
      severity: AlertSeverity.HIGH,
      source: AlertSource.GAME_CORE,
      description: 'Payout failed',
      gameId: session.gameId,
      details: {
        sessionId: session.id,
        roundId,
        playerCid: session.player.cid,
        error: err.message,
      },
    });
    this.playerPublisher.notification(session.id,
      {
        notificationId: NotificationType.PAYOUT_FAILED,
        level: NotificationLevel.ERROR,
        title: 'Wallet error',
        message: 'Payout failed',
      });
  }

  public async playerQuit(
    context: CommonContext,
    event: RouletteEventCommand<{ sessionId: number }>,
  ): Promise<void> {
    this.logger.warn('Roulette event ignored', {
      serial: context.serial,
      sessionId: event.data.sessionId,
      event: event.eventType,
      handler: ProcessWinsPhaseHandler.name,
    });
  }
}
