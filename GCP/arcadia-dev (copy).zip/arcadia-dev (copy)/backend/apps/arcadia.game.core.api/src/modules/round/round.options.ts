export class RoundOptions {
  bet: number;
  rtp: boolean;
  deductRound: number;
  countToLimit: number;
}