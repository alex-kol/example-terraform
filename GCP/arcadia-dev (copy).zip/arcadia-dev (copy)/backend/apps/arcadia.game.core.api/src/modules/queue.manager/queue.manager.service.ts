/* eslint-disable max-lines */
import { EventSource } from '@lib/common';
import {
  EventType, QueueRepository, SessionEntity, SessionStatus,
} from '@lib/dal';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Injectable } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { PlayerClientService } from '../player.client/player.client.service';
import { getSessionHash } from '../session/session.hash';
import { QueueMessageDto } from './dto/queue.message.dto';

@Injectable()
export class QueueManagerService {
  constructor(
    private readonly queueRepo: QueueRepository,
    private readonly monitoringService: MonitoringWorkerClientService,
    private readonly playerPublisher: PlayerClientService,
  ) {
  }

  private getQueueUpdateMessage(sessions: SessionEntity[]): QueueMessageDto {
    const message: QueueMessageDto = {
      queue: [],
      viewers: 0,
      betBehindPlayers: 0,
    };
    if (!sessions?.length) {
      return message;
    }
    const viewerStatuses = new Set([SessionStatus.VIEWER, SessionStatus.VIEWER_BET_BEHIND]);
    const betBehindStatuses = new Set([SessionStatus.QUEUE_BET_BEHIND, SessionStatus.VIEWER_BET_BEHIND]);
    const queueStatuses = new Set([
      SessionStatus.QUEUE_BET_BEHIND,
      SessionStatus.QUEUE,
      SessionStatus.PLAYING,
      SessionStatus.AUTOPLAY,
      SessionStatus.FORCED_AUTOPLAY,
      SessionStatus.RE_BUY,
    ]);
    return sessions
      .sort((a, b) => (
        (a.buyDate ? a.buyDate.valueOf() : Date.now()) - (b.buyDate ? b.buyDate.valueOf() : Date.now())))
      .reduce((accum, session) => {
        if (viewerStatuses.has(session.status)) {
          accum.viewers += 1;
        }

        if (betBehindStatuses.has(session.status)) {
          accum.betBehindPlayers += 1;
        }

        if (queueStatuses.has(session.status)) {
          accum.queue.push({
            queueToken: getSessionHash(session),
            stacks: session.roundsLeft,
            status: session.status,
          });
        }
        return accum;
      }, message);
  }

  public async notifyQueueUpdate(queueId: number, eventLogSession?: SessionEntity): Promise<void> {
    const queue = await this.queueRepo.getQueueFromMaster(queueId);
    if (!queue) {
      throw new RpcException('Queue not found');
    }
    const {
      sessions,
      machine,
    } = queue;
    const message = this.getQueueUpdateMessage(sessions);
    if (eventLogSession) {
      const position = sessions.findIndex(s => s.id === eventLogSession.id);
      await this.monitoringService.sendEventLogMessage({
        eventType: EventType.QUEUE_POSITION,
        source: EventSource.GAME,
        params: {
          sessionId: eventLogSession.id,
          machineSerial: machine.serial,
          position,
        },
      });
    }
    this.playerPublisher.notifyQueueUpdate(queue.machine.serial, message);
  }
}
