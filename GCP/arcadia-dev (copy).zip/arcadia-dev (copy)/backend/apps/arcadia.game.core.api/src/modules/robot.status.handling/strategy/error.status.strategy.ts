import { MachineEntity, ShutdownReason } from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { Inject, Injectable } from '@nestjs/common';
import { Logger } from 'winston';
import { GroupTerminatorService } from '../../group.terminator/group.terminator.service';
import { StatusHandlerStrategy } from './status.handler.strategy';

@Injectable()
export class ErrorStatusStrategy extends StatusHandlerStrategy {
  constructor(
    @Inject(MAIN_LOGGER) logger: Logger,
    private readonly groupTerminator: GroupTerminatorService,
  ) {
    super(logger);
  }

  async onIdle(machine: MachineEntity): Promise<void> {
    await this.groupTerminator.groupHardStop(machine.gameId, machine.group.id, {
      reason: ShutdownReason.ROBOT_ERROR,
      machineIds: [machine.id],
    });
  }

  async onTesting(machine: MachineEntity): Promise<void> {
    await this.groupTerminator.groupHardStop(machine.gameId, machine.group.id, {
      reason: ShutdownReason.ROBOT_ERROR,
      machineIds: [machine.id],
    });
  }

  async onStopping(machine: MachineEntity): Promise<void> {
    await this.groupTerminator.groupHardStop(machine.gameId, machine.group.id, {
      reason: ShutdownReason.ROBOT_ERROR,
      machineIds: [machine.id],
    });
  }

  async onStopped(machine: MachineEntity): Promise<void> {
    await this.groupTerminator.groupHardStop(machine.gameId, machine.group.id, {
      reason: ShutdownReason.ROBOT_ERROR,
      machineIds: [machine.id],
    });
  }

  public toString(): string {
    return ErrorStatusStrategy.name;
  }
}