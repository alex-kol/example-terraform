import { ChipConfiguration } from '@lib/dal';
import { VerifyRes } from './verify.res';

export class ClawRouletteVerifyRes extends VerifyRes {
  chipConfig: ChipConfiguration[];
  limitsAndPayouts: Record<string, { min: number, max: number, winMultiplier?: number }>;
}
