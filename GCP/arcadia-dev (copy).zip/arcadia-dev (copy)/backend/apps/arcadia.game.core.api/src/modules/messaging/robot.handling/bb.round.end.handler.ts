/* eslint-disable max-lines */
import { CommandType, EventSource, TimeoutType } from '@lib/common';
import { ConfigService } from '@lib/config';
import {
  BetBehindConfiguration,
  ChipRepository,
  EventType,
  GameId,
  RoundRepository,
  RoundStatus,
  RoundType,
  SessionEndReason,
  SessionRepository,
  SessionStatus,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Inject, Injectable, Scope } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { DataSource } from 'typeorm';
import { v4 as uuidv4 } from 'uuid';
import { Logger } from 'winston';
import { CommandPublisher } from '../../command/command.publisher';
import { BaseCommand } from '../../command/dto/base.command';
import { OperatorApiClientService } from '../../operator.api.client/operator.api.client.service';
import { NotificationLevel } from '../../player.client/notification.level';
import { NotificationType } from '../../player.client/notification.type';
import { PlayerClientService } from '../../player.client/player.client.service';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { RoundServiceFactory } from '../../round/round.service.factory';
import { SessionDataManager } from '../../session.data.manager/session.data.manager';
import { WorkerClientService } from '../../worker.client/worker.client.service';
import { RoundEndHandler } from './round.end.handler';

@Injectable({ scope: Scope.REQUEST })
export class BbRoundEndHandler extends RoundEndHandler {
  private bbConfig: BetBehindConfiguration;

  constructor(
    config: ConfigService,
    @Inject(MAIN_LOGGER) logger: Logger,
    chipRepo: ChipRepository,
    sessionRepoInjected: SessionRepository,
    robotClient: RobotClientService,
    playerPublisher: PlayerClientService,
    workerClient: WorkerClientService,
    monitoringClient: MonitoringWorkerClientService,
    operatorClient: OperatorApiClientService,
    roundServiceFactory: RoundServiceFactory,
    commandPublisher: CommandPublisher,
    sessionDataManager: SessionDataManager,
    dataSource: DataSource,
  ) {
    super(
      config,
      logger,
      chipRepo,
      sessionRepoInjected,
      playerPublisher,
      monitoringClient,
      operatorClient,
      commandPublisher,
      sessionDataManager,
      robotClient,
      workerClient,
      roundServiceFactory,
      dataSource,
    );
    this.recalculateEventType = EventType.BB_ROUND_ENDED;
  }

  protected async init(data: BaseCommand): Promise<void> {
    const {
      sessionId,
      session,
    } = data;
    if (!sessionId || !session) {
      throw new RpcException('Session has not been injected!');
    }

    this.correlationId = data.correlationId || uuidv4();
    this.sessionId = Number(sessionId);
    this.cachedSession = session;
    this.cachedMachine = session.machine;
    this.cachedGroup = session.group;
    this.cachedOperator = session.operator;
    this.cachedPlayer = session.player;
    this.sessionConfig = session.configuration;

    // transactional repos
    this.sessionRepository = new SessionRepository(this.entityManager);
    this.roundRepo = new RoundRepository(this.entityManager);

    this.session = await this.sessionRepository.findOneOrFail({
      where: { id: this.cachedSession.id },
      relations: ['rounds'],
    });

    if (this.session.status !== SessionStatus.VIEWER_BET_BEHIND
      && this.session.status !== SessionStatus.QUEUE_BET_BEHIND) {
      throw new RpcException(`Session is not in BB status!
      SessionId=${this.session.id}, status=${this.session.status}, correlationId=${this.correlationId}`);
    }

    this.activeRound = this.session.rounds?.find(round => round.status === RoundStatus.ACTIVE
      && round.type === RoundType.BET_BEHIND);
    if (!this.activeRound) {
      throw new RpcException(`No active round to complete!, SessionId=${this.session.id}, correlationId=${this.correlationId}`);
    }

    this.bbConfig = (await this.sessionDataManager.getSessionData(this.session.id)).betBehind;
  }

  protected async handleEvent(): Promise<void> {
    if (this.activeRound.bet === 0) {
      await this.onScatterRoundEnd();
    }

    if (this.maxPayoutThresholdExceededCheck()) {
      return;
    }

    let finalBalance: number;

    try {
      finalBalance = (await this.roundPayout()).balance;
    } catch (err) {
      await this.onPayoutError(err);
      return;
    }
    await this.roundRepo.update(this.activeRound.id,
      {
        status: RoundStatus.COMPLETED,
        finalBalance,
        endDate: new Date(),
      });

    await this.sendRoundEndEvent();

    if (this.session.totalStacksUsed >= this.sessionConfig.stackBuyLimit
      && this.session.pendingScatter === 0) {
      await this.disableBetBehind('Round limit reached');
      this.onRoundLimitReached();
      return;
    }

    if (!this.bbConfig || this.session.isDisconnected) {
      await this.disableBetBehind('No bet behind config or disconnected');
      return;
    }

    this.bbConfig.stopAfterRounds -= 1;
    if (this.bbConfig.stopAfterRounds < 1) {
      await this.disableBetBehind('All rounds played');
    } else {
      await this.sessionDataManager
        .updateSessionData({ betBehind: this.bbConfig }, this.session.id);
    }
  }

  protected async onPayoutError(err: Error): Promise<void> {
    await this.roundRepo.update(this.activeRound.id,
      {
        status: RoundStatus.TERMINATED,
        endDate: new Date(),
      });
    await this.monitoringClient.sendEventLogMessage({
      eventType: EventType.BB_ROUND_TERMINATED,
      source: EventSource.GAME,
      params: {
        sessionId: this.session.id,
        operatorId: this.cachedOperator.id,
        groupId: this.cachedGroup.id,
        machineSerial: this.cachedMachine.serial,
        machineId: this.cachedMachine.id,
        playerCid: this.cachedPlayer.cid,
        round: this.activeRound.id,
      },
    });

    this.notifyErrors(err, this.activeRound.id);
    this.commandPublisher.finalizeSession({
      type: CommandType.FINALIZE_SESSION,
      gameId: GameId.COIN_PUSHER_V1,
      sessionId: this.session.id,
      terminate: true,
      reason: SessionEndReason.WALLET_TRANSACTION_ERROR,
    }, this.correlationId);
  }

  private async disableBetBehind(reason: string): Promise<void> {
    const status = this.session.status === SessionStatus.QUEUE_BET_BEHIND
      ? SessionStatus.QUEUE
      : SessionStatus.VIEWER;
    this.monitoringClient.sendEventLogMessage({
      eventType: EventType.BET_BEHIND_STOPPED,
      source: EventSource.GAME,
      params: {
        sessionId: this.session.id,
        machineSerial: this.cachedMachine.serial,
        playerCid: this.cachedPlayer.cid,
        reason,
      },
    });
    await this.sessionRepository.update(
      this.session.id,
      { status },
      () => this.playerClient.sessionState(this.session.id, { status }),
    );
    await this.sessionDataManager.removeSessionData(['betBehind'], this.session.id);
    if (status === SessionStatus.VIEWER && this.session.isDisconnected) {
      await this.workerClient.timeoutStart({
        timeoutType: TimeoutType.TERMINATE_SESSION,
        sessionId: this.sessionId,
        timeoutSec: this.config
          .get(['core', 'TERMINATE_SESSION_TIMEOUT_SEC']) as unknown as number,
        payload: { reason: SessionEndReason.VIEWER_DISCONNECTED, gameId: this.session.gameId },
      });
    }
  }

  private onRoundLimitReached() {
    this.logger.warn('Round limit reached', { sessionId: this.session.id });
    this.playerClient.notification(this.session.id,
      {
        notificationId: NotificationType.ROUND_LIMIT_REACHED,
        level: NotificationLevel.WARNING,
        title: 'Round limit reached!',
        message: 'You have reached the regulatory round limit, see you next time',
      });
    this.commandPublisher.finalizeSession({
      type: CommandType.FINALIZE_SESSION,
      gameId: GameId.COIN_PUSHER_V1,
      sessionId: this.session.id,
      terminate: false,
      showSessionResult: true,
      reason: SessionEndReason.ROUND_LIMIT_REACHED,
    }, this.correlationId);
  }
}
