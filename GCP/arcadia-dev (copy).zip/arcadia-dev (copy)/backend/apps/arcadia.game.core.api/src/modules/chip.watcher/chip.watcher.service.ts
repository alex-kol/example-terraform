import {
  AuditAction,
  ChangeRepository,
  ChipEntity,
  ChipRepository,
  ChipTypeRepository,
  connectionNames,
  GroupRepository,
  MachineEntity,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import {
  count, every, filter, from, lastValueFrom, mergeMap,
} from 'rxjs';
import {
  catchError, groupBy, map, reduce, toArray,
} from 'rxjs/operators';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { Inject, Injectable } from '@nestjs/common';
import { Logger } from 'winston';
import { ConfigService } from '@lib/config';
import { InjectRepository } from '@nestjs/typeorm';
import { RedisList } from '@lib/redis.cache/redis.list';
import moment from 'moment';
import { getObjectDiffs } from '@lib/common';
import { refurbishChipListKeyFactory } from './util/refurbish.chip.list.key.factory';
import { SeedValue } from '../rng.service.client/dto/seed.value';
import { RefurbishChip } from './types/refurbish.chip';
import { seededChipListKeyFactory } from './util/seeded.chip.list.key.factory';

@Injectable()
export class ChipWatcherService {
  private readonly refurbishTtlMin: number;

  constructor(
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly cacheManager: RedisCacheService,
    private readonly redisList: RedisList,
    @InjectRepository(ChangeRepository, connectionNames.AUDIT) private readonly changeRepository: ChangeRepository,
    private readonly groupRepository: GroupRepository,
    private readonly chipRepo: ChipRepository,
    private readonly chipTypeRepository: ChipTypeRepository,
    private readonly configService: ConfigService,
  ) {
    this.refurbishTtlMin = this.configService.get(['core', 'REFURBISH_TTL_MIN']);
  }

  public async clearRefurbishData(machineId: number): Promise<void> {
    const chipTypes = await this.chipTypeRepository.find({ where: { isDeleted: false } });
    chipTypes.forEach(chipType => this.cacheManager.del(refurbishChipListKeyFactory(machineId, chipType.id)));
  }

  public async prepareForRefurbishing(machine: MachineEntity) {
    const chips = await this.chipRepo.getTableState(machine.id);
    if (!chips.length) {
      return;
    }

    await lastValueFrom(from(chips)
      .pipe(
        groupBy(chip => chip.type.id),
        mergeMap(group => group.pipe(
          map<ChipEntity, RefurbishChip>(chip => ({
            value: chip.value,
            isScatter: chip.isScatter,
          })),
          toArray(),
          mergeMap(values => {
            this.logger.info('Chips added to refurbish list', {
              machineId: machine.id,
              chipCount: values.length,
              values,
              chipTypeId: group.key,
              machineSerial: machine.serial,
              groupId: machine.group.id,
            });
            return this.pushRefurbishChipToList(values, machine.id, group.key);
          }),
        )),
        catchError(e => this.logger.error(
          'prepareForRefurbishing error',
          {
            errorMessage: e.message,
            machineId: machine.id,
            machineSerial: machine.serial,
            groupId: machine.group.id,
          },
        )),
        count(),
      ));

    await this.chipRepo.update({ machine: { id: machine.id } },
      {
        machine: null,
        isScatter: false,
        value: 0,
      });
  }

  public async isRefurbish(resetTableState: boolean, machine: MachineEntity): Promise<boolean> {
    this.logger.debug('isRefurbish check machine',
      {
        resetTableState,
        stoppedDate: machine.stoppedDate,
        isRefurbish: machine.isRefurbish,
        machineId: machine.id,
        machineSerial: machine.serial,
        groupId: machine.group.id,
        groupIdForRefurbish: machine.groupIdForRefurbish,
        refurbishTtlMin: this.refurbishTtlMin,
      });
    if (
      !resetTableState
      || !machine.stoppedDate
      || machine.isRefurbish
      || machine.group.id !== machine.groupIdForRefurbish
      || moment(machine.stoppedDate)
        .isBefore(moment(Date.now())
          .subtract(this.refurbishTtlMin, 'minutes'))
    ) {
      return false;
    }

    const [changes, changesCount] = await this.changeRepository.getAllChanges({
      id: machine.group.id,
      startDate: moment()
        .subtract(this.refurbishTtlMin, 'minutes')
        .toISOString(),
      endDate: moment()
        .toISOString(),
      actionType: AuditAction.UPDATE,
      entity: this.groupRepository.metadata.tableName,
    });

    if (changesCount) {
      const groupNotChange = await lastValueFrom(from(changes)
        .pipe(
          map(e => {
            const objectDiff = getObjectDiffs(e.oldEntity, e.newEntity, this.groupRepository.metadata);
            // eslint-disable-next-line @typescript-eslint/no-unused-vars
            const {
              status = undefined,
              userAction = undefined,
              ...diff
            } = { ...objectDiff.aOld, ...objectDiff.bNew };
            this.logger.debug('isRefurbish check group changes',
              {
                changesCount,
                groupId: machine.group.id,
                machineId: machine.id,
                machineSerial: machine.serial,
                diff,
              });
            return diff;
          }),
          every(data => Object.keys(data).length === 0),
        ));
      return groupNotChange;
    }

    return true;
  }

  public async getRefurbishChipsToPush(
    machineId: number,
  ): Promise<SeedValue[]> {
    const chipTypes = await this.chipTypeRepository.find({ where: { isDeleted: false } });
    return lastValueFrom(from(chipTypes).pipe(
      groupBy(chipType => chipType.name),
      mergeMap(group => group.pipe(
        mergeMap(chipType => this.redisList.redisListLength(refurbishChipListKeyFactory(machineId, chipType.id))),
        reduce((acc, count) => {
          acc += count;
          return acc;
        }, 0),
        filter(v => v > 0),
        map(count => ({ name: group.key, value: count })),
      )),
      toArray(),
    ), { defaultValue: [] });
  }

  public pushRefurbishChipToList(refurbishChip: RefurbishChip | RefurbishChip[], machineId: number, chipId: number): Promise<number> {
    return this.redisList.redisListRPushJson(refurbishChipListKeyFactory(machineId, chipId), Array.isArray(refurbishChip) ? refurbishChip : [refurbishChip]);
  }

  public getChipFromRefurbishList(machineId: number, chipTypeId: number): Promise<RefurbishChip> {
    return this.redisList.redisListRPopJson<RefurbishChip>(refurbishChipListKeyFactory(machineId, chipTypeId));
  }

  public async pushToSeededChipList(machineId: number, chipName: string): Promise<number> {
    return this.redisList.redisListRPushJson(seededChipListKeyFactory(machineId), [chipName]);
  }

  public async clearSeededChipList(machineId: number): Promise<void> {
    await this.cacheManager.del(seededChipListKeyFactory(machineId));
  }

  public async getAllSeededChips(machineId: number): Promise<Record<string, number>> {
    const length = await this.redisList.redisListLength(seededChipListKeyFactory(machineId));
    if (!length) {
      return null;
    }
    const list = await this.redisList.redisListLRange<string>(seededChipListKeyFactory(machineId), 0, length);
    await this.clearSeededChipList(machineId);
    return lastValueFrom(from(list).pipe(
      groupBy(chipName => chipName),
      mergeMap(group => group.pipe(
        count(),
        map(count => ({ key: group.key, count })),
      )),
      reduce((acc, { key, count }) => {
        acc[key] = count;
        return acc;
      }, {}),
    ));
  }
}
