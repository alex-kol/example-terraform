import { RobotLoginRes } from './robot.login.res';

export class CoinPusherV1RobotLoginRes extends RobotLoginRes {
  emuChipMap?: Record<string, string[]>;
}