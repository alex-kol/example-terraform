/* eslint-disable max-lines */
import { CommandType, EventSource, TimeoutType } from '@lib/common';
import {
  EventType, GameId, MachineStatus, QueueEntity, QueueStatus, SessionStatus, VoucherRepository,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Inject, Injectable, Scope } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { OperatorApiClientService } from 'apps/arcadia.game.core.api/src/modules/operator.api.client/operator.api.client.service';
import { toCash } from 'apps/arcadia.game.core.api/src/util/toCash';
import BigNumber from 'bignumber.js';
import moment from 'moment';
import { DataSource } from 'typeorm';
import { Logger } from 'winston';
import { CommandPublisher } from '../../../command/command.publisher';
import { SessionContextHandler } from '../../../command/session.context.handler';
import { SessionDataManager } from '../../../session.data.manager/session.data.manager';
import { PlayerClientService } from '../../../player.client/player.client.service';
import { BuyMessageDto } from '../../../messaging/player.handling/dto/buy.message.dto';
import { EngageSessionCommand } from '../../../command/dto/engage.session.command';
import { WorkerClientService } from '../../../worker.client/worker.client.service';
import { QueueUpdatesCommand } from '../../../command/dto/queue.updates.command';
import { NotificationType } from '../../../player.client/notification.type';
import { getSessionHash } from '../../../session/session.hash';
import { NotificationLevel } from '../../../player.client/notification.level';

@Injectable({ scope: Scope.REQUEST })
export class BuyStacksClawHandler extends SessionContextHandler<BuyMessageDto> {
  // trans repos
  private voucherRepo: VoucherRepository;

  private stacks: number;
  private isUseVouchers: boolean;
  private engageCommand: EngageSessionCommand = null;
  private queue: QueueEntity;

  constructor(
    @Inject(MAIN_LOGGER) logger: Logger,
    private readonly sessionDataManager: SessionDataManager,
    private readonly playerPublisher: PlayerClientService,
    private readonly workerClient: WorkerClientService,
    private readonly commandPublisher: CommandPublisher,
    private readonly operatorClient: OperatorApiClientService,
    private readonly monitoringClient: MonitoringWorkerClientService,
    dataSource: DataSource,
  ) {
    super(logger, dataSource);
  }

  protected async init(data: BuyMessageDto): Promise<void> {
    await super.init(data);

    this.voucherRepo = new VoucherRepository(this.entityManager);

    this.stacks = 1;
    this.isUseVouchers = data.isUseVouchers;

    this.session = await this.sessionRepository.findOneOrFail({
      where: { id: this.sessionId },
      relations: ['machine', 'machine.queue'],
    });
    this.cachedMachine = this.session.machine;
    this.queue = this.session.machine?.queue;
    if (!this.cachedMachine || !this.queue) {
      throw new RpcException('Machine or queue not found');
    }
  }

  protected async handleEvent(): Promise<void> {
    this.sessionStateCheck();
    this.queueStateCheck();

    if (this.stacks < 1) {
      return;
    }

    const isVoucherBuy = await this.voucherCheck();
    const canBuyStacks = await this.getBuyAbility();

    if (!isVoucherBuy && canBuyStacks < this.stacks) {
      this.playerPublisher.notification(this.sessionId,
        {
          notificationId: NotificationType.INSUFFICIENT_FUNDS,
          level: NotificationLevel.ERROR,
          title: 'Insufficient funds',
          message: 'Oops, not enough money',
          data: { canBuy: canBuyStacks },
        });
      return;
    }

    await this.monitoringClient.sendEventLogMessage({
      eventType: EventType.STACK_RESERVATION,
      source: EventSource.GAME,
      params: {
        stacks: this.stacks,
        sessionId: this.sessionId,
        machineSerial: this.cachedMachine.serial,
      },
    });

    this.playerPublisher.notifyBuyResult(this.sessionId, getSessionHash(this.session), this.stacks);

    if (this.session.status === SessionStatus.VIEWER
      || this.session.status === SessionStatus.VIEWER_BET_BEHIND) {
      await this.sessionRepository.update(this.sessionId, {
        status: this.session.status === SessionStatus.VIEWER ? SessionStatus.QUEUE : SessionStatus.QUEUE_BET_BEHIND,
        viewerDuration: moment()
          .diff(this.session.createDate, 'seconds'),
        roundsLeft: this.stacks,
        buyDate: () => 'CURRENT_TIMESTAMP(6)',
      }, data => this.playerPublisher.sessionState(this.sessionId, { status: data.status }));
      if (this.cachedMachine.status === MachineStatus.READY) {
        this.engageCommand = {
          type: CommandType.ENGAGE_SESSION,
          gameId: GameId.CLAW,
          machineId: this.cachedMachine.id,
        };
      }
    } else if (this.session.status === SessionStatus.RE_BUY) {
      await this.workerClient.timeoutStop({
        timeoutType: TimeoutType.REBUY,
        sessionId: this.sessionId,
        payload: { gameId: this.session.gameId },
      }, this.correlationId);
      await this.sessionRepository.update(this.sessionId, { roundsLeft: this.stacks });
      await this.sessionDataManager.setRebuyExpirationSkip(this.sessionId);
      this.engageCommand = {
        type: CommandType.ENGAGE_SESSION,
        gameId: GameId.CLAW,
        machineId: this.cachedMachine.id,
        reBuySessionId: this.sessionId,
      };
    }
  }

  protected async onCommit(): Promise<void> {
    if (this.engageCommand) {
      this.commandPublisher.engageNextSession({
        ...this.engageCommand,
        sessionId: this.sessionId, // needed for session locks
      }, this.correlationId);
    }
    this.commandPublisher.sendCommand<QueueUpdatesCommand>({
      type: CommandType.QUEUE_UPDATES,
      gameId: GameId.CLAW,
      queueId: this.cachedSession.queue.id,
      session: this.cachedSession,
    }, this.correlationId);
  }

  private async voucherCheck(): Promise<boolean> {
    if (this.isUseVouchers) {
      const vouchers = await this.voucherRepo
        .getVouchersForSession(this.cachedOperator.id, this.cachedGroup.id, this.cachedPlayer.cid);
      if (!vouchers.length || !this.isUseVouchers) {
        throw new RpcException('Invalid or stale vouchers');
      }

      await this.voucherRepo.update(
        {
          player: { cid: this.cachedPlayer.cid },
          operator: { id: this.cachedOperator.id },
          group: { id: this.cachedOperator.id },
        },
        { session: this.session },
      );
      this.stacks = vouchers.length;
      return true;
    }
    return false;
  }

  private async getBuyAbility(): Promise<number> {
    const { loginOptions } = await this.sessionDataManager.getSessionData(this.sessionId);
    const {
      sessionToken,
      extGameId,
    } = loginOptions;
    const playerBalance = await this.operatorClient.balance({
      operator: this.cachedOperator,
      accessToken: sessionToken,
      cid: this.cachedPlayer.cid,
      correlationId: this.correlationId,
      gameId: this.session.gameId,
      extGameId,
    },
    );
    return new BigNumber(playerBalance.balance)
      .dividedToIntegerBy(toCash(this.cachedGroup.denominator, this.session.currencyConversionRate))
      .toNumber();
  }

  private sessionStateCheck(): void {
    if ((this.session.status !== SessionStatus.VIEWER
      && this.session.status !== SessionStatus.VIEWER_BET_BEHIND
      && this.session.status !== SessionStatus.RE_BUY) || this.session.roundsLeft > 0) {
      throw new RpcException(`Unexpected "buy": sessionId=${this.sessionId}, correlationId=${this.correlationId}`);
    }
  }

  private queueStateCheck(): void {
    if ((this.queue.status === QueueStatus.DRYING || this.queue.status === QueueStatus.STOPPED)
      && this.session.status !== SessionStatus.RE_BUY) {
      this.playerPublisher.notification(this.sessionId,
        {
          notificationId: NotificationType.BUY_BLOCKED,
          level: NotificationLevel.WARNING,
          title: 'Buy is blocked',
          message: 'Machine is scheduled to shutdown, buy is not allowed',
        });
      throw new RpcException('Buy on drying or stopped machine');
    }
  }
}
