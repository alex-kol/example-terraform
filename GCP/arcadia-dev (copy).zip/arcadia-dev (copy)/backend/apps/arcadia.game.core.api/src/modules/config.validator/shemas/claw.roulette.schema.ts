import { AssetType, Configuration, RouletteType } from '@lib/dal';
import Joi, { SchemaMap } from 'joi';
import { BetType } from '../../roulette.engine/enums';
import { commonSchema } from './common.schema';

export const clawRouletteSchema = Joi.object<Configuration>({
  ...commonSchema,
  chipConfig: Joi.array()
    .min(1)
    .unique((a, b) => a.value === b.value)
    .items(Joi.object({
      value: Joi.number()
        .integer()
        .min(1)
        .required(),
      bigAsset: Joi.string()
        .valid(...Object.values(AssetType))
        .required(),
      smallAsset: Joi.string()
        .valid(...Object.values(AssetType))
        .required(),
    }))
    .required(),
  betLimits: Joi.object({
    tableMin: Joi.number()
      .integer()
      .positive()
      .required(),
    tableMax: Joi.number()
      .integer()
      .positive()
      .required(),
    maxByType: Joi.object<Record<BetType, number>>(Object.values(BetType)
      .reduce((acc: SchemaMap, type) => {
        acc[type] = Joi.number()
          .integer()
          .positive()
          .required();
        return acc;
      }, {}))
      .required(),
  }),
  rouletteType: Joi.string()
    .valid(...Object.values(RouletteType))
    .required(),
});
