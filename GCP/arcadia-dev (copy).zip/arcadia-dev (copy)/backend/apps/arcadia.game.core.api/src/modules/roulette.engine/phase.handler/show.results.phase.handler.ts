import { TimeoutType } from '@lib/common';
import { ConfigService } from '@lib/config';
import {
  GameId, MachineRepository, QueueRepository, SessionEndReason, SessionRepository,
} from '@lib/dal';
import { Injectable } from '@nestjs/common';
import moment from 'moment';
import { count, firstValueFrom } from 'rxjs';
import { tap } from 'rxjs/operators';
import { CommandPublisher } from '../../command/command.publisher';
import { PlayerClientService } from '../../player.client/player.client.service';
import { RobotClientService } from '../../robot.client/robot.client.service';
import { WorkerClientService } from '../../worker.client/worker.client.service';
import { BetManager } from '../bet.manager';
import { GamePhase, PhaseStatus } from '../enums';
import { CommonContext, PhaseResult } from '../types';
import { PhaseHandler } from './phase.handler';

@Injectable()
export class ShowResultsPhaseHandler extends PhaseHandler {
  private readonly rouletteShowResultDurationSec: number;

  constructor(
    commandPublisher: CommandPublisher,
    betManager: BetManager,
    private readonly workerClient: WorkerClientService,
    private readonly playerPublisher: PlayerClientService,
    robotPublisher: RobotClientService,
    sessionRepository: SessionRepository,
    machineRepository: MachineRepository,
    queueRepository: QueueRepository,
    private readonly configService: ConfigService,
  ) {
    super(
      commandPublisher,
      betManager,
      sessionRepository,
      machineRepository,
      robotPublisher,
      queueRepository,
    );
    this.rouletteShowResultDurationSec = this.configService.get(['core', 'ROULETTE_SHOW_RESULTS_DURATION_SEC']);
  }

  public async onStart({ serial }: CommonContext): Promise<PhaseResult> {
    await this.robotPublisher.sendRouletteDisplayMessage(serial, { phase: GamePhase.SHOW_RESULTS });

    const endTimestamp = moment()
      .add(this.rouletteShowResultDurationSec, 'second')
      .toISOString();
    const message = {
      phase: GamePhase.SHOW_RESULTS,
      endTimestamp,
    };
    await firstValueFrom(this.betManager.getMachineBets(serial)
      .pipe(
        tap(({ sessionId }) => this.playerPublisher.gamePhase(sessionId, message)),
        count(),
      ));

    await this.workerClient.timeoutStart({
      timeoutType: TimeoutType.PHASE_END,
      machineSerial: serial,
      payload: { phase: GamePhase.SHOW_RESULTS, gameId: GameId.CLAW_ROULETTE },
      timeoutSec: this.rouletteShowResultDurationSec,
    });
    return {
      status: PhaseStatus.IN_PROGRESS,
      endTimestamp,
    };
  }

  public async onComplete({ serial }: CommonContext): Promise<void> {
    await this.betManager.dropBets(serial);
  }

  public onError(context: CommonContext): Promise<void> {
    return Promise.resolve();
  }

  protected onHardStop(context: CommonContext, ids: number[]): void {
    this.finalizeSession(context.serial, ids, SessionEndReason.MACHINE_STOP);
  }
}
