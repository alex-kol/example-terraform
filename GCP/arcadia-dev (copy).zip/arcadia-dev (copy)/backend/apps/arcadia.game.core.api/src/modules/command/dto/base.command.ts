import { CommandType } from '@lib/common';
import { GameId } from '@lib/dal';
import { IsEnum } from 'class-validator';
import { SessionAwareDto } from '../../dto/session.aware.dto';

export class BaseCommand extends SessionAwareDto {
  @IsEnum(CommandType)
  public type: CommandType;

  @IsEnum(GameId)
  public gameId: GameId;
}
