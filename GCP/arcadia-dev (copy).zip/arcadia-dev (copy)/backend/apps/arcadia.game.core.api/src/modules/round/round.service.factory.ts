import { EntityManager, GameId } from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { Inject, Injectable } from '@nestjs/common';
import { Logger } from 'winston';
import { CommandPublisher } from '../command/command.publisher';
import { OperatorApiClientService } from '../operator.api.client/operator.api.client.service';
import { PlayerClientService } from '../player.client/player.client.service';
import { RngHelper } from '../rng.service.client/rng.helper';
import { SessionDataManager } from '../session.data.manager/session.data.manager';
import { RouletteRoundStarter } from './roulette.round.starter';
import { RoundContext } from './round.context';
import { CoinPusherRoundStarter } from './coin.pusher.round.starter';
import { ClawRoundStarter } from './claw.round.starter';
import { RobotClientService } from '../robot.client/robot.client.service';
import { RngClientService } from '../rng.service.client/rng.client.service';
import { WorkerClientService } from '../worker.client/worker.client.service';

@Injectable()
export class RoundServiceFactory {
  constructor(
    private readonly entityManager: EntityManager,
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly rngHelper: RngHelper,
    private readonly operatorClient: OperatorApiClientService,
    private readonly playerPublisher: PlayerClientService,
    private readonly commandPublisher: CommandPublisher,
    private readonly monitoringService: MonitoringWorkerClientService,
    private readonly sessionDataManager: SessionDataManager,
    private readonly robotClientService: RobotClientService,
    private readonly rngClientService: RngClientService,
    private readonly workerClientService: WorkerClientService,
  ) {
  }

  public getStarter(gameId: GameId, context: RoundContext, manager?: EntityManager) {
    switch (gameId) {
      case GameId.COIN_PUSHER_V1:
        return this.getCoinPusherStarter(context, manager);
      case GameId.CLAW_ROULETTE:
        return this.getRouletteStarter(context, manager);
      case GameId.CLAW:
        return this.getClawRoundStarter(context, manager);
      default:
        throw new Error('Starter not found');
    }
  }

  private getCoinPusherStarter(context: RoundContext, manager?: EntityManager): CoinPusherRoundStarter {
    return new CoinPusherRoundStarter(
      this.logger,
      this.commandPublisher,
      this.rngHelper,
      this.operatorClient,
      this.playerPublisher,
      this.monitoringService,
      this.sessionDataManager,
      context,
      manager || this.entityManager,
    );
  }

  private getRouletteStarter(context: RoundContext, manager?: EntityManager): RouletteRoundStarter {
    return new RouletteRoundStarter(
      this.logger,
      this.operatorClient,
      this.playerPublisher,
      this.monitoringService,
      this.sessionDataManager,
      context,
      manager || this.entityManager,
    );
  }

  private getClawRoundStarter(context: RoundContext, manager?: EntityManager): ClawRoundStarter {
    return new ClawRoundStarter(
      this.logger,
      this.operatorClient,
      this.playerPublisher,
      this.monitoringService,
      this.sessionDataManager,
      this.robotClientService,
      this.rngClientService,
      this.workerClientService,
      context,
      manager || this.entityManager,
    );
  }
}
