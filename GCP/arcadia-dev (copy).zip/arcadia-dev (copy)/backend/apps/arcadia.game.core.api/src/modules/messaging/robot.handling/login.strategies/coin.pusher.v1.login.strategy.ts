/* eslint-disable max-lines */
import { AlertDescription, RmqQueueName } from '@lib/common';
import { ConfigService } from '@lib/config';
import {
  AlertSeverity,
  AlertSource,
  AlertType,
  ChipRepository,
  ChipStatus,
  ChipTypeRepository,
  MachineEntity,
  MachineRepository,
  MachineStatus,
  QueueRepository,
  QueueStatus,
} from '@lib/dal';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import { ServerRMQ } from '@lib/rmq.server';
import { Injectable, NotAcceptableException, NotFoundException } from '@nestjs/common';
import {
  count, firstValueFrom, from, of, throwError,
} from 'rxjs';
import {
  bufferCount, concatMap, map, mergeMap, repeat,
} from 'rxjs/operators';
import { v4 as UUIDv4 } from 'uuid';
import { getRobotQueueName } from '../../../../util';
import { RobotLoginDto } from '../dto/robot.login.dto';
import { CoinPusherV1RobotLoginRes } from '../responses/coin.pusher.v1.robot.login.res';
import { RobotLoginInterface } from './robot.login.interface';

@Injectable()
export class CoinPusherV1LoginStrategy extends RobotLoginInterface {
  readonly monitoringApiUrl: string;

  constructor(
    private readonly machineRepo: MachineRepository,
    private readonly chipRepo: ChipRepository,
    private readonly chipTypeRepo: ChipTypeRepository,
    private readonly queueRepo: QueueRepository,
    public readonly cacheManager: RedisCacheService,
    private readonly serverRMQ: ServerRMQ,
    private readonly configService: ConfigService,
    private readonly monitoringClient: MonitoringWorkerClientService,
  ) {
    super();
    this.monitoringApiUrl = configService.get(['core', 'ROBOT_FILES_API_URL']);
  }

  public async loginRobot(machine: MachineEntity, {
    version,
    demoMode = false,
  }: RobotLoginDto): Promise<CoinPusherV1RobotLoginRes> {
    if (machine.cameras.length !== 1) {
      this.monitoringClient.sendAlertMessage({
        alertType: AlertType.ALERT,
        severity: AlertSeverity.MEDIUM,
        source: AlertSource.GAME_CORE,
        description: AlertDescription.CAMERA_IS_NOT_ASSIGN_TO_MACHINE_ON_MACHINE_LOGIN,
        gameId: machine.gameId,
        details: {
          machineId: machine.id,
          machineName: machine.name,
          machineSerial: machine.serial,
        },
      });
      throw new NotAcceptableException('Camera is not assigned');
    }

    if (!machine.queue) {
      const queue = await this.queueRepo.getFreeQueue();
      await this.queueRepo.update(queue.id, { machine });
    } else if (machine.queue.status !== QueueStatus.STOPPED) {
      await this.queueRepo.update(machine.queue.id, { status: QueueStatus.STOPPED });
    }

    await this.machineRepo.update(machine.id, {
      status: MachineStatus.OFFLINE,
      lastLoginDate: () => 'NOW()',
      pingDate: () => 'NOW()',
      version,
    });

    const queues = {
      publisher: RmqQueueName.ROBOT_TO_CORE_QUEUE,
      subscriber: getRobotQueueName(machine.serial),
    };
    await this.serverRMQ.purgeQueue(queues.subscriber);

    const response: CoinPusherV1RobotLoginRes = {
      queues,
      robotKey: machine.id,
      mgrMessageServer: this.configService.getRabbitMQConfig(!demoMode),
      playerMessageServer: {
        redis: this.configService.getRedisConfig(!demoMode),
        key: 'socket.io',
      },
      gameId: machine.gameId,
      fileApiUrl: this.monitoringApiUrl,
    };

    if (demoMode) {
      response.emuChipMap = await this.registerChips(machine);
    }

    return response;
  }

  private async registerChips({
    serial,
    configuration,
    site,
  }: MachineEntity): Promise<Record<string, string[]>> {
    if (!configuration?.dispensers) {
      throw new NotFoundException('Machine no configuration');
    }

    const chipTypes = (await this.chipTypeRepo.find({
      select: ['id', 'name'],
      where: { isDeleted: false },
    })).reduce((acc, type) => {
      acc.set(type.name, type.id);
      return acc;
    }, new Map<string, number>());

    const registered = await this.chipRepo.getEmuRegisteredChips(serial);

    await firstValueFrom(from(Object.entries(configuration.dispensers))
      .pipe(
        mergeMap(([dispenserName, {
          chipType,
          capacity,
        }]) => {
          const chipTypeId = chipTypes.get(chipType);
          if (!chipTypeId) {
            return throwError(() => new NotFoundException('Chip type not found'));
          }

          if (!registered[dispenserName]) {
            registered[dispenserName] = [];
          }

          let toRegister = capacity - registered[dispenserName].length;
          if (toRegister < 0) {
            toRegister = 0;
          }

          return of(`${serial}:${dispenserName}:${chipType}`)
            .pipe(
              repeat(toRegister),
              map(rfidPartial => {
                const rfid = `${rfidPartial}:${UUIDv4()}`;
                registered[dispenserName].push(rfid);
                return this.chipRepo.create({
                  rfid,
                  type: { id: chipTypeId },
                  site,
                  status: ChipStatus.ACTIVE,
                });
              }),
            );
        }),
        bufferCount(50),
        concatMap(async batch => {
          await this.chipRepo.insert(batch);
          return 1;
        }),
        count(),
      ));
    return registered;
  }
}
