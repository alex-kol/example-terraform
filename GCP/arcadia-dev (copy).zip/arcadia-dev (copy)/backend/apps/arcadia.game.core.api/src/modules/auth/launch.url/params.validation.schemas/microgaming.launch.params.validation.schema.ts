import { MicrogamingClients, MicrogamingEnv } from '@lib/common';
import { GameId } from '@lib/dal';
import Joi from 'joi';
import { urlPattern } from '../../../../util';
import { MicrogamingLaunchParams } from '../types';

export const microgamingLaunchParamsValidationSchema = Joi.object<MicrogamingLaunchParams>({
  siteid: Joi.string()
    .valid(...Object.values(MicrogamingEnv))
    .required(),
  operator: Joi.string()
    .required(),
  callerIp: Joi.string()
    .ip()
    .required(),
  sessiontoken: Joi.string()
    .required(),
  gameid: Joi.string()
    .valid(...Object.values(GameId))
    .required(),
  clientid: Joi.string()
    .valid(...Object.values(MicrogamingClients))
    .required(),
  playmode: Joi.string()
    .valid('real', 'demo')
    .required(),
  lang: Joi.string()
    .default('en'),
  lobbyurl: Joi.string()
    .pattern(urlPattern)
    .allow(null)
    .empty(null)
    .empty(''),
  casinoid: Joi.string(),
  serverid: Joi.string(),
  bingoroom: Joi.string(),
  chatroom: Joi.string(),
  skin: Joi.string(),
});
