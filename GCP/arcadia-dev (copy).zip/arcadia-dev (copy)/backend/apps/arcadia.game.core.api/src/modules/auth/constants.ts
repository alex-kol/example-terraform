export const GROUP_NOT_ASSIGNED = 'Group is not assigned to this operator!';
export const GROUP_WITHOUT_MACHINE = 'Group does not have available machines!';
