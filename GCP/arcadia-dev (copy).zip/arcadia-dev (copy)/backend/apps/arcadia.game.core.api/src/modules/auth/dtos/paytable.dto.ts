export class PayTableDto {
  type: string;
  currencyValue: number;
}
