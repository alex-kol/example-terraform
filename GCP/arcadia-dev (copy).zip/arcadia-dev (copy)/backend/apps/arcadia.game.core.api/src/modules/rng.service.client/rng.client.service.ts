import { genericRetryStrategy } from '@lib/common';
import {
  AlertSeverity, AlertSource, AlertType, ChipEntity, GameId,
} from '@lib/dal';
import { MAIN_LOGGER } from '@lib/logger';
import { MonitoringWorkerClientService } from '@lib/monitoring.worker.client';
import { HttpService } from '@nestjs/axios';
import { Inject, Injectable } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import {
  count, firstValueFrom, from, of, throwError,
} from 'rxjs';
import {
  catchError, groupBy, map, mergeMap, reduce, tap, toArray,
} from 'rxjs/operators';
import { Logger } from 'winston';
import { RNG_RETRY_ATTEMPTS } from './constants';
import { PhantomPrizeDto } from './dto/phantom.prize.dto';
import { RngResponseDto } from './dto/rng.response.dto';
import { SeedValue } from './dto/seed.value';

@Injectable()
export class RngClientService {
  constructor(private readonly rngClient: HttpService,
    @Inject(MAIN_LOGGER) private readonly logger: Logger,
    private readonly monitoringClientService: MonitoringWorkerClientService) {
  }

  public async seed(
    prizeGroup: string, minimalValue: number, minimalCount: number, rtpSegment: string,
    chipsOnTable: ChipEntity[] = [],
  ): Promise<SeedValue[]> {
    const tableState = chipsOnTable.map(chip => ({
      type: chip.type.name,
      value: chip.value,
    }));
    const params = {
      group: prizeGroup,
      minimal_value: minimalValue,
      minimal_count: minimalCount,
      rtpSegment,
      chips_on_table: JSON.stringify(tableState),
    };
    return firstValueFrom(this.rngClient.get<RngResponseDto>('/seed', { params })
      .pipe(
        mergeMap(({ data }) => {
          if (!data.status || data.status === 'err' || !data.seed) {
            this.logger.error(data.msg || 'RNG seed request failed');
            return throwError(() => new RpcException(data.msg || 'RNG seed request failed'));
          }
          return from(data.seed).pipe(
            groupBy(({ name }) => name),
            mergeMap(group => group.pipe(
              count(),
              map(count => ({ name: group.key, value: count })),
            )),
          );
        }),
        toArray(),
        tap(result => this.logger
          .debug(`RNG "seed" result: ${JSON.stringify(result)}, params: ${JSON.stringify(params)}`)),
        genericRetryStrategy(RNG_RETRY_ATTEMPTS),
      ));
  }

  public async rtp(
    prizeGroup: string, rtpSegment: string, seedHistory?: Record<string, number>,
  ): Promise<Record<string, number>> {
    const params = {
      group: prizeGroup,
      rtpSegment,
      seed: JSON.stringify(seedHistory ? [seedHistory] : []),
    };
    return firstValueFrom(this.rngClient.get<RngResponseDto>('/rtp', { params })
      .pipe(
        mergeMap(({ data }) => {
          if (!data.status || data.status === 'err' || !data.rtp) {
            this.logger.error(data.msg || 'RNG rtp call error');
            return throwError(() => new RpcException(data.msg || 'RNG rtp call error'));
          }
          return from(data.rtp)
            .pipe(
              reduce((acc: Record<string, number>, rtp) => {
                if (acc[rtp.name]) {
                  acc[rtp.name] += 1;
                } else {
                  acc[rtp.name] = 1;
                }
                return acc;
              }, {}));
        }),
        tap(result => this.logger
          .debug(`RNG "rtp" result: ${JSON.stringify(result)}, params: ${JSON.stringify(params)}`)),
        genericRetryStrategy(RNG_RETRY_ATTEMPTS),
        catchError(err => {
          this.logger.error(`RNG rtp call error: ${err.message}, stack: ${err.stack}, fall back to empty response`);
          this.monitoringClientService.sendAlertMessage({
            alertType: AlertType.ERROR,
            severity: AlertSeverity.CRITICAL,
            source: AlertSource.GAME_CORE,
            description: 'Rtp error',
            gameId: GameId.COIN_PUSHER_V1,
            details: {
              prizeGroup,
              rtpSegment,
              error: err.response?.data || err.message,
            },
          });
          // it is acceptable to proceed gameplay without rtp seeding
          return of<Record<string, number>>({});
        }),
      ));
  }

  public async phantom(prizeGroup: string, rtpSegment: string): Promise<PhantomPrizeDto> {
    const params = {
      group: prizeGroup,
      rtpSegment,
    };
    return firstValueFrom(this.rngClient.get<RngResponseDto>('/phantom', { params })
      .pipe(
        mergeMap(({ data }) => {
          if (!data.status || data.status === 'err' || !data.prize) {
            this.logger.error(data.msg || 'RNG phantom call error');
            return throwError(() => new RpcException(data.msg || 'RNG phantom call error'));
          }
          this.logger.debug('RNG "phantom"', {
            result: data.prize,
            params,
          });
          return of(data.prize);
        }),
        genericRetryStrategy(RNG_RETRY_ATTEMPTS),
      ));
  }

  public async clawRound(prizeGroup: string, rtpSegment: string): Promise<Record<string, boolean>> {
    const params = {
      group: prizeGroup,
      rtpSegment,
    };
    return firstValueFrom(this.rngClient.get<Record<string, boolean>>('/claw101round', { params })
      .pipe(
        map(({ data }) => data),
        genericRetryStrategy(RNG_RETRY_ATTEMPTS),
      ));
  }

  public async clawPhantom(prizeGroup: string, rtpSegment: string, ballType: string): Promise<number> {
    const params = {
      group: prizeGroup,
      rtpSegment,
      ballType,
    };
    return firstValueFrom(this.rngClient.get<Record<string, any>>('/claw101phantom', { params })
      .pipe(
        map(({ data }) => data.prize.value),
        genericRetryStrategy(RNG_RETRY_ATTEMPTS),
      ));
  }
}
