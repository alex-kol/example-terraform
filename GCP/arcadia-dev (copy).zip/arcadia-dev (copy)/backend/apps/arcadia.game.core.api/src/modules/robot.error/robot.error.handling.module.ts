import { MachineRepository } from '@lib/dal';
import { MonitoringWorkerClientModule } from '@lib/monitoring.worker.client';
import { Module } from '@nestjs/common';
import { GroupTerminatorModule } from '../group.terminator/group.terminator.module';
import { WorkerClientModule } from '../worker.client/worker.client.module';
import { RobotErrorController } from './robot.error.controller';
import { RobotErrorHandler } from './robot.error.handler';

@Module({
  imports: [
    GroupTerminatorModule,
    MonitoringWorkerClientModule,
    WorkerClientModule,
  ],
  providers: [
    MachineRepository,
    RobotErrorHandler,
  ],
  controllers: [RobotErrorController],
})
export class RobotErrorHandlingModule {
}
