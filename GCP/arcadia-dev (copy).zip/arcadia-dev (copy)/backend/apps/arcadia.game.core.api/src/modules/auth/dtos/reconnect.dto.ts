import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsEnum, IsInt, Length } from 'class-validator';
import { GameId, intTransformer } from '@lib/dal';

export class ReconnectDto {
  @ApiProperty()
  @Transform(intTransformer)
  @IsInt()
  public sessionId: number;

  @ApiProperty()
  @Length(10, 50)
  public footprint: string;

  @ApiProperty()
  @IsEnum(GameId)
  public gameId: GameId;
}
