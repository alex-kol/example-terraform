import { jwtSigner } from '@lib/common/utils/jwt.promisified';
import { ConfigService } from '@lib/config';
import {
  SessionEntity,
} from '@lib/dal';
import { RedisCacheService } from '@lib/redis.cache/redis.service';
import {
  Injectable,
} from '@nestjs/common';
import { AuthTokenPayload } from './auth.token.payload';
import { LoginOptions } from './interfaces';
import { AuthResponseDto } from './responses';

@Injectable()
export class PlayerRetentionService {
  private readonly sessionAuthSecret: string;
  private readonly clientIoHaproxyUrl: string;

  constructor(
    configService: ConfigService,
    private readonly cacheManager: RedisCacheService,
  ) {
    this.sessionAuthSecret = configService.get(['core', 'SESSION_AUTH_SECRET']);
    this.clientIoHaproxyUrl = configService.get(['core', 'CLIENT_IO_HAPROXY_URL']);
  }
  public async getPlayerRetentionData(session: SessionEntity, loginOptions: LoginOptions): Promise<AuthResponseDto> {
    const {
      player,
      operator,
      gameId,
    } = session;

    const tokenData: AuthTokenPayload = { operatorId: operator.id, cid: player.cid, gameId };
    const token = await jwtSigner(tokenData, this.sessionAuthSecret, { expiresIn: '5m' });

    await this.cashingSessionOptions(session, loginOptions, token);

    return {
      url: this.clientIoHaproxyUrl,
      token,
      currency: session.currency,
      playerId: player.cid,
      settings: player.settings[gameId],
      homeUrl: loginOptions.homeUrl,
      cashierUrl: loginOptions.cashierUrl,
      gameId,
    };
  }

  private async cashingSessionOptions(
    data: SessionEntity,
    loginOptions: LoginOptions,
    token: string,
  ): Promise<void> {
    const sessionOptions: Partial<SessionEntity> & { loginOptions: LoginOptions } = {
      gameId: data.gameId,
      playerIP: data.playerIP,
      currency: data.currency,
      os: data.os,
      deviceType: data.deviceType,
      browser: data.browser,
      locale: data.locale,
      loginOptions,
    };

    await this.cacheManager.set<Partial<SessionEntity>>(token, sessionOptions, { ttl: 310 });
  }
}
