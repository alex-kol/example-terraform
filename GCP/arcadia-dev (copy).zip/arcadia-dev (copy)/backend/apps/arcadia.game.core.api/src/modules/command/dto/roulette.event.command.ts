import { Allow, IsEnum } from 'class-validator';
import { RouletteEventType } from '../../roulette.engine/enums';
import { RouletteCommand } from './roulette.command';

export class RouletteEventCommand<T extends Record<string, any> = any> extends RouletteCommand {
  @IsEnum(RouletteEventType)
  public eventType: RouletteEventType;

  @Allow()
  public data?: T;
}
