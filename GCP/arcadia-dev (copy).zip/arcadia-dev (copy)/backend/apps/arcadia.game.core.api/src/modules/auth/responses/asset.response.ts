import {
  AllowedLanguage, AssetType, GameId, Regulation,
} from '@lib/dal';
import { ApiProperty } from '@nestjs/swagger';

export class AssetResponse {
  @ApiProperty({ enum: AssetType })
  public assetType: AssetType;

  @ApiProperty()
  public operatorId: number;

  @ApiProperty()
  public groupId: number;

  @ApiProperty({ enum: AllowedLanguage })
  public language: AllowedLanguage;

  @ApiProperty({ enum: Regulation })
  public regulation: Regulation;

  @ApiProperty()
  public fileUrl: string;

  @ApiProperty()
  public contentType: string;

  @ApiProperty({ enum: GameId })
  public gameId: GameId;
}
