import { Length } from 'class-validator';
import { RobotMessage } from '../../messaging/robot.handling/dto';

export class RouletteResultDto extends RobotMessage {
  @Length(1, 128)
  public rfid: string;
}
