import BigNumber from 'bignumber.js';

export const toCash = (value: BigNumber.Value, conversionRate: BigNumber.Value): number => new BigNumber(value).multipliedBy(conversionRate).dp(2).toNumber();
