import { RmqQueueName } from '@lib/common';

export const getRobotQueueName = (serial: string): string => `${RmqQueueName.TO_ROBOT_QUEUE_PATTERN}${serial}`;
