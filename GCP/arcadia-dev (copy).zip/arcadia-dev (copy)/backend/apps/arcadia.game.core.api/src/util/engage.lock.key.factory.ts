export const engageLockKeyFactory: (machineId: number) => string = machineId => `engage-lock-key-${machineId}`;
