export const reassignRtpKeyFactory = (machineId: number, toGroupId: number): string => `reassign-rtp-key-${machineId}-${toGroupId}`;
