export const urlPattern: RegExp = /^https:\/\/.+/;
