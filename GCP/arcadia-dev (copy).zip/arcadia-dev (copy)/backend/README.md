###### Development Environment
Please refer to this [document](deployment/dev/readme.md)

###### Arcadia Disaster Recovery Plan
Please refer to this [document](deployment/README.md)

###### Permitted modules for users
In order to store permitted modules for users many-to-many relation in used.
Cross table: 'user_permitted_modules_bo_module'
