const http = require('http');
const WebSocket = require('ws');
const url = require('url');
const uid2 = require('uid2');

const server = http.createServer();
const wSocket = new WebSocket.Server({ noServer: true });

let _common = null;
let _log = null;
let _ws = null;
let demoMode = true;
let demoNextWin = -1;
let demoBallCount = 37;

let driverClosing = false;

function runServer(success) {
    server.on('upgrade', function upgrade(request, socket, head) {
        const pathname = url.parse(request.url).pathname;

        if (pathname === '/driver') {
            wSocket.handleUpgrade(request, socket, head, (ws) => { wSocket.emit('connection', ws, request); });
        } else {
            socket.destroy();
        }
    });

    wSocket.on('connection', (ws, request) => {
        _ws = ws;
        ws.on('message', message => {
            // _log.debug('driverConn', 'from driver', message);
            let msg = JSON.parse(message);
            driverHandler(msg);
        });
        ws.on('close', (conn) => {
            if (driverClosing) return;
            _ws = null;
            _log.error('driverConn', '', 'connection closed');
        });
        success(); // Allows robot.js to make server communication
    });
}

function init(common) {
    _common = common;
    _log = _common.logger;
    demoMode = _common.demoMode;
    return new Promise((resolve, reject) => {
        if (demoMode) {
            _log.debug('driverConn', 'Init', 'Working in DEMO MODE');
            setTimeout(resolve, 2000);
        }
        else {
            runServer(resolve);
            server.listen(8080);
            _log.debug('driverConn', 'Init', "Listening");
        }
    });
}

function toDriver(message) {
    if (!_ws) {
        _log.error('driverConn', '', `driver not connected ${JSON.stringify(message)}`);
        _common.manager.addFault('driver', 'no connection to driver', {});
        return;
    }
    _log.debug('driverConn', 'to driver', message);
    _ws.send(JSON.stringify(message));
}

function draw(rotateTime, maxAttempts) {
    if (demoMode) {
        demoRound();
        return;
    }
    toDriver({ action: 'randomBall', rotateTime, maxAttempts });
}

function abort() {
  if (demoMode) {
    return;
  }
  toDriver({action:'abort'});
}

function grab() {
    toDriver({ action: "grab" });
}

function ball(x, y) {
    toDriver({ action: "ball", x: x, y: y });
}

function randomBall() {
    toDriver({ action: "randomBall" });
}

function randomXY() {
    toDriver({ action: "randomXY" });
}

function drop() {
    toDriver({ action: "drop" });
}

function photo() {
    toDriver({ action: "photo" });
}

function demoRound() {
  driverHandler({action:'navigation'});
  setTimeout( _ => driverHandler({action:'clawDrop'}), 2000);
  setTimeout( _ => driverHandler({action:'pickup'}), 4000);
  setTimeout(demoResult, 6000);
  setTimeout( _ => driverHandler({action:'ready'}), 10000);
}

function demoResult() {
    demoNextWin += 1;
    if (demoNextWin >= demoBallCount) {
        demoNextWin = 0;
    }

    driverHandler({
        action: 'ballRead',
        rfid: `${_common.serial}:${demoNextWin === 37 ? '00' : demoNextWin}`
    });
}

function stop() {
    if (demoMode) {
        setTimeout(_ => driverHandler({ action: 'stopped' }), 2000);
        return;
    }
    toDriver({ action: "stop" });
}

function reboot() {
    driverClosing = true;
    toDriver({ action: "reboot" });
}

function exit() {
    driverClosing = true;
    toDriver({ action: "exit" });
}

function startRegister() {
    if (demoMode) return;
    toDriver({ action: "register" });
}

function stopRegister() {
    if (demoMode) return;
    toDriver({ action: "stopRegister" });
}

function run(ballCount) {
    if (demoMode) {
        demoBallCount = ballCount;
        setTimeout(_ => driverHandler({ action: 'ready' }), 2000);
        return;
    }
    toDriver({ action: "run", ballCount });
}

function setLogLevel(level) {
    if (demoMode) return;
    toDriver({ action: 'logLevel', level });
}

function driverHandler(msg) {
    switch (msg.action) {
        case 'ready':
        case 'stopped':
            _common.manager.deviceStatus(msg.action);
            break;
        case 'navigation':
        case 'clawDrop':
        case 'pickup':
            _common.manager.pickupPhase(msg.action);
            break;
        case 'fault':
            _common.manager.addFault(msg.module, msg.error, msg.details);
            break;
        case 'log':
            _log.write(msg.severity, { module: msg.module, action: msg.driverAction, text: msg.text, sessionId: _common.sessionId })
            break;
        case 'defaults':
            burst = msg.burst
            break
        case 'process_exit':
            burst = msg.burst;
            _common.manager.processExit(burst);
            break
        case 'workTime':
            time = msg.time;
            _common.manager.workTime(time);
            break
        case 'ballRead':
            _common.manager.ballRead(msg.rfid);
            break;
        case 'photo':
            _common.manager.report('photo');
            break;
        case 'ball':
            _common.manager.report('ball', msg);
            break;
        case 'message':
            _common.manager.report('message', msg);
            break;
        default:
            if (msg.status && msg.status == 'error') {
                _common.manager.addFault('driver', msg.messege, {});
                _log.error('driverConn', 'Driver', msg);
            } else
                _log.error('driverConn', 'Unknown', msg)
            break;
    }
}

module.exports = {
    init,
    run,
    grab,
    drop,
    ball,
    randomBall,
    randomXY,
    photo,
    stop,
    draw,
    setLogLevel,
    reboot,
    exit,
    startRegister,
    stopRegister
};
