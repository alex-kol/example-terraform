const rabbitMQ = require('amqp-connection-manager');
let _channel			= null;
let _common				= null;
let _channelWrapper		= null;
let _server				= null;
const CONNECT_EVENT		= 'connect';
const DISCONNECT_EVENT	= 'disconnect';
let _retries            = 1;

async function init(fullURLs, common, cb) {
    _common = common;

    try {
        //console.log(`----------rabbitMQ init ${_retries} ---------`);
        _server = rabbitMQ.connect(fullURLs, {
            heartbeatIntervalInSeconds: 5,
            reconnectTimeInSeconds: 2
        });
        _server.on(DISCONNECT_EVENT, e => {
            _common.logger.writeAfter('ERROR', `RabbitMessanger Disconnected, retrying ${_retries}...`, _common.logPrintAfter);
            _retries += 1;
            return;
        });
        return new Promise((resolve, reject) => {
            _server.on(DISCONNECT_EVENT, e => {
                //console.log(`---------- server disconnection event ${_retries} ---------`);
                reject(e);
                //console.log(`---------- Promise rejected ${_retries} ---------`);
                return;
            });
            _common.logger.debug('Rabbit', 'Contacting', fullURLs);
            _server.on(CONNECT_EVENT, () => {
                //console.log(`---------- server connection event ${_retries} _channelWrapper ${_channelWrapper} ---------`);
                if (!_channelWrapper) {
                    //console.log(`---------- server connection event creating Channel ---------`);
                    _channelWrapper = _server.createChannel({
                        json: false,
                        setup: (channel) => {
                            _channel = channel;
                            cb(_common.logPrintAfter,'connected');
                            resolve();
                            //console.log(`---------- Promise resolved ${_retries} ---------`);
                            channel.on('error', function (err) {
                                console.log(err);
                                _common.logger.writeAfter('ERROR', `Rabbit Channel error ${_retries}`, _common.logPrintAfter);
                                var sleep = require('system-sleep');
                                sleep(1);    // without this rabbit hangs !?
                            });
                            channel.on('close', function (err) {
                                //console.log(`---------- channel close  ${_retries} ---------`);
                                //cb(_common.logPrintAfter, 'disconnected')
                                console.log(err);
                                _common.logger.writeAfter('ERROR', `Rabbit Channel closed ${_retries}`, _common.logPrintAfter);
                                _channel = null;
                                if ((_common.logPrintAfter == 0) && (_retries > 3)) {
                                    _common.logger.write('INFO', `RabbitMQ errors will be printed every 30 seconds`);
                                    _common.logPrintAfter = 30;    // print every 30 seconds
                                    setTimeout(() => {
                                        _common.logPrintAfter = 0;
                                        _common.logger.write('INFO', `RabbitMQ reset print times to normal`);
                                    }, 60 * 1000);
                                }
                                _common.manager.netError()
                            });
                        },
                    });
                }
                _common.logger.writeAfter('INFO', `RabbitMQ server trying to connect ${_retries}`, _common.logPrintAfter);
                //console.log(`---------- server connected ${_retries} ---------`);
            });
        })
    } catch (e) {
        _common.logger.error('RabbitMessanger', `init`, `RabbitMQ could not be initialized: ${e}`);
    }
}

function listenOn(queueName, cb) {
	_queueName = queueName;
    try {
        //mode = _retries < 5 ? true : false; // error simulation test 
        mode = false;
        console.log(`------------- listenOn retries ${_retries} exclusive ${mode} --------------`);
		_channel.assertQueue(queueName, {
            durable: true,
            exclusive: mode,
            arguments: { 'x-queue-type': 'quorum' },
		});
  	} catch (e) {
		_common.logger.error('RabbitMessanger', `listenOn`, e.message);
		throw e;
 	 }
    _common.logger.writeAfter('DEBUG', `Rabbit listening ${queueName}`, _common.logPrintAfter);
    cb({action:'connected'});
    
//    _common.logger.debug('Rabbit', 'Listening', queueName);

	_channel.consume(queueName, (qMsg) => {
		_common.logger.debug('Rabbit', 'Received', `${qMsg.content}`);
		let msg = '';
		try {
			msg = JSON.parse(qMsg.content);
		} catch (e) {
			_common.logger.error('RabbitMessanger', `listenOn`, e.message);
		}
	  	cb(msg);
	}, {noAck: true});
}

function sendTo(queueName, msg, skip_log=false) {
	if (!_channel) return;
  if (!_common.serial) return; // Some emulator cases

	const msgTxt = JSON.stringify({serial:_common.serial, key:_common.key, ...msg});
  _channel.sendToQueue(queueName, Buffer.from(msgTxt));
  if (!skip_log) _common.logger.debug('Rabbit', 'Sending', msg, _common.sessionId, _common.logPrintAfter);
}

function close() {
	_common.logger.info('Rabbit', 'ChannelClose', _queueName);
    if (_channel) _channel.close();
    _channel = null;
}

var messanger = {
	init,
	listenOn,
	sendTo,
    close
};

module.exports = messanger;
