const uid2 = require('uid2');
const messanger = require('./RabbitMessanger.js');
const jsonHttp = require('./httpGetJson.js');

const STATUS = {
    STOPPED: 'stopped',
    IDLE: 'idle',
    INROUND: 'inround',
    TESTING: 'testing',
    STOPPING: 'stopping',
    REGISTER: 'register',
    NETERROR: 'network_error'
};
const GameIds = ['clawRoulette'];
const MaxRebootTries = 30;

const commander = {
    stop: {
        handler: stop,
        allowedStates: [STATUS.IDLE, STATUS.TESTING, STATUS.NETERROR],
        ignoredStates: [STATUS.STOPPED, STATUS.STOPPING]
    },
    run: {
        handler: (msg) => { run(msg); },
        allowedStates: [STATUS.STOPPED],
        ignoredStates: [STATUS.TESTING]
    },
    setGame: {
        handler: (msg) => {
            if (GameIds.includes(msg.gameId))
                _common.gameId = msg.gameId;
            else
                send2Mgr('GameError', { msg: `Game ${msg.gameId} not supported` });
        },
        allowedStates: [STATUS.STOPPED, STATUS.IDLE]
    },
    grab: {
        handler: (_) => {
            _common.driver.grab();
        },
    },
    ball: {
        handler: (msg) => {
            _common.driver.ball(msg.x, msg.y);
        },
    },
    randomBall: {
        handler: (_) => {
            _common.driver.randomBall();
        },
    },
    randomXY: {
        handler: (_) => {
            _common.driver.randomXY();
        },
    },
    drop: {
        handler: (_) => {
            _common.driver.drop();
        },
    },
    photo: {
        handler: (_) => {
            _common.driver.photo();
        },
    },
    startRound: {
        handler: (msg) => startRound(msg.roundArgs),
        allowedStates: [STATUS.IDLE]
    },
    display: {
        handler: (msg) => _common.display.play(msg),
        allowedStates: [STATUS.IDLE, STATUS.INROUND]
    },
    ballConfig: {
        handler: (msg) => _common.display.showRegisterDisplay(msg),
        allowedStates: [STATUS.STOPPED]
    },
    exit: {
        handler: (_) => exit()
    },
    register: {
        handler: (_) => register(),
        allowedStates: [STATUS.STOPPED]
    },
    reboot: {
        handler: (_) => reBoot()
    }
};

let _common = null;
let _myStatus = STATUS.STOPPED;
let _toMgrQueue = null;
let _fromMgrQueue = null;
let _log = null;
let _faults = [];
let _netTestInterval = null;
let _rebootTries = 0;
let _currentAction = null;
let _pongInterval = null;
let _workHoursInterval = null;
let _workTime = 0;
let _terminator = null;


async function init(common, messageServer, queues) {
    _common = common;
    _log = _common.logger;
    _fromMgrQueue = queues.subscriber;
    _toMgrQueue = queues.publisher;
    _common.sessionId = null;
    try {
        await messanger.init(messageServer, common, (printAfter, status) => {
            if (status == 'connected') {
                messanger.listenOn(_fromMgrQueue, handle);
                if ([STATUS.STOPPED, STATUS.STOPPING, STATUS.IDLE, STATUS.TESTING].includes(_myStatus))
                    statusReport(printAfter);
                else {
                    // don't send anything, it will confuse the server
                }
            }
        });
        if (!_pongInterval) {
            _pongInterval = setInterval(_ => { send2Mgr('Pong') }, 60000);
        }
        if (!_workHoursInterval) {
            hoursReport();
            _workHoursInterval = setInterval(hoursReport, 60 * 60 * 1000);
        }
        _common.driver.startRegister(); // Start listening for balls added by the technician to the table
    } catch (e) {
        let msg = (typeof (e) === 'object' ? JSON.stringify(e) : e);
        _log.error('manager', 'initializing', msg);
    }
}

function hoursReport() {
    let workingHours = Math.round(_workTime / 3600);
    if (workingHours > 0) send2Mgr('WorkingHours', { workingHours });
}

function handle(msg) {
    if (msg.action == 'connected') {
        if (!_common.demoMode) _log.reviveLogger(); // In case of reconnect
        _log.warning('manager', 'connected', 'Restarting cloud logging');
        return;
    }

    _currentAction = null;
    // try {
    cmd = commander[msg.action];
    if (!("allowedStates" in cmd) || (cmd.allowedStates.includes(_myStatus))) {
        _currentAction = msg.action;
        cmd.handler(msg);
    }
    else if (("ignoredStates" in cmd) && (cmd.ignoredStates.includes(_myStatus))) {
        _log.warning('manager', msg.action, `command ${msg.action} ignored in ${_myStatus} state`, _common.sessionId);
        statusReport()
    }
    else {
        _log.error('manager', msg.action, `Invalid action ${msg.action} in ${_myStatus} state`, _common.sessionId);
        send2Mgr('CmdError', { command: msg.action, reason: `Invalid action ${msg.action} in ${_myStatus} state` });
    }
    // } catch (e) {
    // 	if (_log) {
    // 		_log.error('manager', msg.action, e.message, _common.sessionId);
    // 	}
    // 	send2Mgr('CmdError', {command: msg.action, reason:e.message});
    // }
}

function stop() {
    _log.info('manager', 'stop', '', _common.sessionId);
    _common.display.play('stopped');
    _common.driver.stop();
    changeStatus(STATUS.STOPPING);
    //if (_faultInterval) {
    //	_log.debug('manager', 'Clearing network error report');
    //	clearInterval(_faultInterval);
    //	_faultInterval = null;
    //}
    if (_netTestInterval) {
        clearTimeout(_netTestInterval);
        _netTestInterval = null;
    }
}

function run(msg) {
	_log.info('manager', 'run', msg);
    _common.driver.stopRegister();
	_common.driver.run(msg.ballCount);
    _common.display.hideRegisterDisplay();
    _common.display.play({phase:'preparing'});
	changeStatus(STATUS.TESTING);	
}

function startRound(roundConfig) {
	const defaultConfig = {timeout:40, rotateTime:5, maxAttempts:3};

	changeStatus(STATUS.INROUND);
	const config = Object.assign({}, defaultConfig, roundConfig);
	_log.debug('manager', 'startRound', config);
	_terminator = setTimeout(terminateRound, config.timeout*1000);
	_common.driver.draw(config.rotateTime, config.maxAttempts);
}

function ballRead(rfid) {
	if (_myStatus==STATUS.STOPPED) { // New ball assigned to machine
		if (rfid.startsWith('remoter:')) {
			if (_common.demoMode) {
				let [pref, demoRfid] = rfid.split(':');
				send2Mgr('addBall', {rfid:demoRfid});
			} else {
				// This looks like hacking!
				_log.error('manager', 'ballRead', 'Remoter sent addBall in Prod!!!');
			}
		} else {
			send2Mgr('addBall', {rfid});
		}
		return;
	}
	if (_myStatus==STATUS.INROUND) {
		roundResult(rfid);
		return;
	}
	_log.error('manager', 'ballRead', `Ball read in status ${_myStatus}`);
}

function roundResult(rfid) {
	if (_terminator) {
		clearTimeout(_terminator);
		_terminator = null;
	}
	send2Mgr('result', {rfid});
	changeStatus(STATUS.IDLE);
}

function terminateRound() {
    if (_myStatus == STATUS.INROUND) {
        roundResult(-1);
    }
//    changeStatus(STATUS.STOPPING);
//    setTimeout(_ => changeStatus(STATUS.STOPPED), 3000);
}

function pickupPhase(phase) {
    console.log(`pickupPhase ${phase}`);
    _common.display.play({ phase });
}

function cupPhoto(pathToPhoto) {
	_common.display.prizeSnapshot(pathToPhoto);
}

function deviceStatus(status) {
    console.log(`Changing status to ${status}`);
    if (status == 'ready')
        changeStatus(STATUS.IDLE);
    else
        changeStatus(STATUS.STOPPED);
}

function changeStatus(newStatus) {
    console.log(`_myStatus = newStatus:: ${newStatus}`);
    _myStatus = newStatus;
    statusReport();
}

function doReboot() {
    //console.log(`------------- doReboot _myStatus is ${_myStatus} ------------`);
    if (_myStatus == STATUS.STOPPED) {
        _common.driver.reboot();
    }
    else {
        _rebootTries += 1
        //console.log(`------------- doReboot _rebootTries is ${_rebootTries} ------------`);
        if (_rebootTries < MaxRebootTries) {
            _log.debug('manager', `Waiting for shutdown completion ${_rebootTries}`);
            setTimeout(() => { doReboot() }, 1000);
        }
        else {
            _log.debug('manager', `Max reboot exceeded ${MaxRebootTries}, rebooting now`);
            _common.driver.reboot();
        }
    }
}

function reBoot() {
    _log.info('manager', 'Reboot', _common.sessionId);
    stop();
    send2Mgr('Reboot');
    messanger.close();
    if (_common.demoMode) {
        setTimeout(_common.restart, 5000);
    } else {
        //setTimeout(() => { _common.driver.reboot() }, 10000);
        doReboot();
    }
}

function exit() {
    _log.info('manager', 'Exit', _common.sessionId);
    stop();
    _common.driver.exit();
    send2Mgr('Exit');
    if (_myStatus == STATUS.STOPPED) {
        process.exit()
    }
    //setTimeout(() => { process.exit() }, 5000);
}

function register() {
    changeStatus(STATUS.REGISTER);
    _log.info('manager', 'Register', _common.sessionId);
    _common.driver.register();
    //setTimeout(() => { process.exit() }, 5000);
}
function netError() {
    //changeStatus(STATUS.NETERROR);
    //_common.player.resetPlayer();
    //if (!_faultInterval) {
    //	_log.debug('manager', 'Starting network error report every 30 seconds');
    //	_faultInterval = setInterval(_ => {
    //		addFault('manager', 'network error', {});
    //	}, 30 * 1000);
    //}
    _log.killLogger(); // GCP cloud logging goes crazy when there are network errors
    console.log("(Networking) Cloud logging stopped because of network problems");

    if (_currentAction != 'reboot') {
        if (!_netTestInterval) callArcadiaAdmin();
    }
}

async function callArcadiaAdmin() {
    if (!_common.isProduction) return;

    await jsonHttp.get(`http://10.0.4.3:8000/robot?serial=${_common.serial}&action=networkerror`)
        .then(resp => {
            console.log(`callArcadiaAdmin succeeded with response: ${JSON.stringify(resp)}`);
            _log.reviveLogger();
            _log.debug('manager', 'Networking', 'Cloud logging restored..........!!');
        }).catch(err => {
            console.log('callArcadiaAdmin failed')
        });
    _netTestInterval = setTimeout(callArcadiaAdmin, 30_000); // This stops only after the Stop command
}

function statusReport(inervalSecs = 0) {
    send2Mgr('Pong');
    _log.info('manager', 'Status', { application: _myStatus, faults: _faults}, _common.sessionId, inervalSecs);

  // Do not use send2Mgr! 
    messanger.sendTo(_toMgrQueue, 
        {type:'Status', status:{application:_myStatus, faults:_faults}, sessionId:_common.sessionId, gameId:_common.gameId, correlationId:uid2(36)},
        true // skip logging to prevent loops
    );
    _faults = []
}

function addFault(module, error, details) {
    send2Mgr('error', { module, error, details });
}

function driverFault(module, error, details) {
    send2Mgr('error', { module, error, details });
}

function send2Mgr(type, data, correlationId = null) {
    messanger.sendTo(_toMgrQueue, { type, gameId:_common.gameId, sessionId: _common.sessionId, correlationId: (correlationId || uid2(36)), ...data });
}

var manager = {
	init,
	handle,
	ballRead,
	pickupPhase,
	photo: cupPhoto,
	addFault,
	deviceStatus,
	driverFault,
	report: send2Mgr,
	processExit: _ => { process.exit(); },
	workTime: (time) => { _workTime = time;},
	netError
};

module.exports = manager;
