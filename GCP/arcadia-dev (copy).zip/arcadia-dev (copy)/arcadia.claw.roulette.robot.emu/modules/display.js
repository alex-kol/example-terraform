const WebSocket = require('ws')
const wss = new WebSocket.Server({ port: 8011 });
const http = require("http");
const fs = require("fs");
const stdin = process.stdin;

// stdin.setRawMode(true);
// stdin.setEncoding('utf8');
// stdin.resume();

// https://blog.gordonturner.com/2020/06/30/raspberry-pi-full-screen-browser-2020-05-27-raspios-buster/
// sudo nano .config/lxsession/LXDE-pi/autostart

var results = [];

const Steps = [
	{
		name:'Stopped',
		video:'Stopped.jpg',
		preRun: _ => {}
	},
	{
		name:'Preparing',
		video:'Preparing.jpg',
	},
	{
		name:'Idle',
		video:'(16-9)_1_DEFAULT_BG.mp4',
		preRun: _ => {}
	},
	{
		name:'PlaceBets',
		video:'(16-9)_2_PLACE-BETS.mp4',
		preRun: _ => {}
	},
	{
		name:'Navigation',
		video:'(16-9)_3_HERE-WE-GO.mp4',
	},
	{
		name:'ClawDrop',
		video:'(16-9)_4_CLAW-DROP.mp4',
	},
	{
		name:'05_PICK-UP',
		video:'(16-9)_5_BALL-PICK-UP.mp4',
		preRun: _ => {}
	},
	{
		name:'Result',
		video:'(16-9)_6_RESULT.mp4',
		preRun: _ => {}
	}
];

const StepVisuals = {
	stopped:   'Stopped.jpg',
	preparing: 'Preparing.jpg',
	idle:      '(16-9)_1_DEFAULT_BG.mp4',
	placeBets: '(16-9)_2_PLACE-BETS.mp4',
	navigation:'(16-9)_3_HERE-WE-GO.mp4',
	clawDrop:  '(16-9)_4_CLAW-DROP.mp4',
	pickup:    '(16-9)_5_BALL-PICK-UP.mp4',
	result:    '(16-9)_6_RESULT.mp4'
};

let step = null;
let wsHandle = null;
let playing = 0;


async function init(common) {
  return new Promise((resolve, reject) => {
  	if (common.demoMode) {
  		setTimeout(resolve, 1000);
  		return;
  	}

		http.createServer(httpHandler).listen(8000);

		wss.on('connection', ws => {
		  wsHandle = ws;
		  ws.on('message', message => {
		    console.log(`Received message => ${JSON.stringify(message)}`);
		    let msg = JSON.parse(message);
		    handleDisplay(ws, msg);
		  });

			resolve();
		});

  });

}

async function handleDisplay(ws, msg) {
	let action = msg.action;
}

function httpHandler(req, res) {
  fs.readFile(__dirname + '/static' + req.url, function (err,data) {
    if (err) {
      res.writeHead(404);
      res.end(JSON.stringify(err));
      return;
    }
		res.writeHead(200);
		res.end(data);
  });
}

function play(msg) {
	console.log(`Play: ${JSON.stringify(msg)} : ${msg.phase}`);
	let file = StepVisuals[msg.phase];
	if (!file) {
		console.log(`Step not found: ${step}`);
		return;		
	}
	let result = msg.result;
	sendToDisplay({command:'play', file, result});
}

function sendToDisplay(msg) {
	if (wsHandle)
		wsHandle.send(JSON.stringify(msg));
	else
		console.log('Display not active');
}

module.exports = {
	init,
	play,
	addBall: _ => {},
	showRegisterDisplay: msg => {sendToDisplay({command:'showRegister', ...msg});},
	hideRegisterDisplay: _ => {},
	prizeSnapshot: (filename) => {console.log(`Got photo: ${filename}`);}
}
