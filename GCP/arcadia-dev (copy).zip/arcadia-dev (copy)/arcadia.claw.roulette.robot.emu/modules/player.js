
//-------------------------------------------------------------------------------------------

class _InMove {
    #inMove = 0;
    constructor() {
        this.#inMove = 0;
    }
    move() {
        this.#inMove += 1;
        if (status == 'off') {
            console.log(`@@@@@  InMove move when status is off !!!`);
        }
    }
    moved() {
        this.#inMove -= 1;
        if (status != 'off') {
            if (this.#inMove < 0) {
                console.log(`@@@@@ InMove moved internal error ${this.#inMove} < 0, resetting to 0 !!!`);
                this.#inMove = 0;
            }
        }
        else {
            console.log(`@@@@@ InMove moved when status is off !!!`);
        }
    }
    moving() {
        return this.#inMove > 0;
    }
    count() {
        return this.#inMove;
    }
    reset() {
        this.#inMove = 0;
    }
}

//-------------------------------------------------------------------------------------------

const { sleep } = require('sleep');

let coins = 0;
let status = "off";
let gunInterval = null;
let gunTimeout = null;
let fireState = "cease";
let gunState = "idle"
let response = null;
let engageTimeout = null;
let readyTimeout = null;
let _retries = 0;
let _common = null;
let _messanger = null;
let _channel = null;
let _autoShoot = false;
let _autoMove = false;
let _log = null;
let _burst_count = 0;
let _burst = 0;
//let _inMove = 0;
let inMove = new _InMove();
let _autoTimeOut = null;
let _autoMoveTimeOut = null;
const MAX_ANGLE = 100;
const GREEN_ZONE = 90;

function init(common, playerMessageServer) {
    _common = common;
    _log = _common.logger;
    try {
        _messanger = require('./RedisMessanger')(playerMessageServer);
        _messanger.on('player2robot', handlePlayer);
        _log.info('player', 'Init', `Player initialized default burst shoot is ${_burst_count}`);
    } catch (e) {
        _log.error('player', 'Init', `Redis could not be initialized: ${e}`);
    }
}
function sendReady() {
    _retries += 1
    _log.info("player ", { action: "ready " }, `${_retries}`);
    sendToPlayer({ action: "ready" });
    if ((_retries < 3) && (status == 'waitingForPlayer'))
        readyTimeout = setTimeout(sendReady, 2000);
}

function engage(session, burst) {
    _channel = `robot_${_common.serial}__p_${session}`;
    _messanger.join(_channel);
    if (burst != 0) {
        _burst_count = burst;
        _log.info('player', 'engage', `burst shoot set to ${_burst}`);
    }
    status = "waitingForPlayer";
    _setAngle(0);
    _retries = 0;
    sendReady();
    engageTimeout = setTimeout(_ => { return ((x) => { playerDidntCome(x) })(session) }, 5000);
    _common.driver.tray('on');
}

function playerDidntCome(session) {
    status = 'off';
    _common.manager.playerLost(session);
    _messanger.leave(_channel);
}

function setCoins(newVal) {
    if ((!newVal || !Number(newVal)) && !(newVal === 0)) {
        _log.error('player', 'setCoins', `${newVal} is not a number`, _common.sessionId);
        return;
    }
    _log.info('player', 'setCoins', `Loading ${newVal} coins`, _common.sessionId);
    coins = Number(newVal);
    sendToPlayer({ action: "approved", coins });
    sendToPlayer({ action: 'moving', angle: _common.driver.angle() });
    if (_autoShoot) fire();
}

function breakup() {
    ceaseFire();
    coins = 0;
    try {
        sendToPlayer({ action: "denied" });
        _messanger.leave(_channel);
        stopAuto();
        _common.driver.tray('off');
    } catch (e) { } // The player may no longer be connected
    _channel = null;
}

function reshuffle(coins) {
    status = 'reshuffle';
    setCoins(coins);
    setAuto('auto');
}

function stopReshuffle() {
    status = 'off';
    stopAuto();
    _common.manager.stopReshuffle();
}

function handlePlayer(msg) {
    let action = msg.action;
    _log.debug('player', 'handlePlayerAction', msg, _common.sessionId);
    if (action == 'init') {
        if (status == 'waitingForPlayer') {
            if (engageTimeout) {
                clearTimeout(engageTimeout);
                engageTimeout = null;
            }
            if (readyTimeout) {
                clearTimeout(readyTimeout);
                readyTimeout = null;
            }
            _retries = 0;
            _common.manager.playerReady(msg);
            status = 'playing';
            return;
        } else {
            _log.warning('player', 'UnknownPlayer', `Connected while not waiting on ${_channel}`, _common.sessionId);
            return
        }
    }
    if (action == 'userLeft') return;

    try {
        playerActions[action](msg);
    } catch (e) {
        _log.error('player', `UnknownPlayerAction exception - ${action}`, e.stack.toString(), _common.sessionId);
    }
}

function setAuto(swingMode) {
    _log.debug('player', 'auto', { swingMode }, _common.sessionId);
    if (swingMode === 'auto') {
        console.log(`@@@@@ setAuto call startAutoMove() inMove ${inMove.count()}`)
        startAutoMove();
    }
    _autoShoot = true;
    fireState = "fire";
    fire();
}

function stopAuto() {
    if (gunInterval) clearInterval(gunInterval);
    if (_autoTimeOut) {
        clearTimeout(_autoTimeOut);
        _autoTimeOut = null;
    }
    if (_autoMoveTimeOut) {
        clearTimeout(_autoMoveTimeOut);
        _autoMoveTimeOut = null;
    }
    gunInterval = null;
    _autoShoot = false;
    fireState = 'cease';
    stopAutoMove();
}

function stopAutoMove() {
    console.log(`@@@@@ stop auto move`);
    _autoMove = false;
    sendToPlayer({action:'swingMode', swingMode:'manual'});

//    _setAngle(0);
}

function resetPlayer() {
    console.log(`@@@@@ reseting player`);
    //breakup();
    //stopAuto();
    //stopMoving();
    //quit();
    inMove.reset();
    fireState = 'cease';
}

function startAutoMove() {
    if (!_autoMove) {
        console.log(`@@@@@ startAutoMove inMove ${inMove.count()}`);
        if (inMove.moving()) {
            _autoTimeOut = setTimeout(startAutoMove, 500)
        }
        else {
            _autoMove = true;
            autoMove();
            sendToPlayer({ action: 'swingMode', swingMode:'auto' });
        }
    }
    else {
        console.log(`@@@@@ startAutoMove already started`);
    }
}

function setSwingMode(msg) {
    if (!_autoShoot) {
        sendToPlayer({ error: "not in auto mode" });
        return;
    }
    if (msg.mode.toLowerCase() === 'manual' && (_autoMove || (_autoTimeOut != null))) {
        stopAutoMove();
        _setAngle(0);
    }
    if (msg.mode.toLowerCase() === 'auto') {
        console.log(`@@@@@ setSwingMode call startAutoMove() inMove ${inMove.count()}`)
        startAutoMove();
    }
}

function autoMove() {
    angle = _common.driver.angle();
    if (angle < 0) {
        angle = (angle > -GREEN_ZONE) ? -MAX_ANGLE : MAX_ANGLE;
    }
    else {
        angle = (angle < GREEN_ZONE) ?  MAX_ANGLE : -MAX_ANGLE;
    }
    _setAngle(angle);
    console.log(`@@@@@ autoMove ${angle} inMove ${inMove.count()}`)
}
function quit(msg) {
    if (gunInterval) clearInterval(gunInterval);
    gunInterval = null;
    status = "off";
}

function _setAngle(angle) {
    inMove.move();
    _common.driver.setAngle(angle);
}

function setAngle(msg) {
    if (status != 'playing') {
        // sendToPlayer({ error: "not in play mode" });
        return;
    }
    if (_autoMove) {
        console.log(`@@@@@ setAngle In automatic mode`)
        //sendToPlayer({ error: "In automatic mode" });
        return;
    }

    let angle = msg.angle;
    if (angle != undefined && Number(angle) != undefined) {
        _common.manager.report('setAngle');
        _setAngle(angle);
        console.log(`@@@@@ setAngle inMove ${inMove.count()}`)
    }
    else
        _log.warning('player', 'setAngle', `Ilegal angle ${angle}`, _common.sessionId);
}

function stopMoving(msg) {
    _log.warning('player', 'stopMoving', 'Does this ever happen?', _common.sessionId);
    _common.manager.report('StopMoving', msg);
}

function movedTo(dir, angle) {
    _log.debug('player', 'MovedTo', { angle });
    if (_autoMove) {
        _autoMoveTimeOut = setTimeout(autoMove, 200); // change sides! // Timer use to avoid stack recursion
    }
    inMove.moved();
    console.log(`@@@@@ movedTo inMove ${inMove.count()}`)
    sendToPlayer({ action: 'moving', angle });
    _common.manager.position(angle);
}

function openFire(msg) {
    //if (status == "off" || fireState == "fire") {
    if (status == "off") {
        _log.warning('player', 'openFire', `Cannot open fire in ${status} status ${fireState} fireState`, _common.sessionId);
        send({ error: 'off' });
        return;
    }
    if (_autoShoot) {
        _log.warning('player', 'openFire', "Cannot open fire while in autotomatic mode", _common.sessionId);
        sendToPlayer({ error: "In autotomatic mode" });
        return;
    }
    if (gunState == "idle") {
        // _common.manager.report('Fire'); // Redundant report to server
        fireState = "fire";
        _log.debug('player', 'openFire', "Opening fire!");
        _burst = _burst_count;
        fire(); // to make sure at least one coin shot
    }
    //else {
    //    _log.warning('player', 'openFire', `status is ${status}, rescheduling openFire()`, _common.sessionId);
    //    gunTimeout = setTimeout(function () {
    //        openFire(msg);
    //    }, 1000)
    //}
}

function ceaseFire(msg) {
    if (status == "off" || fireState == "cease") {
        send({ error: 'off' });
        return;
    }
    if (_autoShoot) {
        _log.warning('player', 'ceaseFire', "Cannot cease fire while in autotomatic mode", _common.sessionId);
//        sendToPlayer({ error: "In automatic mode" });
        return;
    }
    fireState = "cease";
    if (gunInterval) clearInterval(gunInterval);
    gunInterval = null;
    // _common.manager.report('CeaseFire');  // Redundant report to server
}

function fire() {
    if (coins > 0 && (status == "playing" || status == 'reshuffle')) {
        gunState = "fire"
        _common.driver.shoot();
    } else {
        if (coins == 0) {
            send({ action: "empty" });
            return;
        } else {
            _log.warning('player', 'fire', `Cannot open fire in status ${status}`);
        }
    }
}

function fired() {
    _log.debug('player', `coin fired`, {coins});
    if (coins > 0) {
        coins -= 1;
        sendToPlayer({ action: 'blast', coins: coins });
        _common.coinCounter += 1;
        _common.manager.coinShot(coins);
        if (coins > 0) {
            if (_burst > 0) {
                _burst -= 1;
            }
            if (fireState == "fire" || _burst > 0) {
                gunTimeout = setTimeout(fire, 100); // until cease fire
            }
            else {
                gunState = "idle"
            }
        }
    }
    if (coins == 0) {
        gunState = "idle"
        if (gunTimeout) clearTimeout(gunTimeout);
        gunTimeout = null;
        if (status == 'reshuffle') stopReshuffle();
        //   if (_autoMove)           stopAuto();
    }
}

function send(msg) {
    if (!response) return;
    response.send(JSON.stringify(msg));
}

function sendToPlayer(msg) {
    if (!_channel) return; // Happens in reshuffle

    _log.debug('player', 'sendToPlayer', msg, _common.sessionId);
    _messanger.to(_channel).emit('robot2player', msg);
}

let playerActions = {
    setAngle,
    stopMoving,
    setSwingMode,
    openFire,
    ceaseFire,
    quit
};

var player = {
    init,
    engage,
    breakup,
    setCoins,
    setAuto,
    stopAuto,
    fired,
    movedTo,
    reshuffle,
    chipDetection: (_) => { sendToPlayer({ action: 'ChipDetection' }); },
    chipDrop: (_) => { sendToPlayer({ action: 'ChipDrop' }); },
    setBurst: (burst) => { _burst_count = burst; },
    resetPlayer
};

module.exports = player;
