const sha256File = require('sha256-file');
const glob = require('glob');
const jsonfile = require('jsonfile');
const { modules } = require('./critical-modules.json');

const getDirectories = (directory, callback) => {
  glob(`../backend/apps/${directory}/src/**/*.ts`, callback);
};

for (const module of modules) {
  getDirectories(module.module, (err, files) => {
    if (err) {
      console.log('Critical files signature error', err);
    } else {
      const hashList = files.reduce((hashList, file) => {
        if (module.files.some(fileToSign => file.match(new RegExp(fileToSign)))) {
          hashList[file] = sha256File(file);
        }
        return hashList;
      }, {});
      jsonfile.writeFile(`./signatures/${Date.now()}-${module.module}.json`, hashList, {
        spaces: 2,
        finalEOL: true,
      });
    }
  });
}
