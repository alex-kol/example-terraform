###### Development Environment
Please refer to this [document](deployment/dev/readme.md)
## Requirements

* Ruby 2.6.7

* Google Chrome

* chromedriver: `brew tap homebrew/cask`, then `brew cask install chromedriver`

Install dependencies by:
> bundle install

## Run the specs

From *smoke* run:
> rspec spec/

If rspec command is not working, try to set your ruby version to the one specified in `.ruby-version` file.

If you're using `rbenv`, run:
> rbenv install {version}

> rbenv local {version}

> bundle

You should then be able to run `rspec spec/`
If still not, run:

> bundle exec rspec spec/

- If you'd like to run just a single folder specs, you can do it by running:
> rspec spec/{folder}/

- If you want to run only one test case in a file, you can use:
> rspec precondition.rb spec/{folder}/{spec_name}:{line_number_where_the_it_starts}

###### Permitted modules for users
In order to store permitted modules for users many-to-many relation in used.
Cross table: 'user_permitted_modules_bo_module'
### Run tests on specific scenarios

Run tests command
> bundle exec rspec spec/features/arcadia_robot/arcadia_spec.rb:32

### Run tests on all scenarios
> bundle exec rspec spec/features/arcadia_robot/arcadia_spec.rb

#### Run tests on Jenkins(configurable)

> 1) Navigate on http://jenkins.../job/configurable/
>
> 2) Click on the **Build with Parameters**
>
> 3) Select branch(`master` branch selected by default)
>
> 4) Fill out spec_name field by valid spec name with extension(e.g. `signup_spec.rb`)
>
> 5) Click **Build** button

### Rubocop usage
>rubocop --require rubocop-rspec

### Setup & run allure
>gem install allure-rspec
>
>npm install -g allure-commandline --save-dev
>
>allure generate allure-results --clean -o allure-report

### Remove all screenshots from "results" folder
>rm -rf results/name_*

### Running load test on stage
* To run simultaneously up to 100 users VM minimum requirements 16 core and 64 MB of RAM
* Image(gcr.io/studio-staging-294712/arcadia.e2e) will be created by CI/CD after merging into the staging branch
* First of all, on the server-side containers should be created
    * staging: `for i in {1..80}; do docker create -v /home/kashn/results/$i:/app/results --security-opt seccomp:unconfined --env DEFAULT_GROUP="Autotest Group" --env ENVIRONMENT="stage_load" --env SPINOMENAL_ENV=" " --env SPINOMENAL_LOGIN="arcadia-test" --env SPINOMENAL_PASSWORD="arcadia-test" --env USER_ID="loadUserTest$i"  gcr.io/studio-staging-294712/arcadia.e2e:latest /bin/sh -c 'sleep 60 && bundle exec rspec spec/features/arcadia_robot/load_spec.rb'; done`
    * production: `for i in {61..160}; do docker create -v /home/kashn/results/$i:/app/results --security-opt seccomp:unconfined --env DEFAULT_GROUP="Digi" --env ENVIRONMENT="stage_load" --env SPINOMENAL_ENV=2 --env SPINOMENAL_LOGIN="arcadia-test" --env SPINOMENAL_PASSWORD="arcadia-test" --env USER_ID="tester$i"  gcr.io/studio-staging-294712/arcadia.e2e:latest /bin/sh -c 'sleep 80 && bundle exec rspec spec/features/arcadia_robot/load_spec.rb'; done`
* And run all `docker start $(docker ps -qa)`
