  $template = '
apiVersion: batch/v1
kind: Job
metadata:
  name: arcadia-load-test-{i}
spec:
  completions: 1
  parallelism: 1
  completionMode: Indexed
  ttlSecondsAfterFinished: 90
  template:
    spec:
      containers:
        - name: arcadia-e2e
          image: gcr.io/studio-staging-294712/arcadia.e2e:latest
          imagePullPolicy: Always
          args:
            - bundle
            - exec
            - rspec
            - spec/features/arcadia_robot/load_spec.rb
          env:
            - name: DEFAULT_GROUP
              valueFrom:
                configMapKeyRef:
                  name: arcadia-stage-load-test
                  key: DEFAULT_GROUP
            - name: ENVIRONMENT
              valueFrom:
                configMapKeyRef:
                  name: arcadia-stage-load-test
                  key: ENVIRONMENT
            - name: SPINOMENAL_ENV
              valueFrom:
                configMapKeyRef:
                  name: arcadia-stage-load-test
                  key: SPINOMENAL_ENV
            - name: SPINOMENAL_LOGIN
              valueFrom:
                configMapKeyRef:
                  name: arcadia-stage-load-test
                  key: SPINOMENAL_LOGIN
            - name: SPINOMENAL_PASSWORD
              valueFrom:
                configMapKeyRef:
                  name: arcadia-stage-load-test
                  key: SPINOMENAL_PASSWORD
            - name: USER_ID
              value: "loadUserTest{user}"
      restartPolicy: Never
  '

#gcloud container clusters get-credentials studio-staging-294712-gke --region europe-west3 --project studio-staging-294712

for($i=2; $i -le 10; $i++)
{
  $text = $template -Replace "{user}", $i
  $text = $text -Replace "{i}", $i
  echo "${text}" | kubectl apply -n staging --validate=false -f -
}
