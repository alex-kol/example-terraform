gcloud container clusters get-credentials studio-staging-294712-gke --region europe-west3 --project studio-staging-294712
kubectl delete -n staging $(kubectl get jobs -n staging -o=name | grep "load-test")
