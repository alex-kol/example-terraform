require "capybara"

def generate_random_user_name(digits_number)
  Faker::Name.first_name + Faker::Number.number(digits: digits_number).to_s
end

def generate_random_first_name(additional_chars_quantity)
  Faker::Name.first_name + generate_literal_chars(additional_chars_quantity)
end

def generate_random_last_name(additional_chars_quantity)
  Faker::Name.last_name.tr("'", "") + generate_literal_chars(additional_chars_quantity)
end

def generate_random_phone(digits_number)
  Faker::Number.number(digits: digits_number).to_s
end

def generate_random_address
  Faker::Address.street_address.tr("'", "")
end

def generate_random_town
  Faker::Address.city.tr("'", "")
end

def generate_random_zip_code(digits_number)
  Faker::Number.number(digits: digits_number).to_s
end

def random_string
  require 'time'
  Time.new.strftime('%Y%m%d%H%M%S')
end

def random_day_within_31_days
  rand(1..31).to_s
end

def random_day_within_28_days
  rand(01..28).to_s
end

def generate_random_value_11_30
  rand(11..30).to_s
end

def generate_random_year_within_1979_2002
  rand(1979..2002).to_s
end

def get_random_month_name
  months = %w[01 02 03 04 05 06 07 08 09 10 11 12]
  months.sample.to_s
end

def check_current_url(url)
  sleep 4
  expect(current_url).to include url
end

def current_url_does_not_include(url)
  sleep 4
  expect(current_url).not_to include url
end

def fill_field(locator, value, type = 'css')
  sleep 0.5
  if type == 'css'
    find(locator, visible: true, wait: 10).set value if element_present?(type, locator)
  elsif type == 'xpath'
    find(:xpath, locator, visible: true, wait: 10).set value if element_present?(type, locator)
  else
    raise ArgumentError, "message: #{type} is not supported"
  end
end

def wait_until(timeout = Capybara.default_max_wait_time, message)
  Timeout.timeout(timeout) do
    sleep(0.25) until value = yield
    value
  end
rescue StandardError
  raise StopIteration.new, "#{message} after #{timeout} seconds"
end

def click_element(locator, type = 'css')
  if type == 'css'
    find(locator, visible: true, wait: 30).click if element_present?(type, locator)
  elsif type == 'xpath'
    find(:xpath, locator, visible: true, wait: 30).click if element_present?(type, locator)
  else
    raise ArgumentError, "message: #{type} is not supported or undefined #{locator}"
  end
end

def hover_element(locator, type = 'css')
  if type == 'css'
    find(locator, visible: true, wait: 10).hover if element_present?(type, locator)
  elsif type == 'xpath'
    find(:xpath, locator, visible: true, wait: 10).hover if element_present?(type, locator)
  else
    raise ArgumentError, "message: #{type} is not supported"
  end
end

def find_text(locator, type = 'css')
  if type == 'css'
    find(locator, visible: true, wait: 30).text if element_present?(type, locator)
  elsif type == 'xpath'
    find(:xpath, locator, visible: true, wait: 30).text if element_present?(type, locator)
  else
    raise ArgumentError, "message: #{type} is not supported"
  end
end

# Element state methods

# def element_visible?(xpath_locator)
#   element_present?(xpath_locator) && element_displayed?(xpath_locator)
# end

# def element_present?(timeout = Capybara.default_max_wait_time, xpath_locator)
#   wait_until(timeout, 'unexpected result') do
#     begin
#       page.evaluate_script('document.readyState === "complete"')
#     rescue Timeout::Error
#       puts 'Time out to page load'
#     rescue Selenium::WebDriver::Error::JavascriptError
#       puts 'Java script Error'
#       retry
#     end
#   end
#   page.has_xpath?(xpath_locator, wait: timeout)
# end

def element_present?(type, locator)
  wait_until('unexpected result') do
    page.evaluate_script('document.readyState === "complete"')
  rescue Timeout::Error
    puts 'Time out to page load'
  rescue Selenium::WebDriver::Error::JavascriptError
    puts 'Java script Error'
    retry
  end
  case type
  when 'css'
    page.has_css?(locator)
  when 'xpath'
    page.has_xpath?(locator)
  else
    raise ArgumentError, "message: #{type} is not supported"
  end
end

def css_element_present?(timeout = Capybara.default_max_wait_time, css_locator)
  wait_until('unexpected result') do
    begin
      page.evaluate_script('document.readyState === "complete"')
    rescue Timeout::Error
      puts 'Time out to page load'
    rescue Selenium::WebDriver::Error::JavascriptError
      puts 'Java script Error'
      retry
    end
  end
  page.has_css?(css_locator, wait: timeout)
end

def element_displayed?(web_element_locator)
  find(:xpath, web_element_locator).visible?
end

def switch_to_new_tab
  window = page.driver.browser.window_handles
  if window.size > 1
    page.driver.browser.switch_to.window(window.last)
  end
  sleep 2
end

def scroll_down(height = 500)
  page.driver.execute_script("window.scrollTo(0, #{height})")
end

def switch_back_to_previous_tab
  window = page.driver.browser.window_handles
  if window.size > 1
    # page.driver.browser.close
    page.driver.browser.switch_to.window(window.first)
  end
  sleep 2
end

def refresh_page
  page.driver.browser.navigate.refresh
end

def clean_field(locator, type = 'css')
  find(locator, visible: true, wait: 10).native.clear if element_present?(type, locator)
end

def open_new_browser_tab
  page.driver.execute_script("window.open()")
end

def wait_some_seconds(value)
  sleep(value)
end

def make_sure_element_is_absent(element)
  page.assert_no_selector(:xpath, element)
end

def make_sure_element_is_present(element)
  page.assert_selector(:xpath, element)
end

def make_sure_element_has_property(element)

end

# def interact_with_checkbox(checkbox, action, checked_el)
#   if action == 'checked'
#     execute_script(`$('#{checkbox}').click()`)
#     make_sure_element_is_present(checked_el)
#   elsif action == 'unchecked'
#     execute_script(`$('#{checkbox}').click()`)
#     make_sure_element_is_absent(checked_el)
#   end
# end

def interact_with_checkbox(checkbox, action)
  action == 'checked' ? check_checkbox(checkbox) : uncheck_checkbox(checkbox)
end

def check_checkbox(checkbox)
  execute_script("$('[type=\"checkbox\"]').click()") if checkbox['checked'].nil?
end

def uncheck_checkbox(checkbox)
  execute_script(`$('#{checkbox}').click()`) unless checkbox['checked'].nil?
end

# https://apidock.com/ruby/DateTime/strftime
def convert_date(date, format)
  Chronic.parse(date).strftime(format)
end

# https://apidock.com/ruby/DateTime/strftime
def current_date
  Time.now.strftime("%d/%m/%Y")
end

def generate_literal_chars(quantity)
  [*('A'..'Z')].sample(quantity).join
end

def write_cases_results(cases_ids, status)
  status = case status
           when 'PASSED'
             1
           when 'FAILED'
             5
           else
             raise ArgumentError, "message: #{status} is not supported"
           end

  cases_ids.each do |case_id|
    case_status = {
        "case_id": case_id,
        "status_id": status}
    @@test_cases_results['results'].insert(0, case_status)
  end
end

def current_time
  Time.now.strftime("%H:%M")
end

def random_numeric(n)
  (1..n.to_i).map { '0123456789'.chars.to_a.sample }.join
end

def random_symbolic(n)
  rand(36 ** n).to_s(36)
end

def check_current_url_include(url)
  sleep 4
  expect(current_url).to include url
end

def check_current_url_exact(url)
  sleep 4
  expect(current_url).to eq url
end

def click_on_date_of_birth_field
  el = 'input[name="birthDate"]'
  click_element(el)
end

def select_year_of_birth(year)
  click_element('[aria-label="Choose month and year"]')
  find(:xpath, "//div[contains (text(),\"#{year}\")]", visible: true, wait: 10).click
end

def select_month_of_birth(month)
  value = case month
          when '1'
            'JAN'
          when '2'
            'FEB'
          when '3'
            'MAR'
          when '4'
            'APR'
          when '5'
            'MAY'
          when '6'
            'JUN'
          when '7'
            'JUL'
          when '8'
            'AUG'
          when '9'
            'SEP'
          when '10'
            'OCT'
          when '11'
            'NOV'
          when '12'
            'DEC'
          end
  find(:xpath, "//div[contains (text(),\"#{value}\")]", visible: true, wait: 10).click
end

def select_day_of_birth(day)
  el = find(:xpath, "//td[contains (.,\"#{day}\")]", visible: true, wait: 10)
  el.hover
  el.click
end

def click_btn(label)
  find(:xpath, "//*[contains(text(), '#{label}')]").click
  wait_until_spinner('visible', loader_spinner, 1)
  wait_until_spinner('invisible', loader_spinner, WAIT_TIME)
end

def loader_spinner
  '[data-e2e-selector="spinner"], [class*="appContent"] [class*="overlayContent"] [class*="star"], [data-e2e-selector="video-stream-loading-overlay"], [clip-path*="playingNow"]'
end

def wait_until_spinner(condition, locator, timeout = Capybara.default_max_wait_time)
  # "locator" should be string
  i = 0
  script = "return ('#{locator}').length"
  # script = "return $('#{locator}').length"

  case condition
  when 'visible'
    until page.execute_script(script) > 0
      i += 1
      sleep 0.5
      break if i == timeout
    end
  when 'invisible'
    while page.execute_script(script) > 0
      i += 1
      sleep 0.5
      break if i == timeout
    end
  else
    raise ArgumentError, "message: #{name} is not supported"
  end
end

# def wait_stars_spinner
#   wait_until('Spinner is present') { !element_visible?(loader_spinner) }
#   # element_present?('xpath', loader_spinner) == false
#   # !element_visible?
# end

def close_modal_form
  page.driver.browser.action.send_keys(:escape).perform
end

def drag_and_drop_element(type, element, target)
  if type == 'xpath'
    el1 = page.driver.browser.find_element(xpath: element)
  else
    el1 = page.driver.browser.find_element(css: element)
  end
  if type == 'xpath'
    el2 = page.driver.browser.find_element(xpath: target)
  else
    el2 = page.driver.browser.find_element(css: target)
  end
  sleep 5
  page.driver.browser.action.drag_and_drop(el1, el2).perform
end

def select_dropdown_item(dropdown_locator, option)
  option = page.find(:xpath, "//option[contains (.,\"#{option}\")]", wait: 10).text
  page.select option, :from => dropdown_locator, visible: false
end


######################################################################################################
# Methods for Arcadia
######################################################################################################

def check_home_url(url)
  check_current_url(url)
end

def enter_spinomenal_login(login)
  p "Entering Spinomenal login..."
  el = 'input[name="UserName"]';
  fill_field(el, login)
  p "...OK"
end

def enter_spinomenal_password(password)
  p "Entering Spinomenal password..."
  el = 'input[name="Password"]';
  fill_field(el, password)
  p "...OK"
end

def click_spinomenal_login
  p "Clicking Login button..."
  el = 'button[type="submit"]'
  click_element(el)
  p "...OK"
end

def select_player_from_dropdown(player)
  p "Selecting the player..."
  dropdown = "playerId"
  select_dropdown_item(dropdown, player + " ")
  p "...OK"
end

def hover_select_environment_menu
  p "Clicking Environment menu..."
  el = 'li.dropdown.dropdown-user'
  hover_element(el)
  p "...OK"
end

def select_environment(env)
  p "Selecting environment..."
  el = "//*[contains(text(),'staing-aggregation#{env}')]"
  click_element(el, 'xpath')
  p "...OK"
end

def click_players_dropdown()
  p "Clicking Player dropdown..."
  el = "select#playerId"
  click_element(el)
  p "...OK"
end

def click_launch_game
  p "Launching the game..."
  el = 'button[type="submit"]'
  click_element(el)
  p "...OK"
end

def check_no_error_on_login
  p "Checking that no error..."
  el = 'div[role="alert"]'
  expect(page.has_css?(el, wait: 5)).to eq false
  p "...OK"
end

def check_no_error_on_entering_lobby
  p "Checking that no error on entering lobby..."
  el = 'div[role="alert"]'
  expect(page.has_css?(el, wait: 5)).to eq false
  sleep 1
  p "...OK"
end

def click_play(group)
  p "Clicking Play button..."
  el = "//div/span[text()='#{group}']//..//..//..//..//button[@data-e2e-selector='primary-button']"
  click_element(el, type = 'xpath')
  p "...OK"
end

def whether_buy_panel_is_present
  p "Checking that Buy bar is present..."
  sleep 1 # wait until panel opening
  el = '//*[@data-e2e-selector="buy-snackbar"]'
  make_sure_element_is_present(el)
  p "...OK"
end

def whether_rebuy_panel_is_present
  sleep 0.5 # wait until panel opening
  el = 'div[data-e2e-selector="buy-snackbar"]'
  page.assert_selector(el)
end

def whether_rebuy_panel_is_absent
  sleep 0.5 # wait until panel opening
  el = 'div[data-e2e-selector="buy-snackbar"]'
  page.assert_no_selector(el)
end

def whether_buy_panel_is_absent
  p "Checking that Buy bar is absent"
  sleep 1 # wait until panel hide
  el = '//*[@data-e2e-selector="buy-snackbar"]'
  make_sure_element_is_absent(el)
  p "...OK"
end

def whether_lobby_screen_is_present
  p "Checking Lobby screen..."
  el = '//img[contains(@src, "slotMachine")]'
  page.assert_selector(:xpath, el, wait: 20)
  p "...OK"
end

def close_buy_panel
  el = 'button[data-e2e-selector="close-button"]'
  click_element(el)
end

def check_buy_button_is_not_disabled
  p "Checking that Buy button is not disabled..."
  el = '[data-e2e-selector="buy-button"]:enabled'
  page.assert_selector(:css, el, wait: 7)
  p "...OK"
end

def click_buy_button
  p "Clicking Buy button..."
  el = '[data-e2e-selector="buy-button"]'
  click_element(el)
  sleep 0.5 # waiting panel open
  p "...OK"
end

def click_fire_button
  p "Clicking Fire button..."
  el = '[data-e2e-selector="fire-button"]'
  click_element(el)
  p "...OK"
end

def whether_fire_button_is_present
  p "Checking that Fire button is present..."
  el = '//*[@data-e2e-selector="fire-button"]'
  page.assert_selector(:xpath, el, wait: 3600)
  p "...OK"
end

def whether_fire_button_is_absent
  el = '//*[@data-e2e-selector="fire-button"]'
  make_sure_element_is_absent(el)
end

def whether_queue_button_is_present
  el = '[data-e2e-selector="queue-button"]'
  page.assert_selector(el)
end

def whether_queue_button_is_absent
  el = '[data-e2e-selector="queue-button"]'
  page.assert_no_selector(el)
end

def whether_loading_overlay_is_absent
  el = 'div[data-e2e-selector="loading-overlay"]'
  page.assert_no_selector(el)
  sleep 0.5
end

def whether_fire_button_is_not_disabled
  p "Checking that Fire button is not disabled..."
  el = '//*[@data-e2e-selector="fire-button"][not(@disabled)]'
  page.assert_selector(:xpath, el, wait: 60)
  p "...OK"
end

def whether_stop_button_is_present
  el = "//*[@data-e2e-selector='autoplay-stop-button']"
  make_sure_element_is_present(el)
end

def whether_stop_button_is_absent
  el = "//*[@data-e2e-selector='autoplay-stop-button']"
  make_sure_element_is_absent(el)
end

def hold_fire_button(count)
  sleep 0.5 # for better stability
  for i in 1..count do
    el = '[data-e2e-selector="fire-button"]'
    click_element(el)
    sleep 1.5
    i += 1
  end
  sleep 1
end

def add_stack(stacksToAdd)
  el = '[data-e2e-selector="buy-rounds-increment-button"]'
  for i in 0..stacksToAdd-1 do
    click_element(el)
  end
end

def remove_stack(stacksToRemove)
  el = '[data-e2e-selector="buy-rounds-decrement-button"]'
  for i in 0..stacksToRemove-1 do
    p "Removing stack x" + (i + 1).to_s + "..."
    click_element(el)
    p "...OK"
  end
end

def confirm_buy_stack
  p "Confirming Buy stacks..."
  el = '[data-e2e-selector="buy-confirm-button"]'
  click_element(el)
  sleep 1 # for better stability
  p "...OK"
end

def check_bet(bet)
  currency = EnvConfig.get :currency
  betElement = (find(:xpath, '//div[contains(text(), "Bet:")]')).text
  p betElement
  actualBet = betElement.split('Bet: '+currency)[1].gsub(" ", "").gsub(",", "").to_f
  p 'Bet is ' + actualBet.to_s
  if bet != actualBet
    raise ArgumentError, "Bet amount does not match. The Bet must be #{bet}, but it is #{actualBet}"
  else
    p "Bet is OK"
  end
end

def get_balance_amount
  currency = EnvConfig.get :currency
  el = (find(:xpath, '//div[contains(text(), "Balance:")]')).text
  balance = el.split('Balance: '+currency)[1].gsub(" ", "").gsub(",", "").to_f
  $amount = balance
  p "Started balance = #{$amount}"
end

def check_balance_amount(stacksBought)
  # check balance after buy stuck
  currency = EnvConfig.get :currency
  betElement = (find(:xpath, '//div[contains(text(), "Bet:")]')).text
  bet = betElement.split('Bet: '+currency)[1].gsub(" ", "").gsub(",", "").to_f
  balance = ($amount - bet * stacksBought).round(2)
  el = (find(:xpath, '//div[contains(text(), "Balance:")]')).text
  new_balance = el.split('Balance: '+currency)[1].gsub(" ", "").gsub(",", "").to_f
  p "Balance after buying coins = #{balance}"
  if new_balance != balance
    raise ArgumentError, "Balance amount does not match. The balance must be #{new_balance}, but it is #{balance}"
  else
    p "New balance is OK"
  end
end

def compare_balance_with_previous_balance(value)
  currency = EnvConfig.get :currency
  el = (find(:xpath, '//div[contains(text(), "Balance:")]')).text
  balance = el.split('Balance: '+currency)[1].gsub(" ", "").gsub(",", "").to_f
  p "Started balance = #{balance}"
  if balance == value
    p 'Balance is OK'
  else
    raise ArgumentError, "Balance amount does not match. The balance should be #{balance}"
  end
end

def click_home_button
  el = '[data-e2e-selector="header-go-to-lobby-button"]'
  click_element(el)
end

def confirm_leave_game
  el = '//div[contains(text(),"Confirm")]'
  click_element(el, type = 'xpath')
end

def check_purchase_counter(value)
  # el = "//*[@data-e2e-selector='buy-rounds-counter-value']//*[text()='#{value}']"
  el = "//*[contains(@class,\"rounds\")]//..//*[contains(text(),\"#{value}\")]"
  make_sure_element_is_present(el)
end

def check_coins_counter(value)
  el = "//*[contains(@class, 'coins')]//*[contains(text(), '#{value}')]"
  make_sure_element_is_present(el)
end

def check_stack_counter(value)
  el = "//div[contains(@class, 'rounds')]//..//*[text()='x#{value-1}']"
  make_sure_element_is_present(el)
end

def check_stack_counter_in_queue(value)
  el = "//div[contains(@class, 'rounds')]//..//*[text()='x#{value}']"
  make_sure_element_is_present(el)
end

def click_change_bet
  el = '[data-e2e-selector="change-bet-button"]'
  click_element(el)
end

def whether_change_bet_panel_is_present
  el = '//*[@data-e2e-selector="change-bet-snackbar"]'
  make_sure_element_is_present(el)
end

def whether_change_bet_panel_is_absent
  el = '//*[@data-e2e-selector="change-bet-snackbar"]'
  make_sure_element_is_absent(el)
end

def click_change_bet_via_rebuy_modal
  el = 'button[data-e2e-selector="change-bet-button"] > div > div > div'
  click_element(el)
end

def click_burger_menu
  el = '[data-e2e-selector="header-burger-button"]'
  click_element(el)
end

def check_menu_header(value)
  el = 'div[class*="panelHeader"]'
  page.assert_selector(el, text: value.upcase, visible: true)
end

def whether_menu_is_present(value)
  sleep 0.5 # for better stability
  el = "//div[text()=\"#{value}\"]"
  make_sure_element_is_present(el)
end

def click_back
  el = 'svg[class*="iconArrow"]'
  click_element(el);
end

def click_menu(value)
  el = "//div[text()=\"#{value}\"]"
  click_element(el, type = 'xpath')
end

def click_on_background
  el = '[class*="overlayBackdrop"]'
  click_element(el)
end

def click_voucher
  el = '[data-e2e-selector="voucher-button"]'
  click_element(el)
end

def check_main_screen
  p "Checking Main screen..."
  el = '//*[contains(@class, "headerBackground")]'
  make_sure_element_is_present(el)
  p "...OK"
end

def whether_popup_is_present(value)
  el = "//*[contains(text(), \"#{value}\")]"
  make_sure_element_is_present(el)
  find(:xpath, el).click
end

def whether_autoplay_setup_is_present
  sleep 0.5 # wait until panel opening
  el = '//*[@data-e2e-selector="autoplay-setup-snackbar"]'
  make_sure_element_is_present(el)
end

def whether_autoplay_setup_is_absent
  sleep 0.5 # wait until panel hide
  el = '//*[@data-e2e-selector="autoplay-setup-snackbar"]'
  make_sure_element_is_absent(el)
end

def click_close_button
  el = '[data-e2e-selector="close-button"] > div'
  click_element(el)
  sleep 1 # waiting panel close
end

def click_close_session_result
  p "Closing Game Summary pop up..."
  el = 'button[data-e2e-selector="close-button"] > div'
  page.all(el, wait: 120).last.click()
  sleep 1
  p "...OK"
end

def click_close_autoplay_setup
  el = '(//*[@data-e2e-selector="close-button"])[2]'
  click_element(el, type = 'xpath')
  sleep 1 # waiting panel close
end

def enable_auto_swing_mode
  el = '[data-e2e-selector="autoswing-switch"]'
  area = '//*[@data-e2e-selector="autoswing-switch" and @aria-checked="true"]'
  click_element(el) if element_present?(type = 'xpath', area) == false
end

def check_rail_joystick_active
  el = "//*[@data-e2e-selector='joystick-bar' and @draggable='false']"
  # el = "//*[@alt='Joystick rail']"
  make_sure_element_is_present(el)
end

def check_rail_joystick_disabled
  el1 = "//*[@data-e2e-selector='joystick-bar']"
  el2 = "//*[@data-e2e-selector='joystick-bar' and @draggable='false']"
  make_sure_element_is_present(el1)
  p "joystick ... enabled???"
  make_sure_element_is_absent(el2)
  p "disabled"
end

def click_autoplay
  el = '[data-e2e-selector="autoplay-button"]'
  click_element(el)
end

def click_start_autoplay
  el = '[data-e2e-selector="play-button"]'
  click_element(el)
  sleep 1
end

def click_bet_behind
  el = '[data-e2e-selector="bet-behind-button"]'
  click_element(el)
end

def whether_bet_behind_panel_is_present
  el = '//*[@data-e2e-selector="bet-behind-setup-snackbar"]'
  make_sure_element_is_present(el)
  sleep 1 # for better stability
end

def whether_bet_behind_panel_is_absent
  el = '//*[@data-e2e-selector="bet-behind-setup-snackbar"]'
  make_sure_element_is_absent(el)
end

def delete_bet_behind(number)
  el = '[data-e2e-selector="rounds-decrement-button"]'
  (0..number).each { |i|
    click_element(el)
  }
end

def add_bet_behind
  el = '[data-e2e-selector="rounds-increment-button"]'
  click_element(el)
end

def check_after_stop_counter(value)
  el = "//*[@data-e2e-selector=\"rounds-counter\"]//*[text()=\"#{value}\"]"
  make_sure_element_is_present(el)
end

def check_bet_behind_indicator(value)
  el = "//*[contains(@class,\"betBehindRoundProgressIndicator\")]//*[text()=\"#{value}\"]"
  make_sure_element_is_present(el)
end

def check_jackpot_position(position)
  el = "//*[@data-e2e-selector=\"switch\"][@aria-checked = \"#{position}\"]"
  make_sure_element_is_present(el)
end

def click_jackpot_switcher
  el = '[data-e2e-selector="switch"]'
  click_element(el)
end

def whether_identifying_message_is_present
  el = '//div[text()="Identifying"]'
  make_sure_element_is_present(el)
end

def whether_identifying_message_is_absent
  el = '//div[text()="Identifying"]'
  make_sure_element_is_absent(el)
end

def whether_win_amount_modal_is_present
  el = '//p[contains(., "Session Result")]'
  make_sure_element_is_present(el)
end
