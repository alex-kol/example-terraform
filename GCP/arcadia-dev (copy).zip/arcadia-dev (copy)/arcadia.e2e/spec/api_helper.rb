# frozen_string_literal: true

module ApiHelper
  def register_user_api(data)
    body = {
        'campaignId': data[:campaign_id],
        'email': data[:email],
        'password': data[:password],
        'firstName': data[:first_name],
        'lastName': data[:last_name],
        'country': data[:country],
        'city': data[:city],
        'address': data[:address],
        'currency': data[:currency],
        'phoneNumber': data[:phone_number],
        'policyChecked': data[:policy_checked],
        'registrationCurrency': data[:currency],
        'day-birthDate': data[:day_birth_date],
        'month-birthDate': data[:month_birth_date],
        'year-birthDate': data[:year_birth_date],
        'confirmPassword': data[:password],
        'zipCode': data[:zip_code],
        'houseNumber': data[:house_number],
        'receiveEmail': data[:receive_email],
        'receiveSMS': data[:receive_sms]
    }
    dob = data[:year_birth_date] + '-' + data[:month_birth_date] + '-' + data[:day_birth_date]


    header = {
        authorization: 'Basic ZmlubnBsYXk6cGFzc3dvcmQ=',
        content_type: 'application/x-www-form-urlencoded; charset=UTF-8'
    }
    post data[:url_api] + 'player/registerPlayer', body, header

    expect_status(200)

    expect_json(success: true)

    user_id = json_body[:userId]
    # declare global variable to use it for different tests
    $user_id = user_id

    # login as admin to get "JSESSIONID" for further user update
    header = {
        accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        content_type: 'application/x-www-form-urlencoded'
    }
    body = {
        j_username: data[:j_username],
        j_password: data[:j_password]
    }
    post data[:bo_url] + 'bo/j_spring_security_check', body, header
    bo_cookeis = response.cookies
    jsession_id = bo_cookeis['JSESSIONID']

    expect_status(302)

    # activate user
    header = {
        accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        content_type: 'application/x-www-form-urlencoded',
        cookie: "JSESSIONID=#{jsession_id}"
    }
    body = {
        'user.userId': "#{user_id}",
        'userId': "#{user_id}",
        'paymentEmail.Id': '208',
        'paymentEmail.userId': "#{user_id}",
        'user.nickName': '',
        'user.title': '',
        'user.country': 'UKR',
        'user.registrationCountry': 'UKR',
        'user.agentName': '',
        'user.userName': '',
        'user.firstName': data[:first_name],
        'localPlayerUserGroupIDs': '',
        'user.userStatus': 'active',
        'user.statusComment': '',
        'user.birthDate': dob,
        'user.middleName': '',
        'user.loyaltyTier': 'bronze',
        'user.gender': '',
        'user.lastName': data[:last_name],
        'user.secondLastName': '',
        'addressType': 'localAddress',
        'user.city': data[:city],
        'user.address': 'test',
        'user.district': '',
        'user.state': '',
        'user.residentialCity': '',
        'user.residentialAddress': '',
        'user.birthCountry': '',
        'user.birthState': '',
        'user.zipCode': '1',
        'user.houseNumber': '1',
        'user.address2': '',
        'user.residentialZipCode': '',
        'user.residentialHouseNumber': '',
        'user.birthPlace': '',
        'user.citizenship': '',
        'user.email': data[:email],
        'paymentEmail.email': '',
        'user.phoneNumber': data[:phone_number],
        'user.skypeId': '',
        'user.weChatId': '',
        'user.qqId': '',
        'identificationType': 'passport',
        'user.otherDocumentName': '',
        'user.passportNumber': '',
        'user.passportCountry': '',
        'user.passportMRZLine1': '',
        'user.nationalIdNumber': '',
        'user.nationalIdCardNumber': '',
        'user.nationalIdCardCountry': '',
        'user.addressCardNumber': '',
        'user.driverLicenceNumber': '',
        'user.taxIdentificationNumber': '',
        'user.otherDocumentNumber': '',
        'user.otherDocumentCountry': '',
        'user.passportIssueDate': '',
        'user.passportExpiryDate': '',
        'user.passportMRZLine2': '',
        'user.foreignIdNumber': '',
        'user.nationalIdCardIssueDate': '',
        'user.nationalIdCardExpiryDate': '',
        'user.driverLicenceExpiryDate': '',
        'user.otherDocumentIssueDate': '',
        'user.otherDocumentExpiryDate': '',
        'user.passportIssuedBy': '',
        'user.nationalIdCardIssuedBy': '',
        'user.driverLicenceState': '',
        'user.otherDocumentIssuedBy': '',
        'user.language': 'en',
        'user.policyChecked': 'true',
        'user.timezone': '',
        'user.maidenName': '',
        'user.mothersMaidenName': '',
        'user.lvcNumber': '',
        'user.lvcStatus': '',
        'user.categoryName': '',
        'user.withdrawalCategoryName': 'Inpay',
        'Fixipay': '',
        'user.profession': '',
        'user.activity': ''
    }
    post data[:bo_url] + 'player!updateUserContact.action', body, header

    expect_status(302)
    print('new created user: ' + data[:email])
  end

  def create_chip_detection_msg
    get ARCADIA_ROBOT_URL + "/detection?serial=#{SERIAL}"
    expect_status(200)
    expect_json({"status": "ok"})
  end

  def create_chip_drop_msg(value)   expect_json({
                    status: 'ok',
                    rfid: nil
                })
  end

  def parametrize_mcpd(value)
    get ARCADIA_ROBOT_URL + "/mcpd?serial=#{SERIAL}&mcpd=#{value}"
    expect_status(200)
    expect_json({
                    status: 'ok',
                    mcpd: value.to_i
                })
  end

  def next_push(rfid)
    get ARCADIA_ROBOT_URL + "/nextpush?serial=#{SERIAL}&rfid=#{rfid}"
    expect_status(200)
    expect_json({
                    status: 'ok',
                    rfid: nil
                })
  end

  def fault_report(modul, error)
    get ARCADIA_ROBOT_URL + "/fault?serial=#{SERIAL}&module=#{modul}&error=#{error}"
    expect_status(200)
    expect_json({
                    status: 'ok',
                    mod: modul,
                    err: error
                })
  end

  def crash_robot
    get ARCADIA_ROBOT_URL + "/crash?serial=#{SERIAL}"
    expect_status(200)
    expect_json({status: "ok"})
  end

  # # commented temporarily. it needs to update it when API is implemented
  # def perform_deposit(user_id)
  #   # login as admin to get "JSESSIONID" for further user update
  #   header = {
  #       accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
  #       content_type: 'application/x-www-form-urlencoded'
  #   }
  #   body = {
  #       j_username: j_username,
  #       j_password: j_password
  #   }
  #   post bo_url + 'bo/j_spring_security_check', body, header
  #   bo_cookeis = response.cookies
  #   jsession_id = bo_cookeis['JSESSIONID']
  #   expect_status(302)
  #
  #   deposit_amount = 5
  #   body = {
  #       'userId': "#{user_id}",
  #       'adjustment.direction': 'deposit',
  #       'adjustment.balanceType': 'deposit',
  #       'adjustment.amount': "#{deposit_amount}",
  #       'adjustment.note': 'for+tests'
  #   }
  #   header = {
  #       accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
  #       content_type: 'application/x-www-form-urlencoded',
  #       cookie: "JSESSIONID=#{jsession_id}"
  #   }
  #   post bo_url + "player!adjust?userId=#{user_id}", body, header
  #   expect_status(302)
  # end

end
