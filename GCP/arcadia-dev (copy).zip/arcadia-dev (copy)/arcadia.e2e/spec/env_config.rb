require 'yaml'

module EnvConfig
  @@config = YAML.load_file "#{File.dirname(__FILE__)}/config/#{ENVIRONMENT}.yml"
  #@@config = YAML.safe_load(ERB.new(File.read("spec/config/#{ENVIRONMENT}.yml")).result)
  def self.get(parent, child = nil)
    parent = get_sub_tree @@config, parent
    child.nil? ? parent : get_sub_tree(parent, child)
  end

  def self.get_sub_tree(root, item)
    sub_tree = root[item.to_sym]
    raise "Could not locate '#{item}' in YAML config: '#{root}'" if sub_tree.nil?

    sub_tree
  end
end