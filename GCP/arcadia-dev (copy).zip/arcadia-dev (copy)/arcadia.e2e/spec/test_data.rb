LONG_WAIT_TIME = 60
WAIT_TIME = 10

# alert messages
EMAIL_LOGIN_NOT_FOUND = 'Такой E-mail или логин не найден'
EMAIL_ALREADY_EXISTS = 'This E-mail is already in use'
PASSWORD_IS_INVALID = 'The password is invalid.'
ENTER_CORRECT_EMAIL = 'This E-mail is already in use'
PASSWORD_MUST_BE_NOT_LESS_4_CHARS = 'Required from 4 to 10 letters and numbers'
PASSWORD_REQUIRED = 'The password field is required.'
PASSWORD_SHOULD_CONTAIN_ONLY_LETTERS_TEXT = 'The password may only contain letters and numbers'

# System Params for API request
PROTOCOL = "http://"
PROTOCOL_S = "https://"
LOCALHOST = 'robot-autotests'
PORT = "3001"
ARCADIA_ROBOT_URL = "#{PROTOCOL}" + "#{LOCALHOST}" + ":" + "#{PORT}"
SERIAL = "demo_serial_autotests"

