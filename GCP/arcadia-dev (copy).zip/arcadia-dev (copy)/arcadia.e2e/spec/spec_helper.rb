# select which ENV should be used while running tests
# ENVIRONMENT = (ENV['ENVIRONMENT'] || 'prod').to_sym
# ENVIRONMENT = (ENV['ENVIRONMENT'] || 'stage').to_sym

ENVIRONMENT = ENV.fetch('ENVIRONMENT')
# ENVIRONMENT = 'stage'


# select which MODE should be used while running tests
# MODE = (ENV['MODE'] || 'desktop')
# MODE = (ENV['MODE'] || 'mobile')

# MODE = 'desktop'
MODE = 'mobile'

require 'fileutils'
FileUtils.rm_rf Dir.glob('spec/tmp/*')
# Dir.mkdir('spec/downloads') unless File.directory?('spec/downloads')
raise "Create a configuration file '#{ENVIRONMENT}.yml' under spec/config" unless File.exist? "#{File.dirname(__FILE__)}/config/#{ENVIRONMENT}.yml"

require 'active_support/all'
require 'allure-rspec'
require 'rspec'
require 'rspec/retry'
require 'capybara/rspec'
require 'capybara-screenshot/rspec'
require 'chronic'
require 'faker'
require 'site_prism'
require 'env_config'
require 'webdrivers/chromedriver'
require 'rspec/wait'
require 'rspec/expectations'
require 'airborne'
require 'uri'
require 'net/http'
require 'api_helper'

include ApiHelper
# include RSpec::Matchers
extend RSpec::Matchers


Dir["#{File.dirname(__FILE__)}/pages/**/*.rb"].each { |f| require f }

RSPEC_ROOT = File.dirname __FILE__

RSpec.configure do |config|
  config.include Capybara::DSL
  config.verbose_retry = true
  config.display_try_failure_messages = true
  config.formatter = :documentation
  config.around do |ex|
    ex.run_with_retry retry: 1
  end

  # @@current_scenario = []
  # @@passed_scenarios = []
  # @@failed_scenarios = []
  # @@test_cases_results = {'results' => []}

  config.retry_callback = proc do |_ex|
    Capybara.reset!
  end
  if ENV['DEBUG'] == 'log'
    config.after do
      log_types = page.driver.browser.manage.logs.available_types
      log_types.each do |t|
        puts t.to_s + ': ' + page.driver.browser.manage.logs.get(t).join("\n")
      end
    end
  end
end

Airborne.configure do |config|
  config.verify_ssl = false
end


# For future implementations https://chromedriver.chromium.org/
# Webdrivers::Chromedriver.required_version = '85.0.4183.87'

browser_options = ::Selenium::WebDriver::Chrome::Options.new


win_size = case MODE
           when 'desktop'
             '--window-size=1920,1080'
           when 'mobile'
             # '--window-size=750,1334'
             '--window-size=400,1000'
           else
             raise ArgumentError, "message: #{MODE} is not supported"
           end
browser_options.args << win_size


# browser_options.args << '--window-size=1920,1080'
browser_options.args << '--no-sandbox'
browser_options.args << '--headless'
browser_options.args << '--remote-debugging-port=9222'
browser_options.args << '--disable-gpu'
browser_options.args << '--disable-dev-shm-usage'
browser_options.add_preference(
    :download,
    directory_upgrade: true,
    prompt_for_download: false,
    default_directory: "#{Dir.pwd}/spec/downloads/"
)

Capybara.register_driver :selenium do |app|
  client = Selenium::WebDriver::Remote::Http::Default.new
  client.open_timeout = 120
  Capybara::Selenium::Driver.new(app,
                                 browser: :chrome,
                                 options: browser_options,
                                 http_client: client)
end

Capybara.configure do |config|
  config.exact = true
  config.match = EnvConfig.get :match
  config.run_server = EnvConfig.get :run_server
  config.default_selector = EnvConfig.get :default_selector
  config.default_max_wait_time = EnvConfig.get :wait_time
  config.ignore_hidden_elements = EnvConfig.get :ignore_hidden_elements
end

Allure.configure do |c|
  c.results_directory = 'allure-results'
  c.clean_results_directory = true
end

Capybara::Screenshot.register_driver(:headless_chrome) do |driver, path|
  driver.browser.save_screenshot(path)
end

Capybara::Screenshot.register_filename_prefix_formatter(:rspec) do |example|
  "results/screenshot_#{example.description.tr(' ', '-').gsub(%r{^.*/spec/}, '')}"
end

Capybara::Screenshot.autosave_on_failure = true

# kill processes when manually shutting down RSpec
trap 'INT' do
  Process.exit
end

Capybara.default_driver = EnvConfig.get :default_driver
