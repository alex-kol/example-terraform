class LoginPage < SitePrism::Page

  def open_burger_menu
    el = '//div[contains(@class,"menu-icon")]'
    click_element(el, type = 'xpath')
  end

  def click_login
    el = '//span[contains(.,"Login")]'
    click_element(el, type = 'xpath')
  end

  def fill_email_field(value)
    el = '#login-email'
    fill_field(el, value)
  end

  def fill_password_field(value)
    el = '#login-pass'
    fill_field(el, value)
  end

  def click_login_btn
    el = '(//span[contains(.,"Login")])[2]'
    click_element(el, type = 'xpath')
  end

  def whether_email_alert_is_present
    find_text('//*[@id="login_login"]/parent::*/parent::*/following-sibling::*[@class="ant-form-explain"]', type = 'xpath')
  end

  def whether_password_alert_is_present
    find_text('//*[contains(@id,"password")]/parent::*/parent::*/following-sibling::*[@class="ant-form-explain"]', type = 'xpath')
  end

  def switch_to_signup_page
    click_element('[href="/auth/signup"]')
  end

  def whether_deposit_btn_is_present(value)
    el = '//span[contains(.,"Deposit")]'
    expect(el).to include(value)
  end

  def check_url(url)
    check_current_url(url)
  end

  def whether_check_btn_is_present(btn)
    el = "//span[contains(text(), \"#{btn}\")]"
    make_sure_element_is_present(el)
  end

  def forgot_password
    el = '//div[contains(text(),"Forgot your password?")]'
    click_element(el, type = 'xpath')
  end

  def set_email_for_recover(value)
    el = '(//input[@id="login-email"])[2]'
    fill_field(el, value, type = 'xpath')
  end

  def whether_recover_modal_is_present
    el = '//app-reset-password-popup'
    make_sure_element_is_present(el)
  end

  def set_new_password(value)
    el = '[placeholder="New password"]'
    fill_field(el, value)
  end

  def set_confirm_password(value)
    el = '[placeholder="Confirm password"]'
    fill_field(el, value)
  end

  # PROD
  def click_login_prod
    el = '#login_form #loginButton'
    click_element(el)
  end

  def fill_email_prod(value)
    el = '#loginRegisterPopup_email'
    fill_field(el, value)
  end

  def fill_password_prod(value)
    el = '#loginRegisterPopup_password'
    fill_field(el, value)
  end

  def click_submit_login
    el = '#loginRegisterPopup_loginbutton'
    click_element(el)
  end

  def whether_deposit_btn_is_present_prod(value)
    el = '//a[contains(.,"Deposit")]'
    expect(el).to include(value)
  end

  def forgot_password_prod
    el = '#loginRegisterPopup_forgotpassword'
    click_element(el)
  end

  def fill_email_for_recover_prod(value)
    el = '#forgotpassword_email'
    fill_field(el, value)
  end

  def whether_recover_modal_is_present_prod
    el = '//div[@class="resetPwdSend"]'
    make_sure_element_is_present(el)
  end

  def click_submit_for_recover
    el = '//a[contains(.,"Submit")]'
    click_element(el, type = 'xpath')
  end

  def set_new_password_prod(value)
    el = '#resetPassword_password'
    fill_field(el, value)
  end

  def set_confirm_password_prod(value)
    el = '#resetPassword_confirmPassword'
    fill_field(el, value)
    click_element('#resetPassword_form_saveButton')
  end

  def whether_check_btn_is_present_prod(btn)
    el = "//a[text()='#{btn}']"
    make_sure_element_is_present(el)
  end
end