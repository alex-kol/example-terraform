RSpec.feature 'Arcadia Robots' do
  let(:default_group) {ENV.fetch('DEFAULT_GROUP')}
  let(:home_url) {EnvConfig.get :home_url}
  let (:stacks_default_value) {EnvConfig.get :stacks_default_value }
  let (:login) {ENV.fetch('SPINOMENAL_LOGIN')}
  let (:password) {ENV.fetch('SPINOMENAL_PASSWORD')}
  let (:player_id) {ENV.fetch('USER_ID')}
  let (:spinomenal_env) {ENV.fetch('SPINOMENAL_ENV')}


  before(:each) do
    visit home_url
    enter_spinomenal_login(login)
    enter_spinomenal_password(password)
    click_spinomenal_login
    hover_select_environment_menu
    select_environment(spinomenal_env)
    select_player_from_dropdown(player_id)
    click_launch_game
  end

  after(:each) do

  end

  it '#1 - load scenario' do
      check_no_error_on_login
      whether_lobby_screen_is_present
      click_play(default_group)
      stacks_to_add_remove = 1
      check_main_screen
      check_buy_button_is_not_disabled
      click_buy_button
      whether_buy_panel_is_present
      remove_stack(stacks_to_add_remove)
      confirm_buy_stack
      whether_buy_panel_is_absent
      whether_fire_button_is_present
      whether_fire_button_is_not_disabled
      click_fire_button
      click_close_session_result
  end
  it '#2 - load scenario' do
    check_no_error_on_login
    whether_lobby_screen_is_present
    click_play(default_group)
    stacks_to_add_remove = 1
    check_main_screen
    check_buy_button_is_not_disabled
    click_buy_button
    whether_buy_panel_is_present
    remove_stack(stacks_to_add_remove)
    confirm_buy_stack
    whether_buy_panel_is_absent
    whether_fire_button_is_present
    whether_fire_button_is_not_disabled
    click_fire_button
    click_close_session_result
  end
  it '#3 - load scenario' do
    check_no_error_on_login
    whether_lobby_screen_is_present
    click_play(default_group)
    stacks_to_add_remove = 1
    check_main_screen
    check_buy_button_is_not_disabled
    click_buy_button
    whether_buy_panel_is_present
    remove_stack(stacks_to_add_remove)
    confirm_buy_stack
    whether_buy_panel_is_absent
    whether_fire_button_is_present
    whether_fire_button_is_not_disabled
    click_fire_button
    click_close_session_result
  end
  it '#4 - load scenario' do
    check_no_error_on_login
    whether_lobby_screen_is_present
    click_play(default_group)
    stacks_to_add_remove = 1
    check_main_screen
    check_buy_button_is_not_disabled
    click_buy_button
    whether_buy_panel_is_present
    remove_stack(stacks_to_add_remove)
    confirm_buy_stack
    whether_buy_panel_is_absent
    whether_fire_button_is_present
    whether_fire_button_is_not_disabled
    click_fire_button
    click_close_session_result
  end
  it '#5 - load scenario' do
    check_no_error_on_login
    whether_lobby_screen_is_present
    click_play(default_group)
    stacks_to_add_remove = 1
    check_main_screen
    check_buy_button_is_not_disabled
    click_buy_button
    whether_buy_panel_is_present
    remove_stack(stacks_to_add_remove)
    confirm_buy_stack
    whether_buy_panel_is_absent
    whether_fire_button_is_present
    whether_fire_button_is_not_disabled
    click_fire_button
    click_close_session_result
  end
  it '#6 - load scenario' do
    check_no_error_on_login
    whether_lobby_screen_is_present
    click_play(default_group)
    stacks_to_add_remove = 1
    check_main_screen
    check_buy_button_is_not_disabled
    click_buy_button
    whether_buy_panel_is_present
    remove_stack(stacks_to_add_remove)
    confirm_buy_stack
    whether_buy_panel_is_absent
    whether_fire_button_is_present
    whether_fire_button_is_not_disabled
    click_fire_button
    click_close_session_result
  end
  it '#7 - load scenario' do
    check_no_error_on_login
    whether_lobby_screen_is_present
    click_play(default_group)
    stacks_to_add_remove = 1
    check_main_screen
    check_buy_button_is_not_disabled
    click_buy_button
    whether_buy_panel_is_present
    remove_stack(stacks_to_add_remove)
    confirm_buy_stack
    whether_buy_panel_is_absent
    whether_fire_button_is_present
    whether_fire_button_is_not_disabled
    click_fire_button
    click_close_session_result
  end
  it '#8 - load scenario' do
    check_no_error_on_login
    whether_lobby_screen_is_present
    click_play(default_group)
    stacks_to_add_remove = 1
    check_main_screen
    check_buy_button_is_not_disabled
    click_buy_button
    whether_buy_panel_is_present
    remove_stack(stacks_to_add_remove)
    confirm_buy_stack
    whether_buy_panel_is_absent
    whether_fire_button_is_present
    whether_fire_button_is_not_disabled
    click_fire_button
    click_close_session_result
  end
  it '#9 - load scenario' do
    check_no_error_on_login
    whether_lobby_screen_is_present
    click_play(default_group)
    stacks_to_add_remove = 1
    check_main_screen
    check_buy_button_is_not_disabled
    click_buy_button
    whether_buy_panel_is_present
    remove_stack(stacks_to_add_remove)
    confirm_buy_stack
    whether_buy_panel_is_absent
    whether_fire_button_is_present
    whether_fire_button_is_not_disabled
    click_fire_button
    click_close_session_result
  end
  it '#10 - load scenario' do
    check_no_error_on_login
    whether_lobby_screen_is_present
    click_play(default_group)
    stacks_to_add_remove = 1
    check_main_screen
    check_buy_button_is_not_disabled
    click_buy_button
    whether_buy_panel_is_present
    remove_stack(stacks_to_add_remove)
    confirm_buy_stack
    whether_buy_panel_is_absent
    whether_fire_button_is_present
    whether_fire_button_is_not_disabled
    click_fire_button
    click_close_session_result
  end
end