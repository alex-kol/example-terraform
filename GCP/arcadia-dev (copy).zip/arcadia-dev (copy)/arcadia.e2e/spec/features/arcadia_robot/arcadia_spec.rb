RSpec.feature 'Arcadia Robots' do
  let(:arcadia_url) { EnvConfig.get :arcadia_url }
  let(:bet) {EnvConfig.get :bet}
  let(:currency) {EnvConfig.get :currency}
  let(:default_group) {EnvConfig.get :default_group}
  let(:additional_group) {EnvConfig.get :additional_group}
  let(:home_url) {EnvConfig.get :home_url}
  let(:bye_popup) {EnvConfig.get :bye_popup}
  let(:user_token) {EnvConfig.get :user_token}
  let(:user_token_bb) {EnvConfig.get :user_token_bb}
  let(:game_id) {EnvConfig.get :game_id}
  let(:launch_url) {arcadia_url + user_token + game_id + 'homeUrl=' + home_url}
  let(:launch_url_bb) {arcadia_url + user_token_bb + game_id + 'homeUrl=' + home_url}
  let (:stacks_default_value) {EnvConfig.get :stacks_default_value}
  stacks_to_add_remove = 2

  before(:each) do
    # sleep 25
    visit launch_url
    sleep 5 # for better stability
    visit launch_url
    whether_lobby_screen_is_present
    click_play(default_group)
  end

  after(:each) do

  end

  it '#1 - highway - logon, buy stacks, engage, play stacks, quit' do
    stacks_to_add_remove = 2
    check_main_screen
    click_buy_button
    whether_buy_panel_is_present
    get_balance_amount
    check_purchase_counter(stacks_default_value)
    remove_stack(stacks_to_add_remove)
    confirm_buy_stack
    check_stack_counter(stacks_default_value-stacks_to_add_remove)
    whether_buy_panel_is_absent
    whether_fire_button_is_present
    whether_fire_button_is_not_disabled
    # check_coins_counter('20') # coins counter is not displayed
    check_balance_amount(1)
    click_fire_button
    # check_coins_counter('19') # coins counter is not displayed
    hold_fire_button(9)
    whether_loading_overlay_is_absent
    close_buy_panel
    # wait until coins counter show 0
    click_home_button
    confirm_leave_game
    whether_popup_is_present(bye_popup)
    check_current_url(home_url)
  end

  it '#2 - observe -> quit' do
    check_main_screen
    click_home_button
    confirm_leave_game
    whether_popup_is_present(bye_popup)
    check_current_url(home_url)
  end

  it '#3 - observer -> buy 2 -> quit' do
    stacks_to_add_remove = 1;
    check_main_screen
    click_buy_button
    get_balance_amount
    remove_stack(stacks_to_add_remove)
    check_purchase_counter((stacks_default_value-stacks_to_add_remove).to_s)
    confirm_buy_stack
    whether_buy_panel_is_absent
    # check_coins_counter('20') # coins counter is not displayed
    check_stack_counter(stacks_default_value-stacks_to_add_remove)
    whether_fire_button_is_present
    whether_fire_button_is_not_disabled
    check_balance_amount(1)
    click_home_button
    confirm_leave_game
    whether_popup_is_present(bye_popup)
    check_current_url(home_url)
    sleep 20
  end

  xit '#4 - observer -> set auto -> quit' do
    check_main_screen
    click_buy_button
    whether_buy_panel_is_present
    click_setup_autoplay
    whether_autoplay_setup_is_present
    click_close_autoplay_setup
    whether_autoplay_setup_is_absent
    click_close_button
    whether_buy_panel_is_absent
    click_home_button
    confirm_leave_game
    whether_popup_is_present(bye_popup)
    check_current_url(home_url)
  end

  it '#5 - observer -> buy 3 -> cancel -> buy 3 -> cancel ...' do
    stack_to_add_remove = 1
    check_main_screen
    get_balance_amount
    click_buy_button
    whether_buy_panel_is_present
    check_purchase_counter(stacks_default_value.to_s)
    click_close_button
    whether_buy_panel_is_absent
    check_balance_amount(0)

    # Repeat scenarios num times
    n = 1
    while n < 5 do
      # get_balance_amount
      click_buy_button
      whether_buy_panel_is_present
      add_stack(stack_to_add_remove)
      check_purchase_counter((stacks_default_value+stack_to_add_remove).to_s)
      click_close_button
      whether_buy_panel_is_absent
      check_balance_amount(0)
      n += 1
      p n
      sleep 0.5
    end
    click_home_button
    confirm_leave_game
    whether_popup_is_present(bye_popup)
    check_current_url(home_url)
  end

  xit '#6 - observer -> set auto -> cancel -> set auto -> cancel  ...' do
    check_main_screen
    click_buy_button
    whether_buy_panel_is_present
    click_setup_autoplay
    whether_autoplay_setup_is_present
    click_close_autoplay_setup
    whether_autoplay_setup_is_absent

    # Repeat scenarios num times
    n = 1
    while n < 5 do
      # get_balance_amount
      whether_buy_panel_is_present
      click_setup_autoplay
      whether_autoplay_setup_is_present
      click_close_autoplay_setup
      whether_autoplay_setup_is_absent
      n += 1
      sleep 0.5
    end
    close_buy_panel
    whether_buy_panel_is_absent
    click_home_button
    confirm_leave_game
    whether_popup_is_present(bye_popup)
    check_current_url(home_url)
    sleep 5
  end

  it '#7 - observer -> buy 2  -> set auto -> play to limit -> buy 2 -> set auto -> play to limit -> quit' do
    stack_to_add_remove = 1
    check_main_screen
    get_balance_amount
    click_buy_button
    whether_buy_panel_is_present
    remove_stack(stack_to_add_remove)
    check_purchase_counter((stacks_default_value-stack_to_add_remove).to_s)
    confirm_buy_stack
    whether_buy_panel_is_absent
    # check_coins_counter('10') # coins counter is not displayed
    check_balance_amount(1)
    whether_fire_button_is_present
    click_autoplay
    whether_autoplay_setup_is_present
    enable_auto_swing_mode # auto swing is on
    click_start_autoplay
    whether_autoplay_setup_is_absent
    sleep 1 # for better stability
    whether_stop_button_is_present
    check_rail_joystick_disabled

    sleep 15 # wait until autoplay is ended
    whether_stop_button_is_absent
    whether_rebuy_panel_is_present
    check_purchase_counter((stacks_default_value-stack_to_add_remove).to_s)
    confirm_buy_stack

    click_autoplay
    click_start_autoplay
    whether_autoplay_setup_is_absent
    sleep 1 # for better stability
    whether_stop_button_is_present
    check_rail_joystick_disabled
    # wait until coins counter show 0
    sleep 10 # wait until autoplay is ended
    whether_stop_button_is_absent
    whether_rebuy_panel_is_present
    close_buy_panel
    whether_rebuy_panel_is_absent

    click_home_button
    confirm_leave_game
    whether_popup_is_present(bye_popup)
    check_current_url(home_url)
  end

  it '#8 - observer -> buy 2 -> play 2 -> buy 2 -> set auto -> play to limit -> quit' do
    stack_to_add_remove = 1
    check_main_screen
    click_buy_button
    whether_buy_panel_is_present
    get_balance_amount
    remove_stack(stack_to_add_remove)
    check_purchase_counter((stacks_default_value-stack_to_add_remove).to_s)
    confirm_buy_stack
    whether_buy_panel_is_absent
    whether_fire_button_is_present
    whether_fire_button_is_not_disabled
    # check_coins_counter('20') # coins counter is not displayed
    check_balance_amount(1)
    click_fire_button
    # check_coins_counter('19') # coins counter is not displayed
    hold_fire_button(9)
    sleep 1 # for better stability
    hold_fire_button(10)
    sleep 5
    # wait until coins counter show 0
    whether_fire_button_is_absent
    whether_buy_panel_is_present
    check_purchase_counter((stacks_default_value-stack_to_add_remove).to_s)
    confirm_buy_stack

    click_autoplay
    click_start_autoplay
    whether_autoplay_setup_is_absent
    sleep 1 # for better stability
    whether_stop_button_is_present
    check_rail_joystick_disabled
    # wait until coins counter show 0
    sleep 10 # wait until autoplay is ended
    whether_stop_button_is_absent
    whether_buy_panel_is_present
    close_buy_panel
    whether_rebuy_panel_is_absent

    click_home_button
    confirm_leave_game
    whether_popup_is_present(bye_popup)
    check_current_url(home_url)
  end

  it '#9 - observer -> change bet -> observer -> quit' do
    check_main_screen
    get_balance_amount
    check_bet(bet)
    click_buy_button
    whether_buy_panel_is_present
    click_change_bet
    click_play(additional_group)
    check_main_screen
    check_bet(2 * bet)
    compare_balance_with_previous_balance($amount)

    click_home_button
    confirm_leave_game
    whether_popup_is_present(bye_popup)
    check_current_url(home_url)
  end

  it '#10 - observer -> change bet -> buy 2 -> play 2 -> change bet -> quit' do
    stack_to_add_remove = 1
    check_main_screen
    get_balance_amount
    check_bet(bet)
    click_buy_button
    whether_buy_panel_is_present
    click_change_bet
    click_play(additional_group)
    check_main_screen
    get_balance_amount
    check_bet(2 * bet)
    click_buy_button
    whether_buy_panel_is_present
    remove_stack(stack_to_add_remove)
    check_purchase_counter((stacks_default_value-stack_to_add_remove).to_s)
    confirm_buy_stack
    whether_buy_panel_is_absent
    whether_fire_button_is_present
    whether_fire_button_is_not_disabled
    check_balance_amount(1)
    hold_fire_button(10)
    sleep(1)
    whether_fire_button_is_not_disabled
    hold_fire_button(10)
    whether_buy_panel_is_present

    click_change_bet
    click_play(default_group)
    check_main_screen
    check_bet(bet)

    click_home_button
    confirm_leave_game
    whether_popup_is_present(bye_popup)
    check_current_url(home_url)
  end

  it '#11 - observer -> buy 1 -> play 1 -> change bet on rebuy -> quit' do
    stacks_to_add_remove = 2
    check_main_screen
    get_balance_amount
    check_bet(bet)
    click_buy_button
    whether_buy_panel_is_present
    check_purchase_counter(stacks_default_value)
    remove_stack(stacks_to_add_remove)
    confirm_buy_stack
    whether_buy_panel_is_absent
    whether_fire_button_is_present
    whether_fire_button_is_not_disabled
    check_balance_amount(1)
    click_fire_button
    # check_coins_counter('9') # coins counter is not displayed
    hold_fire_button(9)
    sleep 8
    whether_buy_panel_is_present


    click_change_bet_via_rebuy_modal
    click_play(additional_group)
    check_main_screen
    check_bet(2 * bet)

    # check_balance_amount('11')

    click_home_button
    confirm_leave_game
    whether_popup_is_present(bye_popup)
    check_current_url(home_url)
    sleep 10
  end

  it '#12 - p1 p2 observer -> p1 buy 1 -> p2 set BB ->  p2 cancel BB -> …' do
    stacks_to_add_remove = 1;
    check_main_screen
    click_buy_button
    whether_buy_panel_is_present
    check_purchase_counter(stacks_default_value)
    remove_stack(stacks_to_add_remove)
    confirm_buy_stack
    whether_buy_panel_is_absent
    whether_fire_button_is_present
    whether_fire_button_is_not_disabled
    # check_coins_counter('10') # coins counter is not displayed
    check_stack_counter(stacks_default_value-stacks_to_add_remove)
    click_fire_button

    # Open new tab for BB player
    open_new_browser_tab
    switch_to_new_tab
    visit launch_url_bb
    sleep 2 # for better stability
    whether_lobby_screen_is_present
    click_play(default_group)

    stacks_to_add_remove = 2
    click_buy_button
    whether_buy_panel_is_present
    check_purchase_counter(stacks_default_value)
    remove_stack(stacks_to_add_remove)
    check_purchase_counter(stacks_default_value - stacks_to_add_remove)
    confirm_buy_stack
    whether_buy_panel_is_absent
    # check_coins_counter('0') # coins counter is not displayed
    check_stack_counter_in_queue(stacks_default_value - stacks_to_add_remove)

    click_bet_behind
    whether_bet_behind_panel_is_present
    click_close_button
    whether_bet_behind_panel_is_absent

    # Switch to first tab
    switch_back_to_previous_tab
    click_fire_button

    # Switch to second tab
    switch_to_new_tab
    click_bet_behind
    whether_bet_behind_panel_is_present
    click_close_button
    whether_bet_behind_panel_is_absent

    # Switch to first tab
    switch_back_to_previous_tab
    click_fire_button

    # Switch to second tab
    switch_to_new_tab
    click_bet_behind
    whether_bet_behind_panel_is_present
    click_close_button
    whether_bet_behind_panel_is_absent

    click_home_button
    confirm_leave_game
    whether_popup_is_present(bye_popup)
    check_current_url(home_url)

    # Switch to first tab
    switch_back_to_previous_tab
    hold_fire_button(7)

    click_home_button
    confirm_leave_game
    whether_popup_is_present(bye_popup)
    check_current_url(home_url)
  end

  it '#13 - p1 p2 observer -> p2 bb, p1 active -> p2 in queue -> p2 active -> quit' do
    # player 1:
    check_main_screen

    # player 2:
    open_new_browser_tab
    switch_to_new_tab
    visit launch_url_bb
    sleep 2 # for better stability
    whether_lobby_screen_is_present
    click_play(default_group)

    click_bet_behind
    whether_bet_behind_panel_is_present
    delete_bet_behind(2)
    check_after_stop_counter(1)
    click_start_autoplay
    whether_bet_behind_panel_is_absent

    # player 1:
    switch_back_to_previous_tab
    get_balance_amount
    click_buy_button
    whether_buy_panel_is_present
    remove_stack(2)
    check_purchase_counter('1')
    confirm_buy_stack
    whether_buy_panel_is_absent
    # check_coins_counter('10') # coins counter is not displayed
    check_stack_counter(1)
    whether_fire_button_is_not_disabled
    click_fire_button

    # player 2:
    switch_to_new_tab
    click_buy_button
    whether_buy_panel_is_present
    remove_stack(2)
    check_purchase_counter('1')
    confirm_buy_stack
    whether_buy_panel_is_absent
    check_stack_counter_in_queue(1)

    # player 1:
    switch_back_to_previous_tab
    click_fire_button
    hold_fire_button(8)
    whether_fire_button_is_absent
    whether_rebuy_panel_is_present

    # player 2:
    switch_to_new_tab
    sleep 20 # to wait for rebuy timeout for player 1
    whether_queue_button_is_present
    whether_queue_button_is_absent
    whether_fire_button_is_present
    hold_fire_button(10)
    sleep 5 # check for round end
    whether_fire_button_is_absent
    whether_rebuy_panel_is_present
    sleep 35
    click_close_session_result # close win amount modal
    whether_lobby_screen_is_present
  end

  it '#14 - observer -> buy 1 -> play 3 coins -> time out -> forced autoplay -> close session result' do
    check_main_screen
    get_balance_amount
    click_buy_button
    whether_buy_panel_is_present
    # add_stack
    remove_stack(2)
    check_purchase_counter('1')
    confirm_buy_stack
    whether_buy_panel_is_absent
    whether_fire_button_is_present
    whether_fire_button_is_not_disabled
    # check_coins_counter('10') # coins counter is not displayed
    check_balance_amount(1)
    click_fire_button
    # check_coins_counter('9') # coins counter is not displayed
    click_fire_button
    sleep 0.5 # for better stability
    click_fire_button
    sleep 0.5 # for better stability
    click_fire_button
    sleep 0.5 # for better stability
    # check_coins_counter('6') # coins counter is not displayed
    # hold_fire_button(6)
    # wait until coins counter show 0
    sleep 35
    click_close_session_result # close win amount modal
    whether_lobby_screen_is_present
  end

  it '#15 - observer -> buy 2 -> play 1 -> set auto -> play to limit -> rebuy 1 -> play 1 (script 15)' do
    check_main_screen
    get_balance_amount
    click_buy_button
    whether_buy_panel_is_present
    add_stack(1)
    check_purchase_counter('4')
    confirm_buy_stack
    whether_buy_panel_is_absent
    # check_coins_counter('10') # coins counter is not displayed
    check_balance_amount(1)
    hold_fire_button(10)
    whether_loading_overlay_is_absent
    # check_coins_counter('10') # coins counter is not displayed
    check_stack_counter(3)
    click_autoplay
    whether_autoplay_setup_is_present
    sleep 1 # for better stability
    click_start_autoplay
    whether_stop_button_is_present
    check_rail_joystick_disabled

    sleep 15 # wait until autoplay is ended
    whether_stop_button_is_absent
    whether_rebuy_panel_is_present
    check_purchase_counter('4')
    remove_stack(3)
    confirm_buy_stack
    hold_fire_button(10)
    whether_loading_overlay_is_absent
    whether_fire_button_is_absent
    whether_rebuy_panel_is_present
    close_buy_panel
    whether_rebuy_panel_is_absent

    click_home_button
    confirm_leave_game
    whether_popup_is_present(bye_popup)
    check_current_url(home_url)
  end

  it '#16 - observer -> check menu' do
    check_main_screen

    click_burger_menu
    whether_menu_is_present('Settings')
    whether_menu_is_present('Game Rules')
    whether_menu_is_present('Tutorial')
    whether_menu_is_present('Pay Table')
    whether_menu_is_present('Go to the Lobby')
    # click_on_background
    # click_burger_menu
    click_menu('Settings')
    check_menu_header('Settings')
    click_back
    click_menu('Game Rules')
    click_close_button
    click_burger_menu
    click_menu('Tutorial')
    click_close_button
    click_burger_menu
    click_menu('Pay Table')
    check_menu_header('Pay Table')
    click_back
    click_menu('Go to the Lobby')
    confirm_leave_game
    whether_popup_is_present(bye_popup)
    check_current_url(home_url)
  end

  xit 'script 17' do
    check_main_screen
    get_balance_amount
    click_buy_button
    whether_buy_panel_is_present
    confirm_buy_stack
    whether_buy_panel_is_absent
    check_balance_amount(1)
    # check_coins_counter('20') # coins counter is not displayed
    hold_fire_button(3)
    create_chip_detection_msg
    create_chip_drop_msg('drop')
    puts 'API request done'

    # Check if the identifying message appears
    whether_identifying_message_is_present
    sleep 6 # wait 6 sec
    # Check if the identifying message disappears
    whether_identifying_message_is_absent
    # Check if the win message appears
    # Remember win amount
    # Check how the win message disappears
    # Check the the total win amount

    hold_fire_button(7)
    whether_rebuy_panel_is_present
    click_close_button # close rebuy panel
    sleep 20
    whether_win_amount_modal_is_present # check win amount modal
    click_close_session_result # close win amount modal
    whether_lobby_screen_is_present
  end
end
