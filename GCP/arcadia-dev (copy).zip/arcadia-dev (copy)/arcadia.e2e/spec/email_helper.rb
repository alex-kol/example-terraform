require 'net/imap'
require 'mail'
require 'openssl'

def unique_email(value)
  "#{(EnvConfig.get :email).split('@').first}+#{value}#{random_string}@#{(EnvConfig.get :email).split('@').last}"
end

def delete_all_incoming_emails(email, password)
  imap = Net::IMAP.new('imap.googlemail.com', 993, true)
  imap.login(email, password)
  imap.select('INBOX')
  bad_messages = imap.search(['TO', email])
  puts "#{bad_messages.count} messages will be deleted"
  bad_messages.each do |message_id|
    imap.copy(message_id, '[Gmail]/Trash')
    imap.store(message_id, '+FLAGS', [:Deleted])
  end
  imap.expunge
  imap.logout
  imap.disconnect
end

def grab_reset_password(email, password)
  sleep 5 # for better stability
  subject = 'Reset your password'
  reset_password_url = nil
  imap = Net::IMAP.new('imap.googlemail.com', 993, true)
  imap.login(email, password)
  1000.times do
    break unless reset_password_url.nil?
    imap.select('INBOX')
    imap.search(['SUBJECT', subject, 'TO', email]).each do |message_id|
      msg = imap.fetch(message_id, 'RFC822')[0].attr['RFC822']
      mail = Mail.read_from_string msg
      code = mail.body.decoded.force_encoding('UTF-8').split('activationCode=3D')[1].split('amp')[0].gsub("=\n", "")
      reset_password_url = 'https://www.url.xyz/reset-password?activationCode=' + code + 'i=5'
      if !reset_password_url.empty? # check whether email has reset password. If "NO", exception raises.
        print('reset_password_url') # for DEBUG
        break
      else
        raise ArgumentError, "Email does not contain the reset password"
      end
    end
  end
  imap.logout
  imap.disconnect
  reset_password_url
end

def grab_reset_password_prod(email, password)
  sleep 5 # for better stability
  subject = 'Reset your password'
  reset_password_url = nil
  imap = Net::IMAP.new('imap.googlemail.com', 993, true)
  imap.login(email, password)
  1000.times do
    break unless reset_password_url.nil?
    imap.select('INBOX')
    imap.search(['SUBJECT', subject, 'TO', email]).each do |message_id|
      msg = imap.fetch(message_id, 'RFC822')[0].attr['RFC822']
      mail = Mail.read_from_string msg
      code = mail.body.decoded.force_encoding('UTF-8').split('Code=3D')[1].split('" target=3D')[0].gsub("=\n", "")
      reset_password_url = 'https://www.url.com/en/reset-password?activationCode=' + code
      if !reset_password_url.empty? # check whether email has reset password. If "NO", exception raises.
        print('reset_password_url') # for DEBUG
        break
      else
        raise ArgumentError, "Email does not contain the reset password"
      end
    end
  end
  imap.logout
  imap.disconnect
  reset_password_url
end